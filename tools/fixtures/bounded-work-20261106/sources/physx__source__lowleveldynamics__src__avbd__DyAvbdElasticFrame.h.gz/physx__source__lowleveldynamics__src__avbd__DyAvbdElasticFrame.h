// Copyright (c) 2026 NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: BSD-3-Clause
#ifndef DY_AVBD_ELASTIC_FRAME_H
#define DY_AVBD_ELASTIC_FRAME_H
#include "PxConstraintDesc.h"
#include "DyAvbdElasticFrameCurvature.h"
#include <cfloat>

namespace physx { namespace Dy {
struct AvbdElasticFrameMaterial
{
    PxConstraintElasticFrameData authored;
    double dampingOverDt[6],initial[FINITE_JOINT_ROWS];
};
struct AvbdElasticFrameEvaluation
{
    double energy,gradient[12],root[9][12],energyPairs[FINITE_JOINT_ROWS][2];
    bool valid;
};
struct AvbdElasticFrameArgs
{
    const AvbdElasticFrameMaterial* material;
    const PxTransform* poses;
    bool derivatives;
    AvbdElasticFrameEvaluation* evaluation;
    bool curvature=true;
};
inline PxTransformT<double> avbdElasticFrameDouble(const PxTransform& p)
{
    return PxTransformT<double>(PxVec3d(p.p.x,p.p.y,p.p.z),
        PxQuatT<double>(p.q.x,p.q.y,p.q.z,p.q.w).getNormalized());
}
inline void avbdElasticFrameSections(const PxConstraintElasticFrameData& data,
    const PxTransform* poses,PxTransformT<double>* bodies,PxTransformT<double>* frames)
{
    for(PxU32 i=0;i<2;++i)
    {
        bodies[i]=avbdElasticFrameDouble(poses[i]);
        frames[i]=bodies[i]*avbdElasticFrameDouble(data.frames[i]);
    }
}
inline bool avbdPrepareElasticFrame(AvbdElasticFrameMaterial& m,
    const PxConstraintElasticFrameData& authored,const PxTransform* poses,double h)
{
    if(!(h>0)) return false;
    for(PxU32 i=0;i<2;++i) if(!authored.frames[i].isSane()) return false;
    for(PxU32 i=0;i<6;++i)
        if(!PxIsFinite(authored.stiffness[i]) || authored.stiffness[i]<0 ||
           !PxIsFinite(authored.damping[i]) || authored.damping[i]<0) return false;
    m.authored=authored;
    PxTransformT<double> bodies[2],frames[2];avbdElasticFrameSections(authored,poses,bodies,frames);
    const auto c=finiteJointCoordinates(frames[0],frames[1],bodies[0].p,bodies[1].p);
    for(PxU32 i=0;i<6;++i) m.dampingOverDt[i]=double(authored.damping[i])/h;
    for(PxU32 r=0;r<FINITE_JOINT_ROWS;++r) m.initial[r]=c.value[r];
    return true;
}
// Symmetric Jacobi eigensolve in derivative space, not a physical solver
// block. Pair-scaled tests preserve weak rotational modes beside stiff
// translations; no global eigenvalue/velocity floor is introduced.
inline bool avbdElasticFramePositiveRoot(double (&H)[81],double (&root)[9][12])
{
    double Q[9][9]={};for(PxU32 i=0;i<9;++i) Q[i][i]=1;
    bool converged=false;
    for(PxU32 sweep=0;sweep<64 && !converged;++sweep)
    {
        converged=true;
        for(PxU32 p=0;p<9;++p) for(PxU32 q=p+1;q<9;++q)
        {
            const double off=H[9*p+q],a=H[9*p+p],b=H[9*q+q];
            if(PxAbs(off)<=16*DBL_EPSILON*std::sqrt(PxAbs(a)*PxAbs(b))) continue;
            converged=false;
            const double tau=(b-a)/(2*off);
            const double t=std::copysign(1.0,tau)/(PxAbs(tau)+std::hypot(1.0,tau));
            const double c=1/std::sqrt(1+t*t),s=t*c;
            H[9*p+p]=a-t*off;H[9*q+q]=b+t*off;H[9*p+q]=H[9*q+p]=0;
            for(PxU32 k=0;k<9;++k)
            {
                if(k!=p && k!=q)
                {
                    const double x=H[9*k+p],y=H[9*k+q];
                    H[9*k+p]=H[9*p+k]=c*x-s*y;H[9*k+q]=H[9*q+k]=s*x+c*y;
                }
                const double x=Q[k][p],y=Q[k][q];Q[k][p]=c*x-s*y;Q[k][q]=s*x+c*y;
            }
        }
    }
    if(!converged) return false;
    for(PxU32 r=0;r<9;++r)
    {
        const double scale=std::sqrt(PxMax(0.0,H[9*r+r]));
        for(PxU32 j=0;j<3;++j)
        {
            root[r][j]=scale*Q[j][r];root[r][6+j]=-root[r][j];
            root[r][3+j]=scale*Q[3+j][r];root[r][9+j]=scale*Q[6+j][r];
        }
    }
    return true;
}
inline AvbdElasticFrameEvaluation avbdEvaluateElasticFrame(
    const AvbdElasticFrameMaterial& m,const PxTransform* poses,bool derivatives,bool curvature=true)
{
    AvbdElasticFrameEvaluation result={};
    PxTransformT<double> bodies[2],frames[2];avbdElasticFrameSections(m.authored,poses,bodies,frames);
    const auto c=finiteJointCoordinates(frames[0],frames[1],bodies[0].p,bodies[1].p);
    double weight[FINITE_JOINT_ROWS],bias[FINITE_JOINT_ROWS];
    for(PxU32 r=0;r<FINITE_JOINT_ROWS;++r)
    {
        const PxU32 axis=finiteJointDriveIndex(r);
        const double k=m.authored.stiffness[axis],dh=m.dampingOverDt[axis],C=c.value[r],delta=C-m.initial[r];
        const double force=k*C+dh*delta;weight[r]=k+dh;bias[r]=dh*m.initial[r];
        result.energyPairs[r][0]=C;result.energyPairs[r][1]=force;
        result.energy+=.5*(k*C*C+dh*delta*delta);
        if(derivatives) for(PxU32 j=0;j<3;++j)
        {
            result.gradient[j]+=force*c.linear[r][j];result.gradient[6+j]-=force*c.linear[r][j];
            result.gradient[3+j]+=force*c.angularA[r][j];result.gradient[9+j]-=force*c.angularB[r][j];
        }
    }
    result.valid=PxIsFinite(result.energy);
    if(derivatives)
    {
        if(curvature)
        {
            double H[81];finiteJointMaterialHessian(frames[0],frames[1],bodies[0].p,bodies[1].p,weight,bias,H);
            result.valid &= avbdElasticFramePositiveRoot(H,result.root);
        }
        for(PxU32 i=0;i<12;++i) result.valid &= PxIsFinite(result.gradient[i]);
        for(PxU32 r=0;r<9;++r) for(PxU32 j=0;j<12;++j) result.valid &= PxIsFinite(result.root[r][j]);
    }
    return result;
}
} }
#endif
