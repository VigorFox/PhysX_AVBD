"""Publish the verified baseline products, preserving every overwritten byte."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

root = Path(__file__).resolve().parents[3]
out = Path(__file__).resolve().parent
source = out / 'sdk/bin/win.x86_64.vc143.md/checked'
target = root / 'physx/bin/win.x86_64.vc143.md/checked'
assert source.resolve().is_relative_to(root.resolve())
assert target.resolve().is_relative_to(root.resolve())
assert source.resolve() != target.resolve()
target.mkdir(parents=True, exist_ok=True)

prior = json.loads((out / 'validation/summary.json').read_text())
retry = json.loads((out / 'validation-retry/summary.json').read_text())
assert retry['passed'] and prior['identityStable']
results = {r['name']: r for r in prior['results']}
results.update({r['name']: r for r in retry['results']})
assert len(results) == 43 and all(r['passed'] for r in results.values())
assert all(r['passed'] for r in json.loads((out / 'budget-audit/summary.json').read_text()))
for name in ('surface-scaling', 'volume-scaling'):
    assert json.loads((out / name / 'report.json').read_text())['sceneQuality'] == 'PASS'
for p, digest in retry['fingerprints'].items():
    assert hashlib.sha256((root / p).read_bytes()).hexdigest() == digest, p

copies = [(p, target / p.name) for p in source.iterdir() if p.is_file()]
copies.append((source / 'avbd_smoke.exe', root / 'tools/avbd_smoke.exe'))
backup = out / 'previous-default-products.zip'
assert not backup.exists()
records = []
with zipfile.ZipFile(backup, 'w', zipfile.ZIP_DEFLATED, compresslevel=3) as z:
    for src, dst in copies:
        item = dict(source=str(src.relative_to(root)), target=str(dst.relative_to(root)),
                    newSha256=hashlib.sha256(src.read_bytes()).hexdigest(), existed=dst.exists())
        if dst.exists():
            data = dst.read_bytes()
            item['previousSha256'] = hashlib.sha256(data).hexdigest()
            z.writestr(dst.relative_to(root).as_posix(), data)
        records.append(item)
with zipfile.ZipFile(backup) as z:
    assert z.testzip() is None
    for item in records:
        if item['existed']:
            assert hashlib.sha256(z.read(Path(item['target']).as_posix())).hexdigest() == item['previousSha256']
for (src, dst), item in zip(copies, records):
    shutil.copy2(src, dst)
    assert hashlib.sha256(dst.read_bytes()).hexdigest() == item['newSha256']
(out / 'publication.json').write_text(json.dumps(dict(
    baseline='f9abbe0cd869136d20cba6462551bbb141a75cd0',
    backup=str(backup.relative_to(root)), backupSha256=hashlib.sha256(backup.read_bytes()).hexdigest(),
    verified=True, products=records), indent=2) + '\n')
print('Published verified baseline products:', len(records))
