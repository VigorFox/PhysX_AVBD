// Shared public-SDK high-valence material asset; no solver implementation.
#ifndef AVBD_NODAL_STAR_ASSET_H
#define AVBD_NODAL_STAR_ASSET_H
static bool createStar(PxPhysics& physics,PxScene& scene,Soft& soft,PxU32& center,bool highValence=true)
{
    PxArray<PxVec3> surface,points;PxArray<PxU32> triangles,tets,map;
    VolumeAvbdSnippet::createSubdividedCubeSurface(surface,triangles,1,8);points.pushBack(PxVec3(0));
    for(const auto& p:surface)
    {
        PxU32 found=1;while(found<points.size() && points[found]!=p)++found;
        if(found==points.size())points.pushBack(p);map.pushBack(found);
    }
    for(PxU32 t=0;t<triangles.size();t+=3)
    {
        PxU32 ids[4]={0,map[triangles[t]],map[triangles[t+1]],map[triangles[t+2]]};
        if(PxMat33(points[ids[1]],points[ids[2]],points[ids[3]]).getDeterminant()<0)PxSwap(ids[1],ids[2]);
        for(auto id:ids)tets.pushBack(id);
    }
    if(!highValence)
    {
        // Shape-regular tetrahedra for realtime quality; the authored star
        // above is an explicit high-valence/capacity experiment.
        points.clear();tets.clear();
        for(PxU32 z=0;z<5;++z)for(PxU32 y=0;y<5;++y)for(PxU32 x=0;x<5;++x)
            points.pushBack(PxVec3(.25f*x-.5f,.25f*y-.5f,.25f*z-.5f));
        const PxU32 pattern[6][4]={{0,1,3,7},{0,3,2,7},{0,2,6,7},{0,6,4,7},{0,4,5,7},{0,5,1,7}};
        for(PxU32 z=0;z<4;++z)for(PxU32 y=0;y<4;++y)for(PxU32 x=0;x<4;++x)
        {
            PxU32 cube[8];for(PxU32 k=0;k<8;++k)cube[k]=(x+(k&1))+5*(y+((k>>1)&1))+25*(z+((k>>2)&1));
            for(const auto& row:pattern)
            {
                PxU32 ids[4];for(PxU32 k=0;k<4;++k)ids[k]=cube[row[k]];
                if(PxMat33(points[ids[1]]-points[ids[0]],points[ids[2]]-points[ids[0]],points[ids[3]]-points[ids[0]]).getDeterminant()<0)PxSwap(ids[1],ids[2]);
                for(auto id:ids)tets.pushBack(id);
            }
        }
    }
    PxTetrahedronMeshDesc desc(points,tets);PxDeformableVolumeSimulationDataDesc simulation;PxCookingParams cooking(physics.getTolerancesScale());cooking.buildGPUData=false;
    soft.mesh=PxCreateDeformableVolumeMesh(cooking,desc,desc,simulation,physics.getPhysicsInsertionCallback());if(!soft.mesh)return false;
    soft.actor=physics.createDeformableVolume();if(!soft.actor)return false;soft.actor->setDeformableBodyFlag(PxDeformableBodyFlag::eDISABLE_SELF_COLLISION,true);
    auto* material=physics.createDeformableVolumeMaterial(2.e4f,.3f,0);material->setMaterialModel(PxDeformableVolumeMaterialModel::eNEO_HOOKEAN);
    auto* shape=physics.createShape(PxTetrahedronMeshGeometry(soft.mesh->getCollisionMesh()),&material,1,true,PxShapeFlag::eSIMULATION_SHAPE);
    const bool attached=shape && soft.actor->attachShape(*shape) && soft.actor->attachSimulationMesh(*soft.mesh->getSimulationMesh(),*soft.mesh->getDeformableVolumeAuxData());
    PX_RELEASE(shape);PX_RELEASE(material);if(!attached)return false;
    PxVec4 *p=NULL,*v=NULL,*c=NULL,*r=NULL;PxDeformableVolumeExt::allocateAndInitializeHostMirror(*soft.actor,NULL,p,v,c,r);PxDeformableVolumeExt::updateMass(*soft.actor,100,50,p);
    const auto* sim=soft.mesh->getSimulationMesh();center=PX_MAX_U32;soft.rest.resize(sim->getNbTetrahedrons());soft.indices.resize(4*soft.rest.size());
    for(PxU32 k=0;k<sim->getNbVertices();++k){if(p[k].getXYZ().isZero())center=k;v[k]=PxVec4(0.f);}
    for(PxU32 t=0;t<soft.rest.size();++t)
    {
        PxVec3d x[4];for(PxU32 k=0;k<4;++k)
        {const PxU32 id=sim->getTetrahedronMeshFlags()&PxTetrahedronMeshFlag::e16_BIT_INDICES?static_cast<const PxU16*>(sim->getTetrahedrons())[4*t+k]:static_cast<const PxU32*>(sim->getTetrahedrons())[4*t+k];soft.indices[4*t+k]=id;x[k]=d(p[id].getXYZ());}
        if(PxMat33d(x[1]-x[0],x[2]-x[0],x[3]-x[0]).getDeterminant()<0){PxSwap(x[1],x[2]);PxSwap(soft.indices[4*t+1],soft.indices[4*t+2]);}
        if(!soft.rest[t].build(x))return false;
    }
    if(center==PX_MAX_U32)return false;
    PxDeformableVolumeExt::copyToDevice(*soft.actor,PxDeformableVolumeDataFlag::eALL,p,v,c,r);
    VolumeAvbdSnippet::hostFree(p);VolumeAvbdSnippet::hostFree(v);VolumeAvbdSnippet::hostFree(c);VolumeAvbdSnippet::hostFree(r);
    soft.actor->setLinearDamping(0);soft.actor->setSolverIterationCounts(4,1);return scene.addActor(*soft.actor);
}
#endif
