#include "PxsConvexMaterialPoint.h"
#include "foundation/PxQuat.h"
#include <cstdio>
#include <initializer_list>
using namespace physx;
int main()
{
    unsigned checks=0,failures=0;double worst=0;PxU32 supports=0,visits=0;
    const auto check=[&](bool condition){++checks;failures+=!condition;};
    for(double size:{.001,1.,1000.})for(unsigned sample=0;sample<1000;++sample)
    {
        const PxQuatd q(.017*sample,PxVec3d(.2,.3,1).getNormalized());const PxVec3d offset(.3*size,-.2*size,.1*size);
        PxVec3d vertices[8];for(unsigned i=0;i<8;++i)vertices[i]=q.rotate(size*PxVec3d(i&1?.25:-.25,i&2?.25:-.25,i&4?.25:-.25))+offset;
        const PxVec3d local=size*PxVec3d(.7*std::sin(.13*sample),.6*std::cos(.17*sample),.8*std::sin(.19*sample));
        PxsConvexMaterialPointInput input;input.points=vertices;input.count=8;input.target=q.rotate(local)+offset;
        const auto result=pxsConvexMaterialPoint(input);check(result.valid && result.count<=4);if(!result.valid)continue;
        PxVec3d actual(0);double sum=0;
        for(unsigned i=0;i<result.count;++i){check(result.indices[i]<8 && result.weights[i]>=0);sum+=result.weights[i];actual+=vertices[result.indices[i]]*result.weights[i];}
        const auto expected=q.rotate(PxVec3d(PxClamp(local.x,-.25*size,.25*size),PxClamp(local.y,-.25*size,.25*size),PxClamp(local.z,-.25*size,.25*size)))+offset;
        const double error=(actual-expected).magnitude()/size;worst=PxMax(worst,error);check(error<1.e-10 && std::abs(sum-1)<1.e-12);
        check(result.supportCalls<=33 && result.pointVisits==(result.supportCalls+1)*8);supports=PxMax(supports,result.supportCalls);visits=PxMax(visits,result.pointVisits);
    }
    PxVec3d box[8];for(unsigned i=0;i<8;++i)box[i]=PxVec3d(i&1?.25:-.25,i&2?.25:-.25,i&4?.25:-.25);
    PxsConvexMaterialPointInput input;input.points=box;input.count=8;input.target=PxVec3d(.25717774,-.251976639,.334783286);
    auto result=pxsConvexMaterialPoint(input);PxVec3d captured(0);for(unsigned i=0;i<result.count;++i)captured+=box[result.indices[i]]*result.weights[i];check(result.valid && (captured-PxVec3d(.25,-.25,.25)).magnitude()<1.e-12);
    PxVec3d point(1,2,3);input.points=&point;input.count=1;input.target=point;result=pxsConvexMaterialPoint(input);check(result.valid && result.count==1 && result.weights[0]==1);
    input.count=257;check(!pxsConvexMaterialPoint(input).valid);input.count=0;check(!pxsConvexMaterialPoint(input).valid);
    std::printf("[CONVEX_MATERIAL_POINT] checks=%u failures=%u projectionError=%.9g maxSupportCalls=%u maxPointVisits=%u status=%s\n",checks,failures,worst,supports,visits,failures?"FAIL":"PASS");return failures?1:0;
}
