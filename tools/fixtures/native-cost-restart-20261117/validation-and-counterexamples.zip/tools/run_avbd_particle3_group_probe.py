"""Check the shared mixed Particle3/Rigid6 Table kernel against dense KKT."""
from run_avbd_ogc_certificate_probe import ROOT, run_probe

if __name__ == "__main__":
    for mode in ("/fp:precise", "/fp:fast"):
        print("Particle3 group " + mode, flush=True)
        code = run_probe(ROOT / "tools/avbd_particle3_group_probe.cpp",
                         extra_sources=[ROOT / "physx/source/lowleveldynamics/src/avbd/DyKernelTable.cpp"],
                         compiler_options=(mode,))
        if code:
            raise SystemExit(code)
