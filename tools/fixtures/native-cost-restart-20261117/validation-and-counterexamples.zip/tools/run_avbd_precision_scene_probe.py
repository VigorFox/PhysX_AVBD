"""Run a public-ABI scene against an explicitly selected complete SDK build."""
import argparse
from pathlib import Path
from run_avbd_ogc_certificate_probe import ROOT, run_probe

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bin-dir', type=Path, required=True)
    parser.add_argument('--bits', type=int, choices=(32, 64), required=True)
    args = parser.parse_args()
    raise SystemExit(run_probe(ROOT / 'tools/avbd_precision_scene_probe.cpp', binary_dir=args.bin_dir,
        defines=(f'PX_SOLVER_COMPUTE_BITS={args.bits}', 'NOMINMAX'),
        libraries=('PhysXExtensions_static_64.lib', 'PhysXPvdSDK_static_64.lib',
                   'PhysX_64.lib', 'PhysXCommon_64.lib', 'PhysXCooking_64.lib')))
