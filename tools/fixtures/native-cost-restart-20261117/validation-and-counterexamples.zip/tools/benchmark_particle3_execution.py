"""Sequential 180-frame / four-primal cost and quality comparison (headless).

Particle3 intentionally uses the no-self rest-offset diagnostic; this is not
production qualification or an assertion of identical constitutive models.
"""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--workers', type=int, nargs='+', default=[0, 4, 8])
    parser.add_argument('--repeats', type=int, default=2)
    parser.add_argument('--profile', action='store_true')
    options = parser.parse_args()
    options.out.mkdir(parents=True, exist_ok=True)
    env = {k: v for k, v in os.environ.items()
           if not k.startswith(('PHYSX_AVBD_', 'PHYSX_NP_GEOMETRY_', 'PHYSX_SNIPPET_', 'NODAL_'))}
    results = []
    for workers in options.workers:
        for repeat in range(options.repeats):
            # Reverse each repeat to expose monotone clock/load drift.
            for model in (('Rigid6', 'Particle3') if repeat % 2 == 0 else ('Particle3', 'Rigid6')):
                settings = dict(env)
                if options.profile:
                    settings.update(PHYSX_AVBD_COMMON_STATS='summary', PHYSX_AVBD_LOCAL_PROFILE='1')
                if model == 'Particle3':
                    settings.update(NODAL_PROD_VARIANT='2', NODAL_PROD_WORKERS=str(workers))
                    command = [sys.executable, 'tools/run_avbd_nodal_production_surface_probe.py']
                    tag, metric = '[NODAL_PRODUCTION_SURFACE]', 'meanSimulationMs'
                else:
                    command = [str(ROOT / 'physx/bin/win.x86_64.vc143.md/checked/SnippetDeformableSurfaceAVBD_64.exe'),
                               '--headless', '--solver=avbd', '--case=static-box', '--frames=180',
                               f'--dispatcher-threads={workers}']
                    tag, metric = '[AVBD_GATE]', 'averageStepMs'
                path = options.out / f'{model}-w{workers}-r{repeat}.log'
                start = time.perf_counter()
                with path.open('w', encoding='utf-8') as log:
                    code = subprocess.run(command, cwd=ROOT, env=settings, stdout=log,
                                          stderr=subprocess.STDOUT).returncode
                lines = path.read_text(encoding='utf-8', errors='replace').splitlines()
                observations = [line for line in lines if tag in line]
                values = [float(value) for line in observations
                          for value in re.findall(rf'\b{metric}=([0-9.eE+-]+)', line)]
                result = dict(model=model, workers=workers, repeat=repeat, profile=options.profile,
                              exitCode=code, processWallSeconds=time.perf_counter()-start,
                              meanStepMs=values[-1] if values else None, observations=observations,
                              command=command, log=str(path.resolve()))
                results.append(result)
                print(json.dumps(result, ensure_ascii=False), flush=True)
                (options.out / 'summary.json').write_text(json.dumps(dict(
                    frames=180, iterations=4, particle3SelfCollision=False, productionQualified=False,
                    caveat='Different material models, thickness/contact conventions, and work versus budget strategy.',
                    results=results), indent=2, ensure_ascii=False), encoding='utf-8')
    return int(any(r['exitCode'] or r['meanStepMs'] is None for r in results))


if __name__ == '__main__':
    raise SystemExit(main())
