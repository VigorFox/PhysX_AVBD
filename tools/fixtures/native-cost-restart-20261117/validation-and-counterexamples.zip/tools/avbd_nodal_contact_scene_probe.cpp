// Real SDK mixed contact, N=4. Independent momentum, material determinant and
// full tetrahedron/OBB SAT checks; no second integrator or production formulas.
#include "PxPhysicsAPI.h"
#include "avbd_nodal_test_time.h"
#include "extensions/PxDeformableVolumeExt.h"
#include "../physx/snippets/snippetdeformablevolumeavbd/SnippetDeformableVolumeAVBDCommon.h"
#include "avbd/DyAvbdNodalTet.h"
#include <cstdio>
#include <cstdlib>
#include <initializer_list>
#include <chrono>
using namespace physx;using namespace physx::Dy;
struct Errors:PxErrorCallback
{
    unsigned count=0;
    void reportError(PxErrorCode::Enum code,const char* text,const char*,int) PX_OVERRIDE
    {if(code==PxErrorCode::eDEBUG_INFO || code==PxErrorCode::eDEBUG_WARNING)return;++count;std::printf("[NODAL_CONTACT_ERROR] %s\n",text);}
};
static PxVec3d d(const PxVec3& p){return PxVec3d(p.x,p.y,p.z);}
struct Soft
{
    PxDeformableVolume* actor=NULL;PxDeformableVolumeMesh* mesh=NULL;
    PxArray<PxU32> indices;PxArray<AvbdNodalTetRest> rest;
    bool create(PxPhysics& physics,PxScene& scene,const PxVec3& center,const PxVec3& velocity,float friction,const PxVec3& omega=PxVec3(0),const PxQuat& orientation=PxQuat(PxIdentity))
    {
        mesh=VolumeAvbdSnippet::cookCube(physics,center,1);if(!mesh)return false;
        actor=physics.createDeformableVolume();if(actor)actor->setDeformableBodyFlag(PxDeformableBodyFlag::eDISABLE_SELF_COLLISION,true);auto* material=physics.createDeformableVolumeMaterial(2.e4f,.3f,friction);
        material->setMaterialModel(PxDeformableVolumeMaterialModel::eNEO_HOOKEAN);
        auto* shape=physics.createShape(PxTetrahedronMeshGeometry(mesh->getCollisionMesh()),&material,1,true,PxShapeFlag::eSIMULATION_SHAPE);
        const bool attached=actor && shape && actor->attachShape(*shape) && actor->attachSimulationMesh(*mesh->getSimulationMesh(),*mesh->getDeformableVolumeAuxData());
        PX_RELEASE(shape);PX_RELEASE(material);if(!attached)return false;
        PxVec4 *p=NULL,*v=NULL,*c=NULL,*r=NULL;PxDeformableVolumeExt::allocateAndInitializeHostMirror(*actor,NULL,p,v,c,r);
        PxDeformableVolumeExt::updateMass(*actor,100,50,p);
        const auto* sim=mesh->getSimulationMesh();
        for(PxU32 i=0;i<sim->getNbVertices();++i)v[i]=PxVec4(velocity+omega.cross(p[i].getXYZ()-center),0);
        const PxU32 count=sim->getNbTetrahedrons();rest.resize(count);indices.resize(4*count);
        for(PxU32 t=0;t<count;++t)
        {
            PxVec3d x[4];for(PxU32 k=0;k<4;++k)
            {const PxU32 id=sim->getTetrahedronMeshFlags()&PxTetrahedronMeshFlag::e16_BIT_INDICES?
                static_cast<const PxU16*>(sim->getTetrahedrons())[4*t+k]:static_cast<const PxU32*>(sim->getTetrahedrons())[4*t+k];indices[4*t+k]=id;x[k]=d(p[id].getXYZ());}
            if(PxMat33d(x[1]-x[0],x[2]-x[0],x[3]-x[0]).getDeterminant()<0){PxSwap(x[1],x[2]);PxSwap(indices[4*t+1],indices[4*t+2]);}
            if(!rest[t].build(x))return false;
        }
        for(PxU32 k=0;k<sim->getNbVertices();++k)
        {p[k]=PxVec4(center+orientation.rotate(p[k].getXYZ()-center),p[k].w);v[k]=PxVec4(orientation.rotate(v[k].getXYZ()),v[k].w);}
        PxDeformableVolumeExt::copyToDevice(*actor,PxDeformableVolumeDataFlag::eALL,p,v,c,r);
        VolumeAvbdSnippet::hostFree(p);VolumeAvbdSnippet::hostFree(v);VolumeAvbdSnippet::hostFree(c);VolumeAvbdSnippet::hostFree(r);
        actor->setLinearDamping(0);return scene.addActor(*actor);
    }
    void momentum(PxVec3d& linear,PxVec3d& angular,double& energy)const
    {
        const auto* p=actor->getSimPositionInvMassBufferD();const auto* v=actor->getSimVelocityBufferD();
        for(PxU32 i=0;i<actor->getSimulationMesh()->getNbVertices();++i)
        {const double m=1/double(p[i].w);linear+=d(v[i].getXYZ())*m;angular+=d(p[i].getXYZ()).cross(d(v[i].getXYZ())*m);energy+=.5*m*d(v[i].getXYZ()).magnitudeSquared();}
    }
    double measure(double& energy)const
    {
        const auto* p=actor->getSimPositionInvMassBufferD();double minDet=DBL_MAX;AvbdNodalElasticity material;material.fromYoungPoisson(2.e4,.3);
        for(PxU32 t=0;t<rest.size();++t)
        {PxVec3d x[4];for(PxU32 k=0;k<4;++k)x[k]=d(p[indices[4*t+k]].getXYZ());const auto s=avbdSampleNodalTet(rest[t],material,x);minDet=PxMin(minDet,s.ratio);energy+=s.energy;if(!s.valid)return -DBL_MAX;}
        return minDet;
    }
    double boxGap(const PxTransform& pose,double halfExtent=.3)const
    {
        const auto* p=actor->getSimPositionInvMassBufferD();double minimum=DBL_MAX;
        for(PxU32 t=0;t<rest.size();++t)
        {
            PxVec3d x[4];for(PxU32 k=0;k<4;++k)x[k]=d(pose.transformInv(p[indices[4*t+k]].getXYZ()));
            double separation=-DBL_MAX;
            const auto axis=[&](PxVec3d n)
            {const double length=n.magnitude();if(length<1.e-14)return;n/=length;double lo=DBL_MAX,hi=-DBL_MAX;
                for(const auto& v:x){lo=PxMin(lo,n.dot(v));hi=PxMax(hi,n.dot(v));}const double support=halfExtent*(std::abs(n.x)+std::abs(n.y)+std::abs(n.z));
                separation=PxMax(separation,PxMax(lo-support,-support-hi));};
            axis(PxVec3d(1,0,0));axis(PxVec3d(0,1,0));axis(PxVec3d(0,0,1));
            for(PxU32 a=0;a<4;++a)
            {PxU32 ids[3],count=0;for(PxU32 k=0;k<4;++k)if(k!=a)ids[count++]=k;axis((x[ids[1]]-x[ids[0]]).cross(x[ids[2]]-x[ids[0]]));}
            for(PxU32 a=0;a<4;++a)for(PxU32 b=a+1;b<4;++b)for(PxU32 k=0;k<3;++k)
            {PxVec3d basis(0);basis[k]=1;axis((x[b]-x[a]).cross(basis));}
            minimum=PxMin(minimum,separation);
        }
        return minimum;
    }
    double softGap(const Soft& other)const
    {
        const auto* p=actor->getSimPositionInvMassBufferD();const auto* q=other.actor->getSimPositionInvMassBufferD();double gap=DBL_MAX;
        for(PxU32 a=0;a<rest.size();++a)for(PxU32 b=0;b<other.rest.size();++b)
        {
            PxVec3d x[4],y[4];for(PxU32 k=0;k<4;++k){x[k]=d(p[indices[4*a+k]].getXYZ());y[k]=d(q[other.indices[4*b+k]].getXYZ());}
            double separation=-DBL_MAX;
            const auto axis=[&](PxVec3d n)
            {const double length=n.magnitude();if(length<1.e-14)return;n/=length;double ax=DBL_MAX,bx=-DBL_MAX,ay=DBL_MAX,by=-DBL_MAX;
                for(PxU32 k=0;k<4;++k){ax=PxMin(ax,n.dot(x[k]));bx=PxMax(bx,n.dot(x[k]));ay=PxMin(ay,n.dot(y[k]));by=PxMax(by,n.dot(y[k]));}separation=PxMax(separation,PxMax(ax-by,ay-bx));};
            for(PxU32 omitted=0;omitted<4;++omitted)
            {PxU32 ids[3],n=0;for(PxU32 k=0;k<4;++k)if(k!=omitted)ids[n++]=k;axis((x[ids[1]]-x[ids[0]]).cross(x[ids[2]]-x[ids[0]]));axis((y[ids[1]]-y[ids[0]]).cross(y[ids[2]]-y[ids[0]]));}
            for(PxU32 i=0;i<4;++i)for(PxU32 j=i+1;j<4;++j)for(PxU32 k=0;k<4;++k)for(PxU32 l=k+1;l<4;++l)axis((x[j]-x[i]).cross(y[l]-y[k]));
            gap=PxMin(gap,separation);
        }
        return gap;
    }
    void release(){PX_RELEASE(actor);PX_RELEASE(mesh);}
};
static void momentum(PxRigidDynamic& rigid,PxVec3d& linear,PxVec3d& angular,double& energy)
{
    const auto p=rigid.getGlobalPose();const auto v=d(rigid.getLinearVelocity());const auto w=d(rigid.getAngularVelocity());
    const auto inertia=rigid.getMassSpaceInertiaTensor();const auto local=p.q.rotateInv(rigid.getAngularVelocity());
    const auto iw=d(p.q.rotate(PxVec3(inertia.x*local.x,inertia.y*local.y,inertia.z*local.z)));
    linear+=v*rigid.getMass();angular+=d(p.p).cross(v*rigid.getMass())+iw;energy+=.5*(rigid.getMass()*v.magnitudeSquared()+w.dot(iw));
}
int main()
{
    std::setvbuf(stdout,NULL,_IONBF,0);
    const char* requested=std::getenv("NODAL_CONTACT_ITERATIONS");const PxU32 iterations=requested?std::strtoul(requested,NULL,10):4;
    const double h=std::getenv("NODAL_CONTACT_DT")?std::strtod(std::getenv("NODAL_CONTACT_DT"),NULL):1./60;
    if(!configureNodalTime())return 2;_putenv_s("PHYSX_AVBD_LOCAL_ITERATIONS",requested?requested:"4");_putenv_s("PHYSX_NP_GEOMETRY_CERTIFICATES","2");
    std::printf("[NODAL_CONTACT_CONFIG] dt=%.17g iterations=%u\n",h,iterations);
    PxDefaultAllocator allocator;Errors errors;auto* foundation=PxCreateFoundation(PX_PHYSICS_VERSION,allocator,errors);
    auto* physics=PxCreatePhysics(PX_PHYSICS_VERSION,*foundation,PxTolerancesScale(),true);PxInitExtensions(*physics,NULL);
    unsigned failures=0;const PxU32 frameCount=std::getenv("NODAL_CONTACT_FRAMES")?std::strtoul(std::getenv("NODAL_CONTACT_FRAMES"),NULL,10):180;
    if(!std::getenv("NODAL_COUPLING_CASE"))for(PxU32 workers:{0u,4u,8u})for(PxU32 mode=0;mode<3;++mode)
    {
        if(const char* selected=std::getenv("NODAL_CONTACT_MODE"))if(mode!=std::strtoul(selected,NULL,10))continue;
        const unsigned before=errors.count;auto* dispatcher=PxDefaultCpuDispatcherCreate(workers);PxSceneDesc desc(physics->getTolerancesScale());
        desc.cpuDispatcher=dispatcher;desc.gravity=PxVec3(0);desc.filterShader=PxDefaultSimulationFilterShader;desc.solverType=PxSolverType::eAVBD;
        auto* scene=physics->createScene(desc);Soft soft;const bool created=soft.create(*physics,*scene,PxVec3(0),PxVec3(0),mode==2?.5f:0.f);
        auto* material=physics->createMaterial(mode==2?.5f:0,mode==2?.5f:0,0);
        auto* rigid=PxCreateDynamic(*physics,PxTransform(PxVec3(1.3f,mode?.28f:0,mode?.17f:0)),PxBoxGeometry(.3f,.3f,.3f),*material,100);
        rigid->setLinearDamping(0);rigid->setAngularDamping(0);rigid->setSleepThreshold(0);
        rigid->setLinearVelocity(PxVec3(-2,mode==2?.6f:0,0));scene->addActor(*rigid);
        PxVec3d input(0),inputAngular(0);double inputEnergy=0;soft.momentum(input,inputAngular,inputEnergy);momentum(*rigid,input,inputAngular,inputEnergy);
        double momentumError=0,angularError=0,minDet=DBL_MAX,minGap=DBL_MAX,maxEnergy=0,maxSoftSpeed=0,spin=0;
        const auto start=std::chrono::steady_clock::now();bool fetched=created;
        for(PxU32 frame=0;frame<frameCount && fetched;++frame)
        {
            scene->simulate(PxReal(h));fetched=scene->fetchResults(true);if(!fetched)break;
            PxVec3d linear(0),angular(0),softLinear(0),softAngular(0);double energy=0,softEnergy=0;
            soft.momentum(softLinear,softAngular,softEnergy);linear+=softLinear;angular+=softAngular;energy+=softEnergy;momentum(*rigid,linear,angular,energy);
            minDet=PxMin(minDet,soft.measure(energy));minGap=PxMin(minGap,soft.boxGap(rigid->getGlobalPose()));maxEnergy=PxMax(maxEnergy,energy);
            momentumError=PxMax(momentumError,(linear-input).magnitude()/PxMax(input.magnitude(),1.));
            angularError=PxMax(angularError,(angular-inputAngular).magnitude()/PxMax(input.magnitude(),1.));
            maxSoftSpeed=PxMax(maxSoftSpeed,softLinear.magnitude()/100.);spin=PxMax(spin,double(rigid->getAngularVelocity().magnitude()));
            if(std::getenv("NODAL_CONTACT_TRACE"))
            {
                double rigidKinetic=0;PxVec3d pl(0),al(0);momentum(*rigid,pl,al,rigidKinetic);
                std::printf("[NODAL_FRAME] frame=%u p=%.9g,%.9g,%.9g L=%.9g,%.9g,%.9g gap=%.9g w=%.9g energy=%.9g softKinetic=%.9g rigidKinetic=%.9g material=%.9g\n",frame,linear.x,linear.y,linear.z,angular.x,angular.y,angular.z,soft.boxGap(rigid->getGlobalPose()),double(rigid->getAngularVelocity().magnitude()),energy,softEnergy,rigidKinetic,energy-softEnergy-rigidKinetic);
            }
        }
        const double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()/frameCount;
        const bool pass=created && fetched && errors.count==before && minDet>0 && minGap>=-1.e-6 && momentumError<.01 && angularError<.02 &&
            maxEnergy<1.05*inputEnergy && maxSoftSpeed>.01 && (mode?spin>.05:spin*.3<.01*2.);
        // A centered symmetric impact has no authored torque: allow a rim
        // speed up to 1% of incoming speed, not exact pose/thread symmetry.
        failures+=!pass;
        std::printf("[NODAL_CONTACT_SCENE] mode=%u workers=%u frames=%u iterations=%u minDet=%.9g minGap=%.9g momentumError=%.9g angularErrorM=%.9g inputEnergy=%.9g maxEnergy=%.9g softSpeed=%.9g rigidSpin=%.9g meanMs=%.9g status=%s\n",
            mode,workers,frameCount,iterations,minDet,minGap,momentumError,angularError,inputEnergy,maxEnergy,maxSoftSpeed,spin,ms,pass?"PASS":"FAIL");
        soft.release();rigid->release();material->release();scene->release();dispatcher->release();
    }
    if(!std::getenv("NODAL_CONTACT_MODE"))for(PxU32 workers:{0u,4u,8u})for(PxU32 mode=0;mode<4;++mode)
    {
        if(const char* selected=std::getenv("NODAL_COUPLING_CASE"))if(mode!=std::strtoul(selected,NULL,10))continue;
        const auto before=errors.count;auto* dispatcher=PxDefaultCpuDispatcherCreate(workers);PxSceneDesc desc(physics->getTolerancesScale());
        desc.cpuDispatcher=dispatcher;desc.gravity=mode==0?PxVec3(0,-9.81f,0):PxVec3(0);desc.filterShader=PxDefaultSimulationFilterShader;desc.solverType=PxSolverType::eAVBD;
        auto* scene=physics->createScene(desc);Soft a,b;PxRigidStatic* floor=NULL;auto* material=physics->createMaterial(0,0,0);
        const bool pair=mode>=2;const PxVec3 center=mode==0?PxVec3(0,1.2f,0):pair?PxVec3(-.65f,0,0):PxVec3(0);
        bool valid=a.create(*physics,*scene,center,pair?PxVec3(1,0,0):PxVec3(0),mode==3?.4f:0,mode==1?PxVec3(.3f,.5f,.7f):PxVec3(0));
        if(pair)valid &= b.create(*physics,*scene,PxVec3(.65f,.2f,.1f),PxVec3(-1,0,0),mode==3?.4f:0);
        if(mode==0){floor=PxCreatePlane(*physics,PxPlane(0,1,0,0),*material);scene->addActor(*floor);}
        PxVec3d input(0),inputAngular(0);double inputEnergy=0;a.momentum(input,inputAngular,inputEnergy);if(pair)b.momentum(input,inputAngular,inputEnergy);
        if(mode==0){const auto* p=a.actor->getSimPositionInvMassBufferD();for(PxU32 k=0;k<a.actor->getSimulationMesh()->getNbVertices();++k)inputEnergy+=9.81*p[k].y/p[k].w;}
        double maxEnergy=0,minDet=DBL_MAX,minGap=DBL_MAX,momentumError=0,angularError=0,travel=0;const double momentumScale=pair?200:PxMax(inputAngular.magnitude(),1.);
        const auto start=std::chrono::steady_clock::now();
        for(PxU32 frame=0;frame<frameCount && valid;++frame)
        {
            scene->simulate(PxReal(h));valid=scene->fetchResults(true);if(!valid)break;
            PxVec3d linear(0),angular(0);double energy=0;a.momentum(linear,angular,energy);minDet=PxMin(minDet,a.measure(energy));
            if(pair){b.momentum(linear,angular,energy);minDet=PxMin(minDet,b.measure(energy));minGap=PxMin(minGap,a.softGap(b));}
            else if(mode==0)
            {const auto* p=a.actor->getSimPositionInvMassBufferD();for(PxU32 k=0;k<a.actor->getSimulationMesh()->getNbVertices();++k){energy+=9.81*p[k].y/p[k].w;minGap=PxMin(minGap,double(p[k].y));}}
            else {minGap=0;travel=PxMax(travel,(d(a.actor->getSimPositionInvMassBufferD()[0].getXYZ())-d(a.mesh->getSimulationMesh()->getVertices()[0])).magnitude());}
            maxEnergy=PxMax(maxEnergy,energy);momentumError=PxMax(momentumError,(linear-input).magnitude()/momentumScale);angularError=PxMax(angularError,(angular-inputAngular).magnitude()/momentumScale);
            if(std::getenv("NODAL_COUPLING_TRACE") && (frame<90 || frame%60==0 || frame+1==frameCount))
            {
                const auto* p=a.actor->getSimPositionInvMassBufferD();const auto* v=a.actor->getSimVelocityBufferD();
                double speed=0,lo=DBL_MAX,hi=-DBL_MAX,kinetic=0;PxVec3d pl(0),al(0);
                a.momentum(pl,al,kinetic);
                for(PxU32 k=0;k<a.actor->getSimulationMesh()->getNbVertices();++k)
                {speed=PxMax(speed,double(v[k].getXYZ().magnitude()));lo=PxMin(lo,double(p[k].y));hi=PxMax(hi,double(p[k].y));}
                std::printf("[NODAL_REST_FRAME] mode=%u workers=%u frame=%u maxSpeed=%.9g minY=%.9g maxY=%.9g kinetic=%.9g wakeCounter=%.9g sleepThreshold=%.9g sleeping=%u\n",mode,workers,frame,speed,lo,hi,kinetic,double(a.actor->getWakeCounter()),double(a.actor->getSleepThreshold()),unsigned(a.actor->isSleeping()));
            }
        }
        PxVec3d finalLinear(0),finalAngular(0);double finalKinetic=0;a.momentum(finalLinear,finalAngular,finalKinetic);if(pair)b.momentum(finalLinear,finalAngular,finalKinetic);
        const PxU32 finalAwake=PxU32(!a.actor->isSleeping())+(pair?PxU32(!b.actor->isSleeping()):0);
        const bool pass=valid && errors.count==before && minDet>0 && minGap>=-1.e-6 && maxEnergy<1.05*inputEnergy &&
            (mode==0 || (momentumError<.01 && angularError<.02 && (pair || travel>.1)));
        failures+=!pass;
        const double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()/frameCount;
        std::printf("[NODAL_COUPLING_SCENE] mode=%s workers=%u frames=%u iterations=%u minDet=%.9g minGap=%.9g momentumError=%.9g angularError=%.9g inputEnergy=%.9g maxEnergy=%.9g travel=%.9g finalKinetic=%.9g finalAwake=%u momentumApplicable=%u angularMetric=%s meanMs=%.9g status=%s\n",
            mode==0?"plane-drop":mode==1?"free-spin":mode==2?"soft-pair":"soft-pair-friction",workers,frameCount,iterations,minDet,minGap,momentumError,angularError,inputEnergy,maxEnergy,travel,finalKinetic,finalAwake,mode!=0,mode==1?"relative":"m",ms,pass?"PASS":"FAIL");
        a.release();b.release();PX_RELEASE(floor);material->release();scene->release();dispatcher->release();
    }
    std::printf("[NODAL_CONTACT_SUMMARY] failures=%u productionQualified=0\n",failures);
    PxCloseExtensions();physics->release();foundation->release();return failures?1:0;
}
