// Actual SDK high-degree execution; no private solver or trajectory oracle.
#define main nodalContactScenarioMain
#include "avbd_nodal_contact_scene_probe.cpp"
#undef main
#include "avbd_nodal_shell_fixture.h"
#include <set>
struct TileEvents:PxSimulationEventCallback
{
    std::set<const PxActor*> planes;
    PxVec3d impulse=PxVec3d(0);unsigned invalid=0;
    void onConstraintBreak(PxConstraintInfo*,PxU32) PX_OVERRIDE {}
    void onWake(PxActor**,PxU32) PX_OVERRIDE {}
    void onSleep(PxActor**,PxU32) PX_OVERRIDE {}
    void onTrigger(PxTriggerPair*,PxU32) PX_OVERRIDE {}
    void onAdvance(const PxRigidBody*const*,const PxTransform*,const PxU32) PX_OVERRIDE {}
    void onContact(const PxContactPairHeader& h,const PxContactPair* pairs,PxU32 count) PX_OVERRIDE
    {
        for(PxU32 i=0;i<count;++i)
        {
            if(pairs[i].contactCount)for(PxU32 s=0;s<2;++s)if(h.actors[s]->getType()==PxActorType::eRIGID_STATIC)planes.insert(h.actors[s]);
            PxArray<PxContactPairPoint> contacts(pairs[i].contactCount);const auto n=pairs[i].extractContacts(contacts.begin(),contacts.size());invalid+=n!=pairs[i].contactCount;
            for(PxU32 k=0;k<n;++k){const auto j=contacts[k].impulse;invalid+=!j.isFinite();impulse+=PxVec3d(j.x,j.y,j.z)*(h.actors[0]->getType()==PxActorType::eRIGID_STATIC?-1.:1.);}
        }
    }
};
static PxFilterFlags tileFilter(PxFilterObjectAttributes,PxFilterData,PxFilterObjectAttributes,PxFilterData,PxPairFlags& flags,const void*,PxU32)
{flags=PxPairFlag::eCONTACT_DEFAULT|PxPairFlag::eNOTIFY_TOUCH_FOUND|PxPairFlag::eNOTIFY_TOUCH_PERSISTS|PxPairFlag::eNOTIFY_CONTACT_POINTS;return PxFilterFlag::eDEFAULT;}
int main()
{
    std::setvbuf(stdout,NULL,_IONBF,0);
    _putenv_s("PHYSX_AVBD_COMMON_STEP","work");_putenv_s("PHYSX_AVBD_LOCAL_ITERATIONS","4");_putenv_s("PHYSX_NP_GEOMETRY_CERTIFICATES","2");
    PxDefaultAllocator allocator;Errors errors;auto* foundation=PxCreateFoundation(PX_PHYSICS_VERSION,allocator,errors);
    auto* physics=PxCreatePhysics(PX_PHYSICS_VERSION,*foundation,PxTolerancesScale(),true);PxInitExtensions(*physics,NULL);unsigned failures=0;
    const char* profile=std::getenv("AVBD_TEST_PROFILE");
    const bool capacity=profile && std::strcmp(profile,"capacity-stress")==0;
    if(profile && !capacity && std::strcmp(profile,"realtime")!=0)return 2;
    const PxU32 counts[2]={capacity?65u:1u,capacity?129u:4u};
    for(PxU32 workers:{0u,4u,8u})for(PxU32 planeCount:counts)for(unsigned kind=0;kind<3;++kind)
    {
        if(const char* choice=std::getenv("NODAL_TILED_WORKERS"))if(workers!=std::strtoul(choice,NULL,10))continue;
        if(const char* choice=std::getenv("NODAL_TILED_PLANES"))if(planeCount!=std::strtoul(choice,NULL,10))continue;
        if(const char* choice=std::getenv("NODAL_TILED_KIND"))if(kind!=std::strtoul(choice,NULL,10))continue;
        const auto before=errors.count;auto* dispatcher=PxDefaultCpuDispatcherCreate(workers);TileEvents events;
        PxSceneDesc desc(physics->getTolerancesScale());desc.cpuDispatcher=dispatcher;desc.filterShader=tileFilter;desc.simulationEventCallback=&events;
        desc.solverType=PxSolverType::eAVBD;desc.gravity=PxVec3(0);auto* scene=physics->createScene(desc);auto* material=physics->createMaterial(0,0,0);
        PxArray<PxRigidStatic*> planes;for(PxU32 k=0;k<planeCount;++k)
        {
            // Normal contact work is one platform or four distinct floor tiles.
            // Coincident 65/129 planes are retained only as capacity stress.
            const float extent=planeCount==1?1.f:.5f;
            const PxVec3 center=planeCount==1?PxVec3(0,-.07f,0):PxVec3(k&1?.5f:-.5f,-.07f,k&2?.5f:-.5f);
            auto* plane=capacity?PxCreatePlane(*physics,PxPlane(0,1,0,.02f),*material):
                PxCreateStatic(*physics,PxTransform(center),PxBoxGeometry(extent,.05f,extent),*material);
            scene->addActor(*plane);planes.pushBack(plane);
        }
        Soft soft;AvbdShellTest::Shell shell;PxRigidDynamic* rigid=NULL;bool valid=true;
        if(kind==0){rigid=PxCreateDynamic(*physics,PxTransform(PxVec3(0,.56f,0)),PxBoxGeometry(.5f,.5f,.5f),*material,100);valid=rigid!=NULL;
            if(valid){rigid->setLinearDamping(0);rigid->setAngularDamping(0);rigid->setLinearVelocity(PxVec3(0,-1,0));scene->addActor(*rigid);}}
        else if(kind==1)valid=soft.create(*physics,*scene,PxVec3(0,.56f,0),PxVec3(0,-1,0),0);
        else valid=shell.create(*physics,*scene,PxVec3(0,.06f,0),PxVec3(0,-1,0),0,100,PxQuat(PxHalfPi,PxVec3(1,0,0)));
        double mass=kind==0?(rigid?rigid->getMass():0):kind==2?shell.mass:0;
        if(kind==1 && valid)for(PxU32 k=0;k<soft.actor->getSimulationMesh()->getNbVertices();++k)mass+=1./soft.actor->getSimPositionInvMassBufferD()[k].w;
        const double initialKinetic=.5*mass;
        double minGap=DBL_MAX,minRatio=DBL_MAX,maxMechanical=0,highestVelocity=-DBL_MAX,finalVelocity=-1;unsigned completed=0;
        for(unsigned frame=0;frame<30 && valid;++frame)
        {
            scene->simulate(1.f/60);valid=scene->fetchResults(true) && errors.count==before;if(!valid)break;++completed;
            double energy=0,velocity=0;
            if(kind==0)
            {
                const auto pose=rigid->getGlobalPose();const auto v=rigid->getLinearVelocity(),w=rigid->getAngularVelocity();valid &= pose.isSane() && v.isFinite() && w.isFinite();
                PxVec3d linear(0),angular(0);momentum(*rigid,linear,angular,energy);
                for(unsigned k=0;k<8;++k)minGap=PxMin(minGap,double(pose.transform(PxVec3(k&1?.5f:-.5f,k&2?.5f:-.5f,k&4?.5f:-.5f)).y)+.02);
                velocity=v.y;minRatio=1;
            }
            else
            {
                const auto* x=kind==1?soft.actor->getSimPositionInvMassBufferD():shell.actor->getPositionInvMassBufferH();
                const auto* v=kind==1?soft.actor->getSimVelocityBufferD():shell.actor->getVelocityBufferH();
                const auto count=kind==1?soft.actor->getSimulationMesh()->getNbVertices():shell.mesh->getNbVertices();
                for(PxU32 k=0;k<count;++k){valid &= x[k].isFinite() && v[k].isFinite();minGap=PxMin(minGap,double(x[k].y)+.02);
                    energy+=.5*d(v[k].getXYZ()).magnitudeSquared()/x[k].w;velocity+=v[k].y/x[k].w/mass;}
                minRatio=PxMin(minRatio,kind==1?soft.measure(energy):shell.measure(energy));
            }
            maxMechanical=PxMax(maxMechanical,energy);highestVelocity=PxMax(highestVelocity,velocity);finalVelocity=velocity;
        }
        // K + strain energy omits nonnegative contact storage: a lower-bound
        // energy diagnostic, plus independent gap, material and reaction tests.
        const double deltaMomentum=mass*(finalVelocity+1),impulseRatio=events.impulse.y/deltaMomentum;
        const bool pass=valid && completed==30 && errors.count==before && !events.invalid && events.planes.size()==planeCount && minGap>0 && minRatio>0 &&
            highestVelocity>-.1 && maxMechanical<=1.05*initialKinetic && impulseRatio>.8 && impulseRatio<1.2;
        failures+=!pass;
        std::printf("[NODAL_TILED_SCENE] kind=%s workers=%u planes=%u profile=%s frames=30 completedFrames=%u iterations=4 observedPlanes=%u minGap=%.9g minRatio=%.9g initialKinetic=%.9g maxMechanicalLowerBound=%.9g highestVelocityY=%.9g deltaMomentumY=%.9g reportedImpulseY=%.9g impulseRatio=%.9g errors=%u productionQualified=0 status=%s\n",
            kind==0?"rigid":kind==1?"volume":"surface",workers,planeCount,capacity?"capacity-stress":"realtime",completed,unsigned(events.planes.size()),minGap,minRatio,initialKinetic,maxMechanical,highestVelocity,deltaMomentum,events.impulse.y,impulseRatio,errors.count-before,pass?"PASS":"FAIL");
        PX_RELEASE(rigid);soft.release();shell.release();for(auto* plane:planes)plane->release();material->release();scene->release();dispatcher->release();
    }
    PxCloseExtensions();physics->release();foundation->release();return failures?1:0;
}
