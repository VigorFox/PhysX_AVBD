// Independent dense KKT oracle for the production mixed-dimension Table leaf.
#include "avbd/DyAvbdNonlinearGroup.h"
#include "avbd/DyKernelTable.h"
#include "avbd_probe_foundation.h"
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <limits>
#include <vector>
#include "foundation/PxQuat.h"
using namespace physx;using namespace physx::Dy;
static bool denseSolve(std::vector<double> a,std::vector<double>& b,unsigned n)
{
    for(unsigned k=0;k<n;++k)
    {
        unsigned p=k;for(unsigned i=k+1;i<n;++i)if(std::abs(a[i*n+k])>std::abs(a[p*n+k]))p=i;
        if(!(std::abs(a[p*n+k])>1.e-16))return false;
        for(unsigned j=k;j<n;++j)std::swap(a[k*n+j],a[p*n+j]);std::swap(b[k],b[p]);
        for(unsigned i=k+1;i<n;++i)
        {
            const double t=a[i*n+k]/a[k*n+k];
            for(unsigned j=k;j<n;++j)a[i*n+j]-=t*a[k*n+j];b[i]-=t*b[k];
        }
    }
    for(unsigned i=n;i-->0;){for(unsigned j=i+1;j<n;++j)b[i]-=a[i*n+j]*b[j];b[i]/=a[i*n+i];}
    return true;
}
static void launch(const KernelTable& t,AvbdNonlinearGroup& g)
{AvbdNonlinearGroupArgs a={&g};t.launch(AVBD_NONLINEAR_GROUP,&a);}
static void launch(const KernelTable& t,AvbdLocalNonlinearGroup& g)
{AvbdLocalNonlinearGroupArgs a={&g};t.launch(AVBD_LOCAL_NONLINEAR_GROUP,&a);}
static void launch(const KernelTable& t,AvbdParticleNonlinearGroup& g)
{AvbdParticleNonlinearGroupArgs a={&g};t.launch(AVBD_PARTICLE_NONLINEAR_GROUP,&a);}
static void launch(const KernelTable& t,AvbdLocalParticleNonlinearGroup& g)
{AvbdLocalParticleNonlinearGroupArgs a={&g};t.launch(AVBD_LOCAL_PARTICLE_NONLINEAR_GROUP,&a);}
template<unsigned Cap,unsigned Width> static unsigned check(const KernelTable& table,double& worst,unsigned& cases)
{
    unsigned failures=0;
    for(unsigned count=1;count<=Cap;++count)for(unsigned trial=0;trial<24;++trial)
    {
        AvbdNonlinearGroupT<Cap,Width> g;g.count=count;
        unsigned off[Cap],n=0;
        const bool closed=trial%3==0,indefinite=trial%5==0;
        const unsigned rank=1+(trial/3)%3;g.translationChart.rank=rank;
        const PxQuatd rotation(.13*trial,PxVec3d(1,2,3).getNormalized());
        for(unsigned q=0;q<3;++q)g.translationChart.axes[q]=rotation.rotate(g.translationChart.axes[q]);
        const double units=trial%2?.001:1000.;
        for(unsigned i=0;i<count;++i)
        {
            g.dimension[i]=Width==3 || ((trial>>(i%4))&1)?3:6;
            off[i]=n;n+=g.dimension[i];g.translationMass[i]=closed?1.+i:0;
            g.locked[i]=closed?0:(trial+7*i)%((1u<<g.dimension[i])-1);
        }
        const unsigned size=n+(closed?rank:0);
        std::vector<double> a(size*size,0),rhs(size,0);
        for(unsigned i=0;i<count;++i)for(unsigned r=0;r<Width;++r)
        {
            // Poison absent rotations: they must not enter factorization or RHS.
            if(r>=g.dimension[i])g.gradient[i][r]=std::numeric_limits<double>::quiet_NaN();
            else g.gradient[i][r]=units*std::sin(1.+off[i]+r+trial);
            for(unsigned j=0;j<count;++j)for(unsigned c=0;c<Width;++c)
            {
                double h=std::numeric_limits<double>::quiet_NaN();
                if(r<g.dimension[i] && c<g.dimension[j])
                {
                    const unsigned u=off[i]+r,v=off[j]+c;
                    h=units*((u==v?2.+.1*u:0)+.05*std::cos(1.+u)*std::cos(1.+v));
                    const bool fixed=(g.locked[i]&(1u<<r)) || (g.locked[j]&(1u<<c));
                    a[u*size+v]=fixed?(u==v?1:0):h;
                }
                g.K[i][j][Width*r+c]=g.M[i][j][Width*r+c]=h;
            }
            if(r<g.dimension[i])
            {
                const unsigned u=off[i]+r;rhs[u]=(g.locked[i]&(1u<<r))?0:-g.gradient[i][r];
                if(closed && r<3)for(unsigned q=0;q<rank;++q)a[u*size+n+q]=a[(n+q)*size+u]=g.translationMass[i]*g.translationChart.axes[q][r];
            }
        }
        if(indefinite)
        {
            // A free physical coordinate makes K indefinite. M stays the oracle.
            bool set=false;
            for(unsigned i=0;i<count && !set;++i)for(unsigned r=0;r<g.dimension[i] && !set;++r)
                if(!(g.locked[i]&(1u<<r))){g.K[i][i][(Width+1)*r]=-units;set=true;}
        }
        if(!denseSolve(a,rhs,size)){++failures;continue;}
        launch(table,g);++cases;
        failures+=!g.solved || g.scalarCount!=n || g.factorizations>(closed?3u:2u) || g.substitutions!=(closed?1u+rank:1u);
        for(unsigned i=0;i<count;++i)for(unsigned r=0;r<Width;++r)
        {
            const double expected=r<g.dimension[i]?rhs[off[i]+r]:0;
            const double error=std::abs(g.step[i][r]-expected)/std::max(1.,std::abs(expected));
            worst=std::max(worst,error);failures+=!std::isfinite(error) || error>2.e-9;
        }
    }
    AvbdNonlinearGroupT<Cap,Width> invalid;invalid.count=1;invalid.dimension[0]=4;
    launch(table,invalid);failures+=invalid.solved || invalid.factorizations!=0;
    invalid.dimension[0]=3;invalid.gradient[0][1]=std::numeric_limits<double>::infinity();
    launch(table,invalid);failures+=invalid.solved;
    return failures;
}
// Equal physical Particle3 matrices; the padded control carries unused unit
// rotations. Timing is a kernel comparison, not a scene speedup claim.
template<unsigned Width> static double timed(const KernelTable& t,double& checksum)
{
    AvbdNonlinearGroupT<16,Width> base;base.count=16;
    for(unsigned i=0;i<16;++i)for(unsigned d=0;d<Width;++d)
    {
        base.K[i][i][(Width+1)*d]=base.M[i][i][(Width+1)*d]=2.;
        if(d<3)base.gradient[i][d]=.1*(i+d+1);
    }
    const auto start=std::chrono::steady_clock::now();
    for(unsigned rep=0;rep<600;++rep){auto g=base;launch(t,g);checksum+=g.step[rep%16][rep%3];}
    return std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-start).count()/600;
}
int main()
{
    AvbdProbeFoundation foundation;const auto t=KernelTable::makeAvbdCpuScalar();
    unsigned cases=0,failures=0;double worst=0,checksum=0;
    failures+=check<4,6>(t,worst,cases);failures+=check<16,6>(t,worst,cases);
    failures+=check<4,3>(t,worst,cases);failures+=check<16,3>(t,worst,cases);
    std::printf("[PARTICLE3_GROUP] cases=%u error=%.9g failures=%u bytes3=%zu bytes6=%zu\n",
        cases,worst,failures,sizeof(AvbdLocalParticleNonlinearGroup),sizeof(AvbdLocalNonlinearGroup));
    for(unsigned pair=0;pair<4;++pair)
    {
        double p,r;if(pair%2){p=timed<3>(t,checksum);r=timed<6>(t,checksum);}
        else {r=timed<6>(t,checksum);p=timed<3>(t,checksum);}
        std::printf("[PARTICLE3_GROUP_COST] pair=%u particleUs=%.9g paddedUs=%.9g ratio=%.6g checksum=%.9g\n",pair,p,r,r/p,checksum);
    }
    return failures?1:0;
}
