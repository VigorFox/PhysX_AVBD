// Typed high-degree contacts execute through the common bounded row leaves.
#define main officialSlideScenarioMain
#include "official_physx_free_slide_probe.cpp"
#undef main
int main()
{
    _putenv_s("PHYSX_AVBD_COMMON_STEP","work");_putenv_s("PHYSX_AVBD_LOCAL_ITERATIONS","4");_putenv_s("PHYSX_NP_GEOMETRY_CERTIFICATES","2");
    PxDefaultAllocator allocator;Errors errors;auto* foundation=PxCreateFoundation(PX_PHYSICS_VERSION,allocator,errors);
    auto* physics=PxCreatePhysics(PX_PHYSICS_VERSION,*foundation,PxTolerancesScale(),true);PxInitExtensions(*physics,NULL);unsigned failures=0;
    for(PxU32 workers:{0u,4u,8u})
    {
        auto* dispatcher=PxDefaultCpuDispatcherCreate(workers);PxSceneDesc desc(physics->getTolerancesScale());desc.cpuDispatcher=dispatcher;desc.filterShader=PxDefaultSimulationFilterShader;desc.solverType=PxSolverType::eAVBD;desc.gravity=PxVec3(0);
        auto* scene=physics->createScene(desc);auto* material=physics->createMaterial(0,0,0);PxArray<PxRigidStatic*> planes;
        for(unsigned k=0;k<65;++k){auto* floor=PxCreatePlane(*physics,PxPlane(0,1,0,0),*material);scene->addActor(*floor);planes.pushBack(floor);}
        auto* body=PxCreateDynamic(*physics,PxTransform(PxVec3(0,.501f,0)),PxBoxGeometry(.5f,.5f,.5f),*material,100);body->setLinearDamping(0);body->setAngularDamping(0);scene->addActor(*body);
        const auto initial=body->getGlobalPose();const auto before=errors.count;scene->simulate(1.f/60);const bool fetched=scene->fetchResults(true);
        const auto final=body->getGlobalPose();const bool unchanged=initial.p==final.p && initial.q==final.q && body->getLinearVelocity().isZero() && body->getAngularVelocity().isZero();
        double minGap=DBL_MAX;for(unsigned k=0;k<8;++k)minGap=PxMin(minGap,double(final.transform(PxVec3(k&1?.5f:-.5f,k&2?.5f:-.5f,k&4?.5f:-.5f)).y));
        const bool complete=fetched && errors.count==before && final.isSane() && body->getLinearVelocity().isFinite() && body->getAngularVelocity().isFinite() && minGap>0;
        const bool pass=complete;failures+=!pass;
        std::printf("[WORK_NATIVE_CAPACITY] workers=%u planes=65 particleBlocks=0 publicationRejected=%u stateUnchanged=%u completePhysicalHandling=%u minGap=%.9g errors=%u productionQualified=0 status=%s\n",workers,unsigned(errors.count==before+1),unsigned(unchanged),unsigned(complete),minGap,errors.count-before,pass?"PASS":"FAIL");
        body->release();for(auto* plane:planes)plane->release();material->release();scene->release();dispatcher->release();
    }
    PxCloseExtensions();physics->release();foundation->release();return failures?1:0;
}
