// Host API lifecycle and shared NP reporting; no private solver state.
#include "avbd_nodal_shell_fixture.h"
#include "avbd_nodal_events_fixture.h"
#include <cstdio>
#include <cstdlib>
#include <initializer_list>
using namespace physx;using AvbdShellTest::Shell;
struct Errors:PxErrorCallback
{
    unsigned count=0;
    void reportError(PxErrorCode::Enum c,const char* text,const char*,int) PX_OVERRIDE
    {if(c==PxErrorCode::eDEBUG_INFO || c==PxErrorCode::eDEBUG_WARNING)return;++count;std::printf("[SHELL_LIFE_ERROR] %s\n",text);}
};
int main()
{
    std::setvbuf(stdout,NULL,_IONBF,0);_putenv_s("PHYSX_AVBD_COMMON_STEP","work");_putenv_s("PHYSX_AVBD_LOCAL_ITERATIONS","4");_putenv_s("PHYSX_NP_GEOMETRY_CERTIFICATES","2");
    PxDefaultAllocator allocator;Errors errors;auto* foundation=PxCreateFoundation(PX_PHYSICS_VERSION,allocator,errors);auto* physics=PxCreatePhysics(PX_PHYSICS_VERSION,*foundation,PxTolerancesScale(),true);PxInitExtensions(*physics,NULL);unsigned failures=0;
    for(PxU32 workers:{0u,4u,8u})for(PxU32 mode=0;mode<8;++mode)
    {
        if(const char* selected=std::getenv("SHELL_LIFECYCLE_MODE"))if(mode!=std::strtoul(selected,NULL,10))continue;
        const auto before=errors.count;auto* dispatcher=PxDefaultCpuDispatcherCreate(workers);Events events;PxSceneDesc desc(physics->getTolerancesScale());desc.cpuDispatcher=dispatcher;desc.gravity=PxVec3(0);desc.filterShader=reportingFilter;desc.simulationEventCallback=&events;desc.solverType=PxSolverType::eAVBD;if(mode==6)desc.flags|=PxSceneFlag::eDISABLE_SLEEPING;auto* scene=physics->createScene(desc);
        Shell shell;bool pass=shell.create(*physics,*scene,PxVec3(0),mode==1?PxVec3(0,0,2):PxVec3(0),mode==2?.2f:0);
        auto* material=physics->createMaterial(mode==2?.1f:0,mode==2?.1f:0,0);
        const bool overlap=mode==0 || mode==3;const PxTransform pose=mode>=5?PxTransform(PxVec3(20,0,0)):overlap?PxTransform(PxVec3(.8f,.8f,0),PxQuat(PxPi/4,PxVec3(0,0,1))):PxTransform(PxVec3(0,0,mode==2?.34f:.55f));
        auto* rigid=PxCreateDynamic(*physics,pose,PxBoxGeometry(.3f,.3f,.3f),*material,100);rigid->setLinearDamping(0);rigid->setAngularDamping(0);scene->addActor(*rigid);events.a=shell.actor;events.b=rigid;
        if(mode<2)rigid->putToSleep();if(mode==3 || mode==4)shell.actor->setWakeCounter(0);if(mode==4)rigid->setLinearVelocity(PxVec3(0,0,-2));
        double rigidSpeed=0,shellSpeed=0;const PxU32 frames=overlap?30:(mode==2 || mode==7)?1:90;
        for(PxU32 f=0;f<frames && pass;++f)
        {
            const auto priorVelocity=rigid->getLinearVelocity();const auto priorImpulse=events.impulseOnB;
            scene->simulate(1.f/60);pass &= scene->fetchResults(true) && errors.count==before;rigidSpeed=PxMax(rigidSpeed,double(rigid->getLinearVelocity().magnitude()));
            if(mode==1 && std::getenv("NODAL_IMPULSE_TRACE"))
            {
                const auto v=rigid->getLinearVelocity()-priorVelocity;const auto change=PxVec3d(v.x,v.y,v.z)*rigid->getMass(),reported=events.impulseOnB-priorImpulse;
                std::printf("[NODAL_IMPULSE_FRAME] frame=%u reported=%.12g,%.12g,%.12g change=%.12g,%.12g,%.12g error=%.12g\n",f,reported.x,reported.y,reported.z,change.x,change.y,change.z,(reported-change).magnitude());
            }
            if(mode==0)pass &= rigid->isSleeping() && (rigid->getGlobalPose().p-pose.p).magnitude()<1.e-7;
            if(mode==3 && f>0)pass &= shell.actor->isSleeping();
            PxVec3d p(0),L(0);double energy=0;shell.momentum(p,L,energy);shellSpeed=PxMax(shellSpeed,p.magnitude()/shell.mass);
        }
        if(mode==1)
        {
            const auto v=rigid->getLinearVelocity();const auto momentum=PxVec3d(v.x,v.y,v.z)*rigid->getMass();
            const double norm=PxMax(1.e-9,momentum.magnitude());
            std::printf("[NODAL_IMPULSE_VECTOR] workers=%u reported=%.12g,%.12g,%.12g momentum=%.12g,%.12g,%.12g ratio=%.12g relativeError=%.12g\n",workers,events.impulseOnB.x,events.impulseOnB.y,events.impulseOnB.z,momentum.x,momentum.y,momentum.z,events.impulseOnB.magnitude()/norm,(events.impulseOnB-momentum).magnitude()/norm);
        }
        const float first=events.friction;const double ratio=mode==1?events.impulse/PxMax(1.e-9,double(rigid->getMass()*rigid->getLinearVelocity().magnitude())):0;
        if(overlap)pass &= !events.found && !events.persist && !events.points;
        if(mode==1)pass &= events.found>0 && events.points>0 && rigidSpeed>.01 && ratio>.8 && ratio<1.2;
        if(mode==4)pass &= events.found>0 && events.points>0 && shellSpeed>.01 && !shell.actor->isSleeping();
        if(mode==5)pass &= shell.actor->isSleeping() && shell.actor->getWakeCounter()==0;
        if(mode==6)pass &= !shell.actor->isSleeping() && shell.actor->getWakeCounter()>0;
        if(mode==2)
        {
            shell.material->setDynamicFriction(.8f);material->setDynamicFriction(.3f);material->setStaticFriction(.3f);material->setFrictionCombineMode(PxCombineMode::eMAX);
            scene->simulate(1.f/60);pass &= scene->fetchResults(true) && errors.count==before;pass &= std::abs(first-.15f)<1.e-6 && std::abs(events.friction-.8f)<1.e-6;
        }
        if(mode==7)
        {
            const auto initial=shell.actor->getPositionInvMassBufferH()[0];shell.material->setElasticityDamping(.1f);
            scene->simulate(1.f/60);pass &= scene->fetchResults(true);pass &= errors.count==before+1 && shell.actor->getPositionInvMassBufferH()[0]==initial;
        }
        if(mode==1 || mode==2 || mode==4)
        {
            rigid->setGlobalPose(PxTransform(PxVec3(20,0,0)));rigid->setLinearVelocity(PxVec3(0));scene->simulate(1.f/60);pass &= scene->fetchResults(true) && events.lost>0;
            scene->removeActor(*rigid);scene->addActor(*rigid);scene->simulate(1.f/60);pass &= scene->fetchResults(true);
        }
        pass &= errors.count==before+(mode==7?1:0) && events.invalid==0;failures+=!pass;
        const char* names[]={"overlap-without-touch","touch-wakes-rigid","material-edit","overlap-keeps-cloth-asleep","touch-wakes-cloth","natural-sleep","sleep-disabled","material-damping-edit-rejected"};
        std::printf("[SHELL_LIFECYCLE_SCENE] mode=%s workers=%u iterations=4 found=%u persists=%u lost=%u points=%u impulseNs=%.9g impulseRatio=%.9g firstFriction=%.9g friction=%.9g rigidSpeed=%.9g shellSpeed=%.9g sleeping=%u wake=%.9g errors=%u invalid=%u status=%s\n",names[mode],workers,events.found,events.persist,events.lost,events.points,events.impulse,ratio,first,events.friction,rigidSpeed,shellSpeed,unsigned(shell.actor->isSleeping()),double(shell.actor->getWakeCounter()),errors.count-before,events.invalid,pass?"PASS":"FAIL");
        shell.release();rigid->release();material->release();scene->release();dispatcher->release();
    }
    std::printf("[SHELL_LIFECYCLE_SUMMARY] failures=%u productionQualified=0\n",failures);PxCloseExtensions();physics->release();foundation->release();return failures?1:0;
}
