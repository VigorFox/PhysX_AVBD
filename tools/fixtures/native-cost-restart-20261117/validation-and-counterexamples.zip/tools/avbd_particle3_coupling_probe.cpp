// Virtual work and a mixed inertial/contact local solve. This checks the
// mapped operator, not Host candidate coverage or a complete collision scene.
#include "avbd/DyAvbdPointJacobian.h"
#include "avbd/DyAvbdNonlinearGroup.h"
#include "avbd/DyAvbdRowProgram.h"
#include "avbd/DyKernelTable.h"
#include "avbd/DyAvbdOgcActivation.h"
#include "avbd_probe_foundation.h"
#include <cstdio>
#include <initializer_list>
#include <float.h>
using namespace physx;using namespace physx::Dy;
int main()
{
    AvbdProbeFoundation foundation;const auto table=KernelTable::makeAvbdCpuScalar();
    unsigned failures=0,cases=0;double worstWork=0,worstMomentum=0,worstTorque=0;
    _clearfp();volatile double zeroStiffness=0;
    for(const auto gap:{-.01,.01,.1})
    {
        const auto value=avbdOGCNormalEnvelope(gap,0.,1.e5,.04,double(zeroStiffness));
        failures+=value.energy!=0 || value.force!=0 || value.hessian!=0;
    }
    failures+=(_statusfp()&(_SW_ZERODIVIDE|_SW_INVALID))!=0;
    failures+=avbdOGCNormalResolvent(2.,1.e5,0.,double(zeroStiffness))!=2.;
    // An aliased endpoint exercises canonical support reduction. Signed
    // weights also cover interpolation with an extrapolated material point.
    const unsigned ids[4]={0,1,0,2},members[4]={0,1,2,3};
    const PxVec3d p[3]={PxVec3d(-1,.2,.1),PxVec3d(1,.3,-.1),PxVec3d(.1,.5,1)};
    const double mass[4]={.3,2.,5.,7.};
    for(unsigned trial=0;trial<120;++trial)
    {
        const double w[4]={.1,.2,trial%2?-.1:.3,trial%2?.8:.4};
        const PxVec3d axis=PxVec3d(std::sin(1.+trial),std::cos(.3+trial),.4).getNormalized();
        PxVec3d point(0);for(unsigned k=0;k<4;++k)point+=p[ids[k]]*w[k];
        const PxVec3d center(.2,-.3,.4),arm=point-center;
        double J[4][6]={};
        for(unsigned k=0;k<4;++k)
        {const auto j=avbdPointLinearJacobian(axis,w[k]);for(unsigned d=0;d<3;++d)J[ids[k]][d]+=j[d];}
        const auto linear=avbdPointLinearJacobian(axis,-1.);
        const auto angular=avbdPointAngularJacobian(arm,linear);
        for(unsigned d=0;d<3;++d){J[3][d]=linear[d];J[3][d+3]=angular[d];}
        AvbdRowProgram program;
        failures+=!program.compile(1,4,[&](unsigned,const auto& emit){for(auto id:ids)emit(id);emit(3);return true;});
        failures+=program.rowBlocks.size()!=4;
        PxVec3d total(0),torque(0);double generalized=0;
        PxVec3d dp[3];for(unsigned i=0;i<3;++i)dp[i]=PxVec3d(.1*i,-.2,.03*trial);
        const PxVec3d dpRigid(.3,.1,-.1),angle(.01,-.02,.03);
        PxVec3d pointDelta(0);for(unsigned k=0;k<4;++k)pointDelta+=dp[ids[k]]*w[k];
        const double expected=axis.dot(pointDelta-dpRigid-angle.cross(arm));
        for(unsigned i=0;i<4;++i)
        {
            const PxVec3d f(J[i][0],J[i][1],J[i][2]);total+=f;
            torque+=(i<3?p[i]:center).cross(f);
            generalized+=f.dot(i<3?dp[i]:dpRigid);
        }
        torque+=angular;generalized+=angular.dot(angle);
        worstWork=PxMax(worstWork,std::abs(generalized-expected));
        worstTorque=PxMax(worstTorque,torque.magnitude());
        failures+=total.magnitude()>1.e-12;
        // A linearized contact correction acts on all four physical supports
        // through one force coordinate. Pure Particle3 nodes have no inertia
        // or unknowns in the angular slots of this mixed packet.
        AvbdNonlinearGroup group;group.count=4;
        const double dt=.016,rho=1.e5,gap=-.02;
        for(unsigned i=0;i<4;++i)
        {
            group.dimension[i]=i<3?3:6;
            for(unsigned d=0;d<group.dimension[i];++d)
            {group.K[i][i][7*d]=group.M[i][i][7*d]=(d<3?mass[i]:.7)/(dt*dt);group.gradient[i][d]=rho*gap*J[i][d];}
        }
        group.addRankOne(members,4,J,rho);
        AvbdNonlinearGroupArgs args={&group};table.launch(AVBD_NONLINEAR_GROUP,&args);
        failures+=!group.solved || group.scalarCount!=15;
        PxVec3d momentum(0),angularMomentum(0);
        for(unsigned i=0;i<4;++i)
        {
            const PxVec3d impulse=PxVec3d(group.step[i][0],group.step[i][1],group.step[i][2])*(mass[i]/dt);
            momentum+=impulse;angularMomentum+=(i<3?p[i]:center).cross(impulse);
        }
        angularMomentum+=PxVec3d(group.step[3][3],group.step[3][4],group.step[3][5])*(.7/dt);
        worstMomentum=PxMax(worstMomentum,momentum.magnitude());
        worstTorque=PxMax(worstTorque,angularMomentum.magnitude());++cases;
    }
    failures+=worstWork>1.e-12 || worstMomentum>1.e-11 || worstTorque>1.e-11;
    std::printf("[PARTICLE3_COUPLING] cases=%u virtualWork=%.9g momentum=%.9g torque=%.9g failures=%u\n",cases,worstWork,worstMomentum,worstTorque,failures);
    return failures?1:0;
}
