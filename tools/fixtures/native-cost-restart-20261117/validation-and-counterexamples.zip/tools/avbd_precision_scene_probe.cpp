// Public SDK only. Independent f64 observer; no internal packet ABI crossing.
#include "PxPhysicsAPI.h"
#include "foundation/PxSolverPrecision.h"
#include "extensions/PxDeformableVolumeExt.h"
#include "../physx/snippets/snippetdeformablevolumeavbd/SnippetDeformableVolumeAVBDCommon.h"
#include <cstdio>
#include <cstdlib>
#include <chrono>
#include <windows.h>
using namespace physx;
struct Errors:PxErrorCallback
{
    unsigned count=0;
    void reportError(PxErrorCode::Enum code,const char* message,const char*,int) PX_OVERRIDE
    {if(code==PxErrorCode::eDEBUG_INFO || code==PxErrorCode::eDEBUG_WARNING)return;++count;std::printf("[PRECISION_SCENE_ERROR] %s\n",message);}
};
static PxVec3d wide(const PxVec3& v){return PxVec3d(v.x,v.y,v.z);}
int main()
{
    _putenv_s("PHYSX_AVBD_COMMON_STEP","work");_putenv_s("PHYSX_AVBD_LOCAL_ITERATIONS","4");
    _putenv_s("PHYSX_NP_GEOMETRY_CERTIFICATES","2");_putenv_s("PHYSX_AVBD_COMMON_STATS","summary");
    PxDefaultAllocator allocator;Errors errors;auto* foundation=PxCreateFoundation(PX_PHYSICS_VERSION,allocator,errors);
    auto* physics=PxCreatePhysics(PX_PHYSICS_VERSION,*foundation,PxTolerancesScale(),true);PxInitExtensions(*physics,NULL);
    char loaded[MAX_PATH]={};GetModuleFileNameA(GetModuleHandleA("PhysX_64.dll"),loaded,MAX_PATH);
    std::printf("[PRECISION_DLL] path=%s\n",loaded);
    unsigned failures=0;
    for(unsigned mode=0;mode<2;++mode)
    {
        auto* dispatcher=PxDefaultCpuDispatcherCreate(4);PxSceneDesc desc(physics->getTolerancesScale());
        desc.cpuDispatcher=dispatcher;desc.filterShader=PxDefaultSimulationFilterShader;desc.solverType=PxSolverType::eAVBD;
        desc.gravity=mode?PxVec3(0):PxVec3(0,-9.81f,0);auto* scene=physics->createScene(desc);
        auto* mesh=VolumeAvbdSnippet::cookCube(*physics,PxVec3(0,3,0),1);
        auto* soft=physics->createDeformableVolume();auto* material=physics->createDeformableVolumeMaterial(2.e4f,.3f,0);
        material->setMaterialModel(PxDeformableVolumeMaterialModel::eNEO_HOOKEAN);
        auto* shape=physics->createShape(PxTetrahedronMeshGeometry(mesh->getCollisionMesh()),&material,1,true,PxShapeFlag::eSIMULATION_SHAPE);
        bool valid=soft && shape && soft->attachShape(*shape) && soft->attachSimulationMesh(*mesh->getSimulationMesh(),*mesh->getDeformableVolumeAuxData());
        if(!valid)return 2;shape->release();material->release();
        soft->setDeformableBodyFlag(PxDeformableBodyFlag::eDISABLE_SELF_COLLISION,true);soft->setLinearDamping(0);soft->setSleepThreshold(0);
        PxVec4 *p=NULL,*v=NULL,*c=NULL,*r=NULL;PxDeformableVolumeExt::allocateAndInitializeHostMirror(*soft,NULL,p,v,c,r);
        PxDeformableVolumeExt::updateMass(*soft,100,50,p);
        PxDeformableVolumeExt::copyToDevice(*soft,PxDeformableVolumeDataFlag::eALL,p,v,c,r);
        for(auto* buffer:{p,v,c,r})VolumeAvbdSnippet::hostFree(buffer);valid &= scene->addActor(*soft);
        auto* rigidMaterial=physics->createMaterial(0,0,0);auto* rigid=PxCreateDynamic(*physics,PxTransform(PxVec3(mode?1.3f:3.f,3,0)),PxBoxGeometry(.3f,.3f,.3f),*rigidMaterial,100);
        rigid->setLinearDamping(0);rigid->setAngularDamping(0);rigid->setSleepThreshold(0);if(mode)rigid->setLinearVelocity(PxVec3(-2,0,0));scene->addActor(*rigid);
        double totalMass=0;for(unsigned k=0;k<mesh->getSimulationMesh()->getNbVertices();++k)totalMass+=1./soft->getSimPositionInvMassBufferD()[k].w;
        const PxVec3d initialP=wide(rigid->getLinearVelocity())*rigid->getMass();
        const unsigned before=errors.count,requested=mode?180:120;unsigned completed=0;
        double positionError=0,velocityError=0,momentumError=0,transfer=0,simulationMs=0;
        for(unsigned frame=0;valid && frame<requested;++frame)
        {
            const auto begin=std::chrono::steady_clock::now();scene->simulate(1.f/60);valid=scene->fetchResults(true) && errors.count==before;
            simulationMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();if(!valid)break;++completed;
            PxVec3d center(0),momentum(0);p=soft->getSimPositionInvMassBufferD();v=soft->getSimVelocityBufferD();
            for(unsigned k=0;k<mesh->getSimulationMesh()->getNbVertices();++k)
            {valid &= p[k].isFinite() && v[k].isFinite();center+=wide(p[k].getXYZ())/p[k].w;momentum+=wide(v[k].getXYZ())/p[k].w;}
            center/=totalMass;transfer=PxMax(transfer,momentum.magnitude());
            if(!mode)
            {const double t=completed*double(1.f/60);positionError=PxMax(positionError,(center-PxVec3d(0,3,0)-wide(desc.gravity)*(.5*t*t)).magnitude());velocityError=PxMax(velocityError,(momentum/totalMass-wide(desc.gravity)*t).magnitude());}
            else momentumError=PxMax(momentumError,(momentum+wide(rigid->getLinearVelocity())*rigid->getMass()-initialP).magnitude()/PxMax(1.,initialP.magnitude()));
        }
        const bool pass=valid && completed==requested && (mode?momentumError<.01 && transfer>.1:positionError<.002 && velocityError<.002);
        failures+=!pass;std::printf("[PRECISION_SCENE] mode=%s compilerBits=%u frames=%u completed=%u positionError=%.9g velocityError=%.9g momentumError=%.9g transfer=%.9g meanMs=%.9g productionQualified=0 status=%s\n",mode?"mixed-impact":"local-fall",unsigned(PX_SOLVER_COMPUTE_BITS),requested,completed,positionError,velocityError,momentumError,transfer,simulationMs/PxMax(1u,completed),pass?"PASS":"FAIL");
        rigid->release();rigidMaterial->release();soft->release();mesh->release();scene->release();dispatcher->release();
    }
    PxCloseExtensions();physics->release();foundation->release();return failures?1:0;
}
