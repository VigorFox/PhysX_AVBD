from pathlib import Path
import re, shutil, subprocess, os
p=Path(__file__).resolve().parent
repo=p.parents[2]
build=repo/'physx/compiler/vc17win64-cpu-only/sdk_snippets_bin'
sdk=p/'sdk'
tune=os.getenv('RIG_BUILD_TUNE')=='1'
if tune:sdk=p/'tuned'
sdk.mkdir(exist_ok=True)
for dll in (repo/'physx/bin/win.x86_64.vc143.md/checked').glob('*.dll'):
    shutil.copyfile(dll,sdk/dll.name)
cmds=[]
for proj,stem in [('SnippetHelloWorld','SnippetHelloWorldHeadless'),('SnippetJoint','SnippetJointHeadless'),('SnippetChainmail','SnippetChainmailHeadless'),('SnippetArticulationRC','SnippetArticulationHeadless')]:
    if tune and proj!='SnippetChainmail':continue
    source=repo/'physx/snippets'/proj.lower()/(stem+'.cpp')
    s=source.read_text()
    def change(a,b):
        global s
        assert s.count(a)==1,(proj,a)
        s=s.replace(a,b)
    if proj=='SnippetChainmail':
        if tune:
            change('scene->addActor(*ground);','scene->addActor(*ground);const auto configure=[](PxRigidDynamic* body){if(const char* opt=std::getenv("RIG_CHAIN_TGS_POS"))body->setSolverIterationCounts(PxU32(std::atoi(opt)),1);};')
            change('nodes[i]->setAngularDamping', 'configure(nodes[i]);nodes[i]->setAngularDamping')
            change('ball->setAngularDamping', 'configure(ball);ball->setAngularDamping')
        change('if(!scene->simulate(dt))','const auto benchStart=RigBench::Clock::now();if(!scene->simulate(dt))')
        a='if(!scene->fetchResults(true)){++metrics.fetchFailures;return false;}'
        change(a,a+'RigBench::finish(benchStart,scene);')
    else:
        change('gScene->simulate(gOptions.dt);','const auto benchStart=RigBench::Clock::now();gScene->simulate(gOptions.dt);')
        a='const bool fetched = gScene->fetchResults(true, &errorState);'
        if a in s: change(a,a+'RigBench::finish(benchStart,gScene);')
        else: change('if(!gScene->fetchResults(true, &errorState))','const bool benchFetched=gScene->fetchResults(true,&errorState);RigBench::finish(benchStart,gScene);if(!benchFetched)')
    dest=p/(stem+('Tuned' if tune else ''))
    dest.mkdir(exist_ok=True)
    src=dest/source.name
    src.write_text('#include "../ProbeClock.h"\n'+s)
    def lines(tool):
        return next((build/(proj+'.dir/checked')).glob('*tlog/'+tool+'.command.1.tlog')).read_text(encoding='utf-16').splitlines()
    cl=next(l for l in lines('CL') if l.startswith('/c ') and l.upper().endswith(stem.upper()+'.CPP'))
    cl='/I"'+str(source.parent)+'" '+cl[:cl.upper().rindex(' D:')]+' "'+str(src)+'"'
    for opt,f in [('Fo','probe.obj'),('Fd','probe.pdb')]:
        cl=re.sub('/'+opt+r'"[^"]+"',lambda _: '/'+opt+'"'+str(dest/f)+'"',cl)
    ls=lines('link')
    i=next(i for i,l in enumerate(ls) if l.startswith('/OUT:'))
    link='\n'.join(ls[i:]).split('\n^')[0]
    for opt,file in [('OUT',sdk/(proj+'.exe')),('PDB',dest/'exe.pdb'),('IMPLIB',dest/'exe.lib')]:
        link=re.sub('/'+opt+r':"[^"]+"',lambda _: '/'+opt+':"'+str(file)+'"',link,flags=re.I)
    link=re.sub(r'/ILK:"[^"]+"','',link,flags=re.I).replace(' /INCREMENTAL ',' /INCREMENTAL:NO ')
    obj=str(Path(proj+'.dir')/'checked'/(stem+'.obj'))
    link=re.sub(re.escape(obj),lambda _: '"'+str(dest/'probe.obj')+'"',link,flags=re.I)
    assert str(dest/'probe.obj') in cl and str(dest/'probe.obj') in link
    for tool,raw in [('cl',cl),('link',link)]:
        rsp=dest/(tool+'.rsp');rsp.write_text(raw)
        cmds.append(tool+' @"'+str(rsp)+'"\nif errorlevel 1 exit /b 1')
batch=p/'build.cmd'
batch.write_text('@echo off\ncall "C:\\Program Files\\Microsoft Visual Studio\\2022\\Community\\VC\\Auxiliary\\Build\\vcvars64.bat" >nul\nif errorlevel 1 exit /b 1\n'+'\n'.join(cmds))
with (p/'build.log').open('wb') as f:
    r=subprocess.run(['cmd','/d','/c',batch],cwd=build,env=dict(os.environ,PATH=r'C:\Windows\System32;C:\Windows;C:\Windows\System32\Wbem'),stdout=f,stderr=subprocess.STDOUT)
if r.returncode: raise SystemExit((p/'build.log').read_text(errors='replace')[-3500:])
