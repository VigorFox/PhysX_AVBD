from pathlib import Path
import csv,json,statistics as st,os,subprocess,sys,time,math
p=Path(__file__).resolve().parent
raw=p/'runs';raw.mkdir(exist_ok=True)
cases={'stack-settle':('HelloWorld',600),'ball-shot':('HelloWorld',600),'hang-spherical':('Joint',180),'hang-d6':('Joint',180),'impact':('Chainmail',600),'scissor-cycle':('ArticulationRC',600)}
def gate(line):return dict(t.split('=',1) for t in line.split() if '=' in t)
def percentile(xs,q):return sorted(xs)[math.ceil(q*len(xs))-1]
def run(case,w,solver,rep,diag,tune=0):
    proj,frames=cases[case]
    stem=f'{case}_{w}_{solver}_{rep}'+(f'_pos{tune}' if tune else '');csvfile=raw/(stem+'.csv')
    target=raw/(stem+'.json')
    if target.exists():return
    env={k:v for k,v in os.environ.items() if not k.startswith(('RIG_BENCH_','PHYSX_AVBD_','PHYSX_SNIPPET_','PHYSX_NP_'))}
    env['RIG_BENCH_CSV']=str(csvfile)
    if diag:env['RIG_BENCH_STATS']='1'
    if tune:env['RIG_CHAIN_TGS_POS']=str(tune)
    cmd=[str(p/('tuned' if tune else 'sdk')/('Snippet'+proj+'.exe')),'--headless','--case='+case,'--solver='+solver,'--execution=parallel','--dispatcher-threads='+str(w),'--frames='+str(frames),'--seed=1']
    start=time.monotonic()
    proc=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,cwd=p/'sdk')
    elapsed=time.monotonic()-start
    log=proc.stdout.decode(errors='replace')
    (raw/(stem+'.log')).write_text(log,encoding='utf8')
    lines=[l for l in log.splitlines() if l.startswith('[AVBD_GATE]')]
    config=[l for l in log.splitlines() if l.startswith('[AVBD_GATE_CONFIG]')]
    if not lines or not csvfile.exists(): raise RuntimeError((cmd,log[-3000:]))
    g=gate(lines[-1])
    with csvfile.open() as f:rows=list(csv.DictReader(f))
    def stats(fr):
        times=[float(r['ms']) for r in fr]
        return dict(mean=st.mean(times),median=st.median(times),p95=percentile(times,.95),awake=st.mean(int(r['awake']) for r in fr),npPairs=st.mean(int(r['contacts']) for r in fr),count=len(fr))
    result=dict(case=case,workers=w,solver=solver,rep=rep,diag=diag,tune=tune,returncode=proc.returncode,elapsed=elapsed,config=gate(config[-1]),gate=g,frames=len(rows),request=[int(rows[0]['pos']),int(rows[0]['vel'])],all=stats(rows),first120=stats(rows[:120]),last120=stats(rows[-120:]))
    target.write_text(json.dumps(result,indent=2))
    print(stem,len(rows),g.get('status'),round(result['all']['mean'],4),'ms',round(elapsed,1),'s',flush=True)
def main():
    mode=sys.argv[1]
    if mode=='screen':
        for c in ('hang-spherical','hang-d6','stack-settle','ball-shot','impact','scissor-cycle'):
            for s in ('tgs','avbd'):run(c,4,s,0,True)
    elif mode=='bench':
        for n in (8,16,32,64,128):
            run('impact',4,'tgs',0,True,n)
        for r in range(1,4):
            n=next((n for n in (8,16,32,64,128) if json.loads((raw/f'impact_4_tgs_0_pos{n}.json').read_text())['gate']['status']=='PASS'),0)
            if n:run('impact',4,'tgs',r,False,n)
            for w in ((4,8) if r%2 else (8,4)):
                for c in (list(cases) if r%2 else list(reversed(cases))):
                    for s in (('avbd','tgs') if (r+(w==8))%2 else ('tgs','avbd')):run(c,w,s,r,False)
if __name__=='__main__':main()
