from pathlib import Path
import csv,json,statistics as st,subprocess,os,math,collections,hashlib
from run import p,raw,gate,cases
def records(stem):
    with (raw/(stem+'.csv')).open() as f:return list(csv.DictReader(f))
def val(v):return float(v['ms'])
def windows(c):
    out={'all':(1,cases[c][1])}
    if c=='stack-settle':out.update(active=(2,24),sleep=(481,600))
    if c=='impact':out.update(beforeImpact=(1,120))
    if c=='ball-shot':out.update(final120=(481,600))
    return out
def read(c,w,s,r):return json.loads((raw/f'{c}_{w}_{s}_{r}.json').read_text())
def med(xs):return st.median(xs)
def runstats(vals):
    return dict(mean=st.mean(vals),p95=sorted(vals)[math.ceil(len(vals)*.95)-1])
def profile():
    dest=p/'dispatch';dest.mkdir(exist_ok=True)
    diag={}
    for c in ['stack-settle','hang-d6','impact','scissor-cycle']:
        for w in [4,8]:
            outfile=dest/f'{c}_{w}.log'
            if not outfile.exists():
                env={k:v for k,v in os.environ.items() if not k.startswith(('RIG_BENCH_','PHYSX_AVBD_','PHYSX_SNIPPET_','PHYSX_NP_'))}
                env['PHYSX_AVBD_SCHEDULE_STATS']='1'
                proj=cases[c][0]
                cmd=[str(p/'sdk'/('Snippet'+proj+'.exe')),'--headless','--case='+c,'--solver=avbd','--execution=parallel','--dispatcher-threads='+str(w),'--frames=8','--seed=1']
                proc=subprocess.run(cmd,env=env,cwd=p/'sdk',stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
                outfile.write_bytes(proc.stdout)
            xs=[gate(l) for l in outfile.read_text(errors='replace').splitlines() if l.startswith('[AVBD_SCHEDULE]')]
            if not xs:continue
            diag[c+str(w)]={k:med([int(g[k]) for g in xs]) for k in ('blocks','colors','tasks','maxWidth','workers','peakTasks')}
    return diag
def summarize():
    output=dict(hardware='Intel Core i5-14600K (6P+8E), Windows x64, no CPU affinity applied',dllSHA256=hashlib.sha256((p/'sdk/PhysX_64.dll').read_bytes()).hexdigest(),build='Checked',method='three paired launches, solver order alternated, median of within-run mean and nearest-rank P95; stats captured separately. All timings in ms. Phase labels use 1-based frames.',summary={},physics={},tgsChainmailBudgetProbe={},shortScheduleDiagnostics=profile())
    for c in cases:
        for w in [4,8]:
            key=f'{c}/{w}'
            output['summary'][key]={}
            runs={s:[read(c,w,s,r) for r in range(1,4)] for s in ('avbd','tgs')}
            output['physics'][key]={s:dict(statusCounts=dict(collections.Counter(row['gate']['status'] for row in a)),representativeGate=a[0]['gate']) for s,a in runs.items()}
            for phase,(lo,hi) in windows(c).items():
                entry=dict(frames=[lo,hi])
                diag={}
                for s in ('avbd','tgs'):
                    batches=[runstats(list(map(val,records(f'{c}_{w}_{s}_{r}')[lo-1:hi]))) for r in range(1,4)]
                    entry[s]={k:med([x[k] for x in batches]) for k in ('mean','p95')}
                    entry[s]['runMeans']=[x['mean'] for x in batches]
                    if w==4:
                        rows=records(f'{c}_4_{s}_0')[lo-1:hi]
                        diag[s]={k:st.mean(int(x[k]) for x in rows) for k in ('awake','contacts')}
                if phase=='all' and any(row['gate']['status']!='PASS' for arm in runs.values() for row in arm):
                    entry['comparison']='Physical contract failed in at least one run. Individual timings are diagnostic only.'
                    entry['ratio']=None
                else:
                    if c=='impact' and phase=='beforeImpact':
                        assert all(int(row['gate']['firstContactFrame'])>hi for arm in runs.values() for row in arm)
                        entry['comparison']='Pre-impact joint workload only. Net load-bearing performance is unmeasured in this window.'
                    entry['ratio']=entry['avbd']['mean']/entry['tgs']['mean']
                if w==4:entry['separateWorkloadProbe']=diag
                output['summary'][key][phase]=entry
    for n in (8,16,32,64,128):
        row=json.loads((raw/f'impact_4_tgs_0_pos{n}.json').read_text())
        output['tgsChainmailBudgetProbe'][n]=dict(pos=row['request'][0],vel=row['request'][1],status=row['gate']['status'],reason=row['gate']['detail'],ballFinalY=row['gate']['finalBallY'],reboundRise=row['gate']['reboundRise'],maxJointError=row['gate']['maxJointError'])
    (p/'assessment.json').write_text(json.dumps(output,indent=2),encoding='utf8')
    for k,a in output['summary'].items():
        for phase,b in a.items():print(k,phase,*[round(z,3) if z is not None else 'N/A' for z in (b['avbd']['mean'],b['tgs']['mean'],b['ratio'],b['avbd']['p95'],b['tgs']['p95'])])
    print('schedule',output['shortScheduleDiagnostics'])
if __name__=='__main__':summarize()
