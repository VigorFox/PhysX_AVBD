#pragma once
#include "PxPhysicsAPI.h"
#include <chrono>
#include <vector>
#include <cstdio>
#include <cstdlib>
namespace RigBench {
using Clock=std::chrono::steady_clock;
struct Frame {double ms; int awake, contacts, joints, pos, vel;};
struct Collector {
 std::vector<Frame> frames;
 std::vector<physx::PxActor*> bodies;
 const bool stats=std::getenv("RIG_BENCH_STATS")!=nullptr;
 Collector(){frames.reserve(1024);}
 ~Collector(){
  const char* name=std::getenv("RIG_BENCH_CSV");if(!name)return;
  FILE* f=std::fopen(name,"w"); if(!f)return;
  std::fprintf(f,"frame,ms,awake,contacts,joints,pos,vel\n");
  unsigned frame=0;for(const Frame& row:frames)std::fprintf(f,"%u,%.8f,%d,%d,%d,%d,%d\n",++frame,row.ms,row.awake,row.contacts,row.joints,row.pos,row.vel);
  std::fclose(f);
 }
};
static Collector sample;
inline void finish(Clock::time_point begin,physx::PxScene* scene){
 const auto end=Clock::now();
 Frame record={std::chrono::duration<double,std::milli>(end-begin).count(),-1,-1,-1,-1,-1};
 if(sample.stats){
  using namespace physx;
  PxSimulationStatistics st;scene->getSimulationStatistics(st);
  record.contacts=int(st.nbDiscreteContactPairsTotal);record.joints=int(st.nbActiveConstraints);record.awake=0;
  const auto type=PxActorTypeFlag::eRIGID_DYNAMIC;
  const PxU32 count=scene->getNbActors(type);
  sample.bodies.resize(count);
  if(count)scene->getActors(type,sample.bodies.data(),count);
  for(auto actor:sample.bodies){const auto* body=static_cast<const PxRigidDynamic*>(actor);
   if(body->getRigidBodyFlags()&PxRigidBodyFlag::eKINEMATIC)continue;
   record.awake+=!body->isSleeping();
   if(record.pos<0){PxU32 pos,vel;body->getSolverIterationCounts(pos,vel);record.pos=int(pos);record.vel=int(vel);}
  }
 }
 sample.frames.push_back(record);
}
}
