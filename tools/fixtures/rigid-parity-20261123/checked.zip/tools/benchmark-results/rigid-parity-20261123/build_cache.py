from pathlib import Path
import os,re,shutil,sys
p=Path(__file__).resolve().parent
sys.path.insert(0,str(p.parents[2]/'experiments/avbd_contact_lab'))
import build_five_parallel as b
folder=p/'cached'
if not (folder/'original').exists():shutil.copytree(p/'original',folder/'original',copy_function=os.link)
shutil.copytree(p/'src',folder/'src',dirs_exist_ok=True)
src=folder/'src/avbd'
f=src/'DyAvbdSolve.cpp'
s=f.read_text()
s=s[:s.index('static PxReal avbdMaterialAxisVelocity(')]+s[s.index('static void avbdApplyMaterialAxisImpulse('):]
s=s.replace('void AvbdDynamicsContext::applyImpactMaterial(', '#include "RigidMaterialTrial.inl"\n\nvoid AvbdDynamicsContext::applyImpactMaterial(')
shutil.copyfile(p/'RigidMaterialTrial.inl',src/'RigidMaterialTrial.inl')
a=s.index('if(rigidtrial::tracing){rigidtrial::cur.material=true;')
z=s.index('if(rigidtrial::tracing)rigidtrial::cur.solved=',a)
part=s[a:z]
for k,axis in enumerate(('n','t0','t1')):
    part,nv=re.subn(r'avbdMaterialAxisVelocity\(\s*row,\s*material,\s*mBodies,\s*velocityDelta,\s*row\.scalar\(\)\.'+axis+r'(?:,\s*material\.normalLinearOnly != 0)?\)',f'compiled[mi].speed({k},velocityDelta)',part)
    part,ni=re.subn(r'avbdApplyMaterialAxisImpulse\(\s*row,\s*material,\s*mBodies,\s*velocityDelta,\s*row\.scalar\(\)\.'+axis+r',\s*(newJ - oldJ|next0 - old0|next1 - old1)(?:,\s*material\.normalLinearOnly != 0)?\)',lambda m:f'compiled[mi].apply({k}, {m[1]}, velocityDelta)',part)
    assert nv==(4 if k==0 else 2) and ni==(2 if k==0 else 1),(k,nv,ni)
# Leave original Coulomb projection and material-state updates intact.
part=part.replace('const AvbdRowConstRef& row = mRows[ri];','const AvbdRowConstRef& row = mRows[ri];PX_UNUSED(row);').replace('const AvbdRowConstRef& row = mRows[material.rowIndex];','const AvbdRowConstRef& row = mRows[material.rowIndex];PX_UNUSED(row);')
s=s[:a]+'''PxArray<TrialMaterialContact> compiled;
    compiled.resize(mMaterialRowsScratch.size());
    for(PxU32 i=0;i<compiled.size();++i)compiled[i].compile(mRows[mMaterialRowsScratch[i].rowIndex],mMaterialRowsScratch[i],mBodies);
    '''+part+s[z:]
f.write_text(s)
b.build(folder)
shutil.copyfile(p/'sdk/SnippetHelloWorld.exe',folder/'sdk/SnippetHelloWorld.exe')
