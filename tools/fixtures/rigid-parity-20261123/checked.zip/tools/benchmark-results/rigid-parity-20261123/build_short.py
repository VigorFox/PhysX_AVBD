from pathlib import Path
import os,shutil,sys
p=Path(__file__).resolve().parent
sys.path.insert(0,str(p.parents[2]/'experiments/avbd_contact_lab'))
import build_five_parallel as b
folder=p/'short'
if not (folder/'original').exists():shutil.copytree(p/'original',folder/'original',copy_function=os.link)
shutil.copytree(p/'cached/src',folder/'src',dirs_exist_ok=True)
f=folder/'src/avbd/DyAvbdSolve.cpp'
s=f.read_text()
start=s.index('PxArray<TrialMaterialContact> compiled;')
end=s.index('// Recover support wrenches',start)
a=s[start:end]
needle='iter < AVBD_MATERIAL_MAX_ITERS'
assert a.count(needle)==2
a=a.replace(needle,'iter < sweepLimit')
a='const PxU32 sweepLimit=std::getenv("RIG_SHORT") ? 2u : AVBD_MATERIAL_MAX_ITERS;\n    PxReal residuals[2]={0,0};\n    '+a
needle='if(maxNaturalResidual <= AVBD_MATERIAL_REL_TOL * velocityScale)'
assert a.count(needle)==2
parts=a.split(needle)
a=parts[0]+'residuals[0]=maxNaturalResidual/velocityScale;\n        '+needle+parts[1]+'residuals[1]=maxNaturalResidual/velocityScale;\n        '+needle+parts[2]
a+='if(rigidtrial::tracing)std::fprintf(stderr,"[RIG_RESIDUAL] normal=%.9g jointCone=%.9g tolerance=%.9g rows=%u\\n",double(residuals[0]),double(residuals[1]),double(AVBD_MATERIAL_REL_TOL),compiled.size());\n    '
f.write_text(s[:start]+a+s[end:])
b.build(folder)
shutil.copyfile(p/'sdk/SnippetHelloWorld.exe',folder/'sdk/SnippetHelloWorld.exe')
