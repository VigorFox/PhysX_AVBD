// Cached coefficients for the frozen velocity epoch. Deltas still update in row order.
struct TrialMaterialAxis
{
    PxVec3 axis;
    PxVec3 angular[2];
    PxVec3 angularResponse[2];
    double base;
};
struct TrialMaterialContact
{
    PxU32 ids[2];
    PxReal masses[2];
    TrialMaterialAxis axes[3];
    void compile(const AvbdRowConstRef& row,const AvbdMaterialRow& material,const PxArray<AvbdSolverBody>& bodies)
    {
        ids[0]=row.header().bodyA; ids[1]=row.header().bodyB;
        const PxVec3 arms[2]={material.armA,material.armB};
        axes[0].axis=row.scalar().n; axes[1].axis=row.scalar().t0; axes[2].axis=row.scalar().t1;
        for(PxU32 k=0;k<3;++k)axes[k].base=0;
        for(PxU32 s=0;s<2;++s)
        {
            masses[s]=0;
            if(ids[s]>=bodies.size() || !bodies[ids[s]].core){ids[s]=PX_MAX_U32;continue;}
            const AvbdSolverBody& body=bodies[ids[s]];
            const bool responds=avbdBodyResponds(body);
            masses[s]=responds?body.invMass:0;
            const double sign=s?-1.:1.;
            for(PxU32 k=0;k<3;++k)
            {
                TrialMaterialAxis& v=axes[k];
                const PxVec3 a=v.axis;
                const PxVec3 j=(k==0 && material.normalLinearOnly)?PxVec3(0):arms[s].cross(a);
                v.angular[s]=j;
                v.angularResponse[s]=responds?avbdWorldInvInertiaMul(body,j):PxVec3(0);
                const auto l=body.outputLinVel,w=body.outputAngVel;
                v.base+=sign*(double(a.x)*l.x+double(a.y)*l.y+double(a.z)*l.z+
                    double(j.x)*w.x+double(j.y)*w.y+double(j.z)*w.z);
            }
        }
    }
    PX_FORCE_INLINE PxReal speed(PxU32 k,const PxArray<AvbdMaterialVelocityDelta>& delta)const
    {
        const TrialMaterialAxis& v=axes[k];
        double speed=v.base;
        for(PxU32 s=0;s<2;++s)if(masses[s]>0)
        {
            const auto& d=delta[ids[s]];
            const auto j=v.angular[s];
            const double dv=v.axis.x*d.linear[0]+v.axis.y*d.linear[1]+v.axis.z*d.linear[2]+
                j.x*d.angular[0]+j.y*d.angular[1]+j.z*d.angular[2];
            speed+=s?-dv:dv;
        }
        return PxReal(speed);
    }
    PX_FORCE_INLINE void apply(PxU32 k,double impulse,PxArray<AvbdMaterialVelocityDelta>& delta)const
    {
        if(!PxIsFinite(PxReal(impulse)) || PxAbs(PxReal(impulse))<1.0e-12f)return;
        const TrialMaterialAxis& v=axes[k];
        for(PxU32 s=0;s<2;++s)if(masses[s]>0)
        {
            const double signedImpulse=s?-impulse:impulse;
            auto& d=delta[ids[s]];
            d.addLinear(v.axis,signedImpulse*double(masses[s]));
            d.addAngular(v.angularResponse[s],signedImpulse);
        }
    }
};
