from pathlib import Path
import sys,shutil
p=Path(__file__).resolve().parent
repo=p.parents[2]
sys.path.insert(0,str(repo/'experiments/avbd_contact_lab'))
import build_five_parallel as b
if not (p/'original').exists():b.snapshot(p)
src=p/'src'/'avbd'
shutil.copytree(p/'original'/'avbd',src,dirs_exist_ok=True)
def change(s,a,v):
    if s.count(a)!=1:raise ValueError((a,s.count(a)))
    return s.replace(a,v)
header=r'''#pragma once
#include <chrono>
#include <cstdlib>
namespace rigidtrial {
using Clock=std::chrono::steady_clock;
struct Probe{
 Clock::time_point start,prepared,finish,normal,friction,solved;
 int n=0,f=0; bool material=false;
};
extern Probe cur;
extern const bool tracing,greedy,four;
inline double ms(Clock::time_point a,Clock::time_point b){return std::chrono::duration<double,std::milli>(b-a).count();}
}
'''
(src/'RigidTrial.h').write_text(header)
f=src/'DyAvbdDynamics.cpp'
s=f.read_text()
s='#include "RigidTrial.h"\nnamespace rigidtrial {Probe cur; const bool tracing=std::getenv("RIG_TRACE")!=nullptr, greedy=std::getenv("RIG_GREEDY")!=nullptr, four=std::getenv("RIG_FOUR")!=nullptr;}\n'+s
s=change(s,'mStep=StepState();','mStep=StepState();if(rigidtrial::tracing){rigidtrial::cur={};rigidtrial::cur.start=rigidtrial::Clock::now();}')
s=change(s,'mStep.localBudget?order.size():reorderableCount','(mStep.localBudget || (rigidtrial::greedy && !mStep.hasParticleBlocks && mJoints.empty() && mArticJoints.empty()))?order.size():reorderableCount')
s=change(s,'mIterations = AVBD_ITERS_CONTACT;','mIterations = rigidtrial::four ? 4u : AVBD_ITERS_CONTACT;')
s=change(s,'if (!mStep.sweepPrepared)\n\t\t{','if (!mStep.sweepPrepared)\n\t\t{\n            if(rigidtrial::tracing && !mStep.iteration)rigidtrial::cur.prepared=rigidtrial::Clock::now();')
s=change(s,'void AvbdDynamicsContext::finishStep()\n{','void AvbdDynamicsContext::finishStep()\n{\n    if(rigidtrial::tracing)rigidtrial::cur.finish=rigidtrial::Clock::now();')
s=change(s,'complete:\n    PX_DELETE(mLocalWork)',r'''complete:
    if(rigidtrial::tracing && rigidtrial::cur.prepared!=rigidtrial::Clock::time_point{}){
      using namespace rigidtrial;
      const auto end=Clock::now();const Probe& q=cur;
      const double normal=q.material?ms(q.normal,q.friction):0.0, friction=q.material?ms(q.friction,q.solved):0.0;
      std::fprintf(stderr,"[RIG_TRIAL] prep=%.8f primalDual=%.8f finalOther=%.8f normal=%.8f friction=%.8f ns=%d fs=%d rows=%u colors=%u tasks=%u budget=%u\n",
        ms(q.start,q.prepared),ms(q.prepared,q.finish),ms(q.finish,end)-normal-friction,normal,friction,q.n,q.f,mNpContactRowCount,mColorOffsets.empty()?0:mColorOffsets.size()-1,mStep.submittedTasks,mStep.iterationLimit);
    }
    PX_DELETE(mLocalWork)''')
f.write_text(s)
f=src/'DyAvbdSolve.cpp';s=f.read_text()
s='#include "RigidTrial.h"\n'+s
a='for(PxU32 iter = 0; iter < AVBD_MATERIAL_MAX_ITERS; ++iter)\n\t{'
assert s.count(a)==2
parts=s.split(a)
s=parts[0]+'if(rigidtrial::tracing){rigidtrial::cur.material=true;rigidtrial::cur.normal=rigidtrial::Clock::now();}\n\t'+a+'\n\t\tif(rigidtrial::tracing)++rigidtrial::cur.n;\n'+parts[1]+'if(rigidtrial::tracing)rigidtrial::cur.friction=rigidtrial::Clock::now();\n\t'+a+'\n\t\tif(rigidtrial::tracing)++rigidtrial::cur.f;\n'+parts[2]
s=change(s,'// Recover support wrenches from the very impulse accepted by material.','if(rigidtrial::tracing)rigidtrial::cur.solved=rigidtrial::Clock::now();\n\t// Recover support wrenches from the very impulse accepted by material.')
f.write_text(s)
b.build(p)
prev=p.parent/'rigid-tgs-20261123/sdk'
shutil.copyfile(prev/'SnippetHelloWorld.exe',p/'sdk'/'SnippetHelloWorld.exe')
