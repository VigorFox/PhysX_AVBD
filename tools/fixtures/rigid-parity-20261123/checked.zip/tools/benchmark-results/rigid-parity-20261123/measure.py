from pathlib import Path
import os,subprocess,json,csv,statistics as st,sys,math
p=Path(__file__).resolve().parent
prev=p.parent/'rigid-tgs-20261123'/'sdk'
out=p/'runs';out.mkdir(exist_ok=True)
cases={'stack-settle':600,'ball-shot':600,'sub-bounce-stack':360,'sleep-disabled':180,'lock-flags':120}
def fields(line):return dict(t.split('=',1) for t in line.split() if '=' in t)
def run(c,mode,r,trace=False):
    name=f'{c}_{mode}_{r}';dest=out/(name+'.json')
    if dest.exists():return json.loads(dest.read_text())
    root=prev if mode in ['avbd','tgs'] else (p/'short'/'sdk' if mode.startswith('audit') else (p/'cached'/'sdk' if 'cache' in mode else p/'sdk'))
    env={k:v for k,v in os.environ.items() if not k.startswith(('RIG_','PHYSX_AVBD_','PHYSX_NP_','PHYSX_SNIPPET_'))}
    if 'greedy' in mode:env['RIG_GREEDY']='1'
    if 'four' in mode:env['RIG_FOUR']='1'
    if 'cache' in mode:env['RIG_CACHE']='1'
    if 'short' in mode:env['RIG_SHORT']='1'
    if trace:env['RIG_TRACE']='1'
    if r==0:env['RIG_BENCH_STATS']='1'
    src=out/(name+'.csv')
    env['RIG_BENCH_CSV']=str(src)
    args=[root/'SnippetHelloWorld.exe','--headless','--case='+c,'--solver='+('tgs' if mode=='tgs' else 'avbd'),'--frames='+str(cases[c]),'--execution=parallel','--dispatcher-threads=4','--seed=1']
    proc=subprocess.run(args,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    data=proc.stdout.decode(errors='replace').splitlines();(out/(name+'.log')).write_text('\n'.join(data))
    gates=[fields(l) for l in data if l.startswith('[AVBD_GATE]')]
    if not gates or not src.exists(): raise RuntimeError((c,mode,data[-5:]))
    gate=gates[-1]
    with src.open() as f: rows=list(csv.DictReader(f))
    assert len(rows)==cases[c] and int(gate['completedFrames'])==cases[c],(name,gate)
    vals=[float(x['ms']) for x in rows]
    pref=vals[1:24]
    prof=[fields(l) for l in data if l.startswith('[RIG_TRIAL]')]
    res=dict(case=c,mode=mode,rep=r,gate=gate,mean=st.mean(vals),active=st.mean(pref),p95=sorted(vals)[math.ceil(len(vals)*.95)-1],activeP95=sorted(pref)[math.ceil(len(pref)*.95)-1],late=st.mean(vals[-60:]))
    if prof:
        selection=prof[1:24] if c=='stack-settle' else prof
        divisor=len(selection) if c=='stack-settle' else len(vals)
        res['profileRecords']=len(prof)
        res['profile']={k:sum(float(x[k]) for x in selection)/divisor for k in selection[0]}
    dest.write_text(json.dumps(res,indent=2));print(name,gate['status'],gate['reason'],round(res['mean'],3),round(res['active'],3),res.get('profile',''),flush=True)
    return res
if __name__=='__main__':
    action=sys.argv[1]
    if action=='sleep':
        cases.update({'sleep-idle':180,'sleep-wake':360})
        for c in ('sleep-idle','sleep-wake'):
            for v in ('avbd','tgs','cache-greedy-four'):run(c,v,10)
    if action=='probe':
        for c in ('stack-settle','ball-shot','sub-bounce-stack','sleep-disabled','lock-flags'):
            for v in (['control','greedy','four','greedy-four'] if c in ('stack-settle','ball-shot') else ['control','greedy-four']):
                run(c,v,0,True)
    if action=='measure':
        for r in (1,2,3):
            for c in (cases if r%2 else reversed(cases)):
                variants=['tgs','avbd','greedy-four']
                if c in ('stack-settle','ball-shot'):variants+=['greedy','four']
                for v in (variants if r%2 else reversed(variants)):run(c,v,r)
    if action=='cached':
        for c in cases:
            run(c,'cache-greedy-four',0,True)
        for r in (4,5,6):
            for c in (cases if r%2 else reversed(cases)):
                variants=['tgs','avbd','control','cache','cache-greedy-four']
                if c in ('ball-shot','stack-settle'):variants.insert(3,'greedy-four')
                rotation=r%len(variants)
                variants=variants[rotation:]+variants[:rotation]
                for v in (variants if r%2 else reversed(variants)):run(c,v,r)
    if action=='short':
        for c in ('stack-settle','ball-shot','sub-bounce-stack'):
            for v in ('audit-greedy-four','audit-short-greedy-four'):run(c,v,0,True)
        for r in (7,8,9):
            for c in ('stack-settle','ball-shot','sub-bounce-stack'):
                modes=('tgs','audit-greedy-four','audit-short-greedy-four')
                for v in (modes if r%2 else reversed(modes)):run(c,v,r)
        for r in (20,21):
            for c in ('stack-settle','ball-shot'):
                modes=('control','cache-greedy-four')
                for v in (modes if r%2 else reversed(modes)):run(c,v,r,True)
