from pathlib import Path
import statistics as st,json,csv,math,hashlib
from measure import p,out,cases,fields
def read(c,v,r):return json.loads((out/f'{c}_{v}_{r}.json').read_text())
def pct(xs,q):return sorted(xs)[math.ceil(len(xs)*q)-1]
def summarize(c,v,reps):
    runs=[read(c,v,r) for r in reps]
    assert all(int(a['gate']['completedFrames'])==cases[c] for a in runs)
    key='active' if c=='stack-settle' else 'mean'
    return dict(costMs=st.median(a[key] for a in runs),p95Ms=st.median(a['activeP95' if key=='active' else 'p95'] for a in runs),runMeansMs=[a[key] for a in runs],status=[a['gate']['status'] for a in runs],metrics={k:runs[0]['gate'][k] for k in ('maxEnergyRatio','firstHitFrame','responseMomentumRatio','sunkBodies','maxPenetration','lateAwakeRatio','reason') if k in runs[0]['gate']})
result=dict(build='Checked',cpu='i5-14600K',workers=4,dt='1/60',seed=1,method='Median of three paired run means for simulate+fetchResults. stack-settle uses fixed frames 2-24, other scenes use all frames. P95 is the median within-run P95. Stage diagnostics are separate from timings.',productionSHA256=hashlib.sha256((p.parent/'rigid-tgs-20261123/sdk/PhysX_64.dll').read_bytes()).hexdigest(),description={'avbd':'Production default','control':'Isolated, relinked default using unchanged equations','cache':'Precompiled material J and inverse-mass Jacobian actions per admitted contact row for this step, default sweep policy','greedy-four':'Conflict coloring + four pure-contact primal sweeps, original material algebra','cache-greedy-four':'Both experiments together, same material stopping policy','audit-short-greedy-four':'Combined candidate, additionally capped at two normal and two coupled material iterations'},experiments={},shortMaterial={},stages={})
for c in cases:
    e=result['experiments'][c]={}
    variants=['tgs','avbd','control','cache','cache-greedy-four']
    if c in ('stack-settle','ball-shot'):variants.append('greedy-four')
    for v in variants:e[v]=summarize(c,v,(4,5,6))
    for v,d in e.items():
        d['timeOverTgs']=d['costMs']/e['tgs']['costMs']
    if c in ('stack-settle','ball-shot'):
        for v in ('control','cache-greedy-four'):
            rows=[read(c,v,r)['profile'] for r in (0,20,21)]
            result['stages'].setdefault(c,{})[v]={k:st.median(a[k] for a in rows) for k in rows[0]}
        dr=read(c,'control',0)
        with (out/f'{c}_control_0.csv').open() as f:x=list(csv.DictReader(f))
        if c=='stack-settle':x=x[1:24]
        e['avbd']['diagnosticMeanAwake']=st.mean(int(a['awake']) for a in x)
        e['avbd']['diagnosticMeanPairs']=st.mean(int(a['contacts']) for a in x)
for c in ('stack-settle','ball-shot','sub-bounce-stack'):
    res=result['shortMaterial'][c]={}
    for v in ('tgs','audit-greedy-four','audit-short-greedy-four'):
        res[v]=summarize(c,v,(7,8,9))
        if v=='tgs':continue
        residuals=[fields(l) for l in (out/f'{c}_{v}_0.log').read_text().splitlines() if l.startswith('[RIG_RESIDUAL]')]
        if c=='stack-settle':residuals=residuals[1:24]
        rows=[m for m in residuals if int(m['rows'])]
        if rows:res[v]['residual']={k:dict(p50=st.median(float(m[k]) for m in rows),p95=pct([float(m[k]) for m in rows],.95),max=max(float(m[k]) for m in rows),aboveTolerance=sum(float(m[k])>float(m['tolerance']) for m in rows),count=len(rows)) for k in ('normal','jointCone')}
result['additionalSleepGates']={c:{v:read(c,v,10)['gate']['status'] for v in ('avbd','tgs','cache-greedy-four')} for c in ('sleep-idle','sleep-wake')}
(p/'assessment.json').write_text(json.dumps(result,indent=2))
for c,m in result['experiments'].items():print(c,[(v,round(d['costMs'],3),round(d['timeOverTgs'],2),d['status']) for v,d in m.items()])
for c,m in result['shortMaterial'].items():
    print('short',c,[(v,round(d['costMs'],3),d['status'],d.get('residual',{}).get('jointCone')) for v,d in m.items()])
for c,m in result['stages'].items():print('stage',c,m)
