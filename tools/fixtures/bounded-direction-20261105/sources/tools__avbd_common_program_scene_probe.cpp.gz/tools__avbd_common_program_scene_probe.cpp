#include "PxPhysicsAPI.h"
#include <cstring>
#include "../physx/snippets/snippetjointsoftbody/SnippetFiniteJoint.h"
#include "../physx/snippets/snippetjointsoftbody/SnippetVolumeMaterial.h"
#include <cstdio>
#include <cstdlib>
using namespace physx;
struct Frame:PxConstraintConnector
{
    JointSoftBodySnippet::FiniteJointData data;PxConstraint* constraint=NULL;
    void* prepareData() PX_OVERRIDE{return &data;}
    void onConstraintRelease() PX_OVERRIDE{constraint=NULL;}
    void onComShift(PxU32) PX_OVERRIDE{if(constraint)constraint->markDirty();}
    void onOriginShift(const PxVec3&) PX_OVERRIDE{}
    void* getExternalReference(PxU32& id) PX_OVERRIDE{id=PxConcreteType::eFIRST_USER_EXTENSION+1;return this;}
    bool updatePvdProperties(pvdsdk::PvdDataStream&,const PxConstraint*,PxPvdUpdateType::Enum) const PX_OVERRIDE{return false;}
    void updateOmniPvdProperties() const PX_OVERRIDE{}
    PxBase* getSerializable() PX_OVERRIDE{return NULL;}
    PxConstraintSolverPrep getPrep() const PX_OVERRIDE{return JointSoftBodySnippet::finiteJointPrep;}
    const void* getConstantBlock() const PX_OVERRIDE{return &data;}
};
struct Modify:PxContactModifyCallback
{
    float impulse=PX_MAX_F32;
    void onContactModify(PxContactModifyPair* const pairs,PxU32 count) PX_OVERRIDE
    {for(PxU32 p=0;p<count;++p)for(PxU32 i=0;i<pairs[p].contacts.size();++i)pairs[p].contacts.setMaxImpulse(i,impulse);}
};
static bool useModification=true;
static PxFilterFlags filter(PxFilterObjectAttributes,PxFilterData,PxFilterObjectAttributes,PxFilterData,
    PxPairFlags& flags,const void*,PxU32)
{flags=PxPairFlag::eCONTACT_DEFAULT;if(useModification)flags|=PxPairFlag::eMODIFY_CONTACTS;return PxFilterFlag::eDEFAULT;}
// Independent analytic chain, deliberately crossing three four-body execution
// groups. The original isotropic frame energy is exactly k/2 |x_i-x_j|^2.
// Compare against its tridiagonal implicit solution, not solver internals.
static bool chain(PxPhysics& physics,PxScene& scene,unsigned N)
{
    const double stiffness=1000,dt=double(1.f/60);
    PxArray<PxRigidDynamic*> bodies(N,NULL);PxArray<Frame> frames(N-1);
    PxArray<double> diagonal(N),rhs(N),expected(N);double initialMomentum=0;
    scene.setGravity(PxVec3(0));
    for(unsigned i=0;i<N;++i)
    {
        const float mass=1+.1f*i,velocity=.2f*(int(i%5)-2);
        bodies[i]=physics.createRigidDynamic(PxTransform(PxIdentity));bodies[i]->setMass(mass);
        bodies[i]->setMassSpaceInertiaTensor(PxVec3(1));bodies[i]->setSleepThreshold(0);
        bodies[i]->setLinearDamping(0);bodies[i]->setAngularDamping(0);
        bodies[i]->setLinearVelocity(PxVec3(velocity,0,0));scene.addActor(*bodies[i]);
        diagonal[i]=double(mass)/(dt*dt)+stiffness*(unsigned(i>0)+unsigned(i+1<N));
        rhs[i]=double(mass)*double(velocity)/dt;initialMomentum+=double(mass)*double(velocity);
        if(i)
        {
            Frame& f=frames[i-1];for(unsigned end=0;end<2;++end)f.data.c2b[end]=PxTransform(PxIdentity);
            for(unsigned d=0;d<6;++d)f.data.drives[d]=PxD6JointDrive(d<3?float(stiffness):0,0,PX_MAX_F32,false);
            PxConstraintShaderTable shaders={JointSoftBodySnippet::finiteJointPrep,NULL,PxConstraintFlag::eCOLLISION_ENABLED};
            shaders.elasticFramePrep=JointSoftBodySnippet::finiteJointMaterialPrep;
            f.constraint=physics.createConstraint(bodies[i-1],bodies[i],f,shaders,sizeof(f.data));
        }
    }
    for(unsigned i=1;i<N;++i){const double ratio=-stiffness/diagonal[i-1];diagonal[i]+=ratio*stiffness;rhs[i]-=ratio*rhs[i-1];}
    for(unsigned j=N;j>0;--j){const unsigned i=j-1;expected[i]=(rhs[i]+(i+1<N?stiffness*expected[i+1]:0))/diagonal[i];}
    scene.simulate(float(dt));bool ok=scene.fetchResults(true);double error=0,bdf=0,momentum=0,angular=0;
    for(unsigned i=0;i<N;++i)
    {
        const PxTransform pose=bodies[i]->getGlobalPose();const PxVec3 velocity=bodies[i]->getLinearVelocity();
        ok=ok && pose.isFinite() && velocity.isFinite();
        error=PxMax(error,std::abs(double(pose.p.x)-expected[i]));
        error=PxMax(error,std::abs(double(pose.p.y))+std::abs(double(pose.p.z)));
        bdf=PxMax(bdf,double((pose.p/float(dt)-velocity).magnitude()));
        momentum+=double(bodies[i]->getMass())*double(velocity.x);angular=PxMax(angular,double(bodies[i]->getAngularVelocity().magnitude()));
    }
    ok=ok && error<1.e-6 && bdf<2.e-5 && std::abs(momentum-initialMomentum)<2.e-4 && angular<1.e-5;
    std::printf("[COMMON_CHAIN] bodies=%u positionError=%.9g bdfError=%.9g momentumError=%.9g angular=%.9g status=%s\n",
        N,error,bdf,std::abs(momentum-initialMomentum),angular,ok?"PASS":"FAIL");
    for(auto& f:frames)f.constraint->release();for(auto b:bodies)b->release();return ok;
}
int main(int argc,char** argv)
{
    const unsigned mode=argc>1?unsigned(std::atoi(argv[1])):0;
    useModification=argc<=2 || mode==1;
    PxDefaultAllocator allocator;PxDefaultErrorCallback errors;
    PxFoundation* foundation=PxCreateFoundation(PX_PHYSICS_VERSION,allocator,errors);
    PxPhysics* physics=PxCreatePhysics(PX_PHYSICS_VERSION,*foundation,PxTolerancesScale(),false,NULL);
    const unsigned threads=argc>3?unsigned(std::atoi(argv[3])):4;
    PxInitExtensions(*physics,NULL);PxDefaultCpuDispatcher* dispatcher=PxDefaultCpuDispatcherCreate(threads);
    PxSceneDesc desc(physics->getTolerancesScale());desc.gravity=PxVec3(0,-9.81f,0);desc.solverType=PxSolverType::eAVBD;
    Modify modify;if(mode==1)modify.impulse=.001f;
    desc.cpuDispatcher=dispatcher;desc.filterShader=filter;desc.contactModifyCallback=&modify;
    PxScene* scene=physics->createScene(desc);PxMaterial* material=physics->createMaterial(mode==5?0:.4f,mode==5?0:.4f,0);
    if(mode==6)
    {
        const unsigned count=argc>4?unsigned(std::atoi(argv[4])):12;
        if(count<2 || count>4096)return 2;
        const bool ok=chain(*physics,*scene,count);
        std::printf("[COMMON_PROGRAM_SCENE] mode=6 fetchedFinite=%s\n",ok?"PASS":"FAIL");
        material->release();scene->release();dispatcher->release();PxCloseExtensions();physics->release();foundation->release();return ok?0:1;
    }
    if(mode==7)
    {
        // Incompatible hard anchors have no equilibrium. Even a numerical
        // convergence report must not bypass actual admission or reach BDF.
        scene->setGravity(PxVec3(0));auto* body=physics->createRigidDynamic(PxTransform(PxIdentity));
        body->setMass(1);body->setMassSpaceInertiaTensor(PxVec3(1));body->setSleepThreshold(0);
        body->setLinearDamping(0);body->setAngularDamping(0);body->setLinearVelocity(PxVec3(.2f,0,0));scene->addActor(*body);
        auto* a=PxD6JointCreate(*physics,NULL,PxTransform(PxIdentity),body,PxTransform(PxIdentity));
        auto* b=PxD6JointCreate(*physics,NULL,PxTransform(PxVec3(.1f,0,0)),body,PxTransform(PxIdentity));
        scene->simulate(1.f/60);scene->fetchResults(true);
        const double positionError=body->getGlobalPose().p.magnitude(),velocityError=(body->getLinearVelocity()-PxVec3(.2f,0,0)).magnitude();
        const bool unchanged=positionError==0 && velocityError==0;
        std::printf("[COMMON_CONFLICT] positionError=%.9g velocityError=%.9g unpublished=%s\n",positionError,velocityError,unchanged?"PASS":"FAIL");
        a->release();b->release();body->release();material->release();scene->release();dispatcher->release();
        PxCloseExtensions();physics->release();foundation->release();return unchanged?0:1;
    }
    const unsigned count=mode==4?4:3;
    const float half=argc>2 && std::strcmp(argv[2],"overlap")!=0?.501f:.49f;
    const PxVec3 positions[4]={PxVec3(-half,0,0),PxVec3(half,0,0),PxVec3(-half,1,0),PxVec3(-half,0,1)};
    PxRigidDynamic* bodies[4]={};
    for(unsigned i=0;i<count;++i)
    {
        bodies[i]=physics->createRigidDynamic(PxTransform(positions[i]));bodies[i]->setMass(float(i+1));
        bodies[i]->setMassSpaceInertiaTensor(PxVec3(.1f,.13f,.17f)*float(i+1));
        bodies[i]->setSleepThreshold(0);bodies[i]->setLinearDamping(0);bodies[i]->setAngularDamping(0);
        if(i<2){PxShape* shape=PxRigidActorExt::createExclusiveShape(*bodies[i],PxSphereGeometry(.5f),*material);shape->setContactOffset(.02f);}
        bodies[i]->setLinearVelocity(PxVec3(i==0?.1f:i==1?-.2f:0,.1f*float(i),0));scene->addActor(*bodies[i]);
    }
    if(mode==2)bodies[0]->setRigidDynamicLockFlags(PxRigidDynamicLockFlag::eLOCK_LINEAR_Z|PxRigidDynamicLockFlag::eLOCK_ANGULAR_Z);
    if(mode==3){bodies[1]->setRigidBodyFlag(PxRigidBodyFlag::eKINEMATIC,true);bodies[1]->setKinematicTarget(PxTransform(PxVec3(.48f,0,0)));}
    Frame frame;frame.data.c2b[0]=PxTransform(PxVec3(0,.5f,0));frame.data.c2b[1]=PxTransform(PxVec3(0,-.5f,0));
    for(PxU32 i=0;i<6;++i)frame.data.drives[i]=PxD6JointDrive(300.f+30.f*i,2,PX_MAX_F32,false);
    PxConstraintShaderTable shaders={JointSoftBodySnippet::finiteJointPrep,NULL,PxConstraintFlag::eCOLLISION_ENABLED};
    shaders.elasticFramePrep=JointSoftBodySnippet::finiteJointMaterialPrep;
    frame.constraint=physics->createConstraint(bodies[0],bodies[2],frame,shaders,sizeof(frame.data));
    PxD6Joint* drive=PxD6JointCreate(*physics,NULL,PxTransform(positions[2]+PxVec3(.1f,0,0)),bodies[2],PxTransform(PxIdentity));
    for(PxU32 i=0;i<6;++i)drive->setMotion(PxD6Axis::Enum(i),PxD6Motion::eFREE);
    drive->setConstraintFlag(PxConstraintFlag::eDRIVE_LIMITS_ARE_FORCES,true);
    drive->setDrive(PxD6Drive::eX,PxD6JointDrive(200,3,.8f,false));
    JointSoftBodySnippet::VolumeMaterial* volume=NULL;
    if(mode==4){PxRigidActor* actors[4]={bodies[0],bodies[1],bodies[2],bodies[3]};volume=JointSoftBodySnippet::VolumeMaterial::create(*physics,actors,1.2f,500);}
    scene->simulate(1.f/60);bool fetched=scene->fetchResults(true);
    float bdfError=0;
    for(unsigned i=0;i<count;++i)
    {
        fetched=fetched && bodies[i]->getGlobalPose().isFinite();
        if(!bodies[i]->getRigidBodyFlags().isSet(PxRigidBodyFlag::eKINEMATIC))
            bdfError=PxMax(bdfError,((bodies[i]->getGlobalPose().p-positions[i])*60-bodies[i]->getLinearVelocity()).magnitude());
    }
    if(argc>2)
    {
        fetched=fetched && bdfError<2.e-5f;
        std::printf("[COMMON_BDF] linearError=%.9g\n",double(bdfError));
        PxVec3 direction,driveForce,driveTorque;PxReal depth=0;
        const bool overlap=PxGeometryQuery::computePenetration(direction,depth,PxSphereGeometry(.5f),bodies[0]->getGlobalPose(),
            PxSphereGeometry(.5f),bodies[1]->getGlobalPose());
        drive->getConstraint()->getForce(driveForce,driveTorque);
        fetched=fetched && (mode==1 || !overlap || depth<5.e-7f) && driveForce.magnitude()<.80001f;
        std::printf("[COMMON_PHYSICAL] overlap=%u depth=%.9g driveForce=%.9g\n",unsigned(overlap),double(depth),double(driveForce.magnitude()));
    }
    std::printf("[COMMON_PROGRAM_SCENE] mode=%u fetchedFinite=%s\n",mode,fetched?"PASS":"FAIL");
    if(volume)volume->release();drive->release();frame.constraint->release();
    for(unsigned i=0;i<count;++i)bodies[i]->release();material->release();scene->release();
    dispatcher->release();PxCloseExtensions();physics->release();foundation->release();return fetched?0:1;
}
