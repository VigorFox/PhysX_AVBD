// Copyright (c) 2026 NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: BSD-3-Clause

#ifndef DY_AVBD_DYNAMICS_H
#define DY_AVBD_DYNAMICS_H

#include "DyDynamicsBase.h"
#include "avbd/DyAvbdOgc.h"
#include "avbd/DyAvbdRowProgram.h"
#include "avbd/DyAvbdElasticFrame.h"
#include "avbd/DyAvbdMaterialAssembly.h"
#include "avbd/DyAvbdContactGeometry.h"
#include "avbd/DyAvbdVbd.h"
#include "avbd/DyKernelTable.h"
#include "DyAvbdCpuSoftAccess.h"
#include "foundation/PxVec3.h"
#include "foundation/PxQuat.h"
#include "foundation/PxTransform.h"
#include "foundation/PxMat33.h"
#include "foundation/PxAtomic.h"
#include "PxsIslandSim.h"

namespace physx
{
class PxsContactManager;
namespace Dy
{

struct Constraint;
class AvbdAdvanceTask;
class AvbdBlockSolveTask;
struct AvbdCommonProgram;
struct AvbdCommonPublication;
struct AvbdBoundedResponse;
struct AvbdProgramSubset;
class FeatherstoneArticulation;
struct ArticulationJointCore;

struct AvbdSolverBody
{
	PxVec3 p;
	PxQuat q;
	PxVec3 pHat;
	PxQuat qHat;
	PxVec3 pStart;
	PxQuat qStart;
	PxVec3 pLin;
	PxQuat qLin;
	PxVec3 linVel;
	PxVec3 angVel;
	// Final velocity is staged inside the backend until every rigid and
	// heterogeneous material row has closed. Host state is published once.
	PxVec3 outputLinVel;
	PxVec3 outputAngVel;
	PxReal invMass;
	PxVec3 invInertia;
	// Frozen BDF1 metric, compiled once from qStart and dt.  The nonlinear
	// primal reuses it on every GS sweep.
	PxReal massInvH2;
	PxMat33 inertiaWorldInvH2;
	PxU8 disableGravity;
	PxU8 isKinematic;
	PxU8 hasStaticTouch;
	PxU8 hasContact;
	AvbdOgcRigidRegion ogcRegion;
	PxU8 ogcRegionValid;
	PxU8 ogcExceeded;
	PxsBodyCore* core;
	PxsRigidBody* rigid;
	FeatherstoneArticulation* artic;
	PxU32 linkIndex;
};

// A candidate owns only a pose. All reference epochs and certificates are
// borrowed read-only, never copied into each line-search trial.
struct AvbdBodyPose
{
    const PxVec3 &p, &pHat, &pStart, &pLin;
    const PxQuat &q, &qHat, &qStart, &qLin;
    const AvbdOgcRigidRegion& ogcRegion;
    AvbdBodyPose(const AvbdSolverBody& body,const PxTransform* pose=NULL)
        : p(pose?pose->p:body.p),pHat(body.pHat),pStart(body.pStart),pLin(body.pLin),
          q(pose?pose->q:body.q),qHat(body.qHat),qStart(body.qStart),qLin(body.qLin),
          ogcRegion(body.ogcRegion) {}
};

// Substitute an indexed group, or the complete pose array when indices is NULL.
struct AvbdRigidPoseView
{
    const PxArray<AvbdSolverBody>& bodies;
    const PxU32* indices;
    const PxTransform* candidates;
    PxU32 count;
    PxU32 size() const { return bodies.size(); }
    AvbdBodyPose operator[](PxU32 i) const
    {
        if(!indices) return AvbdBodyPose(bodies[i],i<count?candidates+i:NULL);
        for(PxU32 s=0;s<count;++s) if(indices[s]==i) return AvbdBodyPose(bodies[i],candidates+s);
        return AvbdBodyPose(bodies[i]);
    }
};
struct AvbdRigidGroupRow
{
    PxU32 row,representative,supportCount;
};
struct AvbdRigidGroup
{
    PxU32 blocks[4],count,rowStart,rowCount,sharedStart,sharedCount;
    // Written only by this colored group's task; read after the task barrier.
    PxU32 attempts,unsupported,kernelSolved,accepted,products;
    PxU32 frictionAttempts,frictionAccepted,sharedContactAttempts,sharedContactAccepted;
    PxU32 materialEvaluations,materialEndpointUses;
};

enum AvbdRowFlag
{
	eAVBD_ROW_UNILATERAL = 1 << 0,
	eAVBD_ROW_CONTACT = 1 << 1,
	eAVBD_ROW_INACTIVE = 1 << 2,
	eAVBD_ROW_DRIVE = 1 << 3,
	// The row owns heterogeneous supports in mBlocks/mRowSupports.  This is not
	// a soft-pair policy bit: world/soft, soft/rigid and soft/soft rows all use
	// the same block-row contract.
	eAVBD_ROW_HETEROGENEOUS = 1 << 4,
	// Compatibility spelling for code that only distinguishes the rigid-only
	// evaluator from the heterogeneous evaluator.  New producers use the name
	// above so the IR does not encode a scene/contact-family owner.
	eAVBD_ROW_SOFT_PAIR = eAVBD_ROW_HETEROGENEOUS,
	eAVBD_ROW_FRESH = 1 << 5,
	eAVBD_ROW_OUTPUT_FORCE = 1 << 6,
	// Three bilateral translation rows compiled as one point-coincidence block.
	eAVBD_ROW_POINT_LOCK = 1 << 7
};

enum AvbdRowKernel
{
	eAVBD_ROW_KERNEL_CONSTRAINT = 0,
	eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN,
	eAVBD_ROW_KERNEL_CONTACT_FRAME,
	eAVBD_ROW_KERNEL_FINITE_SPRING,
	eAVBD_ROW_KERNEL_TETRAHEDRON,
    eAVBD_ROW_KERNEL_ELASTIC_FRAME,
    eAVBD_ROW_KERNEL_NP_CONTACT
};

struct AvbdRow
{
	PxU8 kernelId;
	// 1-based index in the geometry payload selected by kernelId. Constraint
	// rows use a rigid-carried plane; zero retains the world-normal evaluator.
	PxU32 geometryIndex;
	PxU32 supportStart;
	PxU16 supportCount;
	PxU32 bodyA;
	PxU32 bodyB;
	PxVec3 n;
	PxVec3 rA;
	PxVec3 rB;
	// Current DCD feature anchors are immutable geometry data for the OGC
	// region. Contact AL may retain older rA/rB anchors while sticking; sharing
	// those two meanings can collapse a valid conservative region to zero.
	PxVec3 ogcRA;
	PxVec3 ogcRB;
	PxVec3 jLinA;
	PxVec3 jAngA;
	PxVec3 jLinB;
	PxVec3 jAngB;
	PxReal C0;
	// solverPrep geometricError at the current linearization pose (pLin/qLin).
	// C0 is the frozen step-start continuation; CLin + J*dx is C_geom.
	PxReal CLin;
	// Contact geometry offset (processed separation/rest distance).  C0 is the
	// independent AL continuation anchor and may be depth-conditioned.
	PxReal contactOffset;
	// Heterogeneous (backend-DCD) rows only: OGC offset radius, so geometric
	// clearance = C + contactRadius and the particle conservative region is
	// built on the clearance.  Rigid NP rows are plain Position-AL rows with
	// C = separation - restDistance and contactRadius = 0.
	PxReal contactRadius;
	// Curvature of the geometric contact energy.  Keep this separate from rho:
	// rho belongs to augmented coordinates (joints and passive friction), while
	// OGC normal contact is an ordinary potential with no persistent normal dual.
	PxReal contactStiffness;
	PxReal rho;
	// demo3d keeps separate tangential penalties that start at PENALTY_MIN
	// and only grow while sticking inside the cone; sharing the (warm/grown)
	// normal rho rails the friction force at the cone bound during impacts.
	PxReal rhoT0;
	PxReal rhoT1;
	PxReal tangentC0;
	PxReal tangentC1;
	PxReal lambda;
	PxReal mu;
	PxReal lambdaT0;
	PxReal lambdaT1;
	PxVec3 t0;
	PxVec3 t1;
	PxReal minLambda;
	PxReal maxLambda;
	PxReal restitution;
	PxU8 flags;
	PxU8 articAxis;
	PxU8 articFlip;
	// solverPrep angular rows whose objective is an integrated step angle.
	// This covers velocity targets and angular couplings such as gear rows
	// without inspecting an extension concrete type.
	PxU8 integratedAngular;
	// A Px1D spring/drive is a physical force objective, not a hard-row AL
	// multiplier. Its position and this-step velocity residuals share J but
	// retain their authored coefficients.
	PxU8 accelerationDrive;
	PxReal driveStiffness;
	PxReal driveDampingOverDt;
	PxReal driveVelocityTarget;
	// Compiled material ownership: geometry normal is always Position-AL;
	// passive tangents participate only when this row's velocity program gives
	// Position-AL (or a later pose-residual owner) that source.
	PxU8 positionTangent;
	// Inbound artic 1D: geometric C/J from current parent/child poses.
	// NULL for contacts and solverPrep rows.
	const ArticulationJointCore* articJoint;
	PxReal articTarget;
	PxReal* forceWriteback;
};

enum AvbdBlockType
{
	eAVBD_BLOCK_PARTICLE3 = 0,
	eAVBD_BLOCK_RIGID6 = 1
};

// A Particle3 block is selected by its local elastic energy, never by the
// Host object that owns it.  Contact, OGC, dual and material rows consume the
// direct particle state below and are therefore independent of this kernel id.
enum AvbdParticleKernel
{
	eAVBD_PARTICLE_KERNEL_NONE = 0,
	eAVBD_PARTICLE_KERNEL_TET,
	eAVBD_PARTICLE_KERNEL_TRIANGLE
};

struct AvbdBlock
{
	PxU32 objectIndex; // local-energy payload index or rigid-body index
	PxU32 stateIndex;  // particle index; unused by rigid blocks
	AvbdSoftParticle* particle; // direct state for Particle3; NULL for Rigid6
	AvbdOgcPointRegion* ogcRegion;
	PxU8* ogcExceeded;
	PxU8 type;
	PxU8 particleKernel;
};

struct AvbdRowSupport
{
	PxU32 block;
	PxReal weight;
	// Only rigid supports use a body-local point. Particle supports use their
	// block position directly.
	PxVec3 localPoint;
};

// Borrowed typed payloads for the common contact evaluators.
struct AvbdContactGeometryView
{
 const PxArray<AvbdContactPlaneGeometry>& planes;
 const PxArray<AvbdContactFrameGeometry>* frames;
 const KernelTable* kernels;
 AvbdContactGeometryView(const PxArray<AvbdContactPlaneGeometry>& p)
  :planes(p),frames(NULL),kernels(NULL) {}
 AvbdContactGeometryView(const PxArray<AvbdContactPlaneGeometry>& p,
  const PxArray<AvbdContactFrameGeometry>& f,const KernelTable& k)
  :planes(p),frames(&f),kernels(&k) {}
};

static const PxU32 AVBD_MAX_JOINT_ROWS = 20;
static const PxU32 AVBD_MAX_ARTIC_ROWS = 12;

struct AvbdJointSrc
{
	Constraint* constraint;
    // Index in the typed preparation payload selected by constraint->multiBody.
    PxU32 payloadIndex;
	PxU32 bodyA;
	PxU32 bodyB;
	PxU32 nbRows;
};

// Ordinary solverPrep history only. A finite four-point material has no AL
// slots, point-lock anchors or per-axis history and allocates none of this.
struct AvbdJointState
{
	PxVec3 body0WorldOffset;
	PxVec3 pointLocalA;
	PxVec3 pointLocalB;
	PxU8 pointLock;
	PxU8 pointInitialized;
	PxU8 integratedInitialized[AVBD_MAX_JOINT_ROWS];
	PxReal integratedC0[AVBD_MAX_JOINT_ROWS];
	PxReal lambda[AVBD_MAX_JOINT_ROWS];
	PxReal rho[AVBD_MAX_JOINT_ROWS];
};

struct AvbdArticJointSrc
{
	ArticulationJointCore* joint;
	PxU32 parentBody;
	PxU32 childBody;
	PxU32 nbRows;
	PxReal lambda[AVBD_MAX_ARTIC_ROWS];
	PxReal rho[AVBD_MAX_ARTIC_ROWS];
};

struct AvbdContactWarm
{
	const PxsContactManager* cm;
	PxU32 materialKey;
	PxVec3 n;
	// Fresh narrow-phase anchors identify the manifold point.  rA/rB and the
	// paired offset are the material constraint tuple and may remain fixed
	// while a sticking point migrates inside the same NP feature.
	PxVec3 detectionRA;
	PxVec3 detectionRB;
	PxVec3 rA;
	PxVec3 rB;
	PxVec3 t0;
	PxVec3 t1;
	PxReal lambda;
	PxReal lambdaT0;
	PxReal lambdaT1;
	PxReal rho;
	PxReal rhoT0;
	PxReal rhoT1;
	PxReal contactOffset;
	PxU8 stick;
};

// Per-step velocity complementarity program.  Quantities derived from the
// frozen solve-start pose/velocity are compiled once; only accumulated
// impulses and current constrained velocities change during the GS sweeps.
struct AvbdMaterialRow
{
	PxU32 rowIndex;
	// One common finalized-pose application point, expressed as a world arm
	// from each endpoint COM.  Equal/opposite material impulses at distinct
	// persistent AL anchors would manufacture an internal couple.
	PxVec3 armA;
	PxVec3 armB;
	// Normal load already supplied by the accepted OGC pose objective. It
	// contributes Coulomb capacity and the public maxImpulse budget, but is not
	// scattered a second time by the velocity complementarity solve.
	PxReal positionNormalImpulse;
	PxReal normalImpulse;
	PxReal normalCapacity;
	PxReal tangentImpulse0;
	PxReal tangentImpulse1;
	PxReal normalTarget;
	PxReal normalResponse;
	PxReal maxNormalImpulse;
	PxReal tangentStep;
	PxU8 solveNormal;
	PxU8 solveTangent;
	// This impact frontier replaces its finalized-pose Position-AL response
	// by a total material impulse assembled at the fresh common point.
	PxU8 replacePositionAl;
	// Joint-coupled fallback normal uses the COM projection until the generic
	// hard-joint Schur mobility is available; tangents retain spatial response.
	PxU8 normalLinearOnly;
};

static const PxU32 AVBD_DEFORMABLE_ITERS = 20;
static const PxU32 AVBD_DEFORMABLE_ITERS_MAX = 128;

class DeformableVolume;
class DeformableSurface;

struct AvbdSoftEmbeddedPoint
{
	PxU32 particleIndices[4];
	PxReal weights[4];
	PxU32 count;
};

struct AvbdSoftBoundaryFace
{
	PxU32 vertices[3];
	PxU32 oppositeVertex;
};

struct AvbdSoftBoundaryEdgeTopology
{
	PxU32 v0, v1;
	PxU32 face0, face1;
};

struct AvbdSoftPairContact
{
	DeformableVolume* queryVolume;
	DeformableVolume* targetVolume;
	PxU32 queryCache;
	PxU32 targetCache;
	PxU32 queryCollisionVertex;
	PxU32 targetFace;
	// Canonical geometric owner.  Vertex/face uses featureType 0 and the
	// historical vertex/face fields above. Edge/edge uses featureType 1 and
	// both sorted endpoint pairs, so warm state cannot jump between adjacent
	// OGC features.
	PxU32 queryFeature1;
	PxU32 targetFeature1;
	PxU8 featureType;
	PxU32 queryParticleIndices[8];
	PxReal queryWeights[8];
	PxU32 queryParticleCount;
	PxU32 targetParticleIndices[12];
	PxReal targetWeights[12];
	PxU32 targetParticleCount;
	PxVec3 normal;
	PxReal margin;
	PxReal k;
	PxReal lambda;
};

struct AvbdSurfaceBoxFeatureContact
{
	PxU32 particleIndices[3];
	PxReal weights[3];
	PxU32 particleCount;
	PxU32 boxIndex;
	PxU32 softFeature0;
	PxU32 softFeature1;
	PxU32 rigidFeature0;
	PxU8 featureType; // 0: rigid vertex / soft face, 1: soft edge / rigid edge, 3: triangle/core
	PxVec3 normal;
	PxVec3 surfacePoint;
	PxReal margin;
	PxReal k;
	PxReal lambda;
};
typedef PxArray<AvbdSurfaceBoxFeatureContact> AvbdSurfaceBoxFeatureContactArray;

struct AvbdVolumeBoxFeatureContact
{
	PxU32 particleIndices[12];
	PxReal weights[12];
	PxU32 particleCount;
	PxU32 boxIndex;
	PxU32 softFeature0;
	PxU32 softFeature1;
	PxU32 rigidFeature0;
	PxU8 featureType; // 0: soft vertex, 1: rigid vertex/soft face, 2: edge/edge, 3: triangle/core
	PxVec3 normal; // dC / d(soft point)
	PxVec3 rigidLocalPoint;
	PxReal margin;
	PxReal k;
	PxReal lambda;
};
typedef PxArray<AvbdVolumeBoxFeatureContact> AvbdVolumeBoxFeatureContactArray;

// Rest element program and instance state for an island deformable volume.
struct AvbdIslandSoftCache
{
	DeformableVolume* volume;
	AvbdSoftTet* tets;
	AvbdSoftParticle* particles;
	AvbdOgcPointRegion* ogcRegions;
	PxU8* ogcExceeded;
	PxReal* contactK;
	PxReal* contactLambda;
	PxReal* boxContactK; // nbParticles * AVBD_SOFT_MAX_STATIC_BOXES
	PxReal* boxContactLambda; // same layout as boxContactK; shared with rigid 6x6
	AvbdSoftEmbeddedPoint* collisionPoints;
	PxU32* collisionTets;
	AvbdSoftBoundaryFace* boundaryFaces;
	AvbdSoftBoundaryEdgeTopology* boundaryEdges;
	PxU8* boundaryVertices;
	PxU32* incidentTetOffsets;
	PxU32* incidentTetIndices;
	PxU8* incidentTetCorners;
	PxU32* materialNeighborOffsets;
	PxU32* materialNeighbors;
	// Shared immutable topology only. Temporary candidate cache copies borrow
	// these views; ownership is released solely by persistent cache teardown.
	PxU32* topologyReferences;
	PxU32* incidentBoundaryFaceOffsets;
	PxU32* incidentBoundaryFaceIndices;
	AvbdVolumeBoxFeatureContactArray* boxFeatureContacts;
	PxU32 nbTets;
	PxU32 nbParticles;
	PxU32 nbCollisionParticles;
	PxU32 nbCollisionTets;
	PxU32 nbBoundaryFaces;
	PxU32 nbBoundaryEdges;
	PxU32 blockStart;
	PxU32 liveStamp;
	PxU8 coupled; // 1: defer writeback; same-snapshot 3x3 + 6x6
};

struct AvbdIslandSurfaceCache
{
	DeformableSurface* surface;
	AvbdSoftTri* triangles;
	AvbdSoftBending* bends;
	AvbdSoftParticle* particles;
	AvbdOgcPointRegion* ogcRegions;
	PxU8* ogcExceeded;
	AvbdSoftBoundaryEdgeTopology* edges;
	PxReal* planeContactK; // nbParticles * DeformableSurface::eMAX_CPU_PLANES
	PxReal* planeContactLambda; // same layout as planeContactK
	PxReal* boxContactK; // nbParticles * DeformableSurface::eMAX_CPU_STATIC_BOXES
	PxReal* boxContactLambda; // same layout as boxContactK
	AvbdSurfaceBoxFeatureContactArray* boxFeatureContacts;
	PxU32 nbTriangles;
	PxU32 nbBends;
	PxU32 nbParticles;
	PxU32 nbEdges;
	PxU32 blockStart;
	PxU32 liveStamp;
};

class AvbdDynamicsContext : public DynamicsContextBase
{
	PX_NOCOPY(AvbdDynamicsContext)
public:
	AvbdDynamicsContext(PxcNpMemBlockPool* memBlockPool, Cm::FlushPool& taskPool,
		PxvSimStats& simStats, Cm::VirtualAllocatorCallback& allocator,
		PxsMaterialManager* materialManager, IG::SimpleIslandManager& islandManager,
		PxU64 contextID, PxReal maxBiasCoefficient, PxReal lengthScale,
		PxSceneFlags sceneFlags);

	virtual ~AvbdDynamicsContext();

	virtual void destroy() PX_OVERRIDE;
	virtual void update(Cm::FlushPool& flushPool, PxBaseTask* continuation,
		PxBaseTask* postPartitioningTask, PxBaseTask* lostTouchTask,
		PxvNphaseImplementationContext* nPhase, PxU32 maxPatchesPerCM,
		PxU32 maxArticulationLinks, PxReal dt, const PxVec3& gravity,
		Cm::PinnableBitMap& changedHandleMap) PX_OVERRIDE;
	virtual void mergeResults() PX_OVERRIDE;
	virtual void setSimulationController(PxsSimulationController* sc) PX_OVERRIDE
	{
		mSimulationController = sc;
	}
	virtual PxSolverType::Enum getSolverType() const PX_OVERRIDE
	{
		return PxSolverType::eAVBD;
	}
    virtual bool supportsTetrahedralConstraints() const PX_OVERRIDE { return true; }
    virtual void invalidateConstraint(const Constraint* constraint) PX_OVERRIDE;
	virtual bool usesInertialDcdContactQuery() const PX_OVERRIDE { return true; }

	const KernelTable& getKernelTable() const
	{
		return mKernels;
	}

private:
	friend class AvbdBlockSolveTask;
	friend class AvbdAdvanceTask;
	void compileBlockColors();
	void compileTrianglePointIncidence();
	void refreshTrianglePoint(PxU32 point);
	void refreshBlockTrianglePoints(PxU32 block);
	void observeTriangleMotion(PxU32 block);
	void advancePrimal();
	void finishStep();
	void preparePrimalSweep();
	void solvePrimalBatch();
    void solveBoundedBatch(PxU32 begin,PxU32 end);
    bool dispatchBoundedWave();
	void solvePrimalBlock(PxU32 blockIndex);
	PxReal finishPrimalSweep(bool* coupledDomainStationary);
	AvbdContactGeometryView contactGeometry() const
	{ return AvbdContactGeometryView(mContactPlaneGeometry,mContactFrameGeometry,mKernels); }
	void initSolverBody(AvbdSolverBody& b, PxsBodyCore& core, PxsRigidBody* rigid,
		const PxVec3& gravity, PxReal dt);
	void collectArticulationLinks(PxReal dt, const PxVec3& gravity);
	void buildContactRows();
	void buildSoftRigidContactRows();
	void buildSurfaceContactRows();
	void compileHeterogeneousBlocks();
	void compileRowProgram();
	void compileVelocityComponents(PxArray<PxU32>& parents) const;
	void buildJointSources(PxU32 nbIslands, const IG::IslandId* islandIds);
	void buildArticJointSources();
	bool refreshJointRows(bool beginStep = false);
	void refreshArticJointRows();
    AvbdTetrahedronEvaluation evaluateTetrahedron(const AvbdRow& row,
        PxU32 candidateIndex=PX_MAX_U32, const PxTransform* candidate=NULL) const;
	void warmstartBlocks();
	bool admitWarmstartCandidate(const AvbdProgramSubset* subset=NULL,PxReal fraction=1.f);
    bool accumulateRigidMaterialRow(PxU32 ri,const PxU32* blocks,PxU32 count,AvbdRigidAssembly* assemblies);
    bool compileCommonProgram(AvbdCommonProgram& program,const char*& reason,const AvbdRigidPoseView* candidate=NULL,
        const AvbdProgramSubset* subset=NULL,bool buildH=true);
    bool solveCommonCandidate(bool& stationary);
    bool commonCapability();
    bool beginCommonPublication(const AvbdProgramSubset& subset,bool bounded);
    bool resumeCommonPublication(bool& stationary);
    void clearCommonPublication();
    bool beginBoundedCommon();
    void startBoundedResponse();
    bool completeBoundedCommon(bool& done,bool& stationary);
    bool solveCommonComponent(const AvbdProgramSubset& subset,bool& stationary);
    void captureCommonProgram();
    void accumulateRigidConstraintRow(PxU32 i,PxU32 ri,PxReal invH2,AvbdRigidAssembly& assembly);
    bool linearizeRigidRow(const AvbdRow& row,PxU32 i,PxReal& C,PxVec3& jLin,PxVec3& jAng,const AvbdRigidPoseView* candidate=NULL) const;
	void solvePrimalBody(PxU32 i, PxReal invH2,
		PxVec3& outDp, PxVec3& outDth, PxVec3& gradientLinear,
		PxVec3& gradientAngular, PxReal (*metric)[6]=NULL);
	PxReal rigidBlockEnergy(PxU32 i, const PxTransform& candidate,
		PxReal invH2) const;
    template<class PoseView>
    double rigidRowEnergy(PxU32 row,PxU32 block,const PoseView& poses,PxReal invH2) const;
    bool solvePrimalRigidGroup(PxU32 root,PxReal invH2);
	PxReal solvePrimalRigidBlock(PxU32 i, PxReal invH2);
	void applyDual();
	void applyImpactMaterial(PxReal dt, const PxArray<PxU8>& materialBody,
		const PxArray<PxReal>& linearPoseGain,
		const PxArray<PxReal>& angularPoseGain);
	void applyHeterogeneousContactMaterial();
	void writeJointDualState();
	void writeJointConstraintWriteback();
	void prepareRigidVelocities(PxReal dt);
	void finalizeRigidBodies(PxReal dt);
	void prepareIslandDeformableVolumes(PxReal dt, const PxVec3& gravity);
	void prepareIslandDeformableSurfaces(PxReal dt, const PxVec3& gravity);
	void fillVolumeSdfBoxes(const DeformableVolume& vol, AvbdSoftStaticBox* boxes,
		PxU32& nbBoxes) const;
	void injectHostDynamicSoftRigidBodies(const PxVec3& gravity, PxReal dt);
	bool anyCoupledDeformableVolume() const;
	bool anyLiveDeformableSurface() const;
	void refreshOgcRegions(bool reanchor = true);
	void refreshSurfaceOgcRegions();
	bool ogcRefreshRequired() const;
	void rebuildSoftRigidContacts();
	void rebuildSurfaceContacts();
	PxReal solveCoupledParticleDomainPrimal(bool& stationary,
		bool repairRequired, bool& repairResolved,
		PxArray<PxU8>& participants,
		const PxArray<PxReal>& localNormalizedSteps,
		const PxArray<PxU8>& repairSeeds);
	PxReal solveSurfaceParticlePrimal(AvbdIslandSurfaceCache& cache,
		PxU32 particleIndex, PxReal invH2);
	bool assembleVolumeParticlePrimal(const AvbdIslandSoftCache& cache,
		PxU32 particleIndex, const AvbdSoftMaterial& material, PxReal invH2,
		AvbdSoftWorldPin* pins, PxU32 nbPins, PxVec3& force, PxMat33& hessian,
		AvbdSoftQuadratic* quadratic=NULL) const;
	PxReal solveVolumeParticlePrimal(AvbdIslandSoftCache& cache,
		PxU32 particleIndex, const AvbdSoftMaterial& material, PxReal invH2,
		AvbdSoftWorldPin* pins, PxU32 nbPins, bool& coupledRepairRequired,
		PxArray<PxU8>& coupledRepairSeeds);
	void assembleParticleContactPrimal(PxU32 blockIndex, PxVec3& force,
		PxMat33& hessian) const;
	double particleContactEnergy(PxU32 blockIndex,
		const PxVec3& candidate, bool change=false) const;
	void clipRigidContactStep(PxU32 bodyIndex, PxVec3& dp, PxVec3& dth) const;
	bool rigidContactCandidateAdmissible(PxU32 bodyIndex,
		const PxTransform& candidate) const;
	bool projectNpCandidate(PxU32 bodyIndex, PxTransform& candidate) const;
	bool particleContactCandidateAdmissible(PxU32 blockIndex,
		const PxVec3& candidate,
		bool committedTriangles=false) const;
	bool triangleDomainSeparated(PxU32 ref,const PxVec3d& delta) const;
	bool triangleCandidateAdmitted(PxU32 row,PxU32 block,const PxVec3& candidate) const;
	void compileCommittedTrianglePlanes(PxU32 ref,AvbdOgcProjectionPlane (&planes)[9]) const;
	bool triangleBatchSeparated(PxU32 batch,const PxVec3d& delta) const;
	void compileParticleCommitDomain(PxU32 blockIndex, const PxVec3& anchor,
		AvbdOgcProjectionPlanes& constraints);
	void rebuildSoftPairContacts();
	void buildTriangleDomainRows();
	void prepareDeformableVelocities(PxReal dt);
	void finalizeDeformableBlocks(PxReal dt);
	void pruneIslandSoftCache();
	void publishIslandSoftCache(AvbdIslandSoftCache& cache);
	void clearIslandSoftCache();
	AvbdIslandSoftCache* getIslandSoftCache(DeformableVolume* volume);
	void clearIslandSurfaceCache();
	void pruneIslandSurfaceCache();
	AvbdIslandSurfaceCache* getIslandSurfaceCache(DeformableSurface* surface);
	PxU32 findBody(const PxsBodyCore* core) const;
	PxTransform bodyPose(PxU32 index, const PxsBodyCore* fallback) const;
	PxU32 solverBodyOf(PxU8 indexType, PxU32 solverBody) const;
	PxU32 contactBody(const PxsIndexedContactManager& cm, PxU32 side) const;

	PxArray<AvbdSolverBody> mBodies;
	PxArray<AvbdBlock> mBlocks;
	PxArray<AvbdRow> mRows;
	PxArray<AvbdRowSupport> mRowSupports;
    PxArray<AvbdTetrahedronMaterial> mTetrahedronMaterials;
    PxArray<AvbdElasticFrameMaterial> mElasticFrameMaterials;
    PxArray<AvbdRigidGroup> mRigidGroups;
    PxArray<PxU32> mRigidGroupRoots,mRigidGroupSharedRows;
    PxArray<PxU32> mRigidGroupFactorOffsets;
    PxArray<AvbdRigidGroupRow> mRigidGroupRows;
	PxArray<AvbdContactPlaneGeometry> mContactPlaneGeometry;
	PxArray<AvbdNpDomain> mNpDomains;
	PxU32 mNpDomainUnsupported, mNpDomainPolicyExcluded, mNpDomainUnseparated;
	PxU32 mNpDomainMode;
	PxU32 mNpDomainAxisRecovered;
	PxArray<AvbdContactFrameGeometry> mContactFrameGeometry;
	PxArray<AvbdTriangleDomainGeometry> mTriangleDomainGeometry;
	PxArray<AvbdAffinePointEvaluation> mTrianglePoints;
	PxArray<AvbdTrianglePointProjection> mTriangleProjections;
	PxArray<PxU32> mTrianglePointProjectionOffsets;
	struct TriangleBlockCoefficients { double weights[6], absoluteWeights[6], lengths[9]; PxU32 groups[9]; };
	PxArray<TriangleBlockCoefficients> mBlockTriangleCoefficients;
	PxArray<PxU32> mBlockTrianglePointOffsets, mBlockTrianglePoints;
	struct TriangleBlockProjection
	{
		PxArray<PxVec3d> normals;
		bool compiled;
		TriangleBlockProjection() : compiled(false) {}
	};
	PxArray<TriangleBlockProjection> mBlockTriangleProjection;
	struct TriangleBlockBatch
	{
		PxU32 geometry,pointStart,countA,count,rowStart,rowCount;
		AvbdTriangleBatchBound bound;
	};
	PxArray<TriangleBlockBatch> mTriangleBatches;
	PxArray<AvbdTriangleProjectionRef> mTriangleBatchPoints;
	PxArray<PxU32> mBlockTriangleBatchOffsets,mTriangleBatchRows;
	PxArray<PxU32> mBlockObjectiveOffsets,mBlockObjectiveRows;
	struct TriangleFixedTerm { PxU32 block; PxVec3 gradient; };
	PxArray<TriangleFixedTerm> mTriangleFixedTerms;
	PxArray<PxU32> mTriangleTermOffsets,mTriangleStencilIndices;
	struct TriangleClosureBounds
	{
		double rhs,tolerance;
		PxU8 state; // 0: not selected, 1: inactive, 2: active
	};
	PxArray<TriangleClosureBounds> mTriangleClosureScratch;
	PxArray<AvbdJointSrc> mJoints;
	PxArray<AvbdJointState> mJointStates;
	PxArray<AvbdArticJointSrc> mArticJoints;
	PxArray<AvbdContactWarm> mContactWarm;
	PxArray<PxU8> mMaterialBodyScratch;
	PxArray<PxU8> mMaterialIncidentScratch;
	PxArray<PxU8> mMaterialTangentBodyScratch;
	PxArray<PxU32> mMaterialComponentParentScratch;
	PxArray<PxU8> mMaterialJointComponentScratch;
	PxArray<PxReal> mLinearPoseGainScratch;
	PxArray<PxReal> mAngularPoseGainScratch;
	PxArray<AvbdMaterialRow> mMaterialRowsScratch;
	AvbdRowProgram mRowProgram;
	// Per heterogeneous block/contact velocity program: x is the accumulated
	// normal impulse and y/z are the two accumulated Coulomb coordinates.
	PxArray<PxVec3> mHeterogeneousMaterialImpulseScratch;
	PxArray<PxVec3> mChebyPrevPosScratch;
	PxArray<PxVec3> mChebyPrevPrevPosScratch;
	PxArray<PxQuat> mChebyPrevRotScratch;
	PxArray<PxQuat> mChebyPrevPrevRotScratch;
	PxArray<AvbdIslandSoftCache> mIslandSoftCache;
	PxArray<AvbdSoftPairContact> mSoftPairContacts;
	PxArray<AvbdIslandSurfaceCache> mIslandSurfaceCache;
	PxArray<AvbdSoftParticle> mSoftParticleScratch;
	PxArray<AvbdSoftMaterial> mSoftMaterialScratch;
	// Rebuilt for each Particle3 solve; capacity survives, GS state does not.
	PxArray<PxU32> mSoftPinCountScratch;
	PxArray<AvbdSoftWorldPin> mSoftWorldPinScratch;
	PxU32 mIslandSoftLiveStamp;
	PxU32 mIslandSurfaceLiveStamp;
	PxU32 mContactRowCount;
	PxU32 mNpContactRowCount;
	PxU32 mIterations;
	PxReal mLengthScale;
	PxVec3 mGravity;
	KernelTable mKernels;
	AvbdOGCParams mOgc;
	volatile PxI32 mLocalDomainFailed;
	struct StepState
	{
		PxBaseTask *continuation = NULL;
		PxU32 iteration = 0, minimumIterations = 0, minimumJointIterations = 0, iterationLimit = 0;
		PxU32 convergedContactJointSweeps = 0, convergedHeterogeneousSweeps = 0, nextColor = 0;
		PxU32 submittedTasks = 0, workers = 0;
        PxU64 boundedWaves = 0, boundedBatches = 0, boundedSweeps = 0;
		PxReal chebyOmega = 1.0f;
		bool hasParticleBlocks = false, rowProgramValid = false, contactJointClosure = false;
        bool commonProgram = false, boundedCommon = false;
		bool useJointChebyshev = false, requiresDomainClosure = false, heterogeneousConverged = false;
		bool contactJointConverged = false, lastCoupledDomainStationary = false, sweepPrepared = false;
	};
	StepState mStep;
	AvbdAdvanceTask* mColorContinuation=NULL;
	PxArray<AvbdBlockSolveTask*> mBlockTasks;
    AvbdCommonPublication* mCommonPublication=NULL;
    AvbdBoundedResponse* mBoundedResponse=NULL;
    PxU32 mBoundedCursor=0;
	PxArray<PxU32> mColorOffsets,mColorBlocks;
	volatile PxI32 mColorCursor=0;
	PxU32 mColorEnd=0;
	PxArray<PxReal> mPrimalSteps;
	PxArray<PxU32> mPrimalIdleIteration,mPrimalChangedIteration,mPrimalIdleSkips;
	PxArray<PxVec3> mTriangleSnapshotPositions;
	mutable volatile PxI32 mTriangleMotionBits=0;
	PxArray<PxU8> mPrimalRepairSeeds;
	volatile PxI32 mActivePrimalTasks=0,mPeakPrimalTasks=0;
};

} // namespace Dy
} // namespace physx

#endif
