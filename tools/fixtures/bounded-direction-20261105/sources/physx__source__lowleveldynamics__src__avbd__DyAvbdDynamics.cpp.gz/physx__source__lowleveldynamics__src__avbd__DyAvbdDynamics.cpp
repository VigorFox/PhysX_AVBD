// Copyright (c) 2026 NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: BSD-3-Clause

#include "avbd/DyAvbdBoundedResponse.h"
#include "avbd/DyAvbdDynamics.h"
#include "avbd/DyAvbdColoring.h"
#include "CmTask.h"
#include "task/PxCpuDispatcher.h"
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include "avbd/DyAvbdVbd.h"
#include "avbd/DyAvbdInternal.h"
#include "avbd/DyAvbdContactGeometry.h"
#include "avbd/DyAvbdCoupledDomain.h"

#include "common/PxProfileZone.h"
#include "CmSpatialVector.h"
#include "DyBodyCoreIntegrator.h"
#include "DyConstraint.h"
#include "DyConstraintPrep.h"
#include "DyFeatherstoneArticulation.h"
#include "DyArticulationJointCore.h"
#include "DyIslandManager.h"
#include "DySleep.h"
#include "PxcNpWorkUnit.h"
#include "PxsContactManager.h"
#include "PxsContactManagerState.h"
#include "PxsIslandSim.h"
#include "PxsRigidBody.h"
#include "PxsSimpleIslandManager.h"
#include "PxConstraint.h"
#include "PxConstraintDesc.h"
#include "PxContact.h"
#include "foundation/PxMath.h"
#include "foundation/PxMat33.h"
#include "foundation/PxMemory.h"
#include "foundation/PxArray.h"
#include "foundation/PxSort.h"
#include "foundation/PxHashMap.h"
#include "DyDeformableVolume.h"
#include "DyDeformableSurface.h"
#include "geometry/PxTetrahedronMesh.h"
#include "geometry/PxTriangleMesh.h"
#include "mesh/GuTetrahedronMesh.h"
#include "GuIntersectionTriangleBox.h"
#include "PxActor.h"

using namespace physx;
using namespace Dy;



namespace physx
{
namespace Dy
{
// A continuation fan-in, never queued as an empty dispatcher job. The last
// worker advances from release(); when the caller finishes last it keeps its
// existing loop instead, so synchronous dispatch cannot grow the call stack.
class AvbdAdvanceTask : public PxLightCpuTask, public PxUserAllocated
{
	AvbdDynamicsContext &mContext;

  public:
	AvbdAdvanceTask(AvbdDynamicsContext &context, PxU64 id) : mContext(context) { mContextID = id; }
	void run() PX_OVERRIDE {}
	const char *getName() const PX_OVERRIDE { return "AVBD.colorComplete"; }
	bool completeInline() { return PxAtomicDecrement(&mRefCount) == 0; }
	void removeReference() PX_OVERRIDE
	{
		if (completeInline())
		{
			PX_SIMD_GUARD;
			mContext.advancePrimal();
		}
	}
};
class AvbdBlockSolveTask : public Cm::Task, public PxUserAllocated
{
	AvbdDynamicsContext &mContext;

  public:
	AvbdBlockSolveTask(AvbdDynamicsContext &context, PxU64 id) : Cm::Task(id), mContext(context) {}
	PxU32 begin=0,end=0;
    bool bounded=false;
    void runInternal() PX_OVERRIDE
    {if(bounded)mContext.solveBoundedBatch(begin,end);else mContext.solvePrimalBatch();}
	const char *getName() const PX_OVERRIDE { return "AVBD.colorBlocks"; }
};
} // namespace Dy
} // namespace physx


PX_COMPILE_TIME_ASSERT(AVBD_MAX_JOINT_ROWS == MAX_CONSTRAINT_ROWS);
PX_COMPILE_TIME_ASSERT(DeformableVolume::eMAX_CPU_STATIC_BOXES + DeformableVolume::eMAX_CPU_DYNAMIC_BOXES
	<= AVBD_SOFT_MAX_STATIC_BOXES);
PX_COMPILE_TIME_ASSERT(DeformableVolume::eMAX_CPU_WORLD_PINS <= AVBD_SOFT_MAX_WORLD_PINS);

AvbdDynamicsContext::AvbdDynamicsContext(PxcNpMemBlockPool* memBlockPool,
	Cm::FlushPool& taskPool, PxvSimStats& simStats,
	Cm::VirtualAllocatorCallback& allocator, PxsMaterialManager* materialManager,
	IG::SimpleIslandManager& islandManager, PxU64 contextID,
	PxReal maxBiasCoefficient, PxReal lengthScale, PxSceneFlags sceneFlags)
	: DynamicsContextBase(memBlockPool, taskPool, simStats, allocator,
		  materialManager, islandManager, contextID, maxBiasCoefficient,
		  lengthScale, sceneFlags)
	, mIslandSoftLiveStamp(0)
	, mIslandSurfaceLiveStamp(0)
	, mContactRowCount(0)
	, mNpContactRowCount(0)
	, mIterations(AVBD_ITERS_CONTACT)
	, mLengthScale(lengthScale)
	, mGravity(0.0f)
	, mKernels(KernelTable::makeAvbdCpuScalar())
{
	mOgc.contactRadius = 0.04f * lengthScale;
	mOgc.contactStiffness = 1.0e5f;
	mOgc.safetyRelax = 0.45f;
	mOgc.tau = -1.0f;
}

AvbdDynamicsContext::~AvbdDynamicsContext()
{
    clearCommonPublication();
	clearIslandSoftCache();
	clearIslandSurfaceCache();
	for(PxU32 i=0;i<mBlockTasks.size();++i) PX_DELETE(mBlockTasks[i]);
	PX_DELETE(mColorContinuation);
}

void AvbdDynamicsContext::destroy()
{
	clearIslandSoftCache();
	clearIslandSurfaceCache();
	this->~AvbdDynamicsContext();
	PX_FREE_THIS;
}

namespace
{
bool avbdReadTetIndices(const PxTetrahedronMesh& mesh, PxU32 tet, PxU32 out[4])
{
	if(tet >= mesh.getNbTetrahedrons())
		return false;
	const bool idx16 = mesh.getTetrahedronMeshFlags() & PxTetrahedronMeshFlag::e16_BIT_INDICES;
	if(idx16)
	{
		const PxU16* idx = reinterpret_cast<const PxU16*>(mesh.getTetrahedrons());
		out[0] = idx[tet * 4 + 0];
		out[1] = idx[tet * 4 + 1];
		out[2] = idx[tet * 4 + 2];
		out[3] = idx[tet * 4 + 3];
	}
	else
	{
		const PxU32* idx = reinterpret_cast<const PxU32*>(mesh.getTetrahedrons());
		out[0] = idx[tet * 4 + 0];
		out[1] = idx[tet * 4 + 1];
		out[2] = idx[tet * 4 + 2];
		out[3] = idx[tet * 4 + 3];
	}
	return true;
}

bool avbdReadTriIndices(const PxTriangleMesh& mesh, PxU32 tri, PxU32 out[3])
{
	if(tri >= mesh.getNbTriangles())
		return false;
	if(mesh.getTriangleMeshFlags() & PxTriangleMeshFlag::e16_BIT_INDICES)
	{
		const PxU16* idx = reinterpret_cast<const PxU16*>(mesh.getTriangles());
		out[0] = idx[tri * 3 + 0];
		out[1] = idx[tri * 3 + 1];
		out[2] = idx[tri * 3 + 2];
	}
	else
	{
		const PxU32* idx = reinterpret_cast<const PxU32*>(mesh.getTriangles());
		out[0] = idx[tri * 3 + 0];
		out[1] = idx[tri * 3 + 1];
		out[2] = idx[tri * 3 + 2];
	}
	return true;
}
} // namespace

namespace
{
PxU32 packCpuWorldPins(DeformableVolume& vol, AvbdSoftWorldPin* pins, PxU32 maxPins)
{
	PxU32 n = 0;
	DeformableVolume::CpuWorldPin* host = vol.getCpuWorldPins();
	const PxU32 nb = vol.getNbCpuWorldPins();
	for(PxU32 i = 0; i < nb && n < maxPins; ++i)
	{
		if(host[i].vertex == PX_MAX_U32)
			continue;
		pins[n].vertex = host[i].vertex;
		pins[n].target = host[i].worldTarget;
		pins[n].k = &host[i].k;
		pins[n].lambda = &host[i].lambda;
		++n;
	}
	return n;
}
} // namespace

void AvbdDynamicsContext::clearIslandSoftCache()
{
	for(PxU32 i = 0; i < mIslandSoftCache.size(); ++i)
		avbdFreeIslandSoftBlocks(mIslandSoftCache[i]);
	mIslandSoftCache.forceSize_Unsafe(0);
}

AvbdIslandSoftCache* AvbdDynamicsContext::getIslandSoftCache(DeformableVolume* volume)
{
	for(PxU32 i = 0; i < mIslandSoftCache.size(); ++i)
	{
		if(mIslandSoftCache[i].volume == volume)
			return &mIslandSoftCache[i];
	}
	return NULL;
}

void AvbdDynamicsContext::fillVolumeSdfBoxes(const DeformableVolume& vol,
	AvbdSoftStaticBox* boxes, PxU32& nbBoxes) const
{
	nbBoxes = 0;
	const PxU32 nHostStatic = vol.getNbCpuStaticBoxes();
	const DeformableVolume::CpuStaticBox* hostStatic = vol.getCpuStaticBoxes();
	for(PxU32 b = 0; b < nHostStatic && nbBoxes < AVBD_SOFT_MAX_STATIC_BOXES; ++b)
	{
		avbdFillSdfBox(boxes[nbBoxes], hostStatic[b].center, hostStatic[b].halfExtent,
			hostStatic[b].contactOffset, mOgc.contactRadius, hostStatic[b].rotation);
		++nbBoxes;
	}
	const PxU32 nHostDyn = vol.getNbCpuDynamicBoxes();
	const DeformableVolume::CpuDynamicBox* hostDyn = vol.getCpuDynamicBoxes();
	for(PxU32 b = 0; b < nHostDyn && nbBoxes < AVBD_SOFT_MAX_STATIC_BOXES; ++b)
	{
		const PxU32 bodyIdx = findBody(hostDyn[b].bodyCore);
		const AvbdSolverBody* body = (bodyIdx < mBodies.size()) ? &mBodies[bodyIdx] : NULL;
		avbdFillHostDynSdfBox(boxes[nbBoxes], hostDyn[b], body, mOgc.contactRadius);
		++nbBoxes;
	}
}

void AvbdDynamicsContext::injectHostDynamicSoftRigidBodies(const PxVec3& gravity, PxReal dt)
{
	const IG::IslandSim& islandSim = mIslandManager.getAccurateIslandSim();
	const PxU32 nbNodes = islandSim.getNbActiveNodes(IG::Node::eDEFORMABLE_VOLUME_TYPE);
	const PxNodeIndex* nodeIds = islandSim.getActiveNodes(IG::Node::eDEFORMABLE_VOLUME_TYPE);
	for(PxU32 n = 0; n < nbNodes; ++n)
	{
		DeformableVolume* vol = static_cast<DeformableVolume*>(islandSim.getNode(nodeIds[n]).mObject);
		if(!vol)
			continue;
		const PxU32 nDyn = vol->getNbCpuDynamicBoxes();
		const DeformableVolume::CpuDynamicBox* hostDyn = vol->getCpuDynamicBoxes();
		for(PxU32 d = 0; d < nDyn; ++d)
		{
			if(!hostDyn[d].bodyCore || findBody(hostDyn[d].bodyCore) != PX_MAX_U32)
				continue;
			PxsBodyCore& core = *hostDyn[d].bodyCore;
			if(core.isKinematic() || core.inverseMass == 0.0f)
				continue;
			if(core.wakeCounter <= 0.0f)
				continue;
			AvbdSolverBody b;
			initSolverBody(b, core, hostDyn[d].rigid, gravity, dt);
			mBodies.pushBack(b);
		}
	}
}

bool AvbdDynamicsContext::anyCoupledDeformableVolume() const
{
	for(PxU32 i = 0; i < mIslandSoftCache.size(); ++i)
	{
		if(mIslandSoftCache[i].coupled &&
			mIslandSoftCache[i].liveStamp == mIslandSoftLiveStamp)
			return true;
	}
	return false;
}

bool AvbdDynamicsContext::anyLiveDeformableSurface() const
{
	for(PxU32 i = 0; i < mIslandSurfaceCache.size(); ++i)
		if(mIslandSurfaceCache[i].liveStamp == mIslandSurfaceLiveStamp)
			return true;
	return false;
}

namespace
{
// The simulation tetrahedra are the AVBD unknowns; collision vertices are an
// embedded view of those unknowns.  This is the Host equivalent of
// PxDeformableVolumeExt::updateEmbeddedCollisionMesh and uses the same cooked
// tet remap/barycentric contract.
bool avbdWriteEmbeddedCollisionPositions(DeformableVolume& volume,
	DeformableVolumeCore& core)
{
	PxTetrahedronMesh* collisionMesh = volume.getCollisionMesh();
	PxTetrahedronMesh* simulationMesh = volume.getSimulationMesh();
	if(!core.positionInvMass || !core.simPositionInvMass || !collisionMesh || !simulationMesh)
		return false;

	const PxU32 nbCollisionVertices = collisionMesh->getNbVertices();
	const PxU32 nbSimulationVertices = simulationMesh->getNbVertices();
	// Equal vertex counts do not imply an identity embedding. Use the cooked
	// mapping for publication, as for contact supports and the SDK extension.

	Gu::DeformableVolumeAuxData* aux =
		static_cast<Gu::DeformableVolumeAuxData*>(volume.getAuxData());
	if(!aux || !aux->mVertsRemapInGridModel || !aux->mVertsBarycentricInGridModel)
		return false;

	const void* tetrahedra = simulationMesh->getTetrahedrons();
	const PxU32 nbTetrahedra = simulationMesh->getNbTetrahedrons();
	if(!tetrahedra || nbTetrahedra == 0)
		return false;
	const bool sixteenBit = simulationMesh->getTetrahedronMeshFlags().isSet(
		PxTetrahedronMeshFlag::e16_BIT_INDICES);
	const PxU16* tets16 = static_cast<const PxU16*>(tetrahedra);
	const PxU32* tets32 = static_cast<const PxU32*>(tetrahedra);

	for(PxU32 i = 0; i < nbCollisionVertices; ++i)
	{
		const PxU32 tet = aux->mVertsRemapInGridModel[i];
		if(tet >= nbTetrahedra)
			return false;
		PxU32 ids[4];
		for(PxU32 j = 0; j < 4; ++j)
		{
			ids[j] = sixteenBit ? PxU32(tets16[4 * tet + j]) : tets32[4 * tet + j];
			if(ids[j] >= nbSimulationVertices)
				return false;
		}
		const PxReal* w = aux->mVertsBarycentricInGridModel + 4 * i;
		PxVec4 embedded = core.simPositionInvMass[ids[0]] * w[0] +
			core.simPositionInvMass[ids[1]] * w[1] +
			core.simPositionInvMass[ids[2]] * w[2] +
			core.simPositionInvMass[ids[3]] * w[3];
		embedded.w = 1.0f;
		core.positionInvMass[i] = embedded;
	}
	return true;
}

PX_FORCE_INLINE void avbdSortFaceKey(PxU32 (&key)[3])
{
	if(key[0] > key[1]) PxSwap(key[0], key[1]);
	if(key[1] > key[2]) PxSwap(key[1], key[2]);
	if(key[0] > key[1]) PxSwap(key[0], key[1]);
}

bool avbdBuildTetIncidence(AvbdIslandSoftCache& cache)
{
	cache.incidentTetOffsets = reinterpret_cast<PxU32*>(PX_ALLOC(
		sizeof(PxU32) * (cache.nbParticles + 1),
		"AvbdIslandSoftCache::incidentTetOffsets"));
	cache.incidentTetIndices = reinterpret_cast<PxU32*>(PX_ALLOC(
		sizeof(PxU32) * 4 * cache.nbTets,
		"AvbdIslandSoftCache::incidentTetIndices"));
	cache.incidentTetCorners = reinterpret_cast<PxU8*>(PX_ALLOC(
		sizeof(PxU8) * 4 * cache.nbTets,
		"AvbdIslandSoftCache::incidentTetCorners"));
	if(!cache.incidentTetOffsets || !cache.incidentTetIndices || !cache.incidentTetCorners) return false;
	PxMemZero(cache.incidentTetOffsets,
		sizeof(PxU32) * (cache.nbParticles + 1));
	for(PxU32 tetIndex = 0; tetIndex < cache.nbTets; ++tetIndex)
	{
		const AvbdSoftTet& tet = cache.tets[tetIndex];
		const PxU32 ids[4] = {tet.p0, tet.p1, tet.p2, tet.p3};
		for(PxU32 corner = 0; corner < 4; ++corner)
		{
			if(ids[corner] >= cache.nbParticles) return false;
			++cache.incidentTetOffsets[ids[corner] + 1];
		}
	}
	for(PxU32 particle = 1; particle <= cache.nbParticles; ++particle)
		cache.incidentTetOffsets[particle] +=
			cache.incidentTetOffsets[particle - 1];
	PxArray<PxU32> cursor;
	cursor.resize(cache.nbParticles);
	for(PxU32 particle = 0; particle < cache.nbParticles; ++particle)
		cursor[particle] = cache.incidentTetOffsets[particle];
	for(PxU32 tetIndex = 0; tetIndex < cache.nbTets; ++tetIndex)
	{
		const AvbdSoftTet& tet = cache.tets[tetIndex];
		const PxU32 ids[4] = {tet.p0, tet.p1, tet.p2, tet.p3};
		for(PxU32 corner = 0; corner < 4; ++corner)
		{
			const PxU32 index = cursor[ids[corner]]++;
			cache.incidentTetIndices[index] = tetIndex;
			cache.incidentTetCorners[index] = PxU8(corner);
		}
	}
	cache.materialNeighborOffsets = reinterpret_cast<PxU32*>(PX_ALLOC(
		sizeof(PxU32) * (cache.nbParticles + 1), "AvbdSoftTopology::neighborOffsets"));
	if(!cache.materialNeighborOffsets) return false;
	PxArray<PxU32> neighbors, local;
	for(PxU32 particle = 0; particle < cache.nbParticles; ++particle)
	{
		cache.materialNeighborOffsets[particle] = neighbors.size();
		local.clear();
		for(PxU32 ref=cache.incidentTetOffsets[particle]; ref<cache.incidentTetOffsets[particle+1]; ++ref)
		{
			const AvbdSoftTet& tet=cache.tets[cache.incidentTetIndices[ref]];
			const PxU32 ids[4]={tet.p0,tet.p1,tet.p2,tet.p3};
			for(PxU32 corner=0; corner<4; ++corner)
				if(ids[corner]!=particle) local.pushBack(ids[corner]);
		}
		if(local.size()) PxSort(local.begin(), local.size());
		for(PxU32 i=0; i<local.size(); ++i)
			if(i==0 || local[i]!=local[i-1]) neighbors.pushBack(local[i]);
	}
	cache.materialNeighborOffsets[cache.nbParticles] = neighbors.size();
	cache.materialNeighbors = reinterpret_cast<PxU32*>(PX_ALLOC(
		sizeof(PxU32) * neighbors.size(), "AvbdSoftTopology::neighbors"));
	if(!cache.materialNeighbors) return false;
	PxMemCopy(cache.materialNeighbors, neighbors.begin(), sizeof(PxU32)*neighbors.size());
	return true;
}

// Cooking publishes collision-to-simulation barycentrics as floats.  Exact
// zero coordinates can therefore arrive as tiny signed values.  Leaving one
// in the row support set is harmless for point reconstruction but singular
// for a coordinate-domain plane: normalizing by that weight magnifies input
// roundoff into a macroscopic Particle3 displacement.  Canonicalize only the
// float input-error interval, then restore the affine partition of unity.
bool avbdCanonicalizeEmbeddedPoint(AvbdSoftEmbeddedPoint& point)
{
	double absoluteSum=0.0;
	for(PxU32 i=0;i<point.count;++i)
	{
		if(!PxIsFinite(point.weights[i])) return false;
		absoluteSum+=PxAbs(double(point.weights[i]));
	}
	const double zeroInterval=4.0*double(PX_EPS_F32)*PxMax(1.0,absoluteSum);
	PxU32 write=0;
	for(PxU32 i=0;i<point.count;++i)
	{
		if(PxAbs(double(point.weights[i]))<=zeroInterval) continue;
		point.particleIndices[write]=point.particleIndices[i];
		point.weights[write]=point.weights[i];
		++write;
	}
	if(!write) return false;
	point.count=PxU8(write);
	double sum=0.0;
	for(PxU32 i=0;i<point.count;++i) sum+=double(point.weights[i]);
	if(!PxIsFinite(sum) || PxAbs(sum)<=zeroInterval) return false;
	PxU32 largest=0;
	PxReal normalizedSum=0.0f;
	for(PxU32 i=0;i<point.count;++i)
	{
		point.weights[i]=PxReal(double(point.weights[i])/sum);
		normalizedSum+=point.weights[i];
		if(PxAbs(point.weights[i])>PxAbs(point.weights[largest])) largest=i;
	}
	point.weights[largest]+=1.0f-normalizedSum;
	return PxIsFinite(point.weights[largest]);
}

bool avbdBuildCollisionTopology(AvbdIslandSoftCache& cache,
	DeformableVolume& volume, const PxTetrahedronMesh& simulationMesh)
{
	// Contact geometry is the cooked collision proxy, expanded immediately to
	// simulation-particle supports. The simulation tetrahedra remain the only
	// unknowns; the collision mesh supplies PhysX's authored feature topology.
	const PxTetrahedronMesh* collisionMesh = volume.getCollisionMesh();
	if(!collisionMesh || !collisionMesh->getNbVertices() ||
		!collisionMesh->getNbTetrahedrons())
		return false;
	cache.nbCollisionParticles = collisionMesh->getNbVertices();
	cache.nbCollisionTets = collisionMesh->getNbTetrahedrons();
	cache.collisionPoints = reinterpret_cast<AvbdSoftEmbeddedPoint*>(PX_ALLOC(
		sizeof(AvbdSoftEmbeddedPoint) * cache.nbCollisionParticles,
		"AvbdIslandSoftCache::collisionPoints"));
	cache.collisionTets = reinterpret_cast<PxU32*>(PX_ALLOC(
		sizeof(PxU32) * 4 * cache.nbCollisionTets,
		"AvbdIslandSoftCache::collisionTets"));
	cache.boundaryFaces = reinterpret_cast<AvbdSoftBoundaryFace*>(PX_ALLOC(
		sizeof(AvbdSoftBoundaryFace) * 4 * cache.nbCollisionTets,
		"AvbdIslandSoftCache::boundaryFaces"));
	if(!cache.collisionPoints || !cache.collisionTets || !cache.boundaryFaces)
		return false;

	for(PxU32 tet = 0; tet < cache.nbCollisionTets; ++tet)
	{
		PxU32 ids[4];
		if(!avbdReadTetIndices(*collisionMesh, tet, ids)) return false;
		for(PxU32 i = 0; i < 4; ++i)
		{
			if(ids[i] >= cache.nbCollisionParticles) return false;
			cache.collisionTets[4 * tet + i] = ids[i];
		}
	}

	const PxU32 simulationVertexCount = simulationMesh.getNbVertices();
	{
		Gu::DeformableVolumeAuxData* aux =
			static_cast<Gu::DeformableVolumeAuxData*>(volume.getAuxData());
		if(!aux || !aux->mVertsRemapInGridModel ||
			!aux->mVertsBarycentricInGridModel)
			return false;
		for(PxU32 vertex = 0; vertex < cache.nbCollisionParticles; ++vertex)
		{
			const PxU32 simulationTet = aux->mVertsRemapInGridModel[vertex];
			PxU32 ids[4];
			if(!avbdReadTetIndices(simulationMesh, simulationTet, ids)) return false;
			AvbdSoftEmbeddedPoint& point = cache.collisionPoints[vertex];
			point.count = 4;
			for(PxU32 i = 0; i < 4; ++i)
			{
				if(ids[i] >= simulationVertexCount) return false;
				point.particleIndices[i] = ids[i];
				point.weights[i] = aux->mVertsBarycentricInGridModel[4 * vertex + i];
			}
			if(!avbdCanonicalizeEmbeddedPoint(point)) return false;
		}
	}

	static const PxU32 faceCorners[4][3] =
	{
		{1, 2, 3}, {0, 3, 2}, {0, 1, 3}, {0, 2, 1}
	};
	PxU32 faceCount = 0;
	for(PxU32 tet = 0; tet < cache.nbCollisionTets; ++tet)
	{
		const PxU32* ids = cache.collisionTets + 4 * tet;
		for(PxU32 opposite = 0; opposite < 4; ++opposite)
		{
			PxU32 key[3] = {ids[faceCorners[opposite][0]],
				ids[faceCorners[opposite][1]], ids[faceCorners[opposite][2]]};
			avbdSortFaceKey(key);
			PxU32 match = PX_MAX_U32;
			for(PxU32 existing = 0; existing < faceCount; ++existing)
			{
				if(cache.boundaryFaces[existing].vertices[0] == PX_MAX_U32) continue;
				PxU32 existingKey[3] = {cache.boundaryFaces[existing].vertices[0],
					cache.boundaryFaces[existing].vertices[1],
					cache.boundaryFaces[existing].vertices[2]};
				avbdSortFaceKey(existingKey);
				if(existingKey[0] == key[0] && existingKey[1] == key[1] &&
					existingKey[2] == key[2]) { match = existing; break; }
			}
			if(match != PX_MAX_U32)
				cache.boundaryFaces[match].vertices[0] = PX_MAX_U32;
			else
			{
				AvbdSoftBoundaryFace& face = cache.boundaryFaces[faceCount++];
				face.vertices[0] = ids[faceCorners[opposite][0]];
				face.vertices[1] = ids[faceCorners[opposite][1]];
				face.vertices[2] = ids[faceCorners[opposite][2]];
				face.oppositeVertex = ids[opposite];
			}
		}
	}
	PxU32 write = 0;
	for(PxU32 face = 0; face < faceCount; ++face)
		if(cache.boundaryFaces[face].vertices[0] != PX_MAX_U32)
			cache.boundaryFaces[write++] = cache.boundaryFaces[face];
	cache.nbBoundaryFaces = write;
	if(write == 0)
		return false;

	cache.boundaryVertices = reinterpret_cast<PxU8*>(PX_ALLOC(
		sizeof(PxU8) * cache.nbCollisionParticles,
		"AvbdIslandSoftCache::boundaryVertices"));
	cache.boundaryEdges = reinterpret_cast<AvbdSoftBoundaryEdgeTopology*>(PX_ALLOC(
		sizeof(AvbdSoftBoundaryEdgeTopology) * 3 * cache.nbBoundaryFaces,
		"AvbdIslandSoftCache::boundaryEdges"));
	if(!cache.boundaryVertices || !cache.boundaryEdges)
		return false;
	PxMemZero(cache.boundaryVertices,
		sizeof(PxU8) * cache.nbCollisionParticles);
	cache.nbBoundaryEdges = 0;
	for(PxU32 faceIndex = 0; faceIndex < cache.nbBoundaryFaces; ++faceIndex)
	{
		const AvbdSoftBoundaryFace& face = cache.boundaryFaces[faceIndex];
		for(PxU32 corner = 0; corner < 3; ++corner)
			cache.boundaryVertices[face.vertices[corner]] = 1;
		for(PxU32 corner = 0; corner < 3; ++corner)
		{
			PxU32 v0 = face.vertices[corner];
			PxU32 v1 = face.vertices[(corner + 1) % 3];
			if(v0 > v1) PxSwap(v0, v1);
			PxU32 edgeIndex = PX_MAX_U32;
			for(PxU32 existing = 0; existing < cache.nbBoundaryEdges; ++existing)
				if(cache.boundaryEdges[existing].v0 == v0 &&
					cache.boundaryEdges[existing].v1 == v1)
				{ edgeIndex = existing; break; }
			if(edgeIndex == PX_MAX_U32)
			{
				AvbdSoftBoundaryEdgeTopology& edge =
					cache.boundaryEdges[cache.nbBoundaryEdges++];
				edge.v0 = v0; edge.v1 = v1;
				edge.face0 = faceIndex; edge.face1 = PX_MAX_U32;
			}
			else if(cache.boundaryEdges[edgeIndex].face1 == PX_MAX_U32)
				cache.boundaryEdges[edgeIndex].face1 = faceIndex;
		}
	}
	if(cache.nbBoundaryEdges == 0)
		return false;

	// Compile the structural access descriptor used by a simulation-particle
	// block.  Collision vertices can be embedded in four simulation particles;
	// a boundary face is incident when any of its three embedded vertices owns
	// a non-zero weight for that particle.  This is topology-only and therefore
	// remains valid for every nonlinear iterate.
	cache.incidentBoundaryFaceOffsets = reinterpret_cast<PxU32*>(PX_ALLOC(
		sizeof(PxU32) * (cache.nbParticles + 1),
		"AvbdIslandSoftCache::incidentBoundaryFaceOffsets"));
	if(!cache.incidentBoundaryFaceOffsets)
		return false;
	PxMemZero(cache.incidentBoundaryFaceOffsets,
		sizeof(PxU32) * (cache.nbParticles + 1));
	for(PxU32 faceIndex = 0; faceIndex < cache.nbBoundaryFaces; ++faceIndex)
	{
		PxU32 supports[12];
		PxU32 supportCount = 0;
		const AvbdSoftBoundaryFace& face = cache.boundaryFaces[faceIndex];
		for(PxU32 corner = 0; corner < 3; ++corner)
		{
			const AvbdSoftEmbeddedPoint& point =
				cache.collisionPoints[face.vertices[corner]];
			for(PxU32 support = 0; support < point.count; ++support)
			{
				if(PxAbs(point.weights[support]) <= 1.0e-8f)
					continue;
				const PxU32 particle = point.particleIndices[support];
				bool duplicate = false;
				for(PxU32 existing = 0; existing < supportCount; ++existing)
					duplicate |= supports[existing] == particle;
				if(!duplicate)
					supports[supportCount++] = particle;
			}
		}
		for(PxU32 support = 0; support < supportCount; ++support)
		{
			if(supports[support] >= cache.nbParticles)
				return false;
			++cache.incidentBoundaryFaceOffsets[supports[support] + 1];
		}
	}
	for(PxU32 particle = 1; particle <= cache.nbParticles; ++particle)
		cache.incidentBoundaryFaceOffsets[particle] +=
			cache.incidentBoundaryFaceOffsets[particle - 1];
	const PxU32 referenceCount =
		cache.incidentBoundaryFaceOffsets[cache.nbParticles];
	cache.incidentBoundaryFaceIndices = reinterpret_cast<PxU32*>(PX_ALLOC(
		sizeof(PxU32) * referenceCount,
		"AvbdIslandSoftCache::incidentBoundaryFaceIndices"));
	if(referenceCount && !cache.incidentBoundaryFaceIndices)
		return false;
	PxArray<PxU32> cursor;
	cursor.resize(cache.nbParticles);
	for(PxU32 particle = 0; particle < cache.nbParticles; ++particle)
		cursor[particle] = cache.incidentBoundaryFaceOffsets[particle];
	for(PxU32 faceIndex = 0; faceIndex < cache.nbBoundaryFaces; ++faceIndex)
	{
		PxU32 supports[12];
		PxU32 supportCount = 0;
		const AvbdSoftBoundaryFace& face = cache.boundaryFaces[faceIndex];
		for(PxU32 corner = 0; corner < 3; ++corner)
		{
			const AvbdSoftEmbeddedPoint& point =
				cache.collisionPoints[face.vertices[corner]];
			for(PxU32 support = 0; support < point.count; ++support)
			{
				if(PxAbs(point.weights[support]) <= 1.0e-8f)
					continue;
				const PxU32 particle = point.particleIndices[support];
				bool duplicate = false;
				for(PxU32 existing = 0; existing < supportCount; ++existing)
					duplicate |= supports[existing] == particle;
				if(!duplicate)
					supports[supportCount++] = particle;
			}
		}
		for(PxU32 support = 0; support < supportCount; ++support)
			cache.incidentBoundaryFaceIndices[cursor[supports[support]]++] = faceIndex;
	}
	return true;
}
} // namespace

void AvbdDynamicsContext::publishIslandSoftCache(AvbdIslandSoftCache& cache)
{
	DeformableVolume* vol = cache.volume;
	if(!vol || !cache.particles)
		return;
	DeformableVolumeCore& core = vol->getCore();
	if(!core.simPositionInvMass || !core.simVelocity)
		return;
	for(PxU32 i = 0; i < cache.nbParticles; ++i)
	{
		AvbdSoftParticle& p = cache.particles[i];
		core.simPositionInvMass[i] = PxVec4(p.p, p.invMass);
		core.simVelocity[i] = PxVec4(p.vel, p.invMass);
		cache.contactK[i] = p.contactK;
		cache.contactLambda[i] = p.contactLambda;
		if(cache.boxContactK)
		{
			for(PxU32 b = 0; b < AVBD_SOFT_MAX_STATIC_BOXES; ++b)
				cache.boxContactK[i * AVBD_SOFT_MAX_STATIC_BOXES + b] = p.boxContactK[b];
		}
		if(cache.boxContactLambda)
		{
			for(PxU32 b = 0; b < AVBD_SOFT_MAX_STATIC_BOXES; ++b)
				cache.boxContactLambda[i * AVBD_SOFT_MAX_STATIC_BOXES + b] = p.boxContactLambda[b];
		}
	}
	avbdWriteEmbeddedCollisionPositions(*vol, core);
	core.dirtyFlags = PxDeformableVolumeDataFlags(PxDeformableVolumeDataFlag::ePOSITION_INVMASS);
	core.dirtyFlags |= PxDeformableVolumeDataFlag::eSIM_POSITION_INVMASS;
	core.dirtyFlags |= PxDeformableVolumeDataFlag::eSIM_VELOCITY;
}

void AvbdDynamicsContext::pruneIslandSoftCache()
{
	PxU32 w = 0;
	for(PxU32 i = 0; i < mIslandSoftCache.size(); ++i)
	{
		if(mIslandSoftCache[i].liveStamp == mIslandSoftLiveStamp)
		{
			if(w != i)
				mIslandSoftCache[w] = mIslandSoftCache[i];
			++w;
		}
		else
			avbdFreeIslandSoftBlocks(mIslandSoftCache[i]);
	}
	mIslandSoftCache.forceSize_Unsafe(w);
}

namespace
{
PxVec3 avbdEmbeddedPosition(const AvbdIslandSoftCache& cache,
	const AvbdSoftEmbeddedPoint& point, bool initial)
{
	PxVec3 result(0.0f);
	for(PxU32 i = 0; i < point.count; ++i)
	{
		const AvbdSoftParticle& particle = cache.particles[point.particleIndices[i]];
		result += (initial ? particle.pStart : particle.p) * point.weights[i];
	}
	return result;
}

PxVec3 avbdEmbeddedPredictedPosition(const AvbdIslandSoftCache& cache,
	const AvbdSoftEmbeddedPoint& point)
{
	PxVec3 result(0.0f);
	for(PxU32 i = 0; i < point.count; ++i)
		result += cache.particles[point.particleIndices[i]].pHat * point.weights[i];
	return result;
}

PxVec3 avbdPairPoint(const AvbdIslandSoftCache& cache,
	const PxU32* indices, const PxReal* weights, PxU32 count)
{
	PxVec3 result(0.0f);
	for(PxU32 i = 0; i < count; ++i)
		result += cache.particles[indices[i]].p * weights[i];
	return result;
}

PxReal avbdPairJacobianScale(const AvbdSoftPairContact& contact,
	PxU32 cacheIndex, PxU32 particleIndex)
{
	PxReal scale = 0.0f;
	if(cacheIndex == contact.queryCache)
		for(PxU32 i = 0; i < contact.queryParticleCount; ++i)
			if(contact.queryParticleIndices[i] == particleIndex)
				scale += contact.queryWeights[i];
	if(cacheIndex == contact.targetCache)
		for(PxU32 i = 0; i < contact.targetParticleCount; ++i)
			if(contact.targetParticleIndices[i] == particleIndex)
				scale -= contact.targetWeights[i];
	return scale;
}

void avbdClosestPointTriangle(const PxVec3& point, const PxVec3& a,
	const PxVec3& b, const PxVec3& c, PxVec3& closest, PxVec3& barycentric)
{
	const PxVec3 ab = b - a, ac = c - a, ap = point - a;
	const PxReal d1 = ab.dot(ap), d2 = ac.dot(ap);
	if(d1 <= 0.0f && d2 <= 0.0f)
	{
		closest = a; barycentric = PxVec3(1.0f, 0.0f, 0.0f); return;
	}
	const PxVec3 bp = point - b;
	const PxReal d3 = ab.dot(bp), d4 = ac.dot(bp);
	if(d3 >= 0.0f && d4 <= d3)
	{
		closest = b; barycentric = PxVec3(0.0f, 1.0f, 0.0f); return;
	}
	const PxReal vc = d1 * d4 - d3 * d2;
	if(vc <= 0.0f && d1 >= 0.0f && d3 <= 0.0f)
	{
		const PxReal v = d1 / (d1 - d3);
		closest = a + ab * v; barycentric = PxVec3(1.0f - v, v, 0.0f); return;
	}
	const PxVec3 cp = point - c;
	const PxReal d5 = ab.dot(cp), d6 = ac.dot(cp);
	if(d6 >= 0.0f && d5 <= d6)
	{
		closest = c; barycentric = PxVec3(0.0f, 0.0f, 1.0f); return;
	}
	const PxReal vb = d5 * d2 - d1 * d6;
	if(vb <= 0.0f && d2 >= 0.0f && d6 <= 0.0f)
	{
		const PxReal w = d2 / (d2 - d6);
		closest = a + ac * w; barycentric = PxVec3(1.0f - w, 0.0f, w); return;
	}
	const PxReal va = d3 * d6 - d5 * d4;
	if(va <= 0.0f && d4 - d3 >= 0.0f && d5 - d6 >= 0.0f)
	{
		const PxReal w = (d4 - d3) / ((d4 - d3) + (d5 - d6));
		closest = b + (c - b) * w; barycentric = PxVec3(0.0f, 1.0f - w, w); return;
	}
	const PxReal denominator = 1.0f / (va + vb + vc);
	const PxReal v = vb * denominator, w = vc * denominator;
	barycentric = PxVec3(1.0f - v - w, v, w);
	closest = a * barycentric.x + b * barycentric.y + c * barycentric.z;
}

bool avbdPointInsideCollisionVolume(const PxVec3& point,
	const AvbdIslandSoftCache& target, const PxArray<PxVec3>& positions)
{
	for(PxU32 tet = 0; tet < target.nbCollisionTets; ++tet)
	{
		const PxU32* ids = target.collisionTets + 4 * tet;
		const PxVec3 a = positions[ids[0]];
		const PxMat33 basis(positions[ids[1]] - a, positions[ids[2]] - a,
			positions[ids[3]] - a);
		if(PxAbs(basis.getDeterminant()) <= 1.0e-12f) continue;
		const PxVec3 w = basis.getInverse() * (point - a);
		const PxReal w0 = 1.0f - w.x - w.y - w.z;
		if(w0 >= 0.0f && w.x >= 0.0f && w.y >= 0.0f && w.z >= 0.0f)
			return true;
	}
	return false;
}

bool avbdHostSoftPair(const DeformableVolume& a, const DeformableVolume& b,
	PxReal& margin)
{
	margin = 0.0f;
	const DeformableVolume::CpuSoftPair* pairs = a.getCpuSoftPairs();
	for(PxU32 i = 0; i < a.getNbCpuSoftPairs(); ++i)
		if(pairs[i].other == &b)
		{
			margin = pairs[i].contactOffset;
			return true;
		}
	return false;
}

void avbdAppendTargetSupport(AvbdSoftPairContact& contact,
	const AvbdSoftEmbeddedPoint& point, PxReal faceWeight)
{
	for(PxU32 i = 0; i < point.count; ++i)
	{
		const PxU32 particle = point.particleIndices[i];
		const PxReal weight = faceWeight * point.weights[i];
		bool found = false;
		for(PxU32 existing = 0; existing < contact.targetParticleCount; ++existing)
			if(contact.targetParticleIndices[existing] == particle)
			{
				contact.targetWeights[existing] += weight;
				found = true;
				break;
			}
		if(!found && contact.targetParticleCount < 12)
		{
			const PxU32 slot = contact.targetParticleCount++;
			contact.targetParticleIndices[slot] = particle;
			contact.targetWeights[slot] = weight;
		}
	}
}

void avbdAppendQuerySupport(AvbdSoftPairContact& contact,
	const AvbdSoftEmbeddedPoint& point, PxReal featureWeight)
{
	for(PxU32 i = 0; i < point.count; ++i)
	{
		const PxU32 particle = point.particleIndices[i];
		const PxReal weight = featureWeight * point.weights[i];
		bool found = false;
		for(PxU32 existing = 0; existing < contact.queryParticleCount; ++existing)
			if(contact.queryParticleIndices[existing] == particle)
			{
				contact.queryWeights[existing] += weight;
				found = true;
				break;
			}
		if(!found && contact.queryParticleCount < 8)
		{
			const PxU32 slot = contact.queryParticleCount++;
			contact.queryParticleIndices[slot] = particle;
			contact.queryWeights[slot] = weight;
		}
	}
}

void avbdClosestPointsSegments(const PxVec3& p0, const PxVec3& p1,
	const PxVec3& q0, const PxVec3& q1, PxReal& pWeight1, PxReal& qWeight1,
	PxVec3& pClosest, PxVec3& qClosest)
{
	const PxVec3 dp = p1 - p0, dq = q1 - q0, r = p0 - q0;
	const PxReal a = dp.dot(dp), e = dq.dot(dq);
	const PxReal epsilon = 1.0e-12f;
	if(a <= epsilon && e <= epsilon)
	{
		pWeight1 = qWeight1 = 0.0f; pClosest = p0; qClosest = q0; return;
	}
	if(a <= epsilon)
	{
		pWeight1 = 0.0f; qWeight1 = PxClamp(dq.dot(-r) / e, 0.0f, 1.0f);
	}
	else
	{
		const PxReal c = dp.dot(r);
		if(e <= epsilon)
		{
			qWeight1 = 0.0f; pWeight1 = PxClamp(-c / a, 0.0f, 1.0f);
		}
		else
		{
			const PxReal b = dp.dot(dq), f = dq.dot(r);
			const PxReal denominator = a * e - b * b;
			pWeight1 = denominator > epsilon ?
				PxClamp((b * f - c * e) / denominator, 0.0f, 1.0f) : 0.0f;
			qWeight1 = (b * pWeight1 + f) / e;
			if(qWeight1 < 0.0f)
			{
				qWeight1 = 0.0f; pWeight1 = PxClamp(-c / a, 0.0f, 1.0f);
			}
			else if(qWeight1 > 1.0f)
			{
				qWeight1 = 1.0f; pWeight1 = PxClamp((b - c) / a, 0.0f, 1.0f);
			}
		}
	}
	pClosest = p0 + dp * pWeight1;
	qClosest = q0 + dq * qWeight1;
}

struct AvbdSoftBoundaryEdgeFeature
{
	PxU32 v0, v1;
	PxVec3 normal0, normal1;
	PxU32 normalCount;
};

struct AvbdSoftFeatureBounds
{
	PxVec3 minimum, maximum;
	PxU32 index;
};

struct AvbdSoftEdgeFeatureBounds
{
	AvbdSoftBoundaryEdgeFeature edge;
	PxVec3 minimum, maximum;
};

PX_FORCE_INLINE bool avbdFeatureBoundsLess(const AvbdSoftFeatureBounds& a,
	const AvbdSoftFeatureBounds& b)
{
	return a.minimum.x < b.minimum.x ||
		(a.minimum.x == b.minimum.x && a.index < b.index);
}

PX_FORCE_INLINE bool avbdEdgeBoundsLess(const AvbdSoftEdgeFeatureBounds& a,
	const AvbdSoftEdgeFeatureBounds& b)
{
	return a.minimum.x < b.minimum.x ||
		(a.minimum.x == b.minimum.x && (a.edge.v0 < b.edge.v0 ||
			(a.edge.v0 == b.edge.v0 && a.edge.v1 < b.edge.v1)));
}

PX_FORCE_INLINE bool avbdBoundsOverlap(const PxVec3& minimumA, const PxVec3& maximumA,
	const PxVec3& minimumB, const PxVec3& maximumB)
{
	return minimumA.x <= maximumB.x && maximumA.x >= minimumB.x &&
		minimumA.y <= maximumB.y && maximumA.y >= minimumB.y &&
		minimumA.z <= maximumB.z && maximumA.z >= minimumB.z;
}

void avbdBuildSoftFaceBounds(const AvbdIslandSoftCache& cache,
	const PxArray<PxVec3>& positions0, const PxArray<PxVec3>* positions1,
	const PxArray<PxVec3>* positions2, PxArray<AvbdSoftFeatureBounds>& bounds)
{
	bounds.resize(cache.nbBoundaryFaces);
	for(PxU32 faceIndex = 0; faceIndex < cache.nbBoundaryFaces; ++faceIndex)
	{
		const AvbdSoftBoundaryFace& face = cache.boundaryFaces[faceIndex];
		AvbdSoftFeatureBounds& entry = bounds[faceIndex];
		entry.index = faceIndex;
		entry.minimum = positions0[face.vertices[0]].minimum(positions0[face.vertices[1]]).
			minimum(positions0[face.vertices[2]]);
		entry.maximum = positions0[face.vertices[0]].maximum(positions0[face.vertices[1]]).
			maximum(positions0[face.vertices[2]]);
		if(positions1)
			for(PxU32 corner = 0; corner < 3; ++corner)
			{
				entry.minimum = entry.minimum.minimum((*positions1)[face.vertices[corner]]);
				entry.maximum = entry.maximum.maximum((*positions1)[face.vertices[corner]]);
			}
		if(positions2)
			for(PxU32 corner = 0; corner < 3; ++corner)
			{
				entry.minimum = entry.minimum.minimum((*positions2)[face.vertices[corner]]);
				entry.maximum = entry.maximum.maximum((*positions2)[face.vertices[corner]]);
			}
	}
	PxSort(bounds.begin(), bounds.size(), avbdFeatureBoundsLess);
}

void avbdCollectSoftFaceCandidates(const PxArray<AvbdSoftFeatureBounds>& bounds,
	const PxVec3& queryMinimum, const PxVec3& queryMaximum, PxArray<PxU32>& candidates)
{
	candidates.clear();
	for(PxU32 i = 0; i < bounds.size(); ++i)
	{
		const AvbdSoftFeatureBounds& entry = bounds[i];
		if(entry.minimum.x > queryMaximum.x)
			break;
		if(avbdBoundsOverlap(entry.minimum, entry.maximum, queryMinimum, queryMaximum))
			candidates.pushBack(entry.index);
	}
	// Geometry ownership is topology ordered, independent of the current AABB
	// ordering. This preserves warm-state keys across refits.
	PxSort(candidates.begin(), candidates.size());
}

void avbdBuildSoftBoundaryEdges(const AvbdIslandSoftCache& cache,
	const PxArray<PxVec3>& positions, PxArray<AvbdSoftBoundaryEdgeFeature>& edges)
{
	edges.resize(cache.nbBoundaryEdges);
	auto faceNormal = [&](PxU32 faceIndex)
	{
		if(faceIndex >= cache.nbBoundaryFaces) return PxVec3(0.0f);
		const AvbdSoftBoundaryFace& face = cache.boundaryFaces[faceIndex];
		const PxVec3 a = positions[face.vertices[0]];
		PxVec3 normal = (positions[face.vertices[1]] - a).cross(
			positions[face.vertices[2]] - a);
		const PxReal normalSq = normal.magnitudeSquared();
		if(normalSq <= 1.0e-16f) return PxVec3(0.0f);
		normal *= PxRecipSqrt(normalSq);
		if(normal.dot(positions[face.oppositeVertex] - a) > 0.0f) normal = -normal;
		return normal;
	};
	for(PxU32 edgeIndex = 0; edgeIndex < cache.nbBoundaryEdges; ++edgeIndex)
	{
		const AvbdSoftBoundaryEdgeTopology& topology = cache.boundaryEdges[edgeIndex];
		AvbdSoftBoundaryEdgeFeature& edge = edges[edgeIndex];
		edge.v0 = topology.v0; edge.v1 = topology.v1;
		edge.normal0 = faceNormal(topology.face0);
		edge.normal1 = faceNormal(topology.face1);
		edge.normalCount = topology.face1 == PX_MAX_U32 ? 1 : 2;
	}
}

void avbdBuildSoftEdgeBounds(const AvbdIslandSoftCache& cache,
	const PxArray<PxVec3>& positions0, const PxArray<PxVec3>* positions1,
	const PxArray<PxVec3>* positions2, PxArray<AvbdSoftEdgeFeatureBounds>& bounds)
{
	PxArray<AvbdSoftBoundaryEdgeFeature> edges;
	avbdBuildSoftBoundaryEdges(cache, positions0, edges);
	bounds.resize(edges.size());
	for(PxU32 edgeIndex = 0; edgeIndex < edges.size(); ++edgeIndex)
	{
		const AvbdSoftBoundaryEdgeFeature& edge = edges[edgeIndex];
		AvbdSoftEdgeFeatureBounds& entry = bounds[edgeIndex];
		entry.edge = edge;
		entry.minimum = positions0[edge.v0].minimum(positions0[edge.v1]);
		entry.maximum = positions0[edge.v0].maximum(positions0[edge.v1]);
		if(positions1)
		{
			entry.minimum = entry.minimum.minimum((*positions1)[edge.v0]).
				minimum((*positions1)[edge.v1]);
			entry.maximum = entry.maximum.maximum((*positions1)[edge.v0]).
				maximum((*positions1)[edge.v1]);
		}
		if(positions2)
		{
			entry.minimum = entry.minimum.minimum((*positions2)[edge.v0]).
				minimum((*positions2)[edge.v1]);
			entry.maximum = entry.maximum.maximum((*positions2)[edge.v0]).
				maximum((*positions2)[edge.v1]);
		}
	}
	PxSort(bounds.begin(), bounds.size(), avbdEdgeBoundsLess);
}

bool avbdOwnsSoftEdgeDirection(const AvbdSoftBoundaryEdgeFeature& edge,
	const PxVec3& direction)
{
	if(edge.normalCount < 2) return true;
	const PxReal directionLengthSq = direction.magnitudeSquared();
	const PxReal n0LengthSq = edge.normal0.magnitudeSquared();
	const PxReal n1LengthSq = edge.normal1.magnitudeSquared();
	if(directionLengthSq <= 1.0e-12f || n0LengthSq <= 1.0e-12f ||
		n1LengthSq <= 1.0e-12f) return true;
	const PxVec3 d = direction * PxRecipSqrt(directionLengthSq);
	const PxVec3 n0 = edge.normal0 * PxRecipSqrt(n0LengthSq);
	const PxVec3 n1 = edge.normal1 * PxRecipSqrt(n1LengthSq);
	const PxReal nd = PxClamp(n0.dot(n1), -1.0f, 1.0f);
	const PxReal determinant = 1.0f - nd * nd;
	if(determinant <= 1.0e-6f) return true;
	const PxReal d0 = d.dot(n0), d1 = d.dot(n1);
	const PxReal c0 = (d0 - nd * d1) / determinant;
	const PxReal c1 = (d1 - nd * d0) / determinant;
	if(c0 < -1.0e-3f || c1 < -1.0e-3f) return false;
	return (d - n0 * c0 - n1 * c1).magnitudeSquared() <= 1.0e-3f;
}

PX_FORCE_INLINE PxVec3 avbdVolumeBoxVertex(const AvbdSoftStaticBox& box,
	PxU32 index)
{
	const PxVec3 local = avbdBoxCornerLocal(box.halfExtent, index);
	return box.center + box.rotation.rotate(local);
}

static const PxU8 gAvbdVolumeBoxEdges[12][2] =
{
	{0,1},{2,3},{4,5},{6,7}, {0,2},{1,3},{4,6},{5,7},
	{0,4},{1,5},{2,6},{3,7}
};

void avbdAppendVolumeBoxSupport(AvbdVolumeBoxFeatureContact& contact,
	const AvbdSoftEmbeddedPoint& embedded, PxReal featureWeight)
{
	for(PxU32 support = 0; support < embedded.count; ++support)
	{
		const PxReal weight = featureWeight * embedded.weights[support];
		if(PxAbs(weight) <= 1.0e-10f) continue;
		PxU32 index = 0;
		for(; index < contact.particleCount; ++index)
			if(contact.particleIndices[index] == embedded.particleIndices[support])
			{
				contact.weights[index] += weight;
				break;
			}
		if(index == contact.particleCount && contact.particleCount < 12)
		{
			contact.particleIndices[index] = embedded.particleIndices[support];
			contact.weights[index] = weight;
			++contact.particleCount;
		}
	}
}

const AvbdVolumeBoxFeatureContact* avbdFindVolumeBoxWarm(
	const PxArray<AvbdVolumeBoxFeatureContact>& previous, PxU32 boxIndex,
	PxU8 featureType, PxU32 soft0, PxU32 soft1, PxU32 rigid0)
{
	for(PxU32 old = 0; old < previous.size(); ++old)
	{
		const AvbdVolumeBoxFeatureContact& contact = previous[old];
		if(contact.boxIndex == boxIndex && contact.featureType == featureType &&
			contact.softFeature0 == soft0 && contact.softFeature1 == soft1 &&
			contact.rigidFeature0 == rigid0)
			return &contact;
	}
	return NULL;
}

PX_FORCE_INLINE PxVec3 avbdVolumeBoxRigidPoint(
	const AvbdVolumeBoxFeatureContact& contact, const AvbdSoftStaticBox& box)
{
	return box.center + box.rotation.rotate(contact.rigidLocalPoint);
}

void avbdCommitVolumeBoxContact(AvbdIslandSoftCache& cache,
	const PxArray<AvbdVolumeBoxFeatureContact>& previous,
	const AvbdSoftStaticBox& box, AvbdVolumeBoxFeatureContact& contact)
{
	const AvbdVolumeBoxFeatureContact* warm = avbdFindVolumeBoxWarm(previous,
		contact.boxIndex, contact.featureType, contact.softFeature0,
		contact.softFeature1, contact.rigidFeature0);
	// The freshly detected normal is part of the current geometry and must never
	// be flipped to fit persistent state.  A stable feature key is insufficient
	// when its oriented closest feature has changed; only a consistently
	// oriented objective may inherit its multiplier and penalty.
	if(warm && contact.normal.dot(warm->normal) >= 0.8f)
	{
		PxVec3 softPoint(0.0f);
		for(PxU32 support = 0; support < contact.particleCount; ++support)
			softPoint += cache.particles[contact.particleIndices[support]].p *
				contact.weights[support];
		const PxVec3 rigidPoint = avbdVolumeBoxRigidPoint(contact, box);
		const PxReal C = (softPoint - rigidPoint).dot(contact.normal) -
			contact.margin;
		const PxReal activeTolerance = PxMax(1.0e-5f,
			1.0e-4f * PxMax(contact.margin, 0.0f));
		// Feature identity alone is not an active-objective identity.  Rows remain
		// detectable in the proximity shell; carrying a compressed multiplier
		// through a separated epoch preloads common free fall and the next impact.
		if(PxIsFinite(C) && C <= activeTolerance)
		{
			if(contact.k > 0.0f)
				contact.k = warm->k;
			contact.lambda = warm->lambda;
		}
	}
	if(contact.particleCount && contact.normal.isFinite() &&
		contact.normal.magnitudeSquared() > 1.0e-12f)
	{
		contact.normal.normalize();
		cache.boxFeatureContacts->pushBack(contact);
	}
}

bool avbdTriangleIntersectsVolumeBox(const PxVec3 (&triangle)[3],
	const AvbdSoftStaticBox& box);

PxReal avbdTriangleVolumeBoxWitness(const PxVec3 (&triangle)[3],
	const AvbdSoftStaticBox& box, PxVec3& trianglePoint, PxVec3& boxPoint);

void avbdRebuildVolumeBoxFeatureContacts(AvbdIslandSoftCache& cache,
	const AvbdSoftStaticBox* boxes, PxU32 boxCount)
{
	if(!cache.boxFeatureContacts || !cache.collisionPoints ||
		!cache.boundaryVertices) return;
	PxArray<AvbdVolumeBoxFeatureContact> previous;
	previous.swap(*cache.boxFeatureContacts);
	PxArray<PxVec3> positions;
	positions.resize(cache.nbCollisionParticles);
	PxVec3 componentMinimum(PX_MAX_F32);
	PxVec3 componentMaximum(-PX_MAX_F32);
	for(PxU32 vertex = 0; vertex < cache.nbCollisionParticles; ++vertex)
	{
		positions[vertex] = avbdEmbeddedPosition(cache,
			cache.collisionPoints[vertex], false);
		componentMinimum = componentMinimum.minimum(positions[vertex]);
		componentMaximum = componentMaximum.maximum(positions[vertex]);
	}
	const PxReal featureEpsilon = 1.0e-4f;
	PxArray<PxU32> triangleCoreFaces;

	for(PxU32 boxIndex = 0; boxIndex < boxCount; ++boxIndex)
	{
		const AvbdSoftStaticBox& box = boxes[boxIndex];
		const PxMat33 rotation(box.rotation);
		const PxVec3 boxExtent(
			PxAbs(rotation.column0.x) * box.halfExtent.x +
				PxAbs(rotation.column1.x) * box.halfExtent.y +
				PxAbs(rotation.column2.x) * box.halfExtent.z + box.margin,
			PxAbs(rotation.column0.y) * box.halfExtent.x +
				PxAbs(rotation.column1.y) * box.halfExtent.y +
				PxAbs(rotation.column2.y) * box.halfExtent.z + box.margin,
			PxAbs(rotation.column0.z) * box.halfExtent.x +
				PxAbs(rotation.column1.z) * box.halfExtent.y +
				PxAbs(rotation.column2.z) * box.halfExtent.z + box.margin);
		const PxVec3 boxMinimum = box.center - boxExtent;
		const PxVec3 boxMaximum = box.center + boxExtent;
		// Host has supplied this collider. Compile its complete boundary plane
		// program at DCD, including zero-energy separated rows: proximity-only
		// rows cannot certify a later warmstart/primal pose outside that shell.
		// Triangle/core certificates belonging to one soft/box pair form one
		// local manifold.  Choose the box face whose maximum required exit over
		// the whole intersecting patch is smallest.  Per-triangle exit faces can
		// oppose each other and turn a coherent contact patch into artificial
		// shear; AVBD_2 groups the same certificates by pair before projection.
		PxReal patchFaceExits[6] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
		bool hasTriangleCore = false;
		triangleCoreFaces.clear();
		for(PxU32 faceIndex = 0; faceIndex < cache.nbBoundaryFaces; ++faceIndex)
		{
			const AvbdSoftBoundaryFace& face = cache.boundaryFaces[faceIndex];
			PxVec3 triangle[3], minimum(PX_MAX_F32), maximum(-PX_MAX_F32);
			for(PxU32 corner = 0; corner < 3; ++corner)
			{
				triangle[corner] = positions[face.vertices[corner]];
				const PxVec3 local = box.rotation.rotateInv(
					triangle[corner] - box.center);
				minimum = minimum.minimum(local);
				maximum = maximum.maximum(local);
			}
			if(!avbdTriangleIntersectsVolumeBox(triangle, box))
			{
				triangleCoreFaces.pushBack(faceIndex);
				continue;
			}
			hasTriangleCore = true;
			triangleCoreFaces.pushBack(faceIndex);
			const PxReal exits[6] =
			{
				box.halfExtent.x - minimum.x, maximum.x + box.halfExtent.x,
				box.halfExtent.y - minimum.y, maximum.y + box.halfExtent.y,
				box.halfExtent.z - minimum.z, maximum.z + box.halfExtent.z
			};
			for(PxU32 candidate = 0; candidate < 6; ++candidate)
				patchFaceExits[candidate] = PxMax(patchFaceExits[candidate],
					PxMax(0.0f, exits[candidate]));
		}
		PxU32 patchExitFace = PX_MAX_U32;
		if(hasTriangleCore)
		{
			patchExitFace = 0;
			for(PxU32 candidate = 1; candidate < 6; ++candidate)
				if(patchFaceExits[candidate] < patchFaceExits[patchExitFace])
					patchExitFace = candidate;
		}
		// Complete plane supports for all boundary triangles against this box.
		// An intersection chooses a common box exit face for its DCD patch;
		// a separated triangle uses its closest-pair separating normal.
		// Each triangle vertex is constrained against every actual box corner.
		// All rows being nonnegative separates the convex projection intervals,
		// including finite rigid rotation. This is a conservative fixed-plane
		// model, not a claim that a centroid sample certifies the whole triangle.
		// Previous trajectory-based experiments are historical (see the C01b
		// closure contract); their old centroid and opening-shell premises do
		// not apply to this shared-potential, complete-support formulation.
		for(PxU32 patchFaceIndex = 0;
			patchFaceIndex < triangleCoreFaces.size(); ++patchFaceIndex)
		{
			const PxU32 faceIndex = triangleCoreFaces[patchFaceIndex];
			const AvbdSoftBoundaryFace& face = cache.boundaryFaces[faceIndex];
			PxVec3 triangle[3];
			for(PxU32 corner = 0; corner < 3; ++corner)
				triangle[corner] = positions[face.vertices[corner]];
			PxVec3 trianglePoint, boxPoint;
			const PxReal gap = avbdTriangleVolumeBoxWitness(triangle, box,
				trianglePoint, boxPoint);
			PxU32 exitFace = patchExitFace;
			PxVec3 normal;
			if(gap > 1.0e-8f)
			{
				normal = (trianglePoint - boxPoint).getNormalized();
				exitFace = 6;
			}
			else
			{
				if(exitFace == PX_MAX_U32) continue;
				PxVec3 normalLocal(0.0f);
				normalLocal[exitFace >> 1] = (exitFace & 1) ? -1.0f : 1.0f;
				normal = box.rotation.rotate(normalLocal);
			}
			const PxReal clearance = PxMax(1.0e-5f, box.margin * 0.02f);
			// A fixed world separating plane separates the convex triangle and
			// box iff every triangle vertex is beyond every box vertex.  Compile
			// those witness pairs, including the rigid corner arms.  This remains
			// sufficient under finite rigid rotation; a centroid/face-center row
			// did not constrain the extent of either feature.
			const PxVec3 localNormal=box.rotation.rotateInv(normal);
			const PxU32 rigidVertex=avbdBoxSupportCorner(localNormal);
			const PxVec3 localCorner=avbdBoxCornerLocal(box.halfExtent,rigidVertex);
			for(PxU32 corner=0;corner<3;++corner)
				{
					AvbdVolumeBoxFeatureContact contact;
					PxMemZero(&contact, sizeof(contact));
					contact.boxIndex = boxIndex;
					contact.softFeature0 = faceIndex;
					contact.softFeature1 = corner;
					contact.rigidFeature0 = exitFace * 8 + rigidVertex;
					contact.featureType = 3;
					avbdAppendVolumeBoxSupport(contact,
						cache.collisionPoints[face.vertices[corner]], 1.0f);
					contact.normal = normal;
					contact.rigidLocalPoint = localCorner;
					contact.margin = clearance;
					contact.k = 0.0f;
					contact.lambda = 0.0f;
					avbdCommitVolumeBoxContact(cache, previous, box, contact);
				}
		}

		// Forward family: collision-boundary vertices against the box SDF.
		for(PxU32 vertex = 0; vertex < cache.nbCollisionParticles; ++vertex)
		{
			if(!cache.boundaryVertices[vertex]) continue;
			PxReal sdf; PxVec3 normal;
			if(!avbdSoftEvalBoxSdf(positions[vertex], box, sdf, normal) ||
				sdf >= box.margin) continue;
			AvbdVolumeBoxFeatureContact contact;
			PxMemZero(&contact, sizeof(contact));
			contact.boxIndex = boxIndex;
			contact.softFeature0 = vertex;
			contact.softFeature1 = PX_MAX_U32;
			contact.rigidFeature0 = PX_MAX_U32;
			contact.featureType = 0;
			avbdAppendVolumeBoxSupport(contact, cache.collisionPoints[vertex], 1.0f);
			contact.normal = normal;
			const PxVec3 surface = positions[vertex] - normal * sdf;
			contact.rigidLocalPoint = box.rotation.rotateInv(surface - box.center);
			contact.margin = box.margin;
			contact.k = 1.0e5f;
			contact.lambda = 0.0f;
			avbdCommitVolumeBoxContact(cache, previous, box, contact);
		}

		// Reverse family: each rigid vertex owns exactly one closest feature on the
		// closed soft boundary.  Testing every oriented face half-space would be
		// incorrect for a non-convex boundary: a perfectly separated vertex can be
		// behind many unrelated faces and would acquire contradictory constraints.
		// The row is compiled at every DCD epoch, not only inside the offset
		// shell: a 6x6 rotation can carry a separated corner through the mesh
		// before the next rebuild, and clipRigidContactStep needs that row.
		for(PxU32 rigidVertex = 0; rigidVertex < 8; ++rigidVertex)
		{
			const PxVec3 rigidPoint = avbdVolumeBoxVertex(box, rigidVertex);
			const bool inside = avbdPointInsideCollisionVolume(rigidPoint,
				cache, positions);
			PxU32 bestFace = PX_MAX_U32;
			PxReal bestDistanceSquared = PX_MAX_REAL;
			PxVec3 bestClosest(0.0f), bestBarycentric(0.0f), bestOutward(0.0f);
			for(PxU32 faceIndex = 0; faceIndex < cache.nbBoundaryFaces; ++faceIndex)
			{
				const AvbdSoftBoundaryFace& face = cache.boundaryFaces[faceIndex];
				const PxVec3 a = positions[face.vertices[0]];
				const PxVec3 b = positions[face.vertices[1]];
				const PxVec3 c = positions[face.vertices[2]];
				PxVec3 outward = (b - a).cross(c - a);
				if(outward.normalize() <= 1.0e-8f) continue;
				if(outward.dot(positions[face.oppositeVertex] - a) > 0.0f)
					outward = -outward;
				PxVec3 closest, barycentric;
				avbdClosestPointTriangle(rigidPoint, a, b, c, closest, barycentric);
				const PxReal distanceSquared = (closest - rigidPoint).magnitudeSquared();
				if(distanceSquared >= bestDistanceSquared) continue;
				bestDistanceSquared = distanceSquared;
				bestFace = faceIndex;
				bestClosest = closest;
				bestBarycentric = barycentric;
				bestOutward = outward;
			}
			if(bestFace == PX_MAX_U32)
				continue;

			const PxReal distance = PxSqrt(bestDistanceSquared);
			PxVec3 normal = -bestOutward;
			if(distance > 1.0e-8f)
				normal = inside ? (rigidPoint - bestClosest) * (1.0f / distance) :
					(bestClosest - rigidPoint) * (1.0f / distance);
			AvbdVolumeBoxFeatureContact contact;
			PxMemZero(&contact, sizeof(contact));
			contact.boxIndex = boxIndex;
			contact.softFeature0 = bestFace;
			contact.softFeature1 = PX_MAX_U32;
			contact.rigidFeature0 = rigidVertex;
			contact.featureType = 1;
			const AvbdSoftBoundaryFace& face = cache.boundaryFaces[bestFace];
			for(PxU32 corner = 0; corner < 3; ++corner)
				avbdAppendVolumeBoxSupport(contact,
					cache.collisionPoints[face.vertices[corner]], bestBarycentric[corner]);
			contact.normal = normal;
			contact.rigidLocalPoint = box.rotation.rotateInv(rigidPoint - box.center);
			contact.margin = box.margin;
			contact.k = 1.0e5f;
			contact.lambda = 0.0f;
			avbdCommitVolumeBoxContact(cache, previous, box, contact);
		}

		// Closed-volume containment is a distinct topology certificate.  Once the
		// complete rigid box is inside the soft boundary, eight independently
		// chosen vertex exits can cancel by symmetry and triangle/core intersection
		// is already zero.  The rigid center owns one closest boundary feature and
		// therefore one coherent escape direction for the whole 6-DOF body.
		if(avbdPointInsideCollisionVolume(box.center, cache, positions))
		{
			PxU32 bestFace = PX_MAX_U32;
			PxReal bestDistanceSquared = PX_MAX_REAL;
			PxVec3 bestClosest(0.0f), bestBarycentric(0.0f);
			for(PxU32 faceIndex = 0; faceIndex < cache.nbBoundaryFaces; ++faceIndex)
			{
				const AvbdSoftBoundaryFace& face = cache.boundaryFaces[faceIndex];
				PxVec3 closest, barycentric;
				avbdClosestPointTriangle(box.center, positions[face.vertices[0]],
					positions[face.vertices[1]], positions[face.vertices[2]],
					closest, barycentric);
				const PxReal distanceSquared =
					(closest - box.center).magnitudeSquared();
				if(distanceSquared >= bestDistanceSquared) continue;
				bestDistanceSquared = distanceSquared;
				bestFace = faceIndex;
				bestClosest = closest;
				bestBarycentric = barycentric;
			}
			if(bestFace != PX_MAX_U32 && bestDistanceSquared > 1.0e-16f)
			{
				AvbdVolumeBoxFeatureContact contact;
				PxMemZero(&contact, sizeof(contact));
				contact.boxIndex = boxIndex;
				contact.softFeature0 = bestFace;
				contact.softFeature1 = PX_MAX_U32;
				contact.rigidFeature0 = PX_MAX_U32;
				contact.featureType = 4;
				const AvbdSoftBoundaryFace& face = cache.boundaryFaces[bestFace];
				for(PxU32 corner = 0; corner < 3; ++corner)
					avbdAppendVolumeBoxSupport(contact,
						cache.collisionPoints[face.vertices[corner]],
						bestBarycentric[corner]);
				const PxReal distance = PxSqrt(bestDistanceSquared);
				contact.normal = (box.center - bestClosest) * (1.0f / distance);
				contact.rigidLocalPoint = PxVec3(0.0f);
				contact.margin = box.margin;
				contact.k = 1.0e5f;
				contact.lambda = 0.0f;
				avbdCommitVolumeBoxContact(cache, previous, box, contact);
			}
		}

		// Edge interiors complete the convex polyhedral feature matrix.
		for(PxU32 softEdgeIndex = 0; softEdgeIndex < cache.nbBoundaryEdges;
			++softEdgeIndex)
		{
			const AvbdSoftBoundaryEdgeTopology& softEdge =
				cache.boundaryEdges[softEdgeIndex];
			const PxVec3 soft0 = positions[softEdge.v0];
			const PxVec3 soft1 = positions[softEdge.v1];
			const PxVec3 softMinimum = soft0.minimum(soft1);
			const PxVec3 softMaximum = soft0.maximum(soft1);
			// Exact segment distance can only enter the contact shell if the
			// segment bounds overlap the box bounds expanded by that shell.
			if(softMaximum.x < boxMinimum.x || softMinimum.x > boxMaximum.x ||
				softMaximum.y < boxMinimum.y || softMinimum.y > boxMaximum.y ||
				softMaximum.z < boxMinimum.z || softMinimum.z > boxMaximum.z)
				continue;
			for(PxU32 rigidEdgeIndex = 0; rigidEdgeIndex < 12; ++rigidEdgeIndex)
			{
				const PxVec3 rigid0 = avbdVolumeBoxVertex(box,
					gAvbdVolumeBoxEdges[rigidEdgeIndex][0]);
				const PxVec3 rigid1 = avbdVolumeBoxVertex(box,
					gAvbdVolumeBoxEdges[rigidEdgeIndex][1]);
				const PxVec3 rigidMinimum = rigid0.minimum(rigid1) -
					PxVec3(box.margin);
				const PxVec3 rigidMaximum = rigid0.maximum(rigid1) +
					PxVec3(box.margin);
				if(softMaximum.x < rigidMinimum.x || softMinimum.x > rigidMaximum.x ||
					softMaximum.y < rigidMinimum.y || softMinimum.y > rigidMaximum.y ||
					softMaximum.z < rigidMinimum.z || softMinimum.z > rigidMaximum.z)
					continue;
				PxReal softWeight, rigidWeight; PxVec3 softPoint, rigidPoint;
				avbdClosestPointsSegments(soft0, soft1,
					rigid0, rigid1, softWeight, rigidWeight, softPoint, rigidPoint);
				if(softWeight <= featureEpsilon || softWeight >= 1.0f - featureEpsilon ||
					rigidWeight <= featureEpsilon || rigidWeight >= 1.0f - featureEpsilon)
					continue;
				PxVec3 normal = softPoint - rigidPoint;
				const PxReal distance = normal.magnitude();
				if(distance >= box.margin || distance <= 1.0e-8f) continue;
				AvbdVolumeBoxFeatureContact contact;
				PxMemZero(&contact, sizeof(contact));
				contact.boxIndex = boxIndex;
				contact.softFeature0 = softEdge.v0;
				contact.softFeature1 = softEdge.v1;
				contact.rigidFeature0 = rigidEdgeIndex;
				contact.featureType = 2;
				avbdAppendVolumeBoxSupport(contact, cache.collisionPoints[softEdge.v0],
					1.0f - softWeight);
				avbdAppendVolumeBoxSupport(contact, cache.collisionPoints[softEdge.v1],
					softWeight);
				contact.normal = normal * (1.0f / distance);
				contact.rigidLocalPoint = box.rotation.rotateInv(rigidPoint - box.center);
				contact.margin = box.margin;
				contact.k = 1.0e5f;
				contact.lambda = 0.0f;
				avbdCommitVolumeBoxContact(cache, previous, box, contact);
			}
		}
	}
}

bool avbdTriangleIntersectsVolumeBox(const PxVec3 (&triangle)[3],
	const AvbdSoftStaticBox& box)
{
	const PxVec3 a = box.rotation.rotateInv(triangle[0] - box.center);
	const PxVec3 b = box.rotation.rotateInv(triangle[1] - box.center);
	const PxVec3 c = box.rotation.rotateInv(triangle[2] - box.center);
	return Gu::intersectTriangleBox_Unsafe(PxVec3(0.0f), box.halfExtent,
		a, b, c) != 0;
}

PxReal avbdTriangleVolumeBoxWitness(const PxVec3 (&triangle)[3],
	const AvbdSoftStaticBox& box, PxVec3& trianglePoint, PxVec3& boxPoint);

PxReal avbdTriangleVolumeBoxDistance(const PxVec3 (&triangle)[3],
	const AvbdSoftStaticBox& box)
{
	PxVec3 trianglePoint, boxPoint;
	return avbdTriangleVolumeBoxWitness(triangle, box, trianglePoint, boxPoint);
}

PxReal avbdTriangleVolumeBoxWitness(const PxVec3 (&triangle)[3],
	const AvbdSoftStaticBox& box, PxVec3& trianglePoint, PxVec3& boxPoint)
{
	if(avbdTriangleIntersectsVolumeBox(triangle, box))
	{
		trianglePoint = (triangle[0] + triangle[1] + triangle[2]) * (1.0f / 3.0f);
		boxPoint = box.center;
		return 0.0f;
	}
	// Separated distance is vertex SDF + box-vertex vs triangle + EE.
	// Face-center / centroid / midpoint SDF is sitting-not-bitwise
	// (y 2.86080289).  VF-blind far-field completion (vertex/edge d > margin)
	// is sitting-bitwise idle; squeeze pierce triangles already have an EE/VF
	// witness inside the 4cm shell, Gu still at frame 9.  Box-edge midpoint
	// vs triangle interior, exact box-edge vs face interior (OGC
	// incidentFacet), and extra Eq.21 triangle-edge x box-face (segment-AABB,
	// edge-interior and box-face-interior only) are sitting-bitwise idle and
	// squeeze-bitwise dump (cores 2 frame 82, covering hanging -5.5mm at
	// frame 11).  Completing the separated SAT pair does not stop covering
	// occupancy extract.  Do not add interior samples or extra edge-face
	// planes.
	PxReal minimumSq = PX_MAX_F32;
	trianglePoint = triangle[0];
	boxPoint = box.center;
	auto consider = [&](const PxVec3& fromTriangle, const PxVec3& fromBox)
	{
		const PxReal d2 = (fromTriangle - fromBox).magnitudeSquared();
		if(d2 >= minimumSq)
			return;
		minimumSq = d2;
		trianglePoint = fromTriangle;
		boxPoint = fromBox;
	};
	for(PxU32 corner = 0; corner < 3; ++corner)
	{
		PxReal sdf; PxVec3 normal;
		if(avbdSoftEvalBoxSdf(triangle[corner], box, sdf, normal))
			consider(triangle[corner], triangle[corner] - normal * sdf);
	}
	for(PxU32 rigidVertex = 0; rigidVertex < 8; ++rigidVertex)
	{
		const PxVec3 point = avbdVolumeBoxVertex(box, rigidVertex);
		PxVec3 closest, barycentric;
		avbdClosestPointTriangle(point, triangle[0], triangle[1], triangle[2],
			closest, barycentric);
		consider(closest, point);
	}
	for(PxU32 softEdge = 0; softEdge < 3; ++softEdge)
		for(PxU32 rigidEdge = 0; rigidEdge < 12; ++rigidEdge)
		{
			PxReal sw, rw; PxVec3 sp, rp;
			avbdClosestPointsSegments(triangle[softEdge], triangle[(softEdge + 1) % 3],
				avbdVolumeBoxVertex(box, gAvbdVolumeBoxEdges[rigidEdge][0]),
				avbdVolumeBoxVertex(box, gAvbdVolumeBoxEdges[rigidEdge][1]),
				sw, rw, sp, rp);
			consider(sp, rp);
		}
	return PxSqrt(PxMax(0.0f, minimumSq));
}

PxReal avbdTriangleTriangleDistance(const PxVec3 (&a)[3],
	const PxVec3 (&b)[3])
{
	PxReal minimumSq = PX_MAX_F32;
	for(PxU32 corner = 0; corner < 3; ++corner)
	{
		PxVec3 closest, barycentric;
		avbdClosestPointTriangle(a[corner], b[0], b[1], b[2], closest,
			barycentric);
		minimumSq = PxMin(minimumSq,
			(a[corner] - closest).magnitudeSquared());
		avbdClosestPointTriangle(b[corner], a[0], a[1], a[2], closest,
			barycentric);
		minimumSq = PxMin(minimumSq,
			(b[corner] - closest).magnitudeSquared());
	}
	for(PxU32 edgeA = 0; edgeA < 3; ++edgeA)
		for(PxU32 edgeB = 0; edgeB < 3; ++edgeB)
		{
			PxReal weightA, weightB;
			PxVec3 closestA, closestB;
			avbdClosestPointsSegments(a[edgeA], a[(edgeA + 1) % 3],
				b[edgeB], b[(edgeB + 1) % 3], weightA, weightB,
				closestA, closestB);
			minimumSq = PxMin(minimumSq,
				(closestA - closestB).magnitudeSquared());
		}
	return PxSqrt(PxMax(0.0f, minimumSq));
}

PxReal avbdTriangleVolumeBoxFaceGap(const PxVec3 (&triangle)[3],
	const AvbdSoftStaticBox& box, PxU32 face)
{
	PxReal gap = PX_MAX_F32;
	for(PxU32 corner = 0; corner < 3; ++corner)
	{
		const PxVec3 local = box.rotation.rotateInv(triangle[corner] - box.center);
		PxReal cornerGap = 0.0f;
		switch(face)
		{
		case 0: cornerGap = local.x - box.halfExtent.x; break;
		case 1: cornerGap = -local.x - box.halfExtent.x; break;
		case 2: cornerGap = local.y - box.halfExtent.y; break;
		case 3: cornerGap = -local.y - box.halfExtent.y; break;
		case 4: cornerGap = local.z - box.halfExtent.z; break;
		default: cornerGap = -local.z - box.halfExtent.z; break;
		}
		gap = PxMin(gap, cornerGap);
	}
	return gap;
}

PxU32 avbdTriangleVolumeBoxMinimumExitFace(const PxVec3 (&triangle)[3],
	const AvbdSoftStaticBox& box)
{
	PxU32 face = 0;
	PxReal bestGap = avbdTriangleVolumeBoxFaceGap(triangle, box, 0);
	for(PxU32 candidate = 1; candidate < 6; ++candidate)
	{
		const PxReal gap = avbdTriangleVolumeBoxFaceGap(triangle, box, candidate);
		if(gap > bestGap) { bestGap = gap; face = candidate; }
	}
	return face;
}

PX_FORCE_INLINE PxBounds3 avbdVolumeBoxCoreBounds(
	const AvbdSoftStaticBox& box, PxReal expansion)
{
	const PxMat33 rotation(box.rotation);
	const PxVec3 extent(
		PxAbs(rotation.column0.x) * box.halfExtent.x +
			PxAbs(rotation.column1.x) * box.halfExtent.y +
			PxAbs(rotation.column2.x) * box.halfExtent.z + expansion,
		PxAbs(rotation.column0.y) * box.halfExtent.x +
			PxAbs(rotation.column1.y) * box.halfExtent.y +
			PxAbs(rotation.column2.y) * box.halfExtent.z + expansion,
		PxAbs(rotation.column0.z) * box.halfExtent.x +
			PxAbs(rotation.column1.z) * box.halfExtent.y +
			PxAbs(rotation.column2.z) * box.halfExtent.z + expansion);
	return PxBounds3(box.center - extent, box.center + extent);
}

PxVec3 avbdEmbeddedPositionFromSnapshot(const AvbdSoftEmbeddedPoint& point,
	const PxArray<PxVec3>& particlePositions)
{
	PxVec3 result(0.0f);
	for(PxU32 support = 0; support < point.count; ++support)
		result += particlePositions[point.particleIndices[support]] * point.weights[support];
	return result;
}

PX_FORCE_INLINE double avbdSoftTetEnergyAtVertex(const AvbdSoftTet& tet,
	PxU32 particleIndex, const PxVec3& candidate,
	const AvbdSoftMaterial& material, const AvbdSoftParticle* particles)
{
	const PxU32 ids[4] = {tet.p0, tet.p1, tet.p2, tet.p3};
	PxVec3 positions[4];
	for(PxU32 corner = 0; corner < 4; ++corner)
		positions[corner] = ids[corner] == particleIndex ? candidate :
			particles[ids[corner]].p;
	const PxMat33 deformation(PxMat33(positions[1] - positions[0],
		positions[2] - positions[0], positions[3] - positions[0]) * tet.dmInv);
	const PxReal J = deformation.getDeterminant();
	if(!PxIsFinite(J) || J <= 0.0f)
		return PX_MAX_F64;
	if(material.coRotationalVolumeModel)
	{
		const PxMat33 rotation = avbdSoftCorotationalRotation(deformation);
		const PxMat33 strain = deformation - rotation;
		const double strainNormSq = double(strain.column0.magnitudeSquared()) +
			double(strain.column1.magnitudeSquared()) +
			double(strain.column2.magnitudeSquared());
		const double strainTrace = double(rotation.column0.dot(deformation.column0)) +
			double(rotation.column1.dot(deformation.column1)) +
			double(rotation.column2.dot(deformation.column2)) - 3.0;
		const double energy = double(tet.restVolume) *
			(double(material.mu) * strainNormSq +
			0.5 * double(material.lambda) * strainTrace * strainTrace);
		return PxIsFinite(energy) ? energy : PX_MAX_F64;
	}
	const double frobeniusSq = double(deformation.column0.magnitudeSquared()) +
		double(deformation.column1.magnitudeSquared()) +
		double(deformation.column2.magnitudeSquared());
	const double volumeResidual = double(J) - double(material.alpha);
	const double energy = double(tet.restVolume) *
		(0.5 * double(material.mu) * frobeniusSq +
		0.5 * double(material.lambda) * volumeResidual * volumeResidual);
	return PxIsFinite(energy) ? energy : PX_MAX_F64;
}

double avbdSoftLocalEnergy(const AvbdIslandSoftCache& cache,
	PxU32 particleIndex, const PxVec3& candidate,
	const AvbdSoftMaterial& material, PxReal massInvH2,
	AvbdSoftWorldPin* pins, PxU32 nbPins)
{
	const AvbdSoftParticle& particle = cache.particles[particleIndex];
	double energy = 0.5 * double(massInvH2) *
		double((candidate - particle.pHat).magnitudeSquared());
	const PxU32 incidentBegin = cache.incidentTetOffsets ?
		cache.incidentTetOffsets[particleIndex] : 0;
	const PxU32 incidentEnd = cache.incidentTetOffsets ?
		cache.incidentTetOffsets[particleIndex + 1] : cache.nbTets;
	for(PxU32 incident = incidentBegin; incident < incidentEnd; ++incident)
	{
		const PxU32 tetIndex = cache.incidentTetIndices ?
			cache.incidentTetIndices[incident] : incident;
		if(tetIndex >= cache.nbTets)
			return PX_MAX_F64;
		energy += avbdSoftTetEnergyAtVertex(cache.tets[tetIndex], particleIndex,
			candidate, material, cache.particles);
	}

	for(PxU32 pinIndex = 0;
		pinIndex < PxMin(nbPins, AVBD_SOFT_MAX_WORLD_PINS); ++pinIndex)
		if(pins[pinIndex].vertex == particleIndex && pins[pinIndex].k)
		{
			const PxVec3 C = candidate - pins[pinIndex].target;
			energy += 0.5 * double(*pins[pinIndex].k) * double(C.magnitudeSquared());
			if(pins[pinIndex].lambda)
				energy += double(pins[pinIndex].lambda->dot(C));
		}
	return PxIsFinite(energy) ? energy : PX_MAX_F64;
}

} // namespace

bool AvbdDynamicsContext::assembleVolumeParticlePrimal(
    const AvbdIslandSoftCache& cache, PxU32 particleIndex,
    const AvbdSoftMaterial& material, PxReal invH2,
    AvbdSoftWorldPin* pins, PxU32 nbPins, PxVec3& force, PxMat33& hessian,
    AvbdSoftQuadratic* quadratic) const
{
  const AvbdSoftParticle& particle=cache.particles[particleIndex];
  const PxReal massInvH2 = particle.mass * invH2;
  force = (particle.pHat - particle.p) * massInvH2;
  hessian = PxMat33::createDiagonal(PxVec3(massInvH2));
  if(quadratic)
  {
    quadratic->gradient=(avbdOgcDouble(particle.p)-avbdOgcDouble(particle.pHat))*double(massInvH2);
    quadratic->hessian=PxMat33d::createDiagonal(PxVec3d(massInvH2));
  }
  if(!cache.incidentTetOffsets || !cache.incidentTetIndices || !cache.incidentTetCorners)
    return false;
  const PxU32 incidentBegin=cache.incidentTetOffsets[particleIndex];
  AvbdTetAssemblyArgs args={cache.tets,cache.particles,&material,
    cache.incidentTetIndices+incidentBegin,cache.incidentTetCorners+incidentBegin,
    cache.incidentTetOffsets[particleIndex+1]-incidentBegin,&force,&hessian,quadratic};
  mKernels.launch(AVBD_VBD_TET,&args);
  for (PxU32 pinIndex = 0; pinIndex < PxMin(nbPins, AVBD_SOFT_MAX_WORLD_PINS);
       ++pinIndex)
    if (pins[pinIndex].vertex == particleIndex)
    {
      avbdSoftAddWorldPin(force, hessian, particle.p, pins[pinIndex]);
      if(quadratic && pins[pinIndex].k)
      {
        const AvbdSoftWorldPin& pin=pins[pinIndex];
        const double k=PxMax(*pin.k,AVBD_SOFT_PIN_K_INIT);
        quadratic->gradient+=(avbdOgcDouble(particle.p)-avbdOgcDouble(pin.target))*k;
        if(pin.lambda) quadratic->gradient+=avbdOgcDouble(*pin.lambda);
        quadratic->hessian+=PxMat33d::createDiagonal(PxVec3d(k));
      }
    }

  return true;
}

PxReal AvbdDynamicsContext::solveVolumeParticlePrimal(
    AvbdIslandSoftCache &cache, PxU32 particleIndex,
    const AvbdSoftMaterial &material, PxReal invH2,
	AvbdSoftWorldPin *pins, PxU32 nbPins, bool& coupledRepairRequired,
	PxArray<PxU8>& coupledRepairSeeds) {
  PxReal maximumCommittedStep = 0.0f;
  AvbdSoftParticle &particle = cache.particles[particleIndex];
  if (particle.invMass <= 0.0f)
    return 0.0f;
  const PxReal massInvH2 = particle.mass * invH2;
  const PxU32 blockIndex = cache.blockStart + particleIndex;
  PxVec3 force;
  PxMat33 hessian;
  AvbdSoftQuadratic quadratic;
  const bool quadraticMaterial=!material.coRotationalVolumeModel;
  if(!assembleVolumeParticlePrimal(cache,particleIndex,material,invH2,pins,nbPins,force,hessian,
    quadraticMaterial ? &quadratic : NULL)) return 0.0f;
  assembleParticleContactPrimal(blockIndex,force,hessian);
  PxVec3 delta;
  PxMat33 effectiveMetric;
  if (avbdSolve3(hessian, force, delta, &effectiveMetric) && delta.isFinite()) {
    const double currentEnergy=quadraticMaterial ? 0.0 : avbdSoftLocalEnergy(
      cache,particleIndex,particle.p,material,massInvH2,pins,nbPins);
    AvbdOgcPointRegion liveRegion;
    if(cache.ogcRegions && cache.ogcExceeded)
      liveRegion = avbdOgcPointRegionAgainstCommittedRigid(
          cache.ogcRegions[particleIndex], mBodies, mIslandSoftCache);
    else avbdOgcResetPointRegion(liveRegion,particle.p);
	AvbdOgcProjectionPlanes commitDomain;
	PxVec3 endpoint=particle.p+delta;
    // A feasible proposal needs no metric projection. Check the complete
    // domain first, retaining every condition for the projection fallback.
    // This is not a proposal-selected subset of the projection's constraints.
    PxInlineArray<AvbdSoftTetDomain,32> tetDomains;
    const PxU32 begin=cache.incidentTetOffsets ? cache.incidentTetOffsets[particleIndex] : 0;
    const PxU32 end=cache.incidentTetOffsets ? cache.incidentTetOffsets[particleIndex+1] : cache.nbTets;
    for(PxU32 ref=begin;ref<end;++ref)
    {
      const AvbdSoftTet& tet=cache.tets[cache.incidentTetIndices ? cache.incidentTetIndices[ref] : ref];
      const PxU32 order=tet.p0==particleIndex ? 0 : tet.p1==particleIndex ? 1 : tet.p2==particleIndex ? 2 : tet.p3==particleIndex ? 3 : PX_MAX_U32;
      if(order!=PX_MAX_U32) tetDomains.pushBack(avbdSoftTetDomain(tet,order,cache.particles));
    }
    auto tetAdmitted=[&](const PxVec3& candidate)
    {
      const PxVec3d displacement=avbdOgcDouble(candidate)-avbdOgcDouble(particle.p);
      for(PxU32 i=0;i<tetDomains.size();++i)
      {
        const AvbdSoftTetDomain& domain=tetDomains[i];
        const double determinant=double(domain.determinant)+avbdOgcDouble(domain.gradient).dot(displacement);
        if(!PxIsFinite(determinant) || determinant<double(PxMin(0.05f,domain.determinant))-
          4.0*PX_EPS_F32*PxAbs(double(domain.determinant))) return false;
      }
      return true;
    };
    const bool direct=endpoint.isFinite() && avbdOgcPointContains(liveRegion,endpoint) &&
      tetAdmitted(endpoint) && particleContactCandidateAdmissible(blockIndex,endpoint,true);
    if(direct && endpoint==particle.p)
    {
      // This is an unconstrained representability result, not a constrained
      // stationarity claim. Shared-domain closure still runs after the sweep.
      mPrimalIdleIteration[blockIndex]=mStep.iteration+1;
      return 0.0f;
    }
    AvbdOgcClip clip={false,false,true};
    if(!direct)
    {
      compileParticleCommitDomain(blockIndex,liveRegion.anchor,commitDomain);
      clip=avbdOgcTruncatePoint(liveRegion,endpoint,&commitDomain,&effectiveMetric,&particle.p);
    }
	if(!clip.feasible) {
		// A non-product triangle/tet domain can have no representable one-block
		// section after earlier in-place commits, while a joint Particle3 move is
		// still feasible. Defer this coordinate stall to the row-driven KKT
		// closure below; only that complete-domain admission may clear it.
		coupledRepairRequired=true;
		if(blockIndex<coupledRepairSeeds.size())
			coupledRepairSeeds[blockIndex]=1;
		return 0.0f;
	}
	const PxVec3 admissible=endpoint-particle.p;
    // The local 3x3 Hessian is a PSD Gauss-Newton model of a non-convex
    // Neo-Hookean block.  Accept it only when the exact local objective
    // decreases.  Project the full proposal once, then backtrack on the
    // segment from the already admitted PxReal state to that feasible point.
    // Re-projecting every scaled unconstrained proposal makes this path
    // discontinuous when the current state lies in a domain's input-error
    // interval, and can flip a descent direction as the fraction shrinks.
    PxReal stepFraction = 1.0f;
    for (PxU32 search = 0; search < 16; ++search) {
      PxVec3 candidate = particle.p + admissible * stepFraction;
      if(candidate == particle.p)
		break;
      const PxVec3 acceptedStep=candidate-particle.p;
      const PxReal predictedDecrease = force.dot(acceptedStep);
	  const bool predictedAdmitted=predictedDecrease>0.0f;
	  double candidateEnergy=PX_MAX_F64;
	  if(predictedAdmitted)
	  {
        candidateEnergy=(quadraticMaterial ? quadratic.change(avbdOgcDouble(candidate)-avbdOgcDouble(particle.p)) :
          avbdSoftLocalEnergy(cache,particleIndex,candidate,material,massInvH2,pins,nbPins)-currentEnergy)+
          particleContactEnergy(blockIndex,candidate,true);
	  }
	  const bool energyAdmitted=predictedAdmitted && PxIsFinite(candidateEnergy) &&
		  candidateEnergy<=-1.0e-4*double(predictedDecrease);
	  const PxVec3d candidateOffset=avbdOgcDouble(candidate)-
		  avbdOgcDouble(liveRegion.anchor);
	  // The complete direct-proposal oracle already examined this actual
	  // PxReal state. No support or dual can change during this colored block
	  // invocation. Reuse that proof only for the identical candidate: rebuilding
	  // p + (endpoint-p), or a backtrack, can round to a different float state.
	  const bool candidateAdmitted=energyAdmitted && ((direct && candidate==endpoint) ||
		  (avbdOgcPointContains(liveRegion,candidate) &&
		   (direct ? tetAdmitted(candidate) : avbdOgcRegionContains(commitDomain,candidateOffset,double(PX_MAX_F32))) &&
		   particleContactCandidateAdmissible(blockIndex,candidate,true)));
	  if(candidateAdmitted) {
          if (clip.spent)
            cache.ogcExceeded[particleIndex] = 1;
          maximumCommittedStep =
              PxMax(maximumCommittedStep, acceptedStep.magnitude());
          particle.p = candidate;
          break;
      }
      stepFraction *= 0.5f;
    }
  }
  return maximumCommittedStep;
}

void AvbdDynamicsContext::refreshOgcRegions(bool reanchor) {
  const PxReal gamma = PxClamp(mOgc.safetyRelax, 0.0f, 0.499f);
  refreshSurfaceOgcRegions();
  if(!reanchor)
  {
    // Keep the DCD-epoch certificate.  Rewriting partnerAnchor from the
    // current pose treats co-fall as closing; tightening shell bounds
    // freezes a landing volume in the offset well and floats the box.
    for(PxU32 bodyIndex = 0; bodyIndex < mBodies.size(); ++bodyIndex)
      mBodies[bodyIndex].ogcExceeded = 0;
    for(PxU32 cacheIndex = 0; cacheIndex < mIslandSoftCache.size();
        ++cacheIndex)
    {
      AvbdIslandSoftCache& cache = mIslandSoftCache[cacheIndex];
      if(!cache.coupled || cache.liveStamp != mIslandSoftLiveStamp ||
          !cache.ogcExceeded)
        continue;
      for(PxU32 particleIndex = 0; particleIndex < cache.nbParticles;
          ++particleIndex)
        cache.ogcExceeded[particleIndex] = 0;
    }
    return;
  }

  PxArray<PxReal> bodySupportRadius;
  bodySupportRadius.resize(mBodies.size(), 0.0f);

  for (PxU32 bodyIndex = 0; bodyIndex < mBodies.size(); ++bodyIndex) {
    AvbdSolverBody &body = mBodies[bodyIndex];
    body.ogcExceeded = 0;
    body.ogcRegionValid = 0;
    body.ogcRegion.anchorPosition = body.p;
    body.ogcRegion.anchorRotation = body.q;
    body.ogcRegion.supportRadius = 0.0f;
    body.ogcRegion.bound = PX_MAX_F32;
    body.ogcRegion.planeCount = 0;
    body.ogcRegion.planes.clear();
  }

  // Volume Eq.21 is a relative half-space per DCD feature:
  // n.(dx_i - dx_j) >= -gamma * d.  Opening and tangent stay free.  The
  // pairwise row still owns the contact force; the half-space is only the
  // local certificate that the detector is not re-run this epoch.

  PxArray<PxArray<PxVec3>> collisionPositions;
  collisionPositions.resize(mIslandSoftCache.size());
  for (PxU32 cacheIndex = 0; cacheIndex < mIslandSoftCache.size();
       ++cacheIndex) {
    AvbdIslandSoftCache &cache = mIslandSoftCache[cacheIndex];
    if (!cache.coupled || cache.liveStamp != mIslandSoftLiveStamp ||
        !cache.particles || !cache.ogcRegions || !cache.ogcExceeded ||
        !cache.collisionPoints)
      continue;
    for (PxU32 particleIndex = 0; particleIndex < cache.nbParticles;
         ++particleIndex) {
      const AvbdSoftParticle &particle = cache.particles[particleIndex];
      AvbdOgcPointRegion &region = cache.ogcRegions[particleIndex];
      avbdOgcResetPointRegion(region, particle.p);
      cache.ogcExceeded[particleIndex] = 0;
	  // Opening is free.  The ground certificate is a downward half-space so
	  // elastic recovery is not frozen inside a millimetre isotropic ball.
	  if(particle.p.y > 1.0e-5f)
		avbdOgcAddHalfSpace(region.planes, region.planeCount,
			PxVec3(0.0f, 1.0f, 0.0f), gamma * particle.p.y, PX_MAX_U32,
			PxVec3(0.0f), PxVec3(0.0f));
    }
    collisionPositions[cacheIndex].resize(cache.nbCollisionParticles);
    for (PxU32 vertex = 0; vertex < cache.nbCollisionParticles; ++vertex)
      collisionPositions[cacheIndex][vertex] =
          avbdEmbeddedPosition(cache, cache.collisionPoints[vertex], false);
  }

  auto limitCollisionVertex = [&](PxU32 cacheIndex, PxU32 vertex,
                                  PxReal distance, const PxVec3& normal,
                                  PxU32 partnerBody, const PxVec3& partnerAnchor,
                                  const PxVec3& partnerDelta) {
    if (cacheIndex >= mIslandSoftCache.size() || !PxIsFinite(distance))
      return;
    AvbdIslandSoftCache &cache = mIslandSoftCache[cacheIndex];
    if (!cache.ogcRegions || vertex >= cache.nbCollisionParticles)
      return;
    const AvbdSoftEmbeddedPoint &embedded = cache.collisionPoints[vertex];
    PxReal absoluteWeightSum = 0.0f;
    for(PxU32 support = 0; support < embedded.count; ++support)
      absoluteWeightSum += PxAbs(embedded.weights[support]);
    if(absoluteWeightSum <= 1.0e-10f)
      return;
    const PxReal featureBound = gamma * PxMax(0.0f, distance);
    for (PxU32 support = 0; support < embedded.count; ++support) {
      const PxU32 particleIndex = embedded.particleIndices[support];
      PxVec3 supportNormal;
      PxReal supportBound;
      if (particleIndex < cache.nbParticles &&
          avbdOgcEmbeddedSupportHalfSpace(normal, featureBound,
              absoluteWeightSum, embedded.weights[support], supportNormal,
              supportBound))
        avbdOgcAddHalfSpace(cache.ogcRegions[particleIndex].planes,
            cache.ogcRegions[particleIndex].planeCount, supportNormal,
            supportBound,
			partnerBody, partnerAnchor, partnerDelta);
    }
  };

  for (PxU32 cacheIndex = 0; cacheIndex < mIslandSoftCache.size();
       ++cacheIndex) {
    AvbdIslandSoftCache &cache = mIslandSoftCache[cacheIndex];
    if (collisionPositions[cacheIndex].empty() || !cache.boundaryFaces ||
        !cache.volume)
      continue;
    for (PxU32 vertex = 0; vertex < cache.nbCollisionParticles; ++vertex) {
		// The DCD domain is the positive core distance.  The contact radius is
		// the support of the offset potential, not an obstacle surface.  Using
		// y-r here prevents the primal from entering its load-bearing shell, so
		// normal force and Coulomb capacity both collapse to zero at rest.
      const PxReal groundGap = collisionPositions[cacheIndex][vertex].y;
		// The active offset shell owns its normal coordinate.  Only a separated
		// vertex contributes a DCD trust-region certificate.
      if(groundGap > 1.0e-5f)
        limitCollisionVertex(cacheIndex, vertex, groundGap,
            PxVec3(0.0f, 1.0f, 0.0f), PX_MAX_U32, PxVec3(0.0f), PxVec3(0.0f));
    }
    // Complete Volume/Box rows own both endpoints' geometry admission.
    // A second, per-endpoint gamma-distance map is neither necessary for
    // their separating-plane proof nor consistent with the same GS state.
  }

  // Moving triangle pairs are compiled as shared row domains.

  for (PxU32 bodyIndex = 0; bodyIndex < mBodies.size(); ++bodyIndex) {
    AvbdSolverBody &body = mBodies[bodyIndex];
    if (body.ogcRegion.planeCount == 0)
      continue;
    body.ogcRegion.supportRadius = bodySupportRadius[bodyIndex];
    body.ogcRegion.bound = PX_MAX_F32;
    body.ogcRegionValid = 1;
  }
}

bool AvbdDynamicsContext::ogcRefreshRequired() const
{
	// Half-space projection is not exhaustion.  Volume DCD is compiled at
	// x^t and kept for the step unless an isotropic envelope (Surface) is
	// spent.  Rebuilding features on a crushed pose every contacting sweep
	// publishes one or two frames of flattened mesh before rebound.
	for(PxU32 bodyIndex = 0; bodyIndex < mBodies.size(); ++bodyIndex)
		if(mBodies[bodyIndex].ogcRegionValid && mBodies[bodyIndex].ogcExceeded)
			return true;
	for(PxU32 cacheIndex = 0; cacheIndex < mIslandSoftCache.size(); ++cacheIndex)
	{
		const AvbdIslandSoftCache& cache = mIslandSoftCache[cacheIndex];
		if(!cache.coupled || cache.liveStamp != mIslandSoftLiveStamp ||
			!cache.ogcRegions || !cache.ogcExceeded || cache.nbParticles == 0)
			continue;
		for(PxU32 particleIndex = 0; particleIndex < cache.nbParticles;
			++particleIndex)
			if(cache.ogcExceeded[particleIndex])
				return true;
	}
	for(PxU32 cacheIndex = 0; cacheIndex < mIslandSurfaceCache.size(); ++cacheIndex)
	{
		const AvbdIslandSurfaceCache& cache = mIslandSurfaceCache[cacheIndex];
		if(cache.liveStamp != mIslandSurfaceLiveStamp || !cache.ogcExceeded)
			continue;
		for(PxU32 particleIndex = 0; particleIndex < cache.nbParticles;
			++particleIndex)
			if(cache.ogcExceeded[particleIndex])
				return true;
	}
	return false;
}
void AvbdDynamicsContext::rebuildSoftPairContacts()
{
	PxArray<AvbdSoftPairContact> previous;
	previous.swap(mSoftPairContacts);
	// Compile the exact current/start/predicted broad bound once per body.  The
	// old pair loop rebuilt the same three embedded position sets for every
	// potential partner before discovering that their bounds were disjoint.
	// This is only an execution-plan accelerator: intersecting pairs still run
	// the unchanged feature detector below on freshly evaluated positions.
	PxArray<PxBounds3> cacheBounds;
	PxArray<PxArray<PxVec3> > cachePositions;
	PxArray<PxArray<PxVec3> > cacheInitialPositions;
	PxArray<PxArray<PxVec3> > cachePredictedPositions;
	PxArray<PxArray<AvbdSoftFeatureBounds> > cacheFaceBounds;
	PxArray<PxArray<AvbdSoftEdgeFeatureBounds> > cacheEdgeBounds;
	cacheBounds.resize(mIslandSoftCache.size());
	cachePositions.resize(mIslandSoftCache.size());
	cacheInitialPositions.resize(mIslandSoftCache.size());
	cachePredictedPositions.resize(mIslandSoftCache.size());
	cacheFaceBounds.resize(mIslandSoftCache.size());
	cacheEdgeBounds.resize(mIslandSoftCache.size());
	for(PxU32 cacheIndex = 0; cacheIndex < mIslandSoftCache.size(); ++cacheIndex)
	{
		const AvbdIslandSoftCache& cache = mIslandSoftCache[cacheIndex];
		PxBounds3 bounds = PxBounds3::empty();
		if(cache.volume && cache.liveStamp == mIslandSoftLiveStamp &&
			cache.collisionPoints)
		{
			PxArray<PxVec3>& positions = cachePositions[cacheIndex];
			PxArray<PxVec3>& initialPositions = cacheInitialPositions[cacheIndex];
			PxArray<PxVec3>& predictedPositions = cachePredictedPositions[cacheIndex];
			positions.resize(cache.nbCollisionParticles);
			initialPositions.resize(cache.nbCollisionParticles);
			predictedPositions.resize(cache.nbCollisionParticles);
			for(PxU32 vertex = 0; vertex < cache.nbCollisionParticles; ++vertex)
			{
				positions[vertex] = avbdEmbeddedPosition(cache,
					cache.collisionPoints[vertex], false);
				initialPositions[vertex] = avbdEmbeddedPosition(cache,
					cache.collisionPoints[vertex], true);
				predictedPositions[vertex] = avbdEmbeddedPredictedPosition(cache,
					cache.collisionPoints[vertex]);
				bounds.include(positions[vertex]);
				bounds.include(initialPositions[vertex]);
				bounds.include(predictedPositions[vertex]);
			}
		}
		cacheBounds[cacheIndex] = bounds;
	}
	for(PxU32 queryCache = 0; queryCache < mIslandSoftCache.size(); ++queryCache)
	{
		AvbdIslandSoftCache& query = mIslandSoftCache[queryCache];
		if(!query.volume || query.liveStamp != mIslandSoftLiveStamp ||
			!query.collisionPoints) continue;
		for(PxU32 targetCache = queryCache + 1; targetCache < mIslandSoftCache.size(); ++targetCache)
		{
			AvbdIslandSoftCache& target = mIslandSoftCache[targetCache];
			if(!target.volume || target.liveStamp != mIslandSoftLiveStamp ||
				!target.collisionPoints) continue;
			PxReal pairMargin = 0.0f;
			if(!avbdHostSoftPair(*query.volume, *target.volume, pairMargin) &&
				!avbdHostSoftPair(*target.volume, *query.volume, pairMargin))
				continue;
			pairMargin = PxMax(pairMargin, mOgc.contactRadius);
			PxBounds3 broadQueryBounds = cacheBounds[queryCache];
			PxBounds3 broadTargetBounds = cacheBounds[targetCache];
			broadQueryBounds.fattenSafe(pairMargin);
			broadTargetBounds.fattenSafe(pairMargin);
			if(!broadQueryBounds.intersects(broadTargetBounds))
				continue;
			const PxArray<PxVec3>& queryPositions = cachePositions[queryCache];
			const PxArray<PxVec3>& queryInitialPositions =
				cacheInitialPositions[queryCache];
			const PxArray<PxVec3>& queryPredictedPositions =
				cachePredictedPositions[queryCache];
			const PxArray<PxVec3>& targetPositions = cachePositions[targetCache];
			const PxArray<PxVec3>& targetInitialPositions =
				cacheInitialPositions[targetCache];
			const PxArray<PxVec3>& targetPredictedPositions =
				cachePredictedPositions[targetCache];
			PxBounds3 queryBounds = cacheBounds[queryCache];
			PxBounds3 targetBounds = cacheBounds[targetCache];
			queryBounds.fattenSafe(pairMargin);
			targetBounds.fattenSafe(pairMargin);
			// The start/prediction envelope is only OGC's conservative DCD query
			// radius. Narrow phase below evaluates the current pose exclusively;
			// it does not compute a time of impact.
			if(!queryBounds.intersects(targetBounds))
				continue;
			// Feature programs are lazy: separated bodies still need their cached
			// three-pose broad bounds, but compiling every face and edge for them
			// would turn the cache itself into unconditional narrow-phase work.
			if(cacheFaceBounds[queryCache].empty() && query.nbBoundaryFaces)
				avbdBuildSoftFaceBounds(query, queryPositions,
					&queryInitialPositions, &queryPredictedPositions,
					cacheFaceBounds[queryCache]);
			if(cacheFaceBounds[targetCache].empty() && target.nbBoundaryFaces)
				avbdBuildSoftFaceBounds(target, targetPositions,
					&targetInitialPositions, &targetPredictedPositions,
					cacheFaceBounds[targetCache]);
			if(cacheEdgeBounds[queryCache].empty() && query.nbBoundaryEdges)
				avbdBuildSoftEdgeBounds(query, queryPositions,
					&queryInitialPositions, &queryPredictedPositions,
					cacheEdgeBounds[queryCache]);
			if(cacheEdgeBounds[targetCache].empty() && target.nbBoundaryEdges)
				avbdBuildSoftEdgeBounds(target, targetPositions,
					&targetInitialPositions, &targetPredictedPositions,
					cacheEdgeBounds[targetCache]);
			const PxArray<AvbdSoftFeatureBounds>& queryFaceBounds =
				cacheFaceBounds[queryCache];
			const PxArray<AvbdSoftFeatureBounds>& targetFaceBounds =
				cacheFaceBounds[targetCache];
			const PxArray<AvbdSoftEdgeFeatureBounds>& queryEdgeBounds =
				cacheEdgeBounds[queryCache];
			const PxArray<AvbdSoftEdgeFeatureBounds>& targetEdgeBounds =
				cacheEdgeBounds[targetCache];

			auto detectDirection = [&](PxU32 sourceCacheIndex, PxU32 destinationCacheIndex,
				const PxArray<PxVec3>& sourcePositions,
				const PxArray<PxVec3>& destinationPositions,
				const PxBounds3& destinationBounds,
				const PxArray<AvbdSoftFeatureBounds>& destinationFaceBounds)
			{
				AvbdIslandSoftCache& source = mIslandSoftCache[sourceCacheIndex];
				AvbdIslandSoftCache& destination = mIslandSoftCache[destinationCacheIndex];
				// Preserve every old row and its original order, but index the
				// directed warm-start stream by source vertex.  This is the CSR
				// execution form of the previous full-manifold scan.
				PxArray<PxU32> previousVertexStarts(
					source.nbCollisionParticles + 1u, 0u);
				for(PxU32 old = 0; old < previous.size(); ++old)
				{
					const AvbdSoftPairContact& oldContact = previous[old];
					if(oldContact.featureType == 0 &&
						oldContact.queryVolume == source.volume &&
						oldContact.targetVolume == destination.volume &&
						oldContact.queryCollisionVertex < source.nbCollisionParticles)
						++previousVertexStarts[oldContact.queryCollisionVertex + 1u];
				}
				for(PxU32 vertex = 1; vertex < previousVertexStarts.size(); ++vertex)
					previousVertexStarts[vertex] += previousVertexStarts[vertex - 1u];
				PxArray<PxU32> previousVertexRows(
					previousVertexStarts.back(), PX_MAX_U32);
				PxArray<PxU32> previousVertexCursor = previousVertexStarts;
				for(PxU32 old = 0; old < previous.size(); ++old)
				{
					const AvbdSoftPairContact& oldContact = previous[old];
					if(oldContact.featureType == 0 &&
						oldContact.queryVolume == source.volume &&
						oldContact.targetVolume == destination.volume &&
						oldContact.queryCollisionVertex < source.nbCollisionParticles)
						previousVertexRows[previousVertexCursor[
							oldContact.queryCollisionVertex]++] = old;
				}
			PxArray<PxU32> faceCandidates;
			for(PxU32 vertex = 0; vertex < source.nbCollisionParticles; ++vertex)
			{
				if(!source.boundaryVertices[vertex]) continue;
					const AvbdSoftEmbeddedPoint& queryPoint = source.collisionPoints[vertex];
					bool dynamicSupport = false;
					for(PxU32 i = 0; i < queryPoint.count; ++i)
						dynamicSupport |= source.particles[queryPoint.particleIndices[i]].invMass > 0.0f;
					if(!dynamicSupport) continue;
					const PxVec3 point = sourcePositions[vertex];
				const PxBounds3 queryBounds(point, point);
				if(!destinationBounds.intersects(queryBounds)) continue;
				avbdCollectSoftFaceCandidates(destinationFaceBounds,
					queryBounds.minimum - PxVec3(pairMargin),
					queryBounds.maximum + PxVec3(pairMargin), faceCandidates);
				const bool inside = avbdPointInsideCollisionVolume(point, destination,
					destinationPositions);
					PxVec3 persistentNormal(0.0f);
					bool hasPersistentNormal = false;
					for(PxU32 ref = previousVertexStarts[vertex];
						ref < previousVertexStarts[vertex + 1u]; ++ref)
					{
						const PxU32 old = previousVertexRows[ref];
						if(previous[old].lambda < 0.0f)
						{
							persistentNormal = previous[old].normal;
							hasPersistentNormal = true;
							break;
						}
					}
					PxReal bestDistanceSq = PX_MAX_F32;
					PxReal bestNormalScore = -PX_MAX_F32;
					PxU32 bestFace = PX_MAX_U32;
					PxVec3 bestClosest(0.0f), bestBarycentric(0.0f), bestNormal(0.0f);
				const PxU32 faceCount = inside ? destination.nbBoundaryFaces : faceCandidates.size();
				for(PxU32 candidate = 0; candidate < faceCount; ++candidate)
				{
					const PxU32 faceIndex = inside ? candidate : faceCandidates[candidate];
						const AvbdSoftBoundaryFace& face = destination.boundaryFaces[faceIndex];
						const PxVec3 a = destinationPositions[face.vertices[0]];
						const PxVec3 b = destinationPositions[face.vertices[1]];
						const PxVec3 c = destinationPositions[face.vertices[2]];
						PxVec3 normal = (b - a).cross(c - a);
						const PxReal normalSq = normal.magnitudeSquared();
						if(normalSq <= 1.0e-16f) continue;
						normal *= PxRecipSqrt(normalSq);
						if(normal.dot(destinationPositions[face.oppositeVertex] - a) > 0.0f)
							normal = -normal;
						PxVec3 closest, barycentric;
						avbdClosestPointTriangle(point, a, b, c, closest, barycentric);
						const PxReal distanceSq = (point - closest).magnitudeSquared();
						const PxReal normalScore = inside && hasPersistentNormal ?
							normal.dot(persistentNormal) : inside ? 0.0f :
							(point - closest).dot(normal);
						const PxReal tieTolerance = 1.0e-10f * PxMax(1.0f, distanceSq);
						if(distanceSq < bestDistanceSq - tieTolerance ||
							(PxAbs(distanceSq - bestDistanceSq) <= tieTolerance &&
								normalScore > bestNormalScore))
						{
							bestDistanceSq = distanceSq; bestFace = faceIndex;
							bestClosest = closest; bestBarycentric = barycentric;
							bestNormal = normal;
							bestNormalScore = normalScore;
						}
					}
					if(bestFace == PX_MAX_U32) continue;
					const PxReal distance = PxSqrt(PxMax(bestDistanceSq, 0.0f));
					const bool discrete = inside || (distance < pairMargin &&
						(point - bestClosest).dot(bestNormal) >= 0.0f);
					if(!discrete) continue;
					if(inside && distance > 1.0e-8f)
						// For a deformed/non-convex tetrahedral boundary the closest
						// feature may be an edge whose incident face normal is not the
						// shortest escape direction. The inside owner is the vector from
						// the query to that closest boundary point, making its compiled
						// core gap exactly -distance.
						bestNormal = (bestClosest - point) * (1.0f / distance);
					else if(!inside && distance > 1.0e-8f)
						bestNormal = (point - bestClosest) * (1.0f / distance);
					AvbdSoftPairContact contact;
					PxMemZero(&contact, sizeof(contact));
					contact.queryVolume = source.volume;
					contact.targetVolume = destination.volume;
					contact.queryCache = sourceCacheIndex;
					contact.targetCache = destinationCacheIndex;
					contact.queryCollisionVertex = vertex;
					contact.targetFace = bestFace;
					contact.queryFeature1 = PX_MAX_U32;
					contact.targetFeature1 = PX_MAX_U32;
					contact.featureType = 0;
					contact.queryParticleCount = queryPoint.count;
					for(PxU32 i = 0; i < queryPoint.count; ++i)
					{
						contact.queryParticleIndices[i] = queryPoint.particleIndices[i];
						contact.queryWeights[i] = queryPoint.weights[i];
					}
					const AvbdSoftBoundaryFace& face = destination.boundaryFaces[bestFace];
					for(PxU32 corner = 0; corner < 3; ++corner)
						avbdAppendTargetSupport(contact,
							destination.collisionPoints[face.vertices[corner]], bestBarycentric[corner]);
					contact.normal = bestNormal;
					contact.margin = pairMargin;
					contact.k = 1.0e5f;
					contact.lambda = 0.0f;
					for(PxU32 ref = previousVertexStarts[vertex];
						ref < previousVertexStarts[vertex + 1u]; ++ref)
					{
						const PxU32 old = previousVertexRows[ref];
						if(previous[old].targetFace == contact.targetFace &&
							previous[old].normal.dot(contact.normal) >= 0.8f)
						{
							const PxVec3 currentQuery = avbdPairPoint(source,
								contact.queryParticleIndices, contact.queryWeights,
								contact.queryParticleCount);
							const PxVec3 currentTarget = avbdPairPoint(destination,
								contact.targetParticleIndices, contact.targetWeights,
								contact.targetParticleCount);
							const PxReal C = (currentQuery - currentTarget).dot(contact.normal) -
								contact.margin;
							const PxReal activeTolerance = PxMax(1.0e-5f,
								1.0e-4f * PxMax(contact.margin, 0.0f));
							if(C <= activeTolerance)
							{
								contact.k = previous[old].k;
								contact.lambda = previous[old].lambda;
							}
							break;
						}
					}
					mSoftPairContacts.pushBack(contact);
				}
			};
			detectDirection(queryCache, targetCache, queryPositions, targetPositions,
				targetBounds,
				targetFaceBounds);
			detectDirection(targetCache, queryCache, targetPositions, queryPositions,
				queryBounds,
				queryFaceBounds);

			// The two directed vertex/face passes do not own a crossing between
			// edge interiors. Compile that missing OGC feature once for the pair.
			const PxArray<PxVec3>& currentA = queryPositions;
			const PxArray<PxVec3>& currentB = targetPositions;
			const PxArray<AvbdSoftEdgeFeatureBounds>& edgeBoundsA = queryEdgeBounds;
			const PxArray<AvbdSoftEdgeFeatureBounds>& edgeBoundsB = targetEdgeBounds;
			const PxReal featureEpsilon = 1.0e-4f;
			const PxReal distanceEpsilon = 1.0e-8f;
			PxU32 edgeBStart = 0;
			for(PxU32 edgeAIndex = 0; edgeAIndex < edgeBoundsA.size(); ++edgeAIndex)
			{
				const AvbdSoftEdgeFeatureBounds& boundsA = edgeBoundsA[edgeAIndex];
				const AvbdSoftBoundaryEdgeFeature& edgeA = boundsA.edge;
				while(edgeBStart < edgeBoundsB.size() &&
					edgeBoundsB[edgeBStart].maximum.x < boundsA.minimum.x - pairMargin)
					++edgeBStart;
				for(PxU32 edgeBIndex = edgeBStart; edgeBIndex < edgeBoundsB.size();
					++edgeBIndex)
				{
					const AvbdSoftEdgeFeatureBounds& boundsB = edgeBoundsB[edgeBIndex];
					if(boundsB.minimum.x > boundsA.maximum.x + pairMargin) break;
					if(boundsB.maximum.x < boundsA.minimum.x - pairMargin ||
						boundsA.minimum.y > boundsB.maximum.y + pairMargin ||
						boundsA.maximum.y < boundsB.minimum.y - pairMargin ||
						boundsA.minimum.z > boundsB.maximum.z + pairMargin ||
						boundsA.maximum.z < boundsB.minimum.z - pairMargin) continue;
					const AvbdSoftBoundaryEdgeFeature& edgeB = boundsB.edge;

					PxReal weightA = 0.0f, weightB = 0.0f;
					PxVec3 closestA, closestB, normal(0.0f);
					avbdClosestPointsSegments(currentA[edgeA.v0], currentA[edgeA.v1],
						currentB[edgeB.v0], currentB[edgeB.v1], weightA, weightB,
						closestA, closestB);
					const PxVec3 delta = closestA - closestB;
					const PxReal distance = delta.magnitude();
					if(distance >= pairMargin || weightA <= featureEpsilon ||
						weightA >= 1.0f - featureEpsilon || weightB <= featureEpsilon ||
						weightB >= 1.0f - featureEpsilon)
						continue;
					else
					{
						normal = delta;
						if(distance > distanceEpsilon) normal *= 1.0f / distance;
						else normal = (currentA[edgeA.v1] - currentA[edgeA.v0]).cross(
							currentB[edgeB.v1] - currentB[edgeB.v0]);
						if(normal.magnitudeSquared() <= 1.0e-16f || !normal.isFinite()) continue;
						normal.normalize();
					}
					if(!avbdOwnsSoftEdgeDirection(edgeA, -normal) ||
						!avbdOwnsSoftEdgeDirection(edgeB, normal)) continue;

					AvbdSoftPairContact contact;
					PxMemZero(&contact, sizeof(contact));
					contact.queryVolume = query.volume;
					contact.targetVolume = target.volume;
					contact.queryCache = queryCache;
					contact.targetCache = targetCache;
					contact.queryCollisionVertex = edgeA.v0;
					contact.queryFeature1 = edgeA.v1;
					contact.targetFace = edgeB.v0;
					contact.targetFeature1 = edgeB.v1;
					contact.featureType = 1;
					avbdAppendQuerySupport(contact, query.collisionPoints[edgeA.v0],
						1.0f - weightA);
					avbdAppendQuerySupport(contact, query.collisionPoints[edgeA.v1], weightA);
					avbdAppendTargetSupport(contact, target.collisionPoints[edgeB.v0],
						1.0f - weightB);
					avbdAppendTargetSupport(contact, target.collisionPoints[edgeB.v1], weightB);
					contact.normal = normal;
					contact.margin = pairMargin;
					contact.k = 1.0e5f;
					contact.lambda = 0.0f;
					for(PxU32 old = 0; old < previous.size(); ++old)
						if(previous[old].featureType == 1 &&
							previous[old].queryVolume == contact.queryVolume &&
							previous[old].targetVolume == contact.targetVolume &&
							previous[old].queryCollisionVertex == contact.queryCollisionVertex &&
							previous[old].queryFeature1 == contact.queryFeature1 &&
							previous[old].targetFace == contact.targetFace &&
							previous[old].targetFeature1 == contact.targetFeature1 &&
							previous[old].normal.dot(contact.normal) >= 0.8f)
						{
							const PxVec3 queryPoint = avbdPairPoint(query,
								contact.queryParticleIndices, contact.queryWeights,
								contact.queryParticleCount);
							const PxVec3 targetPoint = avbdPairPoint(target,
								contact.targetParticleIndices, contact.targetWeights,
								contact.targetParticleCount);
							const PxReal C = (queryPoint - targetPoint).dot(contact.normal) -
								contact.margin;
							const PxReal activeTolerance = PxMax(1.0e-5f,
								1.0e-4f * PxMax(contact.margin, 0.0f));
							if(C <= activeTolerance)
							{
								contact.k = previous[old].k;
								contact.lambda = previous[old].lambda;
							}
							break;
						}
					mSoftPairContacts.pushBack(contact);
				}
			}
		}
	}
}

void AvbdDynamicsContext::rebuildSoftRigidContacts()
{
	for(PxU32 i = 0; i < mIslandSoftCache.size(); ++i)
	{
		AvbdIslandSoftCache& cache = mIslandSoftCache[i];
		if(!cache.coupled || cache.liveStamp != mIslandSoftLiveStamp ||
			!cache.volume) continue;
		AvbdSoftStaticBox boxes[AVBD_SOFT_MAX_STATIC_BOXES];
		PxU32 nbBoxes = 0;
		fillVolumeSdfBoxes(*cache.volume, boxes, nbBoxes);
		avbdRebuildVolumeBoxFeatureContacts(cache, boxes, nbBoxes);
	}
}

void AvbdDynamicsContext::buildTriangleDomainRows()
{
 PxArray<PxArray<PxVec3>> positions,boundaryPositions;
 PxArray<PxArray<PxU32>> vertices,pointIndices;
 pointIndices.resize(mIslandSoftCache.size());
 positions.resize(mIslandSoftCache.size());boundaryPositions.resize(mIslandSoftCache.size());
 vertices.resize(mIslandSoftCache.size());
 for(PxU32 ci=0;ci<mIslandSoftCache.size();++ci)
 {
  const AvbdIslandSoftCache& cache=mIslandSoftCache[ci];
  if(!cache.coupled || cache.liveStamp!=mIslandSoftLiveStamp || !cache.volume ||
   !cache.collisionPoints || !cache.boundaryFaces) continue;
  positions[ci].resize(cache.nbCollisionParticles);
  pointIndices[ci].resize(cache.nbCollisionParticles,PX_MAX_U32);
  for(PxU32 vertex=0;vertex<cache.nbCollisionParticles;++vertex)
   positions[ci][vertex]=avbdEmbeddedPosition(cache,cache.collisionPoints[vertex],false);
  PxArray<PxU8> used(cache.nbCollisionParticles,0);
  for(PxU32 face=0;face<cache.nbBoundaryFaces;++face) for(PxU32 i=0;i<3;++i)
  {
   const PxU32 vertex=cache.boundaryFaces[face].vertices[i];
   if(!used[vertex])
   { used[vertex]=1;vertices[ci].pushBack(vertex);boundaryPositions[ci].pushBack(positions[ci][vertex]); }
  }
 }
 for(PxU32 ca=0;ca<mIslandSoftCache.size();++ca)
  for(PxU32 cb=ca+1;cb<mIslandSoftCache.size();++cb)
  {
   const AvbdIslandSoftCache& a=mIslandSoftCache[ca];
   const AvbdIslandSoftCache& b=mIslandSoftCache[cb];
   if(vertices[ca].empty() || vertices[cb].empty()) continue;
   PxReal margin=0.0f;
   if(!avbdHostSoftPair(*a.volume,*b.volume,margin) &&
    !avbdHostSoftPair(*b.volume,*a.volume,margin)) continue;
   auto append=[&](const PxU32* va,const PxU32* vb,const AvbdTrianglePairPlane& plane)
   {
    if(!plane.normal.isFinite() || !PxIsFinite(plane.gap) ||
     plane.normal.magnitudeSquared()==0.0f || plane.gap<=-PX_MAX_F32)
    {
     PxGetFoundation().error(PxErrorCode::eDEBUG_INFO,PX_FL,
      "AVBD domain diagnostic: invalid triangle-domain plane.");
     PxAtomicExchange(&mLocalDomainFailed,1);return;
    }
    AvbdRow row;PxMemZero(&row,sizeof(row));
    row.kernelId=eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN;
    row.bodyA=row.bodyB=PX_MAX_U32;row.supportStart=mRowSupports.size();
    AvbdTriangleDomainGeometry geometry;
    geometry.normal=plane.normal;geometry.lowerGap=PxMin(0.0f,plane.gap);
    for(PxU32 point=0;point<6;++point)
    {
     const AvbdIslandSoftCache& cache=point<3 ? a : b;
     const PxU32 vertex=point<3 ? va[point] : vb[point-3];
     const AvbdSoftEmbeddedPoint& embedded=cache.collisionPoints[vertex];
     const PxU32 supportStart=mRowSupports.size();
     for(PxU32 i=0;i<embedded.count;++i)
     {
      if(embedded.weights[i]==0.0f) continue;
      if(embedded.particleIndices[i]>=cache.nbParticles)
      {
       PxGetFoundation().error(PxErrorCode::eDEBUG_INFO,PX_FL,
        "AVBD domain diagnostic: invalid triangle-domain support.");
       PxAtomicExchange(&mLocalDomainFailed,1);return;
      }
      AvbdRowSupport support;
      support.block=cache.blockStart+embedded.particleIndices[i];
      support.weight=embedded.weights[i];support.localPoint=PxVec3(0.0f);
      mRowSupports.pushBack(support);
     }
     geometry.supportEnds[point]=PxU16(mRowSupports.size()-row.supportStart);
     PxU32& index=pointIndices[point<3 ? ca : cb][vertex];
     if(index==PX_MAX_U32)
     {
      AvbdAffinePointEvaluation value={};
      value.supportStart=supportStart;value.supportCount=mRowSupports.size()-supportStart;
      index=mTrianglePoints.size();mTrianglePoints.pushBack(value);
     }
     geometry.pointIndices[point]=index;
    }
    row.supportCount=geometry.supportEnds[5];
    mTriangleDomainGeometry.pushBack(geometry);row.geometryIndex=mTriangleDomainGeometry.size();
    mRows.pushBack(row);
   };
   // A full-support plane covers every boundary face. It is shared by all
   // vertex pairs, packed in triples without multiplying incident-face copies.
   PxVec3 centerA(0.0f),centerB(0.0f);
   for(PxU32 i=0;i<boundaryPositions[ca].size();++i) centerA+=boundaryPositions[ca][i];
   for(PxU32 i=0;i<boundaryPositions[cb].size();++i) centerB+=boundaryPositions[cb][i];
   centerA/=PxReal(boundaryPositions[ca].size());centerB/=PxReal(boundaryPositions[cb].size());
   auto fullPlane=[&](const PxVec3& axis)
   { return avbdPointSetsPlane(boundaryPositions[ca].begin(),boundaryPositions[ca].size(),
      boundaryPositions[cb].begin(),boundaryPositions[cb].size(),axis); };
   auto fullyInside=[&](PxU32 sourceIndex,const AvbdIslandSoftCache& target,
    const PxArray<PxVec3>& targetPositions)
   {
    for(PxU32 i=0;i<boundaryPositions[sourceIndex].size();++i)
     if(!avbdPointInsideCollisionVolume(boundaryPositions[sourceIndex][i],
      target,targetPositions)) return false;
    return !boundaryPositions[sourceIndex].empty();
   };
   const bool completeContainment=fullyInside(ca,b,positions[cb]) ||
    fullyInside(cb,a,positions[ca]);
   AvbdTrianglePairPlane shared=fullPlane(centerA-centerB);
   // A completely contained closed surface cannot leave while every locally
   // separated triangle pair is forced to preserve its DCD side.  For that
   // invalid starting topology, retain the full-support signed interval along
   // the objective center-to-center exit direction, including its negative
   // initial gap.  Requiring that one interval gap not decrease gives a
   // coherent recovery corridor and permits it to cross zero.  Ordinary
   // separated/intersecting pairs still take the complete recursive proof.
   // Coincident centers have no objective exit direction and therefore keep
   // the recursive fail-closed path rather than selecting a world axis.
   const bool containmentCorridor=completeContainment &&
    shared.normal.magnitudeSquared()>0.0f && shared.gap>-PX_MAX_F32;
   for(PxU32 side=0;side<2 && !containmentCorridor && shared.gap<=0.0f;++side)
   {
    const AvbdIslandSoftCache& cache=side ? b : a;const PxU32 ci=side ? cb : ca;
    for(PxU32 face=0;face<cache.nbBoundaryFaces && shared.gap<=0.0f;++face)
    {
     const AvbdSoftBoundaryFace& f=cache.boundaryFaces[face];
     shared=fullPlane((positions[ci][f.vertices[1]]-positions[ci][f.vertices[0]]).cross(
      positions[ci][f.vertices[2]]-positions[ci][f.vertices[0]]));
    }
   }
   if(shared.gap>0.0f || containmentCorridor)
   {
    for(PxU32 ia=0;ia<vertices[ca].size();ia+=3)
     for(PxU32 ib=0;ib<vertices[cb].size();ib+=3)
     {
      PxU32 va[3],vb[3];for(PxU32 k=0;k<3;++k)
      { va[k]=vertices[ca][PxMin(ia+k,vertices[ca].size()-1)];vb[k]=vertices[cb][PxMin(ib+k,vertices[cb].size()-1)]; }
      append(va,vb,shared);
     }
   }
   else
   {
    // Subdivide only the packing domain. Each child face set is disjoint;
    // their Cartesian products cover the parent's complete feature pairs.
    struct Group
    {
     PxArray<PxU32> faces,vertices;
     PxArray<PxVec3> points;
     PxVec3 center;
    };
    auto makeGroup=[&](PxU32 ci,const PxArray<PxU32>& faces)
    {
     Group group;group.faces=faces;group.center=PxVec3(0.0f);
     const AvbdIslandSoftCache& cache=mIslandSoftCache[ci];
     PxArray<PxU8> used(cache.nbCollisionParticles,0);
     for(PxU32 f=0;f<faces.size();++f) for(PxU32 k=0;k<3;++k)
     {
      const PxU32 vertex=cache.boundaryFaces[faces[f]].vertices[k];
      if(!used[vertex])
      { used[vertex]=1;group.vertices.pushBack(vertex);group.points.pushBack(positions[ci][vertex]);group.center+=positions[ci][vertex]; }
     }
     group.center/=PxReal(group.points.size());return group;
    };
    auto faceCenter=[&](PxU32 ci,PxU32 face)
    {
     const AvbdSoftBoundaryFace& f=mIslandSoftCache[ci].boundaryFaces[face];
     return (positions[ci][f.vertices[0]]+positions[ci][f.vertices[1]]+positions[ci][f.vertices[2]])/3.0f;
    };
    auto split=[&](PxU32 ci,const Group& group,Group& left,Group& right)
    {
     PxArray<PxU32> faces(group.faces);
     const PxVec3 origin=faceCenter(ci,faces[0]);
     PxVec3 axis(0.0f);PxReal longest=-1.0f;
     for(PxU32 f=0;f<faces.size();++f)
     {
      const PxVec3 delta=faceCenter(ci,faces[f])-origin;
      if(delta.magnitudeSquared()>longest) { longest=delta.magnitudeSquared();axis=delta; }
     }
     PxSort(faces.begin(),faces.size(),[&](PxU32 x,PxU32 y)
     {
      const PxReal px=axis.dot(faceCenter(ci,x)),py=axis.dot(faceCenter(ci,y));
      return px<py || (px==py && x<y);
     });
     const PxU32 middle=faces.size()/2;
     PxArray<PxU32> lf,rf;
     for(PxU32 i=0;i<faces.size();++i) (i<middle ? lf : rf).pushBack(faces[i]);
     left=makeGroup(ci,lf);right=makeGroup(ci,rf);
    };
    auto visit=[&](auto&& self,const Group& ga,const Group& gb)->void
    {
     auto project=[&](const PxVec3& axis)
     { return avbdPointSetsPlane(ga.points.begin(),ga.points.size(),gb.points.begin(),gb.points.size(),axis); };
     AvbdTrianglePairPlane plane=project(ga.center-gb.center);
     for(PxU32 side=0;side<2 && plane.gap<=0.0f;++side)
     {
      const Group& group=side ? gb : ga;const PxU32 ci=side ? cb : ca;
      for(PxU32 k=0;k<group.faces.size() && plane.gap<=0.0f;++k)
      {
       const AvbdSoftBoundaryFace& f=mIslandSoftCache[ci].boundaryFaces[group.faces[k]];
       plane=project((positions[ci][f.vertices[1]]-positions[ci][f.vertices[0]]).cross(
        positions[ci][f.vertices[2]]-positions[ci][f.vertices[0]]));
      }
     }
     if(plane.gap>0.0f)
     {
      for(PxU32 ia=0;ia<ga.vertices.size();ia+=3) for(PxU32 ib=0;ib<gb.vertices.size();ib+=3)
      {
       PxU32 va[3],vb[3];for(PxU32 k=0;k<3;++k)
       { va[k]=ga.vertices[PxMin(ia+k,ga.vertices.size()-1)];vb[k]=gb.vertices[PxMin(ib+k,gb.vertices.size()-1)]; }
       append(va,vb,plane);
      }
     }
     else if(ga.faces.size()==1 && gb.faces.size()==1)
     {
      const PxU32* va=a.boundaryFaces[ga.faces[0]].vertices;
      const PxU32* vb=b.boundaryFaces[gb.faces[0]].vertices;
      PxVec3 ta[3],tb[3];for(PxU32 i=0;i<3;++i) { ta[i]=positions[ca][va[i]];tb[i]=positions[cb][vb[i]]; }
      append(va,vb,avbdTrianglePairPlane(ta,tb,ta[0]-tb[0]));
     }
     else
     {
      Group left,right;
      if(ga.faces.size()>=gb.faces.size())
      { split(ca,ga,left,right);self(self,left,gb);self(self,right,gb); }
      else
      { split(cb,gb,left,right);self(self,ga,left);self(self,ga,right); }
     }
    };
    PxArray<PxU32> facesA,facesB;
    for(PxU32 f=0;f<a.nbBoundaryFaces;++f) facesA.pushBack(f);
    for(PxU32 f=0;f<b.nbBoundaryFaces;++f) facesB.pushBack(f);
    const Group ga=makeGroup(ca,facesA),gb=makeGroup(cb,facesB);
    visit(visit,ga,gb);
   }
  }
 mContactRowCount=mRows.size();
}

void AvbdDynamicsContext::assembleParticleContactPrimal(PxU32 blockIndex,
	PxVec3& force, PxMat33& hessian) const
{
	if(blockIndex + 1 >= mBlockObjectiveOffsets.size())
		return;
	for(PxU32 rowRef = mBlockObjectiveOffsets[blockIndex];
		rowRef < mBlockObjectiveOffsets[blockIndex + 1]; ++rowRef)
	{
		if(rowRef >= mBlockObjectiveRows.size())
			break;
		const PxU32 rowIndex = mBlockObjectiveRows[rowRef];
		if(rowIndex >= mRows.size())
			continue;
		const AvbdRow& row = mRows[rowIndex];
		if((row.flags & (eAVBD_ROW_CONTACT | eAVBD_ROW_HETEROGENEOUS |
			eAVBD_ROW_INACTIVE)) !=
			(eAVBD_ROW_CONTACT | eAVBD_ROW_HETEROGENEOUS))
			continue;
		if(row.kernelId==eAVBD_ROW_KERNEL_CONTACT_FRAME)
		{
			const auto value=avbdContactFrameRow(row,mRowSupports,mBlocks,mBodies,contactGeometry());
			if(!value.valid) { force=PxVec3(PxReal(NAN));return; }
			const PxVec3 jacobian=avbdContactFrameGradient(row,mRowSupports,contactGeometry(),value,blockIndex);
			const auto potential=avbdHeterogeneousContactPotential(row,PxReal(value.gap));
			force-=jacobian*potential.gradient;
			hessian+=avbdSoftOuter(jacobian,jacobian)*potential.curvature;
			continue;
		}
		PxReal weight = 0.0f;
		for(PxU32 supportIndex = row.supportStart;
			supportIndex < row.supportStart + row.supportCount; ++supportIndex)
			if(supportIndex < mRowSupports.size() &&
				mRowSupports[supportIndex].block == blockIndex)
				weight += mRowSupports[supportIndex].weight;
		if(PxAbs(weight) <= 1.0e-8f)
			continue;
		const PxVec3 jacobian = avbdHeterogeneousNormal(row, mBodies, contactGeometry(),mRowSupports,mBlocks) * weight;
		const PxReal C = avbdHeterogeneousRowC(row, mRowSupports, mBlocks,
			mBodies, contactGeometry());
		const AvbdContactPotential potential =
			avbdHeterogeneousContactPotential(row, C);
		force -= jacobian * potential.gradient;
		hessian += avbdSoftOuter(jacobian, jacobian) * potential.curvature;
	}
}

double AvbdDynamicsContext::particleContactEnergy(PxU32 blockIndex,
	const PxVec3& candidate, bool change) const
{
	if(blockIndex >= mBlocks.size() ||
		mBlocks[blockIndex].type != eAVBD_BLOCK_PARTICLE3 ||
		!mBlocks[blockIndex].particle ||
		blockIndex + 1 >= mBlockObjectiveOffsets.size())
		return 0.0f;
	const AvbdSoftParticle& particle = *mBlocks[blockIndex].particle;
	double energy = 0.0;
	for(PxU32 rowRef = mBlockObjectiveOffsets[blockIndex];
		rowRef < mBlockObjectiveOffsets[blockIndex + 1]; ++rowRef)
	{
		if(rowRef >= mBlockObjectiveRows.size())
			return PX_MAX_F32;
		const PxU32 rowIndex = mBlockObjectiveRows[rowRef];
		if(rowIndex >= mRows.size())
			continue;
		const AvbdRow& row = mRows[rowIndex];
		if((row.flags & (eAVBD_ROW_CONTACT | eAVBD_ROW_HETEROGENEOUS |
			eAVBD_ROW_INACTIVE)) !=
			(eAVBD_ROW_CONTACT | eAVBD_ROW_HETEROGENEOUS))
			continue;
		auto difference=[&](double gap,double delta)
		{
			const bool al=avbdHeterogeneousPositionAl(row);
			return avbdUnilateralContactEnergyChange(gap,delta,al ? row.rho : row.contactStiffness,
				al ? row.lambda : 0.0f,row.minLambda);
		};
		if(row.kernelId==eAVBD_ROW_KERNEL_CONTACT_FRAME)
		{
			const auto value=avbdContactFrameRow(row,mRowSupports,mBlocks,mBodies,contactGeometry(),blockIndex,&candidate);
			if(!value.valid) return PX_MAX_F32;
			if(change)
			{
				const auto current=avbdContactFrameRow(row,mRowSupports,mBlocks,mBodies,contactGeometry());
				if(!current.valid) return PX_MAX_F32;
				energy+=difference(current.gap,value.gap-current.gap);
			}
			else energy+=avbdHeterogeneousContactPotential(row,PxReal(value.gap)).energy;
			continue;
		}
		PxReal weight = 0.0f;
		for(PxU32 supportIndex = row.supportStart;
			supportIndex < row.supportStart + row.supportCount; ++supportIndex)
			if(supportIndex < mRowSupports.size() &&
				mRowSupports[supportIndex].block == blockIndex)
				weight += mRowSupports[supportIndex].weight;
		if(PxAbs(weight) <= 1.0e-8f)
			continue;
		const PxReal currentC = avbdHeterogeneousRowC(row, mRowSupports,
			mBlocks, mBodies, contactGeometry());
		const PxVec3 normal=avbdHeterogeneousNormal(row,mBodies,contactGeometry(),mRowSupports,mBlocks);
		const double deltaC=avbdOgcDouble(normal).dot(avbdOgcDouble(candidate)-avbdOgcDouble(particle.p))*double(weight);
		energy+=change ? difference(currentC,deltaC) :
			avbdHeterogeneousContactPotential(row,currentC+normal.dot(candidate-particle.p)*weight).energy;
	}
	return PxIsFinite(energy) ? energy : PX_MAX_F32;
}

void AvbdDynamicsContext::compileCommittedTrianglePlanes(PxU32 ref,
 AvbdOgcProjectionPlane (&planes)[9]) const
{
 const AvbdRow& row=mRows[mRowProgram.blockRows[ref]];
 const AvbdTriangleDomainGeometry& geometry=mTriangleDomainGeometry[row.geometryIndex-1];
 PxVec3d points[6],scales[6];
 for(PxU32 i=0;i<6;++i)
 {
  const AvbdAffinePointEvaluation& value=mTrianglePoints[geometry.pointIndices[i]];
  points[i]=value.point;scales[i]=value.scale;
 }
 AvbdTriangleDomainArgs args={&geometry,points,scales,mBlockTriangleCoefficients[ref].weights,planes};
 mKernels.launch(AVBD_TRIANGLE_DOMAIN,&args);
}

bool AvbdDynamicsContext::triangleDomainSeparated(PxU32 ref,const PxVec3d& delta) const
{
 const AvbdRow& row=mRows[mRowProgram.blockRows[ref]];
 bool separated=false;
 AvbdTriangleDomainScreenArgs args={&mTriangleDomainGeometry[row.geometryIndex-1],
  mTriangleProjections.begin(),mBlockTriangleCoefficients[ref].weights,&delta,&separated};
 args.absoluteWeights=mBlockTriangleCoefficients[ref].absoluteWeights;args.inputIntervals=true;
 mKernels.launch(AVBD_TRIANGLE_DOMAIN_SCREEN,&args);
 return separated;
}

bool AvbdDynamicsContext::triangleBatchSeparated(PxU32 index,const PxVec3d& delta) const
{
 const TriangleBlockBatch& batch=mTriangleBatches[index];
 const PxReal motion=PxUnionCast<PxReal,PxI32>(PxAtomicCompareExchange(&mTriangleMotionBits,0,0));
 if(batch.bound.admits(motion,PxMax(PxAbs(delta.x),PxMax(PxAbs(delta.y),PxAbs(delta.z))))) return true;
 bool separated=false;
 AvbdTriangleDomainScreenArgs args={&mTriangleDomainGeometry[batch.geometry],
  mTriangleProjections.begin(),NULL,&delta,&separated};
 args.refs=mTriangleBatchPoints.begin()+batch.pointStart;args.countA=batch.countA;args.count=batch.count;
 args.inputIntervals=true;
 mKernels.launch(AVBD_TRIANGLE_DOMAIN_SCREEN,&args);
 return separated;
}

void AvbdDynamicsContext::compileParticleCommitDomain(PxU32 blockIndex,
 const PxVec3& anchor, AvbdOgcProjectionPlanes& constraints)
{
 // Each block owns its projection program. The coefficients are immutable
 // for this DCD epoch; defer normalization/sorting until a proposal needs it.
 TriangleBlockProjection& projection=mBlockTriangleProjection[blockIndex];
 if(!projection.compiled)
 {
  struct Entry { PxVec3d normal; PxU32 ref,plane; };
  PxArray<Entry> entries;
  for(PxU32 ref=mRowProgram.blockOffsets[blockIndex];ref<mRowProgram.blockOffsets[blockIndex+1];++ref)
  {
   const AvbdRow& row=mRows[mRowProgram.blockRows[ref]];
   if(row.kernelId!=eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN) continue;
   const PxVec3d normal=avbdOgcDouble(mTriangleDomainGeometry[row.geometryIndex-1].normal);
   TriangleBlockCoefficients& coefficients=mBlockTriangleCoefficients[ref];
   for(PxU32 a=0;a<3;++a) for(PxU32 b=3;b<6;++b)
   {
    const PxU32 plane=a*3+b-3;
    const PxVec3d coefficient=avbdTriangleDomainCoefficient(normal,coefficients.weights,a,b);
    const double length=coefficient.magnitude();
    coefficients.lengths[plane]=length;coefficients.groups[plane]=PX_MAX_U32;
    if(length>0.0 && PxIsFinite(length))
    {
     Entry entry={coefficient/length,ref,plane};entries.pushBack(entry);
    }
   }
  }
  PxSort(entries.begin(),entries.size(),[](const Entry& a,const Entry& b)->bool
  {
   if(a.normal.x!=b.normal.x) return a.normal.x<b.normal.x;
   if(a.normal.y!=b.normal.y) return a.normal.y<b.normal.y;
   if(a.normal.z!=b.normal.z) return a.normal.z<b.normal.z;
   return a.ref<b.ref || (a.ref==b.ref && a.plane<b.plane);
  });
  for(PxU32 i=0;i<entries.size();++i)
  {
   if(i==0 || entries[i].normal!=entries[i-1].normal)
    projection.normals.pushBack(entries[i].normal);
   mBlockTriangleCoefficients[entries[i].ref].groups[entries[i].plane]=projection.normals.size()-1;
  }
  projection.compiled=true;
 }
 PxInlineArray<AvbdOgcParallelPlaneBounds,8> grouped;
 grouped.resize(projection.normals.size());
 const AvbdBlock& block=mBlocks[blockIndex];
 const PxVec3 current=block.particle->p;
 const PxVec3d origin=avbdOgcDouble(current)-avbdOgcDouble(anchor);
 const PxVec3d inputScale=avbdOgcDouble(current.abs())+avbdOgcDouble(anchor.abs());
 auto append=[&](const PxVec3& gradient,double lower,double roundoff)
 {
  AvbdOgcProjectionPlane plane;
  plane.n=avbdOgcDouble(gradient);
  plane.b=lower+plane.n.dot(origin);
  plane.roundoff=roundoff+4.0*PX_EPS_F32*avbdOgcDouble(gradient.abs()).dot(inputScale);
  const double length=plane.n.magnitude();
  if(length>0.0) { plane.n/=length; plane.b/=length; plane.roundoff/=length; }
  constraints.pushBack(plane);
 };
 if(blockIndex+1<mRowProgram.blockOffsets.size())
  for(PxU32 ref=mRowProgram.blockOffsets[blockIndex];ref<mRowProgram.blockOffsets[blockIndex+1];++ref)
  {
   const PxU32 rowIndex=mRowProgram.blockRows[ref];
   const AvbdRow& row=mRows[rowIndex];
   if(row.kernelId==eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN)
   {
    AvbdOgcProjectionPlane planes[9];
    compileCommittedTrianglePlanes(ref,planes);
     for(PxU32 i=0;i<9;++i)
    {
     AvbdOgcProjectionPlane plane=planes[i];
     const double length=mBlockTriangleCoefficients[ref].lengths[i];
     if(length==0.0 && plane.b<=plane.roundoff) continue;
     plane.b+=plane.n.dot(origin);
     plane.roundoff+=4.0*PX_EPS_F32*plane.n.abs().dot(inputScale);
     const PxU32 group=mBlockTriangleCoefficients[ref].groups[i];
     if(length>0.0)
     {
      plane.n=group!=PX_MAX_U32 ? projection.normals[group] : plane.n/length;
      plane.b/=length;plane.roundoff/=length;
     }
     if(group!=PX_MAX_U32 && PxIsFinite(plane.b) && PxIsFinite(plane.roundoff) && plane.roundoff>=0.0)
      grouped[group].include(plane);
     else constraints.pushBack(plane);
    }
    continue;
   }
   // This objective is nonlinear in a frame support. Complete triangle rows,
   // not a frozen tangent of the physical potential, certify nonpenetration.
   if(row.kernelId==eAVBD_ROW_KERNEL_CONTACT_FRAME) continue;
   if((row.flags&(eAVBD_ROW_CONTACT|eAVBD_ROW_HETEROGENEOUS|eAVBD_ROW_INACTIVE))!=
    (eAVBD_ROW_CONTACT|eAVBD_ROW_HETEROGENEOUS)) continue;
   const PxVec3 normal=avbdHeterogeneousNormal(row,mBodies,contactGeometry(),mRowSupports,mBlocks);
   const double admissionOffset=avbdHeterogeneousAdmissionOffset(row);
   const double gap=double(avbdHeterogeneousRowC(row,mRowSupports,mBlocks,mBodies,contactGeometry()))+admissionOffset;
   PxReal weight=0.0f;
   double scale=PxAbs(row.contactOffset)+PxAbs(row.contactRadius);
   for(PxU32 k=row.supportStart;k<row.supportStart+row.supportCount;++k)
   {
    const AvbdRowSupport& support=mRowSupports[k];
    if(support.block==blockIndex) weight+=support.weight;
    const PxVec3 point=avbdBlockSupportPoint(mBlocks[support.block],support,mBodies);
    scale+=double(PxAbs(support.weight))*double(normal.abs().dot(point.abs()));
   }
   if(weight!=0.0f)
   {
    const double lower=avbdHeterogeneousAdmissionLower(row,gap);
    append(normal*weight,lower-gap,4.0*PX_EPS_F32*scale);
   }
  }
 for(PxU32 i=0;i<grouped.size();++i) grouped[i].append(constraints);
 if(block.particleKernel==eAVBD_PARTICLE_KERNEL_TET && block.objectIndex<mIslandSoftCache.size())
 {
  const AvbdIslandSoftCache& cache=mIslandSoftCache[block.objectIndex];
  const PxU32 begin=cache.incidentTetOffsets ? cache.incidentTetOffsets[block.stateIndex] : 0;
  const PxU32 end=cache.incidentTetOffsets ? cache.incidentTetOffsets[block.stateIndex+1] : cache.nbTets;
  for(PxU32 ref=begin;ref<end;++ref)
  {
   const AvbdSoftTet& tet=cache.tets[cache.incidentTetIndices ? cache.incidentTetIndices[ref] : ref];
   const PxU32 order=tet.p0==block.stateIndex ? 0 : tet.p1==block.stateIndex ? 1 :
    tet.p2==block.stateIndex ? 2 : tet.p3==block.stateIndex ? 3 : PX_MAX_U32;
   if(order==PX_MAX_U32) continue;
   const AvbdSoftTetDomain domain=avbdSoftTetDomain(tet,order,cache.particles);
   // The determinant is affine for this coordinate block. Compile it beside
   // contact/OGC planes, rather than altering an already projected candidate.
   append(domain.gradient,double(PxMin(0.05f,domain.determinant))-domain.determinant,
    4.0*PX_EPS_F32*PxAbs(domain.determinant));
  }
 }
}

bool AvbdDynamicsContext::triangleCandidateAdmitted(PxU32 rowIndex,PxU32 blockIndex,const PxVec3& candidate) const
{
 const AvbdRow& row=mRows[rowIndex];
 const AvbdTriangleDomainGeometry& geometry=mTriangleDomainGeometry[row.geometryIndex-1];
 PxVec3d points[6],scales[6];double weights[6];
 avbdTriangleDomainPoints(geometry,mRowSupports.begin()+row.supportStart,
  [&](const AvbdRowSupport& support)
  { return support.block==blockIndex ? candidate : avbdBlockSupportPoint(mBlocks[support.block],support,mBodies); },
  PX_MAX_U32,points,scales,weights);
 AvbdOgcProjectionPlane planes[9];
 AvbdTriangleDomainArgs args={&geometry,points,scales,weights,planes};
 mKernels.launch(AVBD_TRIANGLE_DOMAIN,&args);
 return avbdTriangleDomainAdmits(planes,9,PxVec3d(0.0));
}

bool AvbdDynamicsContext::particleContactCandidateAdmissible(PxU32 blockIndex,
 const PxVec3& candidate,bool committedTriangles) const
{
 if(!candidate.isFinite()) return false;
 if(blockIndex+1>=mRowProgram.blockOffsets.size()) return true;
 const PxVec3 original=mBlocks[blockIndex].particle->p;
 const PxVec3d delta=avbdOgcDouble(candidate)-avbdOgcDouble(original);
 if(committedTriangles)
  for(PxU32 b=mBlockTriangleBatchOffsets[blockIndex];b<mBlockTriangleBatchOffsets[blockIndex+1];++b)
  {
   if(triangleBatchSeparated(b,delta)) continue;
   const TriangleBlockBatch& batch=mTriangleBatches[b];
   for(PxU32 r=batch.rowStart;r<batch.rowStart+batch.rowCount;++r)
   {
    const PxU32 ref=mTriangleBatchRows[r];
    if(triangleDomainSeparated(ref,delta)) continue;
    // At an input-interval boundary evaluate the actual PxReal candidate.
    // Adding J*delta to a cached gap has a different rounding order and input
    // scale than the joint publication oracle; it is only a screening test.
    if(!triangleCandidateAdmitted(mRowProgram.blockRows[ref],blockIndex,candidate)) return false;
   }
  }

 const PxArray<PxU32>& offsets=committedTriangles ? mBlockObjectiveOffsets : mRowProgram.blockOffsets;
 const PxArray<PxU32>& rows=committedTriangles ? mBlockObjectiveRows : mRowProgram.blockRows;
 for(PxU32 ref=offsets[blockIndex];ref<offsets[blockIndex+1];++ref)
 {
  const AvbdRow& row=mRows[rows[ref]];
  if(row.kernelId==eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN)
  {
   if(!triangleCandidateAdmitted(rows[ref],blockIndex,candidate)) return false;
   continue;
  }
  if(row.kernelId==eAVBD_ROW_KERNEL_CONTACT_FRAME)
  {
   if(!avbdContactFrameRow(row,mRowSupports,mBlocks,mBodies,contactGeometry(),blockIndex,&candidate).valid) return false;
   continue;
  }
  // Projection is an accelerator, not the publication oracle.  Re-evaluate
  // the complete float-authored row so Particle3 and the following Rigid6
  // block use the same input-error interval for the exact committed state.
  if((row.flags&(eAVBD_ROW_CONTACT|eAVBD_ROW_HETEROGENEOUS|eAVBD_ROW_INACTIVE))!=
   (eAVBD_ROW_CONTACT|eAVBD_ROW_HETEROGENEOUS)) continue;
  const PxVec3 normal=avbdHeterogeneousNormal(row,mBodies,contactGeometry(),mRowSupports,mBlocks);
  auto currentPoint=[&](const AvbdRowSupport& support)
  { return avbdBlockSupportPoint(mBlocks[support.block],support,mBodies); };
  auto candidatePoint=[&](const AvbdRowSupport& support)
  { return support.block==blockIndex ? candidate : currentPoint(support); };
  if(!avbdHeterogeneousCandidateAdmissiblePoints(row,mRowSupports,normal,
   normal,currentPoint,candidatePoint))
   return false;
 }
 return true;
}

PxReal AvbdDynamicsContext::solveSurfaceParticlePrimal(
	AvbdIslandSurfaceCache& cache, PxU32 particleIndex, PxReal invH2)
{
	if(!cache.surface || !cache.particles || particleIndex >= cache.nbParticles)
		return 0.0f;
	AvbdSoftParticle& particle = cache.particles[particleIndex];
	if(particle.invMass <= 0.0f)
		return 0.0f;
	const DeformableSurfaceCore& core = cache.surface->getCore();
	const AvbdSoftMaterial lame = avbdSoftLameFromYoungPoisson(core.cpuYoungs,
		PxClamp(core.cpuPoissons, 0.0f, 0.499f));
	const PxReal thickness = PxMax(core.cpuThickness, 1.0e-6f);
	const PxReal mu = lame.mu * thickness;
	const PxReal lambda = lame.lambda * thickness;
	const PxReal bendingStiffness = PxMax(core.cpuBendingStiffness, 0.0f);
	const bool flattening = core.surfaceFlags &
		PxDeformableSurfaceFlag::eENABLE_FLATTENING;
	const PxReal massInvH2 = particle.mass * invH2;
	PxVec3 force = (particle.pHat - particle.p) * massInvH2;
	PxMat33 hessian = PxMat33::createDiagonal(PxVec3(massInvH2));

	for(PxU32 triangleIndex = 0; triangleIndex < cache.nbTriangles;
		++triangleIndex)
	{
		const AvbdSoftTri& triangle = cache.triangles[triangleIndex];
		const PxU32 order = triangle.p0 == particleIndex ? 0 :
			triangle.p1 == particleIndex ? 1 :
			triangle.p2 == particleIndex ? 2 : PX_MAX_U32;
		if(order == PX_MAX_U32)
			continue;
		PxVec3 elementForce;
		PxMat33 elementHessian;
		avbdSoftStvkTriForceHessian(triangle, order, mu, lambda,
			cache.particles, elementForce, elementHessian);
		force += elementForce;
		hessian += elementHessian;
	}
	for(PxU32 bendIndex = 0; bendIndex < cache.nbBends; ++bendIndex)
	{
		const AvbdSoftBending& bend = cache.bends[bendIndex];
		const PxU32 vertices[4] = {bend.opp0, bend.opp1,
			bend.edgeStart, bend.edgeEnd};
		PxU32 order = PX_MAX_U32;
		for(PxU32 candidate = 0; candidate < 4; ++candidate)
			if(vertices[candidate] == particleIndex)
			{
				order = candidate;
				break;
			}
		if(order == PX_MAX_U32)
			continue;
		PxVec3 elementForce;
		PxMat33 elementHessian;
		avbdSoftBendingForceHessian(bend, order, bendingStiffness,
			flattening ? 0.0f : bend.restShapeAngle, cache.particles,
			elementForce, elementHessian);
		force += elementForce;
		hessian += elementHessian;
	}

	const PxU32 blockIndex = cache.blockStart + particleIndex;
	const AvbdBlock& block=mBlocks[blockIndex];
	assembleParticleContactPrimal(blockIndex, force, hessian);

	PxVec3 delta;
	PxMat33 effectiveMetric;
	if(!avbdSolve3(hessian, force, delta, &effectiveMetric) || !delta.isFinite())
		return 0.0f;
	auto energy=[&](const PxVec3& candidate)->PxReal
	{
		auto point=[&](PxU32 index)->PxVec3 { return index==particleIndex ? candidate : cache.particles[index].p; };
		PxReal value=0.5f*massInvH2*(candidate-particle.pHat).magnitudeSquared()+
			PxReal(particleContactEnergy(blockIndex,candidate));
		for(PxU32 i=0;i<cache.nbTriangles;++i)
		{
			const AvbdSoftTri& tri=cache.triangles[i];
			if(tri.p0!=particleIndex && tri.p1!=particleIndex && tri.p2!=particleIndex) continue;
			value+=avbdSoftStvkTriEnergy(tri,mu,lambda,point(tri.p0),point(tri.p1),point(tri.p2));
		}
		for(PxU32 i=0;i<cache.nbBends;++i)
		{
			const AvbdSoftBending& bend=cache.bends[i];
			if(bend.opp0!=particleIndex && bend.opp1!=particleIndex &&
				bend.edgeStart!=particleIndex && bend.edgeEnd!=particleIndex) continue;
			value+=avbdSoftBendingEnergy(bend,bendingStiffness,
				flattening?0.0f:bend.restShapeAngle,point(bend.opp0),point(bend.opp1),
				point(bend.edgeStart),point(bend.edgeEnd));
		}
		return value;
	};
	const PxReal currentEnergy=energy(particle.p);
	AvbdOgcPointRegion region;
	if(block.ogcRegion)
		region=avbdOgcPointRegionAgainstCommittedRigid(*block.ogcRegion,
			mBodies,mIslandSoftCache);
	else avbdOgcResetPointRegion(region,particle.p);
	AvbdOgcProjectionPlanes commitDomain;
	compileParticleCommitDomain(blockIndex,region.anchor,commitDomain);
	PxVec3 endpoint=particle.p+delta;
	const AvbdOgcClip clip=avbdOgcTruncatePoint(region,endpoint,&commitDomain,
		&effectiveMetric,&particle.p);
	if(!clip.feasible) {
		PxGetFoundation().error(PxErrorCode::eDEBUG_INFO,PX_FL,
			"AVBD domain diagnostic: surface Particle3 projection infeasible.");
		PxAtomicExchange(&mLocalDomainFailed,1); return 0.0f;
	}
	const PxVec3 admissible=endpoint-particle.p;
	PxReal fraction=1.0f;
	for(PxU32 search=0;search<16;++search)
	{
		PxVec3 candidate=particle.p+admissible*fraction;
		if(candidate==particle.p) break;
		const PxVec3 step=candidate-particle.p;
		const PxReal descent=force.dot(step);
		const PxVec3d candidateOffset=avbdOgcDouble(candidate)-
			avbdOgcDouble(region.anchor);
		if(descent>0.0f && avbdOgcPointContains(region,candidate) &&
			avbdOgcRegionContains(commitDomain,candidateOffset,double(PX_MAX_F32)) &&
			particleContactCandidateAdmissible(blockIndex,candidate))
		{
			const PxReal candidateEnergy=energy(candidate);
			if(PxIsFinite(candidateEnergy) && candidateEnergy<=currentEnergy-1.0e-4f*descent)
			{
				if(clip.spent && cache.ogcExceeded) cache.ogcExceeded[particleIndex]=1;
				particle.p=candidate;
				return step.magnitude();
			}
		}
		fraction*=0.5f;
	}
	return 0.0f;
}

PxReal AvbdDynamicsContext::solveCoupledParticleDomainPrimal(bool& stationary,
	bool repairRequired, bool& repairResolved,
	PxArray<PxU8>& participant,
	const PxArray<PxReal>& localNormalizedSteps,
	const PxArray<PxU8>& repairSeeds)
{
	stationary=true;
	repairResolved=!repairRequired;
	participant.resize(mBlocks.size());
	for(PxU32 i=0;i<participant.size();++i) participant[i]=0;
	PxArray<PxU8> correctionParticipant;
	correctionParticipant.resize(mBlocks.size());
	for(PxU32 i=0;i<correctionParticipant.size();++i)
		correctionParticipant[i]=0;
	bool hasVolumeParticipant=false;
	auto eligibleVolumeBlock=[&](PxU32 blockIndex)->bool
	{
		if(blockIndex>=mBlocks.size()) return false;
		const AvbdBlock& block=mBlocks[blockIndex];
		if(block.type!=eAVBD_BLOCK_PARTICLE3 || !block.particle ||
			block.particleKernel!=eAVBD_PARTICLE_KERNEL_TET ||
			block.particle->invMass<=0.0f ||
			block.objectIndex>=mIslandSoftCache.size()) return false;
		const AvbdIslandSoftCache& cache=mIslandSoftCache[block.objectIndex];
		return cache.coupled && cache.liveStamp==mIslandSoftLiveStamp &&
			cache.volume && cache.particles && cache.tets;
	};
	for(PxU32 blockIndex=0;blockIndex<mBlocks.size();++blockIndex)
	{
		if(!eligibleVolumeBlock(blockIndex)) continue;
		participant[blockIndex]=repairRequired ?
			(blockIndex<repairSeeds.size() && repairSeeds[blockIndex]) : 1;
		hasVolumeParticipant|=participant[blockIndex]!=0;
	}
	if(!hasVolumeParticipant) return 0.0f;
	if(repairRequired)
	{
		// A failed PxReal coordinate identifies the joint-domain component that
		// needs repair. Preserve every material block in each selected volume and
		// cross only rows that actually share Particle3 endpoints. Disconnected
		// volumes form independent block-diagonal KKT programs; compiling them into
		// the same temporary Schur system changes no solution and dominates the
		// cost once the DCD manifold contains thousands of triangle planes.
		PxArray<PxU8> selectedObjects;
		selectedObjects.resize(mIslandSoftCache.size());
		for(PxU32 objectIndex=0;objectIndex<selectedObjects.size();++objectIndex)
			selectedObjects[objectIndex]=0;
		for(PxU32 blockIndex=0;blockIndex<participant.size();++blockIndex)
			if(participant[blockIndex])
				selectedObjects[mBlocks[blockIndex].objectIndex]=1;
		bool expanded=true;
		while(expanded)
		{
			expanded=false;
			for(PxU32 rowIndex=0;rowIndex<mRows.size();++rowIndex)
			{
				const AvbdRow& row=mRows[rowIndex];
				const bool sharedDomain=row.kernelId==eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN ||
					(row.supportCount &&
						(row.flags&(eAVBD_ROW_CONTACT|eAVBD_ROW_HETEROGENEOUS|
							eAVBD_ROW_INACTIVE))==
							(eAVBD_ROW_CONTACT|eAVBD_ROW_HETEROGENEOUS) &&
						row.kernelId!=eAVBD_ROW_KERNEL_CONTACT_FRAME);
				if(!sharedDomain) continue;
				bool touchesSelected=false;
				for(PxU32 supportIndex=row.supportStart;
					supportIndex<row.supportStart+row.supportCount;++supportIndex)
				{
					const PxU32 blockIndex=mRowSupports[supportIndex].block;
					if(eligibleVolumeBlock(blockIndex) &&
						selectedObjects[mBlocks[blockIndex].objectIndex])
					{
						touchesSelected=true;
						break;
					}
				}
				if(!touchesSelected) continue;
				for(PxU32 supportIndex=row.supportStart;
					supportIndex<row.supportStart+row.supportCount;++supportIndex)
				{
					const PxU32 blockIndex=mRowSupports[supportIndex].block;
					if(!eligibleVolumeBlock(blockIndex)) continue;
					const PxU32 objectIndex=mBlocks[blockIndex].objectIndex;
					if(!selectedObjects[objectIndex])
					{
						selectedObjects[objectIndex]=1;
						expanded=true;
					}
				}
			}
		}
		for(PxU32 blockIndex=0;blockIndex<participant.size();++blockIndex)
			participant[blockIndex]=eligibleVolumeBlock(blockIndex) &&
				selectedObjects[mBlocks[blockIndex].objectIndex];
	}
	PxReal maximumLocalStep=0.0f;
	for(PxU32 blockIndex=0;blockIndex<participant.size();++blockIndex)
		if(participant[blockIndex] && blockIndex<localNormalizedSteps.size())
			maximumLocalStep=PxMax(maximumLocalStep,
				localNormalizedSteps[blockIndex]);
	if(maximumLocalStep>1.0f && !repairRequired)
	{
		for(PxU32 blockIndex=0;blockIndex<participant.size();++blockIndex)
			participant[blockIndex]=0;
		stationary=!repairRequired;
		return 0.0f;
	}

	const PxReal invH2=(mDt>0.0f) ? 1.0f/(mDt*mDt) : 3600.0f;
	PxArray<PxVec3> forces;
	PxArray<PxMat33> metrics;
	PxArray<AvbdCoupledDomainBlock> kktBlocks;
	forces.resize(mBlocks.size());
	metrics.resize(mBlocks.size());
	kktBlocks.resize(mBlocks.size());
	for(PxU32 blockIndex=0;blockIndex<mBlocks.size();++blockIndex)
	{
		kktBlocks[blockIndex].step=PxVec3d(0.0);
		if(!participant[blockIndex]) continue;
		const AvbdBlock& block=mBlocks[blockIndex];
		if(block.objectIndex>=mIslandSoftCache.size() ||
			block.objectIndex>=mSoftMaterialScratch.size() ||
			block.objectIndex>=mSoftPinCountScratch.size())
		{
			stationary=false; return 0.0f;
		}
		const AvbdIslandSoftCache& cache=mIslandSoftCache[block.objectIndex];
		AvbdSoftWorldPin* pins=mSoftWorldPinScratch.begin()+
			block.objectIndex*AVBD_SOFT_MAX_WORLD_PINS;
		PxMat33 hessian;
		if(!assembleVolumeParticlePrimal(cache,block.stateIndex,
			mSoftMaterialScratch[block.objectIndex],invH2,pins,
			mSoftPinCountScratch[block.objectIndex],forces[blockIndex],hessian))
		{
			stationary=false; return 0.0f;
		}
		// The atomic candidate is admitted against particleEnergy(), which includes
		// the heterogeneous contact potential. Compile the same gradient and
		// Gauss-Newton curvature here as in the ordinary Particle3 block solve;
		// otherwise the KKT ray is not a direction of its acceptance objective.
		assembleParticleContactPrimal(blockIndex,forces[blockIndex],hessian);
		PxVec3 unconstrained;
		if(!avbdSolve3(hessian,forces[blockIndex],unconstrained,
			&metrics[blockIndex]) || !unconstrained.isFinite())
		{
			stationary=false; return 0.0f;
		}
		kktBlocks[blockIndex].step=avbdOgcDouble(unconstrained);
	}

	PxArray<AvbdCoupledDomainConstraint> constraints;
	PxArray<AvbdCoupledDomainTerm> terms;
	PxArray<PxU32> contactDomainIndices(mRows.size(),PX_MAX_U32);
	auto appendTerm=[&](PxU32 blockIndex,const PxVec3& gradient)->bool
	{
		if(blockIndex>=participant.size() || !participant[blockIndex] ||
			gradient.magnitudeSquared()<=1.0e-30f)
			return true;
		if(!gradient.isFinite()) return false;
		AvbdCoupledDomainTerm term;
		term.block=blockIndex;
		term.gradient=avbdOgcDouble(gradient);
		term.inverseMetricGradient=PxVec3d(0.0);
		terms.pushBack(term);
		return true;
	};
	auto finishConstraint=[&](AvbdCoupledDomainConstraint& constraint)->bool
	{
		constraint.termCount=terms.size()-constraint.termStart;
		if(constraint.termCount)
		{
			constraints.pushBack(constraint);
			return true;
		}
		return constraint.rhs-constraint.tolerance<=
			64.0*DBL_EPSILON*(1.0+PxAbs(constraint.rhs));
	};
	mTriangleClosureScratch.clear();
	mTriangleClosureScratch.resize(mTriangleTermOffsets.size()-1,TriangleClosureBounds{});
	for(PxU32 rowIndex=0;rowIndex<mRows.size();++rowIndex)
	{
		const AvbdRow& row=mRows[rowIndex];
		if(row.kernelId!=eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN) continue;
		bool hasParticipantSupport=false;
		for(PxU32 supportIndex=row.supportStart;
			supportIndex<row.supportStart+row.supportCount;++supportIndex)
		{
			const PxU32 blockIndex=mRowSupports[supportIndex].block;
			hasParticipantSupport|=blockIndex<participant.size() &&
				participant[blockIndex];
		}
		if(!hasParticipantSupport) continue;
		if(!row.geometryIndex || row.geometryIndex>mTriangleDomainGeometry.size())
		{
			stationary=false; return 0.0f;
		}
		const AvbdTriangleDomainGeometry& geometry=
			mTriangleDomainGeometry[row.geometryIndex-1];
		AvbdOgcProjectionPlane full[9];
		const double zeroWeights[6]={};
		avbdCompileTriangleDomain(row,geometry,mRowSupports,mBlocks,mBodies,
			PX_MAX_U32,mKernels,full,mTrianglePoints.begin(),zeroWeights);
		for(PxU32 plane=0;plane<9;++plane)
		{
			const PxU32 index=mTriangleStencilIndices[(row.geometryIndex-1)*9+plane];
			bool hasTerm=false;
			for(PxU32 t=mTriangleTermOffsets[index];t<mTriangleTermOffsets[index+1];++t)
				hasTerm|=participant[mTriangleFixedTerms[t].block]!=0;
			if(!hasTerm && full[plane].b-full[plane].roundoff>
				64.0*DBL_EPSILON*(1.0+PxAbs(full[plane].b)))
			{ stationary=false;return 0.0f; }
			if(!hasTerm) continue;
			TriangleClosureBounds& bounds=mTriangleClosureScratch[index];
			// All original rows remain in final nonlinear admission. Within this
			// fixed linear solve, equal left sides have exactly one strongest rhs.
			if(!bounds.state || full[plane].b-full[plane].roundoff>bounds.rhs-bounds.tolerance)
			{
				bounds.rhs=full[plane].b;bounds.tolerance=full[plane].roundoff;
				bounds.state=1;
			}
		}
	}

	// Admission is owned by the complete heterogeneous row.  Compile one
	// inequality with every dynamic Particle3 endpoint so the Schur solve can
	// preserve relative co-motion instead of intersecting independently
	// projected coordinate domains.
	for(PxU32 rowIndex=0;rowIndex<mRows.size();++rowIndex)
	{
		const AvbdRow& row=mRows[rowIndex];
		if(!row.supportCount ||
			(row.flags&(eAVBD_ROW_CONTACT|eAVBD_ROW_HETEROGENEOUS|
				eAVBD_ROW_INACTIVE))!=
				(eAVBD_ROW_CONTACT|eAVBD_ROW_HETEROGENEOUS) ||
			row.kernelId==eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN ||
			row.kernelId==eAVBD_ROW_KERNEL_CONTACT_FRAME)
			continue;
		bool hasParticipantSupport=false;
		for(PxU32 supportIndex=row.supportStart;
			supportIndex<row.supportStart+row.supportCount;++supportIndex)
		{
			const PxU32 blockIndex=mRowSupports[supportIndex].block;
			hasParticipantSupport|=blockIndex<participant.size() &&
				participant[blockIndex];
		}
		if(!hasParticipantSupport) continue;
		const PxVec3 normal=avbdHeterogeneousNormal(row,mBodies,
			contactGeometry(),mRowSupports,mBlocks);
		const double admissionOffset=avbdHeterogeneousAdmissionOffset(row);
		AvbdContactAdmissionState admission(row.contactOffset,admissionOffset,row.C0);
		for(PxU32 supportIndex=row.supportStart;
			supportIndex<row.supportStart+row.supportCount;++supportIndex)
		{
			const AvbdRowSupport& support=mRowSupports[supportIndex];
			admission.add(support.weight,normal,
				avbdBlockSupportPoint(mBlocks[support.block],support,mBodies));
		}
		const double lower=avbdHeterogeneousAdmissionLower(row,admission.gap);
		if(!normal.isFinite() || !PxIsFinite(admission.gap) || !PxIsFinite(lower))
		{
			stationary=false; return 0.0f;
		}
		AvbdCoupledDomainConstraint constraint={};
		constraint.termStart=terms.size();
		// Preserve the absolute plane and spend its input interval once. In
		// particular, an admitted slightly negative gap has only the remaining
		// interval available, not a fresh tolerance measured from that pose.
		constraint.rhs=lower-admission.gap;
		constraint.tolerance=admission.tolerance(admission);
		for(PxU32 supportIndex=row.supportStart;
			supportIndex<row.supportStart+row.supportCount;++supportIndex)
		{
			const PxU32 blockIndex=mRowSupports[supportIndex].block;
			if(blockIndex>=participant.size() || !participant[blockIndex]) continue;
			bool duplicate=false;
			for(PxU32 previous=row.supportStart;previous<supportIndex;++previous)
				duplicate|=mRowSupports[previous].block==blockIndex;
			if(duplicate) continue;
			PxReal weight=0.0f;
			for(PxU32 merged=row.supportStart;
				merged<row.supportStart+row.supportCount;++merged)
				if(mRowSupports[merged].block==blockIndex)
					weight+=mRowSupports[merged].weight;
			if(!appendTerm(blockIndex,normal*weight))
			{
				stationary=false; return 0.0f;
			}
		}
		if(terms.size()>constraint.termStart) contactDomainIndices[rowIndex]=constraints.size();
		if(!finishConstraint(constraint))
		{
			stationary=false; return 0.0f;
		}
	}
	// The point OGC half-spaces are part of the same hard domain.  Volume
	// regions have no finite isotropic envelope; their exact live region is
	// still re-evaluated below before the atomic candidate is published.
	for(PxU32 blockIndex=0;blockIndex<mBlocks.size();++blockIndex)
	{
		if(!participant[blockIndex]) continue;
		const AvbdBlock& block=mBlocks[blockIndex];
		if(!block.ogcRegion || !block.particle) continue;
		const AvbdOgcPointRegion live=avbdOgcPointRegionAgainstCommittedRigid(
			*block.ogcRegion,mBodies,mIslandSoftCache);
		const PxVec3 currentOffset=block.particle->p-live.anchor;
		for(PxU32 planeIndex=0;planeIndex<live.planeCount;++planeIndex)
		{
			const AvbdOgcHalfSpace& plane=live.planes[planeIndex];
			AvbdCoupledDomainConstraint constraint={};
			constraint.termStart=terms.size();
			constraint.rhs=double(plane.n.dot(plane.partnerDelta))-plane.bound-
				double(plane.n.dot(currentOffset));
			constraint.tolerance=4.0*double(PX_EPS_F32)*double(
					plane.n.abs().dot(live.anchor.abs()+block.particle->p.abs()+
						plane.partnerDelta.abs())+PxAbs(plane.bound));
			if(!appendTerm(blockIndex,plane.n) || !finishConstraint(constraint))
			{
				stationary=false; return 0.0f;
			}
		}
	}
	// A rigid region can use an embedded soft triangle as its moving partner.
	// The rigid pose is fixed during this particle-only correction, but changing
	// that witness changes the rigid half-space by the opposite amount. Compile
	// this reciprocal condition into the same KKT program; checking it only at
	// final admission leaves a boundary rigid body outside the candidate domain
	// for every nonzero particle step.
	for(PxU32 bodyIndex=0;bodyIndex<mBodies.size();++bodyIndex)
	{
		const AvbdSolverBody& body=mBodies[bodyIndex];
		if(!body.ogcRegionValid) continue;
		const AvbdOgcRigidRegion& region=body.ogcRegion;
		const PxVec3 bodyOffset=body.p-region.anchorPosition;
		for(PxU32 planeIndex=0;planeIndex<region.planeCount;++planeIndex)
		{
			const AvbdOgcHalfSpace& plane=region.planes[planeIndex];
			if(plane.partnerCache>=mIslandSoftCache.size()) continue;
			const AvbdIslandSoftCache& cache=mIslandSoftCache[plane.partnerCache];
			if(!cache.particles || !cache.collisionPoints) continue;
			bool validWitness=true;
			for(PxU32 corner=0;corner<3;++corner)
				validWitness&=plane.partnerVertices[corner]<cache.nbCollisionParticles;
			if(!validWitness) continue;

			const PxVec3 rotationDelta=body.q.rotate(plane.selfLocalPoint)-
				region.anchorRotation.rotate(plane.selfLocalPoint);
			const PxVec3 partner=avbdOgcLivePartnerDelta(plane,mBodies,
				mIslandSoftCache)-rotationDelta;
			AvbdCoupledDomainConstraint constraint={};
			constraint.termStart=terms.size();
			constraint.rhs=double(plane.n.dot(partner))-plane.bound-
				double(plane.n.dot(bodyOffset));
			constraint.tolerance=4.0*double(PX_EPS_F32)*double(
				plane.n.abs().dot(region.anchorPosition.abs()+body.p.abs()+
					partner.abs())+PxAbs(plane.bound));

			PxU32 witnessBlocks[12];
			PxReal witnessWeights[12];
			PxU32 witnessBlockCount=0;
			for(PxU32 corner=0;corner<3;++corner)
			{
				const AvbdSoftEmbeddedPoint& point=
					cache.collisionPoints[plane.partnerVertices[corner]];
				for(PxU32 support=0;support<point.count;++support)
				{
					if(point.particleIndices[support]>=cache.nbParticles)
					{
						validWitness=false;
						break;
					}
					const PxU32 blockIndex=cache.blockStart+
						point.particleIndices[support];
					const PxReal weight=-plane.partnerWeights[corner]*
						point.weights[support];
					PxU32 merged=0;
					while(merged<witnessBlockCount &&
						witnessBlocks[merged]!=blockIndex) ++merged;
					if(merged==witnessBlockCount)
					{
						if(witnessBlockCount>=12) { validWitness=false; break; }
						witnessBlocks[witnessBlockCount]=blockIndex;
						witnessWeights[witnessBlockCount]=weight;
						++witnessBlockCount;
					}
					else
						witnessWeights[merged]+=weight;
				}
				if(!validWitness) break;
			}
			if(!validWitness) continue;
			bool hasParticipantWitness=false;
			for(PxU32 witness=0;witness<witnessBlockCount;++witness)
				hasParticipantWitness|=witnessBlocks[witness]<participant.size() &&
					participant[witnessBlocks[witness]];
			if(!hasParticipantWitness) continue;
			for(PxU32 witness=0;witness<witnessBlockCount;++witness)
				if(!appendTerm(witnessBlocks[witness],
					plane.n*witnessWeights[witness]))
				{
					stationary=false; return 0.0f;
				}
			if(!finishConstraint(constraint))
			{
				stationary=false; return 0.0f;
			}
		}
	}
	// det(F) is affine in one coordinate block but coupled across all four tet
	// vertices.  Its tangent therefore belongs in one four-block constraint;
	// exact nonlinear determinant admission remains the publication test.
	for(PxU32 cacheIndex=0;cacheIndex<mIslandSoftCache.size();++cacheIndex)
	{
		const AvbdIslandSoftCache& cache=mIslandSoftCache[cacheIndex];
		if(!cache.coupled || cache.liveStamp!=mIslandSoftLiveStamp ||
			!cache.volume) continue;
		if(!cache.particles || !cache.tets) { stationary=false; return 0.0f; }
		bool hasParticipant=false;
		for(PxU32 particleIndex=0;particleIndex<cache.nbParticles;++particleIndex)
		{
			const PxU32 blockIndex=cache.blockStart+particleIndex;
			hasParticipant|=blockIndex<participant.size() && participant[blockIndex];
		}
		if(!hasParticipant) continue;
		for(PxU32 tetIndex=0;tetIndex<cache.nbTets;++tetIndex)
		{
			const AvbdSoftTet& tet=cache.tets[tetIndex];
			const AvbdSoftTetDomain current=avbdSoftTetDomain(tet,0,cache.particles);
			if(!PxIsFinite(current.determinant)) { stationary=false; return 0.0f; }
			AvbdCoupledDomainConstraint constraint={};
			constraint.termStart=terms.size();
			constraint.rhs=double(PxMin(0.05f,current.determinant))-
				double(current.determinant);
			constraint.tolerance=8.0*double(PX_EPS_F32)*
					PxAbs(double(current.determinant));
			const PxU32 vertices[4]={tet.p0,tet.p1,tet.p2,tet.p3};
			for(PxU32 order=0;order<4;++order)
			{
				const PxU32 blockIndex=cache.blockStart+vertices[order];
				if(blockIndex>=mBlocks.size() || vertices[order]>=cache.nbParticles)
				{
					stationary=false; return 0.0f;
				}
				const AvbdSoftTetDomain domain=avbdSoftTetDomain(tet,order,
					cache.particles);
				if(!appendTerm(blockIndex,domain.gradient))
				{
					stationary=false; return 0.0f;
				}
			}
			if(!finishConstraint(constraint))
			{
				stationary=false; return 0.0f;
			}
		}
	}

	// Most compiled planes are far from the unconstrained solution.  Solving
	// all of them by multiplier coordinate ascent makes one sweep quadratic in
	// the mesh constraint count.  Grow the active program from actual
	// violations: after each solve, add every newly violated compiled plane and
	// restart from the same unconstrained step.  When no plane can be added,
	// the result is the KKT solution of the complete compiled domain.
	const PxArray<AvbdCoupledDomainBlock> unconstrainedBlocks(kktBlocks);
	PxArray<PxU8> activeMask;
	activeMask.resize(constraints.size());
	PxArray<AvbdCoupledDomainConstraint> activeConstraints;
	double maximumKktViolation=0.0;
	// The backend publishes PxReal states and every local/final admission uses
	// the corresponding float-input interval.  The coupled stationarity oracle
	// must solve that same domain: forcing an already admitted boundary state to
	// the ideal real-valued plane can produce a nonzero, energy-increasing
	// "repair" direction even though the representable zero step is feasible.
	bool useInputIntervals=true;
	const PxU32 conditionCount=constraints.size()+mTriangleClosureScratch.size();
	const PxU32 compiledTermCount=terms.size();
	const PxArray<PxU8> directionParticipants(participant);
	PxArray<double> publicationMargins(constraints.size(),0.0);
	PxArray<double> trianglePublicationMargins(mTriangleClosureScratch.size(),0.0);
	auto solveDirection=[&](bool forPublication)->bool
	{
	kktBlocks=unconstrainedBlocks;
	terms.resize(compiledTermCount);
	activeConstraints.clear();
	for(PxU32 i=0;i<activeMask.size();++i) activeMask[i]=0;
	for(PxU32 i=0;i<mTriangleClosureScratch.size();++i)
		if(mTriangleClosureScratch[i].state==2) mTriangleClosureScratch[i].state=1;
	for(PxU32 pass=0;pass<=conditionCount;++pass)
	{
		PxU32 added=0;
		// Query every certificate after each active solve, but materialize only
		// violated stencils. Fixed gradients retain the original support order;
		// inactive conditions allocate no metric responses or KKT term records.
		for(PxU32 index=0;index<mTriangleClosureScratch.size();++index)
		{
			TriangleClosureBounds& bounds=mTriangleClosureScratch[index];
			if(bounds.state!=1) continue;
			const double margin=forPublication ? trianglePublicationMargins[index] : 0.0;
			const PxU32 begin=mTriangleTermOffsets[index],end=mTriangleTermOffsets[index+1];
			double value=0.0;
			for(PxU32 t=begin;t<end;++t)
			{
				const TriangleFixedTerm& term=mTriangleFixedTerms[t];
				if(directionParticipants[term.block])
				{
					value+=avbdOgcDouble(term.gradient).dot(kktBlocks[term.block].step);
				}
			}
			const double scale=1.0+PxAbs(bounds.rhs)+PxAbs(value)+bounds.tolerance;
			if(!PxIsFinite(value)) { return false; }
			if(bounds.rhs+margin-value-bounds.tolerance<=256.0*DBL_EPSILON*scale) continue;
			AvbdCoupledDomainConstraint constraint={};
			constraint.termStart=terms.size();
			constraint.rhs=bounds.rhs+margin;constraint.tolerance=bounds.tolerance;
			for(PxU32 t=begin;t<end;++t)
			{
				const TriangleFixedTerm& fixed=mTriangleFixedTerms[t];
				if(!directionParticipants[fixed.block]) continue;
				PxVec3 response;
				if(!avbdSolve3(metrics[fixed.block],fixed.gradient,response) || !response.isFinite())
				{ return false; }
				AvbdCoupledDomainTerm term={fixed.block,avbdOgcDouble(fixed.gradient),avbdOgcDouble(response)};
				terms.pushBack(term);
			}
			constraint.termCount=terms.size()-constraint.termStart;
			activeConstraints.pushBack(constraint);
			bounds.state=2;++added;
		}
		for(PxU32 constraintIndex=0;constraintIndex<constraints.size();
			++constraintIndex)
		{
			if(activeMask[constraintIndex]) continue;
			AvbdCoupledDomainConstraint constraint=constraints[constraintIndex];
			if(forPublication) constraint.rhs+=publicationMargins[constraintIndex];
			double value=0.0;
			for(PxU32 termIndex=constraint.termStart;
				termIndex<constraint.termStart+constraint.termCount;++termIndex)
			{
				if(termIndex>=terms.size() || terms[termIndex].block>=kktBlocks.size())
				{
					return false;
				}
				value+=terms[termIndex].gradient.dot(
					kktBlocks[terms[termIndex].block].step);
			}
			const double inputTolerance=useInputIntervals ?
				constraint.tolerance : 0.0;
			const double scale=1.0+PxAbs(constraint.rhs)+PxAbs(value)+
				inputTolerance;
			if(!PxIsFinite(value) ||
				constraint.rhs-value-inputTolerance<=
					256.0*DBL_EPSILON*scale)
				continue;
			activeMask[constraintIndex]=1;
			for(PxU32 termIndex=constraint.termStart;
				termIndex<constraint.termStart+constraint.termCount;++termIndex)
			{
				AvbdCoupledDomainTerm& term=terms[termIndex];
				const PxVec3 gradient(PxReal(term.gradient.x),
					PxReal(term.gradient.y),PxReal(term.gradient.z));
				PxVec3 response;
				if(!avbdSolve3(metrics[term.block],gradient,response) ||
					!response.isFinite())
				{
					return false;
				}
				term.inverseMetricGradient=avbdOgcDouble(response);
			}
			activeConstraints.pushBack(constraint);
			++added;
		}
		if(!added) break;
		if(!avbdCoupledDomainPublicationScope(unconstrainedBlocks,activeConstraints,
			terms,correctionParticipant,kktBlocks))
		{ return false; }
		for(PxU32 i=0;i<activeConstraints.size();++i)
		{
			const AvbdCoupledDomainConstraint& c=activeConstraints[i];
			for(PxU32 j=c.termStart;j<c.termStart+c.termCount;++j)
			{
				AvbdCoupledDomainTerm& term=terms[j];
				if(!correctionParticipant[term.block])
				{ term.inverseMetricGradient=PxVec3d(0.0);continue; }
				if(term.inverseMetricGradient!=PxVec3d(0.0)) continue;
				PxVec3 response;
				if(!avbdSolve3(metrics[term.block],PxVec3(PxReal(term.gradient.x),
					PxReal(term.gradient.y),PxReal(term.gradient.z)),response) || !response.isFinite())
				{ return false; }
				term.inverseMetricGradient=avbdOgcDouble(response);
			}
		}
		const bool kktSolved=avbdSolveCoupledDomainKkt(kktBlocks,activeConstraints,
			terms,maximumKktViolation,useInputIntervals);
		if(!kktSolved)
		{
			return false;
		}
		if(pass==conditionCount)
		{
			return false;
		}
	}
	return true;
	};
	if(!solveDirection(false)) { stationary=false;return 0.0f; }
	// Seed a joint candidate with non-product constraints. A one-block hard
	// domain joins only after its ordinary in-place GS component has no
	// representable step above the closure threshold; this is the PxReal
	// coordinate-stall case, not a replacement for the default GS sweep.
	bool hasActiveNonProductDomain=false;
	for(PxU32 activeIndex=0;activeIndex<activeConstraints.size();++activeIndex)
		hasActiveNonProductDomain|=activeConstraints[activeIndex].termCount>=2;
	// A whole-volume simultaneous Newton residual is not the convergence
	// contract of fixed-budget AVBD.  It is needed only to detect the proven
	// coordinate-stall case: ordinary GS has stopped, while an active hard
	// domain couples more than one dynamic block.  Single-block OGC and a GS
	// map that is still moving keep their ordinary in-place schedule.
	if(!hasActiveNonProductDomain)
	{
		for(PxU32 blockIndex=0;blockIndex<participant.size();++blockIndex)
			participant[blockIndex]=0;
		stationary=!repairRequired;
		return 0.0f;
	}
	for(PxU32 activeIndex=0;activeIndex<activeConstraints.size();++activeIndex)
	{
		const AvbdCoupledDomainConstraint& constraint=activeConstraints[activeIndex];
		if(constraint.termCount<2) continue;
		for(PxU32 termIndex=constraint.termStart;
			termIndex<constraint.termStart+constraint.termCount;++termIndex)
		{
			if(termIndex>=terms.size() || terms[termIndex].block>=mBlocks.size())
			{
				stationary=false; return 0.0f;
			}
			const PxU32 blockIndex=terms[termIndex].block;
			correctionParticipant[blockIndex]=1;
		}
	}
	// Publish exactly the blocks joined by active non-product domain rows.
	// Expanding that set through every incident material tet reaches the whole
	// connected volume and turns this local closure into a simultaneous Jacobi
	// material update.  Besides violating the in-place GS schedule, that makes
	// the affine det(F) tangent non-conservative when many vertices of the same
	// tet move together.  Incident material blocks remain owned by the ordinary
	// Particle3 GS sweep; an active tet constraint already contributes all four
	// of its endpoints above.
	bool hasSharedDomain=false;
	for(PxU32 blockIndex=0;blockIndex<correctionParticipant.size();++blockIndex)
	{
		hasSharedDomain|=correctionParticipant[blockIndex]!=0;
		participant[blockIndex]=correctionParticipant[blockIndex];
	}
	const PxReal positionTolerance=PxMax(
		AVBD_ARTIC_POSITION_REL_TOL*getLengthScale(),1.0e-9f);
	PxReal maximumStep=0.0f,maximumUncorrectedStep=0.0f;
	double predictedDecrease=0.0;
	for(PxU32 blockIndex=0;blockIndex<mBlocks.size();++blockIndex)
	{
		if(!participant[blockIndex]) continue;
		const PxVec3 step(PxReal(kktBlocks[blockIndex].step.x),
			PxReal(kktBlocks[blockIndex].step.y),PxReal(kktBlocks[blockIndex].step.z));
		if(!step.isFinite()) { stationary=false; return 0.0f; }
		if(correctionParticipant[blockIndex])
		{
			maximumStep=PxMax(maximumStep,step.magnitude());
			predictedDecrease+=double(forces[blockIndex].dot(step));
		}
		else
			maximumUncorrectedStep=PxMax(maximumUncorrectedStep,step.magnitude());
	}
	PxReal maximumResidualStep=PxMax(maximumStep,maximumUncorrectedStep);
	if(maximumResidualStep<=positionTolerance && !repairRequired)
		return 0.0f;
	bool publishJointCorrection=hasSharedDomain &&
		(maximumStep>positionTolerance || repairRequired);
	if(!publishJointCorrection)
	{
		predictedDecrease=0.0;
		for(PxU32 blockIndex=0;blockIndex<mBlocks.size();++blockIndex)
			if(participant[blockIndex])
			{
				const PxVec3 step(PxReal(kktBlocks[blockIndex].step.x),
					PxReal(kktBlocks[blockIndex].step.y),
					PxReal(kktBlocks[blockIndex].step.z));
				predictedDecrease+=double(forces[blockIndex].dot(step));
			}
	}
	if(!PxIsFinite(predictedDecrease) || predictedDecrease<=0.0)
	{
		stationary=false; return 0.0f;
	}

	PxArray<AvbdSoftParticle> candidateParticles;
	PxArray<AvbdBlock> candidateBlocks(mBlocks);
	PxArray<AvbdIslandSoftCache> candidateCaches(mIslandSoftCache);
	candidateParticles.resize(mBlocks.size());
	for(PxU32 blockIndex=0;blockIndex<mBlocks.size();++blockIndex)
	{
		AvbdBlock& candidateBlock=candidateBlocks[blockIndex];
		if(candidateBlock.type!=eAVBD_BLOCK_PARTICLE3 || !candidateBlock.particle)
			continue;
		candidateParticles[blockIndex]=*candidateBlock.particle;
		candidateBlock.particle=&candidateParticles[blockIndex];
	}
	for(PxU32 cacheIndex=0;cacheIndex<candidateCaches.size();++cacheIndex)
		if(candidateCaches[cacheIndex].particles)
			candidateCaches[cacheIndex].particles=candidateParticles.begin()+
				candidateCaches[cacheIndex].blockStart;

	auto particleEnergyChange=[&]()->double
	{
		double change=0.0;
		for(PxU32 ci=0;ci<candidateCaches.size();++ci)
		{
			const AvbdIslandSoftCache& cache=candidateCaches[ci];
			const AvbdIslandSoftCache& old=mIslandSoftCache[ci];
			if(!cache.coupled || cache.liveStamp!=mIslandSoftLiveStamp || !cache.volume ||
				!cache.particles || !cache.tets || ci>=mSoftMaterialScratch.size()) continue;
			const AvbdSoftMaterial& material=mSoftMaterialScratch[ci];
			for(PxU32 i=0;i<cache.nbParticles;++i)
			{
				const PxVec3d delta=avbdOgcDouble(cache.particles[i].p)-avbdOgcDouble(old.particles[i].p);
				const PxVec3d residual=avbdOgcDouble(old.particles[i].p)-avbdOgcDouble(old.particles[i].pHat);
				change+=double(old.particles[i].mass*invH2)*delta.dot(residual+delta*0.5);
			}
			for(PxU32 ti=0;ti<cache.nbTets;++ti)
			{
				const AvbdSoftTet& tet=cache.tets[ti];
				const PxU32 ids[4]={tet.p0,tet.p1,tet.p2,tet.p3};
				PxVec3d p[4],d[4];bool changed=false;
				for(PxU32 i=0;i<4;++i)
				{ p[i]=avbdOgcDouble(old.particles[ids[i]].p);d[i]=avbdOgcDouble(cache.particles[ids[i]].p)-p[i];changed|=d[i]!=PxVec3d(0.0); }
				if(!changed) continue;
				if(material.coRotationalVolumeModel)
				{
					change+=avbdSoftTetEnergyAtVertex(tet,tet.p0,cache.particles[tet.p0].p,material,cache.particles)-
						avbdSoftTetEnergyAtVertex(tet,tet.p0,old.particles[tet.p0].p,material,old.particles);
					continue;
				}
				const PxMat33d inverse(avbdOgcDouble(tet.dmInv.column0),avbdOgcDouble(tet.dmInv.column1),avbdOgcDouble(tet.dmInv.column2));
				change+=avbdSoftNeoHookeanEnergyChange(PxMat33d(p[1]-p[0],p[2]-p[0],p[3]-p[0])*inverse,
					PxMat33d(d[1]-d[0],d[2]-d[0],d[3]-d[0])*inverse,material,tet.restVolume);
			}
			if(ci<mSoftPinCountScratch.size())
				for(PxU32 pi=0;pi<PxMin(mSoftPinCountScratch[ci],PxU32(AVBD_SOFT_MAX_WORLD_PINS));++pi)
				{
					const AvbdSoftWorldPin& pin=mSoftWorldPinScratch[ci*AVBD_SOFT_MAX_WORLD_PINS+pi];
					if(pin.vertex>=cache.nbParticles || !pin.k) continue;
					const PxVec3d delta=avbdOgcDouble(cache.particles[pin.vertex].p)-avbdOgcDouble(old.particles[pin.vertex].p);
					const PxVec3d residual=avbdOgcDouble(old.particles[pin.vertex].p)-avbdOgcDouble(pin.target);
					change+=double(PxMax(*pin.k,AVBD_SOFT_PIN_K_INIT))*delta.dot(residual+delta*0.5);
					if(pin.lambda) change+=avbdOgcDouble(*pin.lambda).dot(delta);
				}
		}
		for(PxU32 ri=0;ri<mRows.size();++ri)
		{
			const AvbdRow& row=mRows[ri];
			if(!row.supportCount || (row.flags&(eAVBD_ROW_CONTACT|eAVBD_ROW_HETEROGENEOUS|eAVBD_ROW_INACTIVE))!=
				(eAVBD_ROW_CONTACT|eAVBD_ROW_HETEROGENEOUS) || row.kernelId==eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN) continue;
			bool affected=false;
			for(PxU32 k=row.supportStart;k<row.supportStart+row.supportCount;++k)
			{
				const PxU32 block=mRowSupports[k].block;
				affected|=mBlocks[block].particle && candidateBlocks[block].particle &&
					mBlocks[block].particle->p!=candidateBlocks[block].particle->p;
			}
			if(!affected) continue;
			double gap,delta;
			if(row.kernelId==eAVBD_ROW_KERNEL_CONTACT_FRAME)
			{
				const auto before=avbdContactFrameRow(row,mRowSupports,mBlocks,mBodies,contactGeometry());
				const auto after=avbdContactFrameRow(row,mRowSupports,candidateBlocks,mBodies,contactGeometry());
				if(!before.valid || !after.valid) return PX_MAX_F64;
				gap=before.gap;delta=after.gap-before.gap;
			}
			else
			{
				gap=avbdHeterogeneousRowC(row,mRowSupports,mBlocks,mBodies,contactGeometry());
				const PxVec3d normal=avbdOgcDouble(avbdHeterogeneousNormal(row,mBodies,contactGeometry(),mRowSupports,mBlocks));
				delta=0.0;
				for(PxU32 k=row.supportStart;k<row.supportStart+row.supportCount;++k)
				{
					const AvbdRowSupport& support=mRowSupports[k];
					if(!mBlocks[support.block].particle || !candidateBlocks[support.block].particle) continue;
					delta+=double(support.weight)*normal.dot(avbdOgcDouble(candidateBlocks[support.block].particle->p)-
						avbdOgcDouble(mBlocks[support.block].particle->p));
				}
			}
			const bool al=avbdHeterogeneousPositionAl(row);
			change+=avbdUnilateralContactEnergyChange(gap,delta,al ? row.rho : row.contactStiffness,
				al ? row.lambda : 0.0f,row.minLambda);
		}
		return PxIsFinite(change) ? change : PX_MAX_F64;
	};

	PxU32 addedPublicationMargins=0;
	auto candidateAdmissible=[&]()->bool
	{
		for(PxU32 cacheIndex=0;cacheIndex<candidateCaches.size();++cacheIndex)
		{
			const AvbdIslandSoftCache& oldCache=mIslandSoftCache[cacheIndex];
			const AvbdIslandSoftCache& newCache=candidateCaches[cacheIndex];
			if(!newCache.coupled || newCache.liveStamp!=mIslandSoftLiveStamp ||
				!newCache.particles || !newCache.tets) continue;
			for(PxU32 tetIndex=0;tetIndex<newCache.nbTets;++tetIndex)
			{
				const AvbdSoftTet& tet=newCache.tets[tetIndex];
				const PxU32 vertices[4]={tet.p0,tet.p1,tet.p2,tet.p3};
				bool affected=false;
				for(PxU32 vertex=0;vertex<4;++vertex)
				{
					const PxU32 blockIndex=newCache.blockStart+vertices[vertex];
					affected|=blockIndex<candidateBlocks.size() &&
						candidateBlocks[blockIndex].particle &&
						mBlocks[blockIndex].particle &&
						candidateBlocks[blockIndex].particle->p!=
							mBlocks[blockIndex].particle->p;
				}
				if(!affected) continue;
				const PxReal oldDet=avbdSoftTetDomain(oldCache.tets[tetIndex],0,
					oldCache.particles).determinant;
				const PxReal newDet=avbdSoftTetDomain(newCache.tets[tetIndex],0,
					newCache.particles).determinant;
				const PxReal tolerance=4.0f*PX_EPS_F32*(PxAbs(oldDet)+PxAbs(newDet));
				if(!PxIsFinite(newDet) || newDet<PxMin(0.05f,oldDet)-tolerance)
					return false;
			}
		}
		for(PxU32 blockIndex=0;blockIndex<candidateBlocks.size();++blockIndex)
		{
			const AvbdBlock& block=candidateBlocks[blockIndex];
			if(block.type!=eAVBD_BLOCK_PARTICLE3 || !block.particle ||
				!block.ogcRegion || !mBlocks[blockIndex].particle ||
				block.particle->p==mBlocks[blockIndex].particle->p) continue;
			const AvbdOgcPointRegion live=avbdOgcPointRegionAgainstCommittedRigid(
				*block.ogcRegion,mBodies,candidateCaches);
			if(!avbdOgcPointContains(live,block.particle->p))
				return false;
		}
		for(PxU32 bodyIndex=0;bodyIndex<mBodies.size();++bodyIndex)
		{
			const AvbdSolverBody& body=mBodies[bodyIndex];
			if(!body.ogcRegionValid) continue;
			AvbdOgcRigidRegion live=body.ogcRegion;
			bool affected=false;
			for(PxU32 planeIndex=0;planeIndex<live.planeCount;++planeIndex)
			{
				const PxU32 cacheIndex=live.planes[planeIndex].partnerCache;
				if(cacheIndex<candidateCaches.size())
				{
					const AvbdIslandSoftCache& cache=candidateCaches[cacheIndex];
					for(PxU32 particleIndex=0;particleIndex<cache.nbParticles;++particleIndex)
					{
						const PxU32 blockIndex=cache.blockStart+particleIndex;
						affected|=blockIndex<candidateBlocks.size() &&
							candidateBlocks[blockIndex].particle &&
							mBlocks[blockIndex].particle &&
							candidateBlocks[blockIndex].particle->p!=
								mBlocks[blockIndex].particle->p;
					}
				}
				live.planes[planeIndex].partnerDelta=avbdOgcLivePartnerDelta(
					live.planes[planeIndex],mBodies,candidateCaches);
			}
			if(!affected) continue;
			if(!avbdOgcRigidContains(live,body.p,body.q))
				return false;
		}
		for(PxU32 rowIndex=0;rowIndex<mRows.size();++rowIndex)
		{
			const AvbdRow& row=mRows[rowIndex];
			bool affected=false;
			for(PxU32 supportIndex=row.supportStart;
				supportIndex<row.supportStart+row.supportCount;++supportIndex)
			{
				const PxU32 blockIndex=mRowSupports[supportIndex].block;
				affected|=blockIndex<candidateBlocks.size() &&
					candidateBlocks[blockIndex].particle &&
					mBlocks[blockIndex].particle &&
					candidateBlocks[blockIndex].particle->p!=
						mBlocks[blockIndex].particle->p;
			}
			if(!affected) continue;
			if(row.kernelId==eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN)
			{
				if(!row.geometryIndex || row.geometryIndex>mTriangleDomainGeometry.size())
					return false;
				AvbdOgcProjectionPlane planes[9];
				avbdCompileTriangleDomain(row,mTriangleDomainGeometry[row.geometryIndex-1],
					mRowSupports,candidateBlocks,mBodies,PX_MAX_U32,mKernels,planes);
				for(PxU32 planeIndex=0;planeIndex<9;++planeIndex)
					if(planes[planeIndex].b>planes[planeIndex].roundoff)
					{
						const PxU32 index=mTriangleStencilIndices[(row.geometryIndex-1)*9+planeIndex];
						if(trianglePublicationMargins[index]==0.0)
						{
							double margin=0.0;
							for(PxU32 j=mTriangleTermOffsets[index];j<mTriangleTermOffsets[index+1];++j)
							{
								const TriangleFixedTerm& t=mTriangleFixedTerms[j];
								if(correctionParticipant[t.block])
									margin+=avbdCoupledPublicationError(mBlocks[t.block].particle->p,
										kktBlocks[t.block].step,avbdOgcDouble(t.gradient));
							}
							if(margin>0.0) { trianglePublicationMargins[index]=margin;++addedPublicationMargins; }
						}
						return false;
					}
				continue;
			}
			if((row.flags&(eAVBD_ROW_CONTACT|eAVBD_ROW_INACTIVE))!=eAVBD_ROW_CONTACT ||
				!row.supportCount) continue;
			if(!avbdHeterogeneousCandidateAdmissible(row,mRowSupports,mBlocks,mBodies,
				candidateBlocks,mBodies,contactGeometry()))
			{
				const PxU32 index=contactDomainIndices[rowIndex];
				if(index<constraints.size() && publicationMargins[index]==0.0)
				{
					const AvbdCoupledDomainConstraint& c=constraints[index];
					double margin=0.0;
					for(PxU32 j=c.termStart;j<c.termStart+c.termCount;++j)
					{
						const AvbdCoupledDomainTerm& t=terms[j];
						if(correctionParticipant[t.block])
							margin+=avbdCoupledPublicationError(mBlocks[t.block].particle->p,
								kktBlocks[t.block].step,t.gradient);
					}
					if(margin>0.0) { publicationMargins[index]=margin;++addedPublicationMargins; }
				}
				return false;
			}
		}
		return true;
	};

	for(PxU32 direction=0;;++direction)
	{
		if(direction)
		{
			// The original KKT direction did not publish. Solve a conservative
			// numerical candidate in the same support program; its failure must
			// not certify stationarity of the larger, original domain.
			if(!solveDirection(true)) break;
			maximumStep=0.0f;predictedDecrease=0.0;
			for(PxU32 i=0;i<mBlocks.size();++i)
				if(correctionParticipant[i])
				{
					maximumStep=PxMax(maximumStep,PxReal(kktBlocks[i].step.magnitude()));
					predictedDecrease+=avbdOgcDouble(forces[i]).dot(kktBlocks[i].step);
				}
			if(!PxIsFinite(predictedDecrease) || predictedDecrease<=0.0) break;
			maximumResidualStep=maximumStep;publishJointCorrection=true;
		}
	addedPublicationMargins=0;
	const double currentEnergy=0.0;
	bool testedAdmissibleDescent=false;
	double bestCandidateEnergy=PX_MAX_F64;
	PxReal maximumEnergyLoweringStep=0.0f;
	for(PxU32 search=0;search<24;++search)
	{
		const PxReal fraction=PxPow(0.5f,PxReal(search));
		PxReal actualMaximumStep=0.0f;
		double actualPredictedDecrease=0.0;
		bool changed=false;
		for(PxU32 blockIndex=0;blockIndex<candidateBlocks.size();++blockIndex)
		{
			if(candidateBlocks[blockIndex].type!=eAVBD_BLOCK_PARTICLE3 ||
				!candidateBlocks[blockIndex].particle) continue;
			const PxVec3 original=mBlocks[blockIndex].particle->p;
			PxVec3 candidate=original;
			const bool trial=publishJointCorrection ?
				correctionParticipant[blockIndex]!=0 : participant[blockIndex]!=0;
			if(trial)
			{
				const PxVec3 step(PxReal(kktBlocks[blockIndex].step.x),
					PxReal(kktBlocks[blockIndex].step.y),PxReal(kktBlocks[blockIndex].step.z));
				candidate=original+step*fraction;
				const PxVec3 actualStep=candidate-original;
				changed|=candidate!=original;
				actualMaximumStep=PxMax(actualMaximumStep,actualStep.magnitude());
				actualPredictedDecrease+=double(forces[blockIndex].dot(actualStep));
			}
			candidateBlocks[blockIndex].particle->p=candidate;
		}
		if(!changed) break;
		if(actualPredictedDecrease<=0.0)
			continue;
		if(!candidateAdmissible())
			continue;
		const double candidateEnergy=particleEnergyChange();
		if(candidateEnergy==PX_MAX_F64)
			continue;
		testedAdmissibleDescent=true;
		bestCandidateEnergy=PxMin(bestCandidateEnergy,candidateEnergy);
		if(candidateEnergy<currentEnergy)
			maximumEnergyLoweringStep=PxMax(maximumEnergyLoweringStep,
				actualMaximumStep);
		if(candidateEnergy<currentEnergy-1.0e-4*actualPredictedDecrease)
		{
			if(!publishJointCorrection)
			{
				// This direction proves the in-place GS state is not stationary,
				// but publishing it would turn the ordinary Volume program into a
				// full-cache Jacobi update.  Retain it as a read-only residual.
				stationary=false;
				return maximumResidualStep/positionTolerance;
			}
			for(PxU32 blockIndex=0;blockIndex<mBlocks.size();++blockIndex)
				if(correctionParticipant[blockIndex])
				{
					if(mBlocks[blockIndex].particle->p!=candidateBlocks[blockIndex].particle->p)
						mPrimalChangedIteration[blockIndex]=mStep.iteration+1;
					mBlocks[blockIndex].particle->p=
						candidateBlocks[blockIndex].particle->p;
				}
			const PxReal residualStep=PxMax(actualMaximumStep,
				maximumUncorrectedStep);
			// The active joint domain has been resolved: this representable
			// candidate satisfies the complete nonlinear admission program and
			// lowers the same energy used by the primal blocks.  residualStep is
			// retained for the fixed-budget progress measure; it is not evidence
			// that the admitted joint descent was infeasible.
			stationary=true;
			repairResolved=true;
			return residualStep/positionTolerance;
		}
	}
	// The backend state is stored in PxReal.  Once dyadic backtracking reaches
	// an unchanged float state, a non-descending ray or one whose every
	// energy-lowering sample is below the block closure resolution is
	// numerically stationary.  A resolved descent or a required repair must
	// still satisfy the full nonlinear domain and Armijo program.
	if(direction==0 && !repairRequired && testedAdmissibleDescent &&
		(bestCandidateEnergy>=currentEnergy ||
			maximumEnergyLoweringStep<=positionTolerance))
	{
		if(!publishJointCorrection)
		{
			return 0.0f;
		}
		// Every energy-lowering sample on the feasible KKT ray is below the same
		// Particle3 closure resolution used by the block map.  Larger samples all
		// failed exact admission or Armijo descent, so there is no publishable
		// descent at this PxReal state.  This is numerical stationarity even when
		// unrelated fixed-budget Volume modes still have a larger residual.
		stationary=true;
		return maximumUncorrectedStep/positionTolerance;
	}
		if(!addedPublicationMargins) break;
	}
	stationary=false;
	return 0.0f;
}

void AvbdDynamicsContext::compileBlockColors()
{
	AvbdBlockColoring graph;
	PxArray<PxU8> writable(mBlocks.size(), 0);
	PxArray<PxU32> order;
	for (PxU32 i = 0; i < mBlocks.size(); ++i)
	{
		const AvbdBlock &block = mBlocks[i];
		writable[i] = block.type == eAVBD_BLOCK_RIGID6 ? (mBodies[block.objectIndex].invMass > 0.0f &&
		                                                  !mBodies[block.objectIndex].isKinematic)
		                                               : (block.particle && block.particle->invMass > 0.0f);
	}
    mRigidGroups.clear();mRigidGroupRoots.clear();mRigidGroupRows.clear();mRigidGroupSharedRows.clear();mRigidGroupFactorOffsets.clear();
    mRigidGroupFactorOffsets.pushBack(0);
    bool grouped=false;
    if(!mTetrahedronMaterials.empty() || !mElasticFrameMaterials.empty())
    {
        mRigidGroups.resize(mBodies.size());mRigidGroupRoots.resize(mBodies.size());
        for(PxU32 i=0;i<mBodies.size();++i)
        { mRigidGroupRoots[i]=i;AvbdRigidGroup g={};g.blocks[0]=i;g.count=1;mRigidGroups[i]=g; }
        PxArray<PxU8> assigned(mBodies.size(),0);
        // Prefer larger bounded material supports, then fill remaining pairs.
        // This is an algebraic write-set partition, independent of geometry.
        for(PxU32 arity=4;arity>=2;--arity) for(PxU32 r=0;r<mRows.size();++r)
        {
            const AvbdRow& row=mRows[r];
            if(row.kernelId!=eAVBD_ROW_KERNEL_TETRAHEDRON && row.kernelId!=eAVBD_ROW_KERNEL_ELASTIC_FRAME) continue;
            AvbdRigidGroup group={};bool available=true;
            mRowProgram.forEachBlock(r,[&](PxU32 b)
            {
                if(b>=mBodies.size() || !writable[b]) return;
                if(assigned[b]) available=false;
                if(group.count<4) group.blocks[group.count++]=b;else available=false;
            });
            if(!available || group.count!=arity) continue;
            const PxU32 root=group.blocks[0];
            for(PxU32 s=0;s<group.count;++s)
            { assigned[group.blocks[s]]=1;mRigidGroupRoots[group.blocks[s]]=root;mRigidGroups[group.blocks[s]].count=0; }
            mRigidGroups[root]=group;grouped=true;
        }
        for(PxU32 i=0;i<mRigidGroups.size();++i)
        {
            AvbdRigidGroup& group=mRigidGroups[i];if(group.count<2) continue;
            PxArray<PxU32> rows;
            for(PxU32 s=0;s<group.count;++s)
                for(PxU32 j=mRowProgram.blockOffsets[group.blocks[s]];j<mRowProgram.blockOffsets[group.blocks[s]+1];++j)
                    rows.pushBack(mRowProgram.blockRows[j]);
            if(rows.size()>1) std::sort(rows.begin(),rows.end());
            group.rowStart=mRigidGroupRows.size();
            group.sharedStart=mRigidGroupSharedRows.size();
            for(PxU32 r=0;r<rows.size();++r) if(!r || rows[r]!=rows[r-1])
            {
                AvbdRigidGroupRow entry={rows[r],i,0};
                mRowProgram.forEachBlock(entry.row,[&](PxU32 block)
                {
                    for(PxU32 s=0;s<group.count;++s) if(group.blocks[s]==block)
                    { if(!entry.supportCount) entry.representative=block;++entry.supportCount; }
                });
                mRigidGroupRows.pushBack(entry);
                if(entry.supportCount>1)
                {
                    mRigidGroupSharedRows.pushBack(entry.row);
                    const AvbdRow& row=mRows[entry.row];
                    const PxU32 rank=row.kernelId==eAVBD_ROW_KERNEL_ELASTIC_FRAME?9:
                        ((row.flags&eAVBD_ROW_CONTACT) && row.positionTangent && row.mu>0?3:1);
                    mRigidGroupFactorOffsets.pushBack(mRigidGroupFactorOffsets.back()+rank);
                }
            }
            group.rowCount=mRigidGroupRows.size()-group.rowStart;
            group.sharedCount=mRigidGroupSharedRows.size()-group.sharedStart;
        }
    }
    auto rootOf=[&](PxU32 block) { return block<mRigidGroupRoots.size() ? mRigidGroupRoots[block] : block; };
    auto addScope=[&](const PxU32* ids,PxU32 count)
    {
        if(!grouped) { graph.addScope(ids,count,writable);return; }
        PxArray<PxU32> mapped;
        for(PxU32 i=0;i<count;++i) if(ids[i]<writable.size() && writable[ids[i]]) mapped.pushBack(rootOf(ids[i]));
        if(mapped.size()>1) std::sort(mapped.begin(),mapped.end());
        PxU32 distinct=0;for(PxU32 i=0;i<mapped.size();++i) if(!i || mapped[i]!=mapped[i-1]) mapped[distinct++]=mapped[i];
        graph.addScope(mapped.begin(),distinct,writable);
    };
	// Compile one deterministic color program for single-thread and task execution.
	// Finite elastic objectives need no historical hard-joint conflict order.
	// Derive that execution property from the actual 1D row program, without
	// recognizing joint classes or adding a separate softbody schedule.
	PxArray<PxU8> jointPrograms(mBodies.size(), 0);
	for(PxU32 i = mContactRowCount; i < mRows.size(); ++i)
	{
		const AvbdRow& row = mRows[i];
		const PxU8 property =
			(row.flags & (eAVBD_ROW_DRIVE | eAVBD_ROW_INACTIVE)) == eAVBD_ROW_DRIVE ? 1 : 2;
		mRowProgram.forEachBlock(i, [&](PxU32 block)
		{
			if(mBlocks[block].type == eAVBD_BLOCK_RIGID6)
				jointPrograms[mBlocks[block].objectIndex] |= property;
		});
	}
	for(PxU32 i=0;i<mBodies.size();++i)
		jointPrograms[rootOf(i)] |= jointPrograms[i];
	PxU32 reorderableCount = 0;
	for (PxU32 kind = 0; kind < 3; ++kind)
		for (PxU32 i = 0; i < mBlocks.size(); ++i)
		{
			const AvbdBlock& block = mBlocks[i];
			const PxU32 blockKind = block.type != eAVBD_BLOCK_RIGID6 ? 0 :
				(jointPrograms[block.objectIndex] == 1 ? 1 : 2);
			if (writable[i] && rootOf(i)==i && blockKind == kind)
			{
				order.pushBack(i);
				if (kind < 2) ++reorderableCount;
			}
		}
    if(!grouped) graph.addProgram(mRowProgram);
    else
        for(PxU32 r=0;r<mRows.size();++r)
            addScope(mRowProgram.rowBlocks.begin()+mRowProgram.rowOffsets[r],mRowProgram.rowOffsets[r+1]-mRowProgram.rowOffsets[r]);
	for (PxU32 c = 0; c < mIslandSoftCache.size(); ++c)
	{
		const AvbdIslandSoftCache &cache = mIslandSoftCache[c];
		if (!cache.coupled || cache.liveStamp != mIslandSoftLiveStamp)
			continue;
		graph.addAdjacency(cache.materialNeighborOffsets, cache.materialNeighbors,
			cache.blockStart, cache.nbParticles);
	}
	for (PxU32 c = 0; c < mIslandSurfaceCache.size(); ++c)
	{
		const AvbdIslandSurfaceCache &cache = mIslandSurfaceCache[c];
		if (cache.liveStamp != mIslandSurfaceLiveStamp)
			continue;
		for (PxU32 t = 0; t < cache.nbTriangles; ++t)
		{
			const AvbdSoftTri &tri = cache.triangles[t];
			const PxU32 ids[3] = {cache.blockStart + tri.p0, cache.blockStart + tri.p1,
			                      cache.blockStart + tri.p2};
			addScope(ids,3);
		}
		for (PxU32 t = 0; t < cache.nbBends; ++t)
		{
			const AvbdSoftBending &bend = cache.bends[t];
			const PxU32 ids[4] = {cache.blockStart + bend.opp0, cache.blockStart + bend.opp1,
			                      cache.blockStart + bend.edgeStart, cache.blockStart + bend.edgeEnd};
			addScope(ids,4);
		}
	}
	auto partner = [&](PxU32 block, const AvbdOgcHalfSpace &plane)
	{
		if (plane.partnerBody < mBodies.size())
		{
			const PxU32 ids[2] = {block, plane.partnerBody};
			addScope(ids,2);
		}
		else if (plane.partnerCache < mIslandSoftCache.size())
		{
			const AvbdIslandSoftCache &cache = mIslandSoftCache[plane.partnerCache];
			if (!cache.particles || !cache.collisionPoints)
				return;
			for (PxU32 v = 0; v < 3; ++v)
			{
				if (plane.partnerVertices[v] >= cache.nbCollisionParticles)
					continue;
				const AvbdSoftEmbeddedPoint &point = cache.collisionPoints[plane.partnerVertices[v]];
				for (PxU32 k = 0; k < point.count; ++k)
				{
					const PxU32 ids[2] = {block, cache.blockStart + point.particleIndices[k]};
					addScope(ids,2);
				}
			}
		}
	};
	for (PxU32 i = 0; i < mBlocks.size(); ++i)
	{
		const AvbdBlock &block = mBlocks[i];
		if (block.type == eAVBD_BLOCK_RIGID6)
		{
			const AvbdSolverBody &body = mBodies[block.objectIndex];
			if (body.ogcRegionValid)
				for (PxU32 p = 0; p < body.ogcRegion.planeCount; ++p)
					partner(i, body.ogcRegion.planes[p]);
		}
		else if (block.ogcRegion)
			for (PxU32 p = 0; p < block.ogcRegion->planeCount; ++p)
				partner(i, block.ogcRegion->planes[p]);
	}
	graph.build(order, mBlocks.size(), mColorOffsets, mColorBlocks, reorderableCount);
}

void AvbdDynamicsContext::compileTrianglePointIncidence()
{
 for(PxU32 i=0;i<mTrianglePoints.size();++i)
 {
  AvbdAffinePointEvaluation& point=mTrianglePoints[i];point.absoluteWeight=0.0;
  for(PxU32 j=0;j<point.supportCount;++j)
   point.absoluteWeight+=PxAbs(double(mRowSupports[point.supportStart+j].weight));
 }
 // Geometry certificates have no energy/dual. Compile the objective view
 // once instead of scanning thousands of certificate rows per line search.
 mBlockObjectiveOffsets.resize(mBlocks.size()+1);mBlockObjectiveRows.clear();
 for(PxU32 block=0;block<mBlocks.size();++block)
 {
  mBlockObjectiveOffsets[block]=mBlockObjectiveRows.size();
  for(PxU32 ref=mRowProgram.blockOffsets[block];ref<mRowProgram.blockOffsets[block+1];++ref)
   if(mRows[mRowProgram.blockRows[ref]].kernelId!=eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN)
    mBlockObjectiveRows.pushBack(mRowProgram.blockRows[ref]);
 }
 mBlockObjectiveOffsets.back()=mBlockObjectiveRows.size();

 // Factor repeated point/normal evaluations across the complete certificate
 // program. This index owns no physical state and is rebuilt with incidence.
 struct ProjectionRef { PxU32 point,geometry,corner; PxVec3 normal; };
 PxArray<ProjectionRef> projections;
 for(PxU32 g=0;g<mTriangleDomainGeometry.size();++g)
  for(PxU32 corner=0;corner<6;++corner)
  {
   const AvbdTriangleDomainGeometry& geometry=mTriangleDomainGeometry[g];
   ProjectionRef ref={geometry.pointIndices[corner],g,corner,geometry.normal};
   projections.pushBack(ref);
  }
 PxSort(projections.begin(),projections.size(),[](const ProjectionRef& a,const ProjectionRef& b)->bool
 {
  if(a.point!=b.point) return a.point<b.point;
  if(a.normal.x!=b.normal.x) return a.normal.x<b.normal.x;
  if(a.normal.y!=b.normal.y) return a.normal.y<b.normal.y;
  return a.normal.z<b.normal.z;
 });
 mTriangleProjections.clear();
 mTrianglePointProjectionOffsets.resize(mTrianglePoints.size()+1);
 for(PxU32 i=0;i<mTrianglePointProjectionOffsets.size();++i) mTrianglePointProjectionOffsets[i]=0;
 for(PxU32 i=0;i<projections.size();++i)
 {
  const ProjectionRef& ref=projections[i];
  if(i==0 || ref.point!=projections[i-1].point || ref.normal!=projections[i-1].normal)
  {
   AvbdTrianglePointProjection value={ref.normal,ref.point,0.0,0.0};
   mTriangleProjections.pushBack(value);
   ++mTrianglePointProjectionOffsets[ref.point+1];
  }
  mTriangleDomainGeometry[ref.geometry].projectionIndices[ref.corner]=mTriangleProjections.size()-1;
 }
 for(PxU32 i=1;i<mTrianglePointProjectionOffsets.size();++i)
  mTrianglePointProjectionOffsets[i]+=mTrianglePointProjectionOffsets[i-1];
 // Embedding coefficients are fixed for the whole DCD epoch, even though
 // point positions and input scales must follow every committed GS update.
 mBlockTriangleCoefficients.resize(mRowProgram.blockRows.size());
 mBlockTriangleProjection.resize(mBlocks.size());
 for(PxU32 block=0;block<mBlocks.size();++block)
 {
  mBlockTriangleProjection[block].compiled=false;
  mBlockTriangleProjection[block].normals.clear();
  for(PxU32 ref=mRowProgram.blockOffsets[block];ref<mRowProgram.blockOffsets[block+1];++ref)
  {
   const AvbdRow& row=mRows[mRowProgram.blockRows[ref]];
   if(row.kernelId!=eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN) continue;
   const AvbdTriangleDomainGeometry& geometry=mTriangleDomainGeometry[row.geometryIndex-1];
   PxU32 start=row.supportStart;
   for(PxU32 point=0;point<6;++point)
   {
    double weight=0.0,absoluteWeight=0.0;
    const PxU32 end=row.supportStart+geometry.supportEnds[point];
    for(;start<end;++start)
     if(mRowSupports[start].block==block)
     { weight+=double(mRowSupports[start].weight);absoluteWeight+=PxAbs(double(mRowSupports[start].weight)); }
    mBlockTriangleCoefficients[ref].weights[point]=weight;
    mBlockTriangleCoefficients[ref].absoluteWeights[point]=absoluteWeight;
   }
  }
 }
 // Equal plane payloads can prove the union of many row products with
 // one factorized point-set query. A non-product union is conservatively
 // enlarged only for screening; uncertain batches retain every original row.
 mTriangleBatches.clear();mTriangleBatchPoints.clear();mTriangleBatchRows.clear();
 mBlockTriangleBatchOffsets.resize(mBlocks.size()+1);
 PxArray<PxU32> batchRows;
 struct BatchPoint { AvbdTriangleProjectionRef ref; PxU32 side; };
 PxArray<BatchPoint> batchPoints;
 auto geometryAt=[&](PxU32 ref)->const AvbdTriangleDomainGeometry&
 { return mTriangleDomainGeometry[mRows[mRowProgram.blockRows[ref]].geometryIndex-1]; };
 for(PxU32 block=0;block<mBlocks.size();++block)
 {
  mBlockTriangleBatchOffsets[block]=mTriangleBatches.size();batchRows.clear();
  for(PxU32 ref=mRowProgram.blockOffsets[block];ref<mRowProgram.blockOffsets[block+1];++ref)
   if(mRows[mRowProgram.blockRows[ref]].kernelId==eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN) batchRows.pushBack(ref);
  PxSort(batchRows.begin(),batchRows.size(),[&](PxU32 a,PxU32 b)->bool
  {
   const AvbdTriangleDomainGeometry& x=geometryAt(a);const AvbdTriangleDomainGeometry& y=geometryAt(b);
   if(x.normal.x!=y.normal.x) return x.normal.x<y.normal.x;
   if(x.normal.y!=y.normal.y) return x.normal.y<y.normal.y;
   if(x.normal.z!=y.normal.z) return x.normal.z<y.normal.z;
   if(x.lowerGap!=y.lowerGap) return x.lowerGap<y.lowerGap;
   return a<b;
  });
  for(PxU32 begin=0;begin<batchRows.size();)
  {
   const AvbdTriangleDomainGeometry& first=geometryAt(batchRows[begin]);
   PxU32 end=begin+1;
   while(end<batchRows.size() && geometryAt(batchRows[end]).normal==first.normal &&
    geometryAt(batchRows[end]).lowerGap==first.lowerGap) ++end;
   TriangleBlockBatch batch={mRows[mRowProgram.blockRows[batchRows[begin]]].geometryIndex-1,
    mTriangleBatchPoints.size(),0,0,mTriangleBatchRows.size(),end-begin};
   batchPoints.clear();
   for(PxU32 r=begin;r<end;++r)
   {
    const PxU32 ref=batchRows[r];mTriangleBatchRows.pushBack(ref);
    const AvbdTriangleDomainGeometry& geometry=geometryAt(ref);
    for(PxU32 i=0;i<6;++i)
    {
     BatchPoint point={{geometry.projectionIndices[i],mBlockTriangleCoefficients[ref].weights[i],
      mBlockTriangleCoefficients[ref].absoluteWeights[i]},i/3};
     batchPoints.pushBack(point);
    }
   }
   PxSort(batchPoints.begin(),batchPoints.size(),[](const BatchPoint& a,const BatchPoint& b)->bool
   { return a.side!=b.side ? a.side<b.side : a.ref.projection<b.ref.projection; });
   for(PxU32 i=0;i<batchPoints.size();++i)
    if(i==0 || batchPoints[i].side!=batchPoints[i-1].side ||
     batchPoints[i].ref.projection!=batchPoints[i-1].ref.projection)
    {
     mTriangleBatchPoints.pushBack(batchPoints[i].ref);++batch.count;
     if(batchPoints[i].side==0) ++batch.countA;
    }
   mTriangleBatches.pushBack(batch);begin=end;
  }
 }
 mBlockTriangleBatchOffsets.back()=mTriangleBatches.size();
 mTriangleFixedTerms.clear();
 mTriangleTermOffsets.clear();
 mTriangleStencilIndices.resize(mTriangleDomainGeometry.size()*9);
 PxHashMap<PxU64,PxU32> stencilIndices;
 PxArray<PxU32> blocks,refs;
 for(PxU32 rowIndex=0;rowIndex<mRows.size();++rowIndex)
 {
  const AvbdRow& row=mRows[rowIndex];
  if(row.kernelId!=eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN) continue;
  const AvbdTriangleDomainGeometry& geometry=mTriangleDomainGeometry[row.geometryIndex-1];
  blocks.clear();refs.clear();
  for(PxU32 s=row.supportStart;s<row.supportStart+row.supportCount;++s)
  {
   const PxU32 block=mRowSupports[s].block;
   bool duplicate=false;
   for(PxU32 previous=row.supportStart;previous<s;++previous) duplicate|=mRowSupports[previous].block==block;
   if(duplicate) continue;
   PxU32 lo=mRowProgram.blockOffsets[block],hi=mRowProgram.blockOffsets[block+1];
   while(lo<hi)
   {
    const PxU32 mid=lo+(hi-lo)/2;
    if(mRowProgram.blockRows[mid]<rowIndex) lo=mid+1;else hi=mid;
   }
   if(lo==mRowProgram.blockOffsets[block+1] || mRowProgram.blockRows[lo]!=rowIndex)
   { PxAtomicExchange(&mLocalDomainFailed,1);return; }
   blocks.pushBack(block);refs.pushBack(lo);
  }
  for(PxU32 plane=0;plane<9;++plane)
  {
   // A directed pair of shared point/normal projections defines one affine
   // gradient stencil, even when many triangle rows reference that pair.
   const PxU64 key=(PxU64(geometry.projectionIndices[plane/3])<<32)|
    PxU64(geometry.projectionIndices[plane%3+3]);
   const auto* found=stencilIndices.find(key);
   if(found)
   {
    mTriangleStencilIndices[(row.geometryIndex-1)*9+plane]=found->second;
    continue;
   }
   const PxU32 stencil=mTriangleTermOffsets.size();
   stencilIndices.insert(key,stencil);
   mTriangleStencilIndices[(row.geometryIndex-1)*9+plane]=stencil;
   mTriangleTermOffsets.pushBack(mTriangleFixedTerms.size());
   for(PxU32 i=0;i<blocks.size();++i)
   {
    const PxVec3d coefficient=avbdTriangleDomainCoefficient(avbdOgcDouble(geometry.normal),
     mBlockTriangleCoefficients[refs[i]].weights,plane/3,plane%3+3);
    if(coefficient.magnitudeSquared()<=1.0e-30) continue;
    const PxVec3 gradient(PxReal(coefficient.x),PxReal(coefficient.y),PxReal(coefficient.z));
    if(!gradient.isFinite()) { PxAtomicExchange(&mLocalDomainFailed,1);return; }
    if(gradient.magnitudeSquared()<=1.0e-30f) continue;
    TriangleFixedTerm term={blocks[i],gradient};mTriangleFixedTerms.pushBack(term);
   }
  }
 }
 mTriangleTermOffsets.pushBack(mTriangleFixedTerms.size());
 mBlockTrianglePointOffsets.resize(mBlocks.size()+1);
 for(PxU32 i=0;i<mBlockTrianglePointOffsets.size();++i) mBlockTrianglePointOffsets[i]=0;
 for(PxU32 i=0;i<mTrianglePoints.size();++i)
 {
  const AvbdAffinePointEvaluation& point=mTrianglePoints[i];
  for(PxU32 j=0;j<point.supportCount;++j)
   ++mBlockTrianglePointOffsets[mRowSupports[point.supportStart+j].block+1];
 }
 for(PxU32 i=1;i<mBlockTrianglePointOffsets.size();++i)
  mBlockTrianglePointOffsets[i]+=mBlockTrianglePointOffsets[i-1];
 mBlockTrianglePoints.resize(mBlockTrianglePointOffsets.back());
 PxArray<PxU32> cursors(mBlockTrianglePointOffsets);
 for(PxU32 i=0;i<mTrianglePoints.size();++i)
 {
  const AvbdAffinePointEvaluation& point=mTrianglePoints[i];
  for(PxU32 j=0;j<point.supportCount;++j)
   mBlockTrianglePoints[cursors[mRowSupports[point.supportStart+j].block]++]=i;
 }
}

void AvbdDynamicsContext::refreshTrianglePoint(PxU32 index)
{
 AvbdAffinePointEvaluation& point=mTrianglePoints[index];
 avbdEvaluateAffinePoint(mRowSupports.begin()+point.supportStart,point.supportCount,
  [&](const AvbdRowSupport& support)
  { return avbdBlockSupportPoint(mBlocks[support.block],support,mBodies); },point);
 for(PxU32 i=mTrianglePointProjectionOffsets[index];i<mTrianglePointProjectionOffsets[index+1];++i)
 {
  AvbdTrianglePointProjection& projection=mTriangleProjections[i];
  const PxVec3d normal=avbdOgcDouble(projection.normal);
  projection.value=normal.dot(point.point);
  projection.scale=normal.abs().dot(point.scale);
 }
}

void AvbdDynamicsContext::observeTriangleMotion(PxU32 block)
{
 if(!mBlocks[block].particle || block>=mTriangleSnapshotPositions.size()) return;
 const PxVec3d delta=avbdOgcDouble(mBlocks[block].particle->p)-avbdOgcDouble(mTriangleSnapshotPositions[block]);
 const double distance=PxMax(PxAbs(delta.x),PxMax(PxAbs(delta.y),PxAbs(delta.z)));
 PxReal upper=PxReal(distance);
 if(double(upper)<distance) upper=std::nextafter(upper,PX_MAX_F32);
 if(!PxIsFinite(upper)) upper=PX_MAX_F32;
 PxAtomicMax(&mTriangleMotionBits,PxUnionCast<PxI32,PxReal>(upper));
}

void AvbdDynamicsContext::refreshBlockTrianglePoints(PxU32 block)
{
 observeTriangleMotion(block);
 // Every cached point is read through a row containing all its supports.
 // The existing row conflict scope therefore orders every writer and reader,
 // including two writers of the same point. No read-side lazy writes occur.
 for(PxU32 i=mBlockTrianglePointOffsets[block];i<mBlockTrianglePointOffsets[block+1];++i)
  refreshTrianglePoint(mBlockTrianglePoints[i]);
}

void AvbdDynamicsContext::preparePrimalSweep()
{
	// Includes any accepted warmstart or joint-domain commit since the last sweep.
	for(PxU32 i=0;i<mTrianglePoints.size();++i) refreshTrianglePoint(i);
	if(mStep.iteration==0)
	{
		mTriangleSnapshotPositions.resize(mBlocks.size());mTriangleMotionBits=0;
		for(PxU32 i=0;i<mBlocks.size();++i)
			if(mBlocks[i].particle) mTriangleSnapshotPositions[i]=mBlocks[i].particle->p;
		for(PxU32 i=0;i<mTriangleBatches.size();++i)
		{
			TriangleBlockBatch& batch=mTriangleBatches[i];
			const AvbdTriangleDomainGeometry& geometry=mTriangleDomainGeometry[batch.geometry];
			double minimum=DBL_MAX,maximum=-DBL_MAX,scale[2]={},weight[2]={},local[2]={};
			bool valid=true;
			for(PxU32 j=0;j<batch.count;++j)
			{
				const AvbdTriangleProjectionRef& ref=mTriangleBatchPoints[batch.pointStart+j];
				const AvbdTrianglePointProjection& projection=mTriangleProjections[ref.projection];
				const PxU32 side=j<batch.countA ? 0 : 1;
				const double value=projection.value+(side ? -1.0 : 1.0)*4.0*FLT_EPSILON*projection.scale;
				valid &= PxIsFinite(value) && PxIsFinite(projection.scale);
				if(side) maximum=PxMax(maximum,value);else minimum=PxMin(minimum,value);
				scale[side]=PxMax(scale[side],projection.scale);
				weight[side]=PxMax(weight[side],mTrianglePoints[projection.pointIndex].absoluteWeight);
				local[side]=PxMax(local[side],ref.absoluteWeight);
			}
			const double norm=PxAbs(double(geometry.normal.x))+PxAbs(double(geometry.normal.y))+PxAbs(double(geometry.normal.z));
			batch.bound.gap=valid ? minimum-maximum-double(geometry.lowerGap)+4.0*FLT_EPSILON*PxAbs(double(geometry.lowerGap)) : -DBL_MAX;
			batch.bound.scale=scale[0]+scale[1]+PxAbs(double(geometry.lowerGap));
			batch.bound.motionCoefficient=norm*(weight[0]+weight[1]);
			batch.bound.localCoefficient=norm*(local[0]+local[1]);
		}
	}
	else for(PxU32 i=0;i<mBlocks.size();++i) observeTriangleMotion(i);
	const PxU32 cacheCount = mIslandSoftCache.size();
	PxArray<AvbdSoftMaterial> &materials = mSoftMaterialScratch;
	PxArray<PxU32> &pinCounts = mSoftPinCountScratch;
	PxArray<AvbdSoftWorldPin> &pins = mSoftWorldPinScratch;
	materials.resize(cacheCount);
	pinCounts.resize(cacheCount);
	pins.resize(cacheCount * AVBD_SOFT_MAX_WORLD_PINS);
	for (PxU32 cacheIndex = 0; cacheIndex < cacheCount; ++cacheIndex)
	{
		AvbdIslandSoftCache &cache = mIslandSoftCache[cacheIndex];
		pinCounts[cacheIndex] = 0;
		if (!cache.coupled || cache.liveStamp != mIslandSoftLiveStamp)
			continue;
		if (!cache.volume || !cache.particles || !cache.tets)
			continue;
		AvbdSoftWorldPin *cachePins = pins.begin() + cacheIndex * AVBD_SOFT_MAX_WORLD_PINS;
		pinCounts[cacheIndex] = packCpuWorldPins(*cache.volume, cachePins, AVBD_SOFT_MAX_WORLD_PINS);
		const DeformableVolumeCore &core = cache.volume->getCore();
		materials[cacheIndex] = avbdSoftLameFromYoungPoisson(
		    core.cpuYoungs, PxClamp(core.cpuPoissons, 0.0f, 0.499f),
		    core.cpuMaterialModel == PxDeformableVolumeMaterialModel::eCO_ROTATIONAL);
	}

	mPrimalSteps.resize(mBlocks.size());
	mPrimalRepairSeeds.resize(mBlocks.size());
	if(mStep.iteration==0)
	{
		mPrimalIdleIteration.clear();mPrimalIdleIteration.resize(mBlocks.size(),0);
		mPrimalChangedIteration.clear();mPrimalChangedIteration.resize(mBlocks.size(),0);
		mPrimalIdleSkips.clear();mPrimalIdleSkips.resize(mBlocks.size(),0);
	}
	for (PxU32 i = 0; i < mBlocks.size(); ++i)
	{
		mPrimalSteps[i] = 0.0f;
		mPrimalRepairSeeds[i] = 0;
	}
}

void AvbdDynamicsContext::solveBoundedBatch(PxU32 begin,PxU32 end)
{
    PxAtomicMax(&mPeakPrimalTasks,PxAtomicIncrement(&mActivePrimalTasks));
    AvbdBoundedBatchArgs args={mBoundedResponse,begin,end,false};
    mKernels.launch(AVBD_BOUNDED_BATCH,&args);
    if(!args.executed)PxAtomicExchange(&mLocalDomainFailed,1);
    PxAtomicDecrement(&mActivePrimalTasks);
}

bool AvbdDynamicsContext::dispatchBoundedWave()
{
    auto& response=*mBoundedResponse;
    if(mBoundedCursor==response.count())
    {response.advance();++mStep.boundedWaves;mBoundedCursor=0;return true;}
    const PxU32 width=AvbdBoundedResponse::BatchWidth;
    const PxU32 remaining=(response.count()-mBoundedCursor+width-1)/width;
    // Fixed ranges, including the helping caller. No worker drains a queue.
    // Limit both a numerical job and this fan-out to an input-independent cap.
    const PxU32 count=PxMin(remaining,PxMin(width,PxMax(PxU32(1),mStep.workers)));
    if(mStep.continuation && count>1)
    {
        mStep.boundedBatches+=count;
        if(!mColorContinuation)mColorContinuation=PX_NEW(AvbdAdvanceTask)(*this,mContextID);
        auto* next=mColorContinuation;next->setContinuation(*mStep.continuation->getTaskManager(),NULL);
        while(mBlockTasks.size()+1<count)mBlockTasks.pushBack(PX_NEW(AvbdBlockSolveTask)(*this,mContextID));
        for(PxU32 i=0;i+1<count;++i)
        {
            auto* task=mBlockTasks[i];task->bounded=true;task->begin=mBoundedCursor;
            task->end=PxMin(mBoundedCursor+width,response.count());mBoundedCursor=task->end;
            task->setContinuation(next);++mStep.submittedTasks;task->removeReference();
        }
        const PxU32 begin=mBoundedCursor;mBoundedCursor=PxMin(begin+width,response.count());
        solveBoundedBatch(begin,mBoundedCursor);
        return next->completeInline();
    }
    const PxU32 begin=mBoundedCursor;mBoundedCursor=PxMin(begin+width,response.count());
    ++mStep.boundedBatches;
    solveBoundedBatch(begin,mBoundedCursor);return true;
}

void AvbdDynamicsContext::solvePrimalBatch()
{
	PxAtomicMax(&mPeakPrimalTasks, PxAtomicIncrement(&mActivePrimalTasks));
	for (;;)
	{
		const PxU32 index = PxU32(PxAtomicIncrement(&mColorCursor) - 1);
		if (index >= mColorEnd)
			break;
		solvePrimalBlock(mColorBlocks[index]);
	}
	PxAtomicDecrement(&mActivePrimalTasks);
}

void AvbdDynamicsContext::solvePrimalBlock(PxU32 blockIndex)
{
	const PxReal invH2 = mDt > 0.0f ? 1.0f / (mDt * mDt) : 3600.0f;
	const PxU32 cacheCount = mIslandSoftCache.size();
	const PxArray<AvbdSoftMaterial> &materials = mSoftMaterialScratch;
	const PxArray<PxU32> &pinCounts = mSoftPinCountScratch;
	PxArray<AvbdSoftWorldPin> &pins = mSoftWorldPinScratch;
	const PxReal particleStepScale = 1.0f / PxMax(AVBD_ARTIC_POSITION_REL_TOL * getLengthScale(), 1.0e-9f);
	bool repairRequired = false;
	const AvbdBlock &block = mBlocks[blockIndex];
	if (block.type == eAVBD_BLOCK_RIGID6)
	{
        if(block.objectIndex<mRigidGroups.size() && mRigidGroups[block.objectIndex].count>1)
        {
            const AvbdRigidGroup& group=mRigidGroups[block.objectIndex];
            if(solvePrimalRigidGroup(block.objectIndex,invH2)) return;
            for(PxU32 s=0;s<group.count;++s)
            {
                const PxU32 b=group.blocks[s];const PxVec3 before=mBodies[b].p;const PxQuat rotation=mBodies[b].q;
                mPrimalSteps[b]=solvePrimalRigidBlock(b,invH2);
                if(mBodies[b].p!=before || !(mBodies[b].q==rotation)) mPrimalChangedIteration[b]=mStep.iteration+1;
            }
            return;
        }
		if (block.objectIndex < mBodies.size())
		{
			const PxVec3 before=mBodies[block.objectIndex].p;
			const PxQuat rotation=mBodies[block.objectIndex].q;
			const PxReal step = solvePrimalRigidBlock(block.objectIndex, invH2);
			mPrimalSteps[blockIndex] = step;
			if(mBodies[block.objectIndex].p!=before || !(mBodies[block.objectIndex].q==rotation))
				mPrimalChangedIteration[blockIndex]=mStep.iteration+1;
		}
		return;
	}
	if (block.type != eAVBD_BLOCK_PARTICLE3)
		return;
	const PxVec3 before=block.particle->p;
	if (block.particleKernel == eAVBD_PARTICLE_KERNEL_TRIANGLE)
	{
		if (block.objectIndex < mIslandSurfaceCache.size())
		{
			const PxReal particleStep =
			    solveSurfaceParticlePrimal(mIslandSurfaceCache[block.objectIndex], block.stateIndex, invH2);
			mPrimalSteps[blockIndex] = particleStep * particleStepScale;
			if(block.particle->p!=before)
			{
				mPrimalChangedIteration[blockIndex]=mStep.iteration+1;
				refreshBlockTrianglePoints(blockIndex);
			}
		}
		return;
	}
	if (block.particleKernel != eAVBD_PARTICLE_KERNEL_TET || block.objectIndex >= cacheCount)
		return;
	AvbdIslandSoftCache &cache = mIslandSoftCache[block.objectIndex];
	if (!cache.volume || !cache.particles || !cache.tets || block.stateIndex >= cache.nbParticles)
		return;
	AvbdSoftWorldPin *cachePins = pins.begin() + block.objectIndex * AVBD_SOFT_MAX_WORLD_PINS;
	// A zero unconstrained float step remains zero while its objective inputs
	// are unchanged. Read dependencies include incident tets and every physical
	// row support. AL and pin coordinates always reevaluate their changing duals.
	// Hard geometry can only restrict this zero proposal, not create a local
	// descent. It remains covered by the unchanged joint-domain closure.
	const PxU32 idle=mPrimalIdleIteration[blockIndex];
	if(idle && !pinCounts[block.objectIndex] && cache.incidentTetOffsets)
	{
		bool unchanged=mPrimalChangedIteration[blockIndex]<idle;
		for(PxU32 ref=mBlockObjectiveOffsets[blockIndex];
			ref<mBlockObjectiveOffsets[blockIndex+1] && unchanged;++ref)
		{
			const AvbdRow& row=mRows[mBlockObjectiveRows[ref]];
			unchanged &= (row.flags&(eAVBD_ROW_CONTACT|eAVBD_ROW_HETEROGENEOUS))==
				(eAVBD_ROW_CONTACT|eAVBD_ROW_HETEROGENEOUS) && !avbdHeterogeneousPositionAl(row);
			if(row.bodyA<mBodies.size()) unchanged &= mPrimalChangedIteration[row.bodyA]<idle;
			if(row.bodyB<mBodies.size()) unchanged &= mPrimalChangedIteration[row.bodyB]<idle;
			for(PxU32 k=row.supportStart;k<row.supportStart+row.supportCount && unchanged;++k)
				unchanged &= mPrimalChangedIteration[mRowSupports[k].block]<idle;
		}
		for(PxU32 ref=cache.incidentTetOffsets[block.stateIndex];
			ref<cache.incidentTetOffsets[block.stateIndex+1] && unchanged;++ref)
		{
			const AvbdSoftTet& tet=cache.tets[cache.incidentTetIndices[ref]];
			const PxU32 vertices[4]={tet.p0,tet.p1,tet.p2,tet.p3};
			for(PxU32 i=0;i<4;++i)
				unchanged &= mPrimalChangedIteration[cache.blockStart+vertices[i]]<idle;
		}
		if(unchanged) { ++mPrimalIdleSkips[blockIndex];return; }
	}
	mPrimalIdleIteration[blockIndex]=0;
	const PxReal particleStep =
	    solveVolumeParticlePrimal(cache, block.stateIndex, materials[block.objectIndex], invH2, cachePins,
	                              pinCounts[block.objectIndex], repairRequired, mPrimalRepairSeeds);
	mPrimalSteps[blockIndex] = particleStep * particleStepScale;
	if (repairRequired)
		mPrimalRepairSeeds[blockIndex] = 1;
	if(block.particle->p!=before)
	{
		mPrimalChangedIteration[blockIndex]=mStep.iteration+1;
		refreshBlockTrianglePoints(blockIndex);
	}
}

PxReal AvbdDynamicsContext::finishPrimalSweep(bool *coupledDomainStationary)
{
	const PxU32 cacheCount = mIslandSoftCache.size();
	const PxArray<PxU32> &pinCounts = mSoftPinCountScratch;
	PxArray<AvbdSoftWorldPin> &pins = mSoftWorldPinScratch;
	AvbdSoftGroundParams ground;
	ground.planeY = 0.0f;
	ground.contactRadius = mOgc.contactRadius;
	ground.kInit = mOgc.contactStiffness;
	ground.kMax = 1.0e6f;
	ground.beta = 1000.0f;
	if (!mStep.hasParticleBlocks)
	{
		PxReal step = 0.0f;
		for (PxU32 i = 0; i < mPrimalSteps.size(); ++i)
			step = PxMax(step, mPrimalSteps[i]);
		*coupledDomainStationary = true;
		return step;
	}
	bool coupledRepairRequired = false;
	for (PxU32 i = 0; i < mPrimalRepairSeeds.size(); ++i)
		coupledRepairRequired |= mPrimalRepairSeeds[i] != 0;

	// A shared hard domain can make the coordinate GS map cycle before its
	// individual block steps become small.  Apply the row-driven Schur/KKT
	// correction after every GS sweep so joint closure can break that cycle;
	// the GS sweep remains the primary in-place primal schedule.
	bool jointStationary = true;
	bool coupledRepairResolved = !coupledRepairRequired;
	PxArray<PxU8> jointParticipants;
	const PxReal coupledStep =
	    solveCoupledParticleDomainPrimal(jointStationary, coupledRepairRequired, coupledRepairResolved,
	                                     jointParticipants, mPrimalSteps, mPrimalRepairSeeds);
	if (coupledRepairRequired && !coupledRepairResolved)
		jointStationary = false;
	PxReal maximumNormalizedStep = coupledStep;
	// A covered Particle3 block may take a large coordinate GS step and then be
	// returned by the atomic joint correction to the same constrained optimum.
	// Its final projected residual is the KKT certificate above.  Local steps
	// remain the closure measure for every block outside that joint program.
	for (PxU32 blockIndex = 0; blockIndex < mPrimalSteps.size(); ++blockIndex)
	{
		if (blockIndex < jointParticipants.size() && jointParticipants[blockIndex])
			continue;
		maximumNormalizedStep = PxMax(maximumNormalizedStep, mPrimalSteps[blockIndex]);
	}
	if (coupledDomainStationary)
		*coupledDomainStationary = jointStationary;

	for (PxU32 cacheIndex = 0; cacheIndex < cacheCount; ++cacheIndex)
	{
		AvbdIslandSoftCache &cache = mIslandSoftCache[cacheIndex];
		if (!cache.coupled || cache.liveStamp != mIslandSoftLiveStamp || !cache.volume || !cache.particles ||
		    !cache.tets)
			continue;
		AvbdSoftWorldPin *cachePins = pins.begin() + cacheIndex * AVBD_SOFT_MAX_WORLD_PINS;
		// OGC contact is an energy assembled in both incident block Hessians.  Only
		// authored pins retain an AL dual in this local volume program.
		avbdSoftApplyDualContacts(cache.particles, cache.nbParticles, ground, NULL, 0, cachePins,
		                          pinCounts[cacheIndex], 0, false);
	}
	return maximumNormalizedStep;
}

void AvbdDynamicsContext::prepareDeformableVelocities(PxReal dt)
{
	for(PxU32 i = 0; i < mIslandSoftCache.size(); ++i)
	{
		AvbdIslandSoftCache& cache = mIslandSoftCache[i];
		if(!cache.coupled || cache.liveStamp != mIslandSoftLiveStamp ||
			!cache.volume || !cache.particles)
			continue;
		avbdSoftWriteback(cache.particles, cache.nbParticles, dt);
		const DeformableVolumeCore& core = cache.volume->getCore();
		const PxReal damping = PxMax(
			core.linearDamping + core.cpuElasticityDamping, 0.0f);
		const PxReal dampingScale = 1.0f / (1.0f + damping * dt);
		for(PxU32 particleIndex = 0; particleIndex < cache.nbParticles;
			++particleIndex)
			cache.particles[particleIndex].vel *= dampingScale;
	}
	for(PxU32 i = 0; i < mIslandSurfaceCache.size(); ++i)
	{
		AvbdIslandSurfaceCache& cache = mIslandSurfaceCache[i];
		if(cache.liveStamp != mIslandSurfaceLiveStamp || !cache.surface ||
			!cache.particles)
			continue;
		avbdSoftWriteback(cache.particles, cache.nbParticles, dt);
		const PxReal damping = PxMax(cache.surface->getCore().linearDamping, 0.0f);
		const PxReal dampingScale = 1.0f / (1.0f + damping * dt);
		for(PxU32 particleIndex = 0; particleIndex < cache.nbParticles;
			++particleIndex)
			cache.particles[particleIndex].vel *= dampingScale;
	}
}

void AvbdDynamicsContext::finalizeDeformableBlocks(PxReal dt)
{
	PX_UNUSED(dt);
	for(PxU32 i = 0; i < mIslandSoftCache.size(); ++i)
	{
		AvbdIslandSoftCache& cache = mIslandSoftCache[i];
		if(cache.coupled && cache.liveStamp == mIslandSoftLiveStamp)
			publishIslandSoftCache(cache);
	}
	for(PxU32 cacheIndex = 0; cacheIndex < mIslandSurfaceCache.size(); ++cacheIndex)
	{
		AvbdIslandSurfaceCache& cache = mIslandSurfaceCache[cacheIndex];
		if(cache.liveStamp != mIslandSurfaceLiveStamp || !cache.surface ||
			!cache.particles)
			continue;
		DeformableSurfaceCore& core = cache.surface->getCore();
		if(!core.positionInvMass || !core.velocity)
			continue;
		for(PxU32 particleIndex = 0; particleIndex < cache.nbParticles;
			++particleIndex)
		{
			const AvbdSoftParticle& particle = cache.particles[particleIndex];
			core.positionInvMass[particleIndex] = PxVec4(particle.p,
				particle.invMass);
			core.velocity[particleIndex] = PxVec4(particle.vel, particle.invMass);
		}
		core.dirtyFlags = PxDeformableSurfaceDataFlags(
			PxDeformableSurfaceDataFlag::ePOSITION_INVMASS);
		core.dirtyFlags |= PxDeformableSurfaceDataFlag::eVELOCITY;
		core.cpuAvbdWakeRequested = false;
	}
	pruneIslandSoftCache();
	pruneIslandSurfaceCache();
}

void AvbdDynamicsContext::prepareIslandDeformableVolumes(PxReal dt, const PxVec3& gravity)
{
	const IG::IslandSim& islandSim = mIslandManager.getAccurateIslandSim();
	const PxU32 nbNodes = islandSim.getNbActiveNodes(IG::Node::eDEFORMABLE_VOLUME_TYPE);
	const PxNodeIndex* nodeIds = islandSim.getActiveNodes(IG::Node::eDEFORMABLE_VOLUME_TYPE);
	++mIslandSoftLiveStamp;
	if(mIslandSoftLiveStamp == 0)
		++mIslandSoftLiveStamp;

	AvbdSoftGroundParams ground;
	ground.planeY = 0.0f;
	ground.contactRadius = mOgc.contactRadius;
	ground.kInit = mOgc.contactStiffness;
	ground.kMax = 1.0e6f;
	ground.beta = 1000.0f;
	for(PxU32 n = 0; n < nbNodes; ++n)
	{
		DeformableVolume* vol = static_cast<DeformableVolume*>(islandSim.getNode(nodeIds[n]).mObject);
		if(!vol)
			continue;
		PxTetrahedronMesh* simMesh = vol->getSimulationMesh();
		DeformableVolumeCore& core = vol->getCore();
		if(!simMesh || !core.simPositionInvMass || !core.simVelocity)
			continue;

		const PxU32 nbParticles = simMesh->getNbVertices();
		const PxU32 nbTetsIn = simMesh->getNbTetrahedrons();
		if(nbParticles == 0 || nbTetsIn == 0)
			continue;

		AvbdIslandSoftCache* cache = getIslandSoftCache(vol);
		if(!cache)
		{
			AvbdIslandSoftCache fresh;
			PxMemZero(&fresh, sizeof(fresh));
			fresh.volume = vol;
			fresh.nbParticles = nbParticles;
			fresh.tets = reinterpret_cast<AvbdSoftTet*>(
				PX_ALLOC(sizeof(AvbdSoftTet) * nbTetsIn, "AvbdIslandSoftCache::tets"));
			fresh.particles = reinterpret_cast<AvbdSoftParticle*>(
				PX_ALLOC(sizeof(AvbdSoftParticle) * nbParticles, "AvbdIslandSoftCache::particles"));
			fresh.ogcRegions = avbdOgcCreatePointRegions(nbParticles);
			fresh.ogcExceeded = reinterpret_cast<PxU8*>(
				PX_ALLOC(sizeof(PxU8) * nbParticles,
					"AvbdIslandSoftCache::ogcExceeded"));
			fresh.contactK = reinterpret_cast<PxReal*>(
				PX_ALLOC(sizeof(PxReal) * nbParticles, "AvbdIslandSoftCache::contactK"));
			fresh.contactLambda = reinterpret_cast<PxReal*>(
				PX_ALLOC(sizeof(PxReal) * nbParticles, "AvbdIslandSoftCache::contactLambda"));
			fresh.boxContactK = reinterpret_cast<PxReal*>(
				PX_ALLOC(sizeof(PxReal) * nbParticles * AVBD_SOFT_MAX_STATIC_BOXES,
					"AvbdIslandSoftCache::boxContactK"));
			fresh.boxContactLambda = reinterpret_cast<PxReal*>(
				PX_ALLOC(sizeof(PxReal) * nbParticles * AVBD_SOFT_MAX_STATIC_BOXES,
					"AvbdIslandSoftCache::boxContactLambda"));
			void* featureContactMemory = PX_ALLOC(sizeof(AvbdVolumeBoxFeatureContactArray),
				"AvbdIslandSoftCache::boxFeatureContacts");
			fresh.boxFeatureContacts = featureContactMemory ? PX_PLACEMENT_NEW(
				featureContactMemory, AvbdVolumeBoxFeatureContactArray) : NULL;
			if(!fresh.tets || !fresh.particles || !fresh.ogcRegions ||
				!fresh.ogcExceeded || !fresh.contactK || !fresh.contactLambda ||
				!fresh.boxContactK ||
				!fresh.boxContactLambda || !fresh.boxFeatureContacts)
			{
				avbdFreeIslandSoftBlocks(fresh);
				continue;
			}
			for(PxU32 i = 0; i < nbParticles; ++i)
			{
				fresh.contactK[i] = ground.kInit;
				fresh.contactLambda[i] = 0.0f;
				for(PxU32 b = 0; b < AVBD_SOFT_MAX_STATIC_BOXES; ++b)
				{
					fresh.boxContactK[i * AVBD_SOFT_MAX_STATIC_BOXES + b] = 1.0e5f;
					fresh.boxContactLambda[i * AVBD_SOFT_MAX_STATIC_BOXES + b] = 0.0f;
				}
			}

			for(PxU32 i = 0; i < nbParticles; ++i)
			{
				const PxVec4 pv = core.simPositionInvMass[i];
				AvbdSoftParticle& p = fresh.particles[i];
				p.p = pv.getXYZ();
				p.pHat = p.p;
				p.pStart = p.p;
				p.vel = PxVec3(0.0f);
				p.mass = 1.0f;
				p.invMass = 1.0f;
				p.contactK = ground.kInit;
				p.contactLambda = 0.0f;
				for(PxU32 b = 0; b < AVBD_SOFT_MAX_STATIC_BOXES; ++b)
				{
					p.boxContactK[b] = 1.0e5f;
					p.boxContactLambda[b] = 0.0f;
				}
			}

			PxU32 nbTets = 0;
			for(PxU32 t = 0; t < nbTetsIn; ++t)
			{
				PxU32 idx[4];
				if(!avbdReadTetIndices(*simMesh, t, idx))
					continue;
				if(idx[0] >= nbParticles || idx[1] >= nbParticles ||
					idx[2] >= nbParticles || idx[3] >= nbParticles)
					continue;
				if(avbdSoftBuildTet(fresh.tets[nbTets], idx[0], idx[1], idx[2], idx[3],
					fresh.particles))
					++nbTets;
			}
			if(nbTets == 0)
			{
				avbdFreeIslandSoftBlocks(fresh);
				continue;
			}
			fresh.nbTets = nbTets;
			// Reuse only topology belonging to an already visited live actor. Mesh
			// and auxiliary identities are valid for this step; rest operators stay
			// instance-local because transform/scale/deformation may differ.
			const AvbdIslandSoftCache* topology = NULL;
			for(PxU32 other=0; other<mIslandSoftCache.size() && !topology; ++other)
			{
				const AvbdIslandSoftCache& candidate=mIslandSoftCache[other];
				if(candidate.liveStamp!=mIslandSoftLiveStamp || !candidate.volume ||
					candidate.nbParticles!=nbParticles || candidate.nbTets!=nbTets ||
					candidate.volume->getSimulationMesh()!=simMesh ||
					candidate.volume->getCollisionMesh()!=vol->getCollisionMesh() ||
					candidate.volume->getAuxData()!=vol->getAuxData()) continue;
				bool equal=true;
				for(PxU32 t=0; t<nbTets && equal; ++t)
				{
					const AvbdSoftTet& a=fresh.tets[t]; const AvbdSoftTet& b=candidate.tets[t];
					equal=a.p0==b.p0 && a.p1==b.p1 && a.p2==b.p2 && a.p3==b.p3;
				}
				if(equal) topology=&candidate;
			}
			if(topology)
			{
				fresh.topologyReferences=topology->topologyReferences;
				++*fresh.topologyReferences;
				fresh.incidentTetOffsets=topology->incidentTetOffsets;
				fresh.incidentTetIndices=topology->incidentTetIndices;
				fresh.incidentTetCorners=topology->incidentTetCorners;
				fresh.materialNeighborOffsets=topology->materialNeighborOffsets;
				fresh.materialNeighbors=topology->materialNeighbors;
				fresh.collisionPoints=topology->collisionPoints;
				fresh.collisionTets=topology->collisionTets;
				fresh.boundaryFaces=topology->boundaryFaces;
				fresh.boundaryEdges=topology->boundaryEdges;
				fresh.boundaryVertices=topology->boundaryVertices;
				fresh.incidentBoundaryFaceOffsets=topology->incidentBoundaryFaceOffsets;
				fresh.incidentBoundaryFaceIndices=topology->incidentBoundaryFaceIndices;
				fresh.nbCollisionParticles=topology->nbCollisionParticles;
				fresh.nbCollisionTets=topology->nbCollisionTets;
				fresh.nbBoundaryFaces=topology->nbBoundaryFaces;
				fresh.nbBoundaryEdges=topology->nbBoundaryEdges;
			}
			else
			{
				fresh.topologyReferences = reinterpret_cast<PxU32*>(PX_ALLOC(
					sizeof(PxU32), "AvbdSoftTopology::references"));
				if(fresh.topologyReferences) *fresh.topologyReferences=1;
			}
			if(!fresh.topologyReferences || (!topology &&
				(!avbdBuildTetIncidence(fresh) || !avbdBuildCollisionTopology(fresh, *vol, *simMesh))))
			{
				avbdFreeIslandSoftBlocks(fresh);
				continue;
			}
			mIslandSoftCache.pushBack(fresh);
			cache = &mIslandSoftCache[mIslandSoftCache.size() - 1];
		}
		if(!cache->particles)
		{
			cache->particles = reinterpret_cast<AvbdSoftParticle*>(
				PX_ALLOC(sizeof(AvbdSoftParticle) * nbParticles, "AvbdIslandSoftCache::particles"));
			if(!cache->particles)
				continue;
		}
		cache->liveStamp = mIslandSoftLiveStamp;

		for(PxU32 i = 0; i < nbParticles; ++i)
		{
			const PxVec4 pv = core.simPositionInvMass[i];
			const PxVec4 vv = core.simVelocity[i];
			AvbdSoftParticle& p = cache->particles[i];
			p.p = pv.getXYZ();
			p.pHat = p.p;
			p.pStart = p.p;
			p.vel = vv.getXYZ();
			const PxReal invMass = pv.w;
			p.invMass = invMass;
			p.mass = (invMass > 1.0e-8f) ? (1.0f / invMass) : 0.0f;
			p.contactK = cache->contactK[i];
			p.contactLambda = cache->contactLambda[i];
			for(PxU32 b = 0; b < AVBD_SOFT_MAX_STATIC_BOXES; ++b)
			{
				p.boxContactK[b] = cache->boxContactK[i * AVBD_SOFT_MAX_STATIC_BOXES + b];
				p.boxContactLambda[b] = cache->boxContactLambda ?
					cache->boxContactLambda[i * AVBD_SOFT_MAX_STATIC_BOXES + b] : 0.0f;
			}
		}

		const PxU32 nDyn = vol->getNbCpuDynamicBoxes();
		const DeformableVolume::CpuDynamicBox* hostDyn = vol->getCpuDynamicBoxes();
		for(PxU32 d = 0; d < nDyn; ++d)
		{
			PxsBodyCore* bodyCore = hostDyn[d].bodyCore;
			if(!bodyCore || bodyCore->isKinematic() || bodyCore->inverseMass == 0.0f)
				continue;
			AvbdSoftStaticBox sdfBox;
			avbdFillHostDynSdfBox(sdfBox, hostDyn[d], NULL, mOgc.contactRadius);
			bool touch = avbdParticlesTouchBox(cache->particles, nbParticles, sdfBox);
			if(!touch)
			{
				PxTetrahedronMesh* collisionMesh = vol->getCollisionMesh();
				const PxVec4* collision = core.positionInvMass;
				const PxU32 nbCollision = (collisionMesh && collision) ?
					collisionMesh->getNbVertices() : 0;
				touch = avbdPointsTouchBox(collision, nbCollision, sdfBox);
			}
			if(touch && bodyCore->wakeCounter <= 0.0f)
				bodyCore->wakeCounter = AVBD_SOFT_RIGID_WAKE_COUNTER;
		}
		// A Host overlap is enough to enter the coupled feature program. Contact
		// activity is decided from collision-boundary features below; simulation
		// particles are not a valid proxy for collision-surface overlap.
		// Every island deformable is a set of particle blocks in the shared
		// backend.  "Coupled" is an execution ownership bit, not a contact-
		// presence classification; selecting the standalone soft step when no
		// explicit pair exists creates a second primal/dual/writeback pipeline.
		cache->coupled = 1;

		PxVec3 g = gravity;
		if(core.actorFlags & PxActorFlag::eDISABLE_GRAVITY)
			g = PxVec3(0.0f);

		avbdSoftPredict(cache->particles, nbParticles, g, dt);
	}

	if(!anyCoupledDeformableVolume())
		pruneIslandSoftCache();
}

namespace
{
bool avbdBuildSurfaceEdgeTopology(AvbdIslandSurfaceCache& cache)
{
	cache.edges = reinterpret_cast<AvbdSoftBoundaryEdgeTopology*>(PX_ALLOC(
		sizeof(AvbdSoftBoundaryEdgeTopology) * 3 * cache.nbTriangles,
		"AvbdIslandSurfaceCache::edges"));
	if(!cache.edges) return false;
	cache.nbEdges = 0;
	for(PxU32 triangleIndex = 0; triangleIndex < cache.nbTriangles; ++triangleIndex)
	{
		const AvbdSoftTri& triangle = cache.triangles[triangleIndex];
		const PxU32 vertices[3] = {triangle.p0, triangle.p1, triangle.p2};
		for(PxU32 corner = 0; corner < 3; ++corner)
		{
			PxU32 v0 = vertices[corner], v1 = vertices[(corner + 1) % 3];
			if(v0 > v1) PxSwap(v0, v1);
			PxU32 edgeIndex = PX_MAX_U32;
			for(PxU32 existing = 0; existing < cache.nbEdges; ++existing)
				if(cache.edges[existing].v0 == v0 && cache.edges[existing].v1 == v1)
				{ edgeIndex = existing; break; }
			if(edgeIndex == PX_MAX_U32)
			{
				AvbdSoftBoundaryEdgeTopology& edge = cache.edges[cache.nbEdges++];
				edge.v0 = v0; edge.v1 = v1;
				edge.face0 = triangleIndex; edge.face1 = PX_MAX_U32;
			}
			else if(cache.edges[edgeIndex].face1 == PX_MAX_U32)
				cache.edges[edgeIndex].face1 = triangleIndex;
		}
	}
	cache.bends = reinterpret_cast<AvbdSoftBending*>(PX_ALLOC(
		sizeof(AvbdSoftBending) * cache.nbEdges,
		"AvbdIslandSurfaceCache::bends"));
	if(!cache.bends) return false;
	cache.nbBends = 0;
	for(PxU32 edgeIndex = 0; edgeIndex < cache.nbEdges; ++edgeIndex)
	{
		const AvbdSoftBoundaryEdgeTopology& edge = cache.edges[edgeIndex];
		if(edge.face1 == PX_MAX_U32) continue;
		const AvbdSoftTri& face0 = cache.triangles[edge.face0];
		const AvbdSoftTri& face1 = cache.triangles[edge.face1];
		const PxU32 face0Vertices[3] = {face0.p0, face0.p1, face0.p2};
		const PxU32 face1Vertices[3] = {face1.p0, face1.p1, face1.p2};
		PxU32 opposite0 = PX_MAX_U32, opposite1 = PX_MAX_U32;
		for(PxU32 corner = 0; corner < 3; ++corner)
		{
			if(face0Vertices[corner] != edge.v0 && face0Vertices[corner] != edge.v1)
				opposite0 = face0Vertices[corner];
			if(face1Vertices[corner] != edge.v0 && face1Vertices[corner] != edge.v1)
				opposite1 = face1Vertices[corner];
		}
		if(opposite0 == PX_MAX_U32 || opposite1 == PX_MAX_U32) continue;
		AvbdSoftBending& bend = cache.bends[cache.nbBends++];
		bend.opp0 = opposite0; bend.opp1 = opposite1;
		bend.edgeStart = edge.v0; bend.edgeEnd = edge.v1;
		bend.restShapeAngle = avbdSoftDihedralAngle(
			cache.particles[opposite0].p, cache.particles[opposite1].p,
			cache.particles[edge.v0].p, cache.particles[edge.v1].p);
		bend.restLength = (cache.particles[edge.v1].p -
			cache.particles[edge.v0].p).magnitude();
	}
	return cache.nbEdges > 0;
}

bool avbdSegmentBoxInterval(const PxVec3& start, const PxVec3& end,
	const PxVec3& halfExtent, PxReal& enter, PxReal& exit)
{
	enter = 0.0f; exit = 1.0f;
	const PxVec3 direction = end - start;
	for(PxU32 axis = 0; axis < 3; ++axis)
	{
		if(PxAbs(direction[axis]) <= 1.0e-10f)
		{
			if(PxAbs(start[axis]) > halfExtent[axis]) return false;
			continue;
		}
		PxReal axisEnter = (-halfExtent[axis] - start[axis]) / direction[axis];
		PxReal axisExit = (halfExtent[axis] - start[axis]) / direction[axis];
		if(axisEnter > axisExit) PxSwap(axisEnter, axisExit);
		enter = PxMax(enter, axisEnter);
		exit = PxMin(exit, axisExit);
		if(enter > exit) return false;
	}
	return exit >= 0.0f && enter <= 1.0f;
}

PX_FORCE_INLINE PxVec3 avbdBoxVertex(const AvbdSoftStaticBox& box, PxU32 index)
{
	const PxVec3 local((index & 1) ? box.halfExtent.x : -box.halfExtent.x,
		(index & 2) ? box.halfExtent.y : -box.halfExtent.y,
		(index & 4) ? box.halfExtent.z : -box.halfExtent.z);
	return box.center + box.rotation.rotate(local);
}

static const PxU8 gAvbdBoxEdges[12][2] =
{
	{0,1},{2,3},{4,5},{6,7}, {0,2},{1,3},{4,6},{5,7},
	{0,4},{1,5},{2,6},{3,7}
};

const AvbdSurfaceBoxFeatureContact* avbdFindSurfaceBoxWarm(
	const PxArray<AvbdSurfaceBoxFeatureContact>& previous, PxU32 boxIndex,
	PxU8 featureType, PxU32 soft0, PxU32 soft1, PxU32 rigid0)
{
	for(PxU32 old = 0; old < previous.size(); ++old)
	{
		const AvbdSurfaceBoxFeatureContact& contact = previous[old];
		if(contact.boxIndex == boxIndex && contact.featureType == featureType &&
			contact.softFeature0 == soft0 && contact.softFeature1 == soft1 &&
			contact.rigidFeature0 == rigid0)
			return &contact;
	}
	return NULL;
}

void avbdRebuildSurfaceBoxFeatureContacts(AvbdIslandSurfaceCache& cache,
	const AvbdSoftStaticBox* boxes, PxU32 boxCount)
{
	if(!cache.boxFeatureContacts) return;
	PxArray<AvbdSurfaceBoxFeatureContact> previous;
	previous.swap(*cache.boxFeatureContacts);
	const PxReal featureEpsilon = 1.0e-4f;

	for(PxU32 boxIndex = 0; boxIndex < boxCount; ++boxIndex)
	{
		const AvbdSoftStaticBox& box = boxes[boxIndex];
		// Recovery and admission use the same complete triangle/box support
		// plane. Combining disjoint touching patches into one box-face exit
		// turns roundoff at opposite sides into metre-scale penetration.
		for(PxU32 triangleIndex = 0; triangleIndex < cache.nbTriangles; ++triangleIndex)
		{
			const AvbdSoftTri& triangle = cache.triangles[triangleIndex];
			const PxU32 ids[3] = {triangle.p0, triangle.p1, triangle.p2};
			if(cache.particles[ids[0]].invMass <= 0.0f &&
				cache.particles[ids[1]].invMass <= 0.0f &&
				cache.particles[ids[2]].invMass <= 0.0f)
				continue;
			const PxVec3 points[3] = {cache.particles[ids[0]].pStart,
				cache.particles[ids[1]].pStart, cache.particles[ids[2]].pStart};
			if(!avbdTriangleIntersectsVolumeBox(points, box)) continue;
			const AvbdTrianglePairPlane plane = avbdTriangleBoxPlane(points,
				box.center, box.rotation, box.halfExtent);
			const PxVec3 normal = plane.normal;
			const PxU32 supportCorner = avbdBoxSupportCorner(box.rotation.rotateInv(normal));
			const PxVec3 surfacePoint = box.center + box.rotation.rotate(
				avbdBoxCornerLocal(box.halfExtent, supportCorner));
			const PxReal clearance = PxMax(1.0e-5f, box.margin * 0.02f);
			for(PxU32 corner = 0; corner < 3; ++corner)
			{
				if(cache.particles[ids[corner]].invMass <= 0.0f)
					continue;
				AvbdSurfaceBoxFeatureContact contact;
				PxMemZero(&contact, sizeof(contact));
				contact.particleCount = 1;
				contact.boxIndex = boxIndex;
				contact.softFeature0 = triangleIndex;
				contact.softFeature1 = corner;
				contact.rigidFeature0 = supportCorner;
				contact.featureType = 3;
				contact.particleIndices[0] = ids[corner];
				contact.weights[0] = 1.0f;
				contact.surfacePoint = surfacePoint;
				contact.normal = normal;
				contact.margin = clearance;
				contact.k = 1.0e5f;
				contact.lambda = 0.0f;
				const AvbdSurfaceBoxFeatureContact* warm = avbdFindSurfaceBoxWarm(
					previous, boxIndex, 3, triangleIndex, corner, supportCorner);
				if(warm && contact.normal.dot(warm->normal) >= 0.8f)
				{
					const PxReal C = (cache.particles[ids[corner]].p -
						surfacePoint).dot(contact.normal) - contact.margin;
					const PxReal activeTolerance = PxMax(1.0e-5f,
						1.0e-4f * PxMax(contact.margin, 0.0f));
					if(PxIsFinite(C) && C <= activeTolerance)
					{
						contact.k = warm->k;
						contact.lambda = warm->lambda;
					}
				}
				if(contact.normal.magnitudeSquared() > 1.0e-12f &&
					contact.normal.isFinite())
				{
					contact.normal.normalize();
					cache.boxFeatureContacts->pushBack(contact);
				}
			}
		}

		// Reverse feature family: every rigid vertex owns the interior of one
		// soft triangle.  This is the case missed by endpoint SDF rows when a box
		// corner passes through the middle of a cloth triangle.
		for(PxU32 triangleIndex = 0; triangleIndex < cache.nbTriangles; ++triangleIndex)
		{
			const AvbdSoftTri& triangle = cache.triangles[triangleIndex];
			const PxU32 ids[3] = {triangle.p0, triangle.p1, triangle.p2};
			if(cache.particles[ids[0]].invMass <= 0.0f &&
				cache.particles[ids[1]].invMass <= 0.0f &&
				cache.particles[ids[2]].invMass <= 0.0f)
				continue;
			const PxVec3 current[3] = {cache.particles[ids[0]].p,
				cache.particles[ids[1]].p, cache.particles[ids[2]].p};
			for(PxU32 rigidVertex = 0; rigidVertex < 8; ++rigidVertex)
			{
				const PxVec3 rigidPoint = avbdBoxVertex(box, rigidVertex);
				PxVec3 closest, barycentric;
				avbdClosestPointTriangle(rigidPoint, current[0], current[1],
					current[2], closest, barycentric);
				const PxVec3 separation = closest - rigidPoint;
				const PxReal distance = separation.magnitude();
				const bool faceOwned = barycentric.x > featureEpsilon &&
					barycentric.y > featureEpsilon &&
					barycentric.z > featureEpsilon;
				if(!faceOwned || distance >= box.margin)
					continue;

				AvbdSurfaceBoxFeatureContact contact;
				PxMemZero(&contact, sizeof(contact));
				contact.particleCount = 3;
				contact.boxIndex = boxIndex;
				contact.softFeature0 = triangleIndex;
				contact.softFeature1 = PX_MAX_U32;
				contact.rigidFeature0 = rigidVertex;
				contact.featureType = 0;
				for(PxU32 corner = 0; corner < 3; ++corner)
				{
					contact.particleIndices[corner] = ids[corner];
					contact.weights[corner] = barycentric[corner];
				}
				contact.surfacePoint = rigidPoint;
				contact.normal = distance > 1.0e-8f ?
					separation * (1.0f / distance) :
					(current[1] - current[0]).cross(current[2] - current[0]);
				contact.margin = box.margin;
				contact.k = 1.0e5f;
				contact.lambda = 0.0f;
				const AvbdSurfaceBoxFeatureContact* warm = avbdFindSurfaceBoxWarm(
					previous, boxIndex, 0, triangleIndex, PX_MAX_U32, rigidVertex);
				if(warm && separation.dot(warm->normal) < box.margin)
					contact.normal = warm->normal;
				const PxReal C = separation.dot(contact.normal) - contact.margin;
				const PxReal activeTolerance = PxMax(1.0e-5f,
					1.0e-4f * PxMax(contact.margin, 0.0f));
				if(warm && warm->normal.dot(contact.normal) >= 0.8f &&
					C <= activeTolerance)
				{
					contact.k = warm->k;
					contact.lambda = warm->lambda;
				}
				if(contact.normal.magnitudeSquared() > 1.0e-12f &&
					contact.normal.isFinite())
				{
					contact.normal.normalize();
					cache.boxFeatureContacts->pushBack(contact);
				}
			}
		}

		// Canonical edge interiors complete the polyhedral feature matrix.
		for(PxU32 softEdgeIndex = 0; softEdgeIndex < cache.nbEdges; ++softEdgeIndex)
		{
			const AvbdSoftBoundaryEdgeTopology& softEdge = cache.edges[softEdgeIndex];
			if(cache.particles[softEdge.v0].invMass <= 0.0f &&
				cache.particles[softEdge.v1].invMass <= 0.0f) continue;
			for(PxU32 rigidEdgeIndex = 0; rigidEdgeIndex < 12; ++rigidEdgeIndex)
			{
				const PxVec3 rigid0 = avbdBoxVertex(box, gAvbdBoxEdges[rigidEdgeIndex][0]);
				const PxVec3 rigid1 = avbdBoxVertex(box, gAvbdBoxEdges[rigidEdgeIndex][1]);
				PxReal softWeight = 0.0f, rigidWeight = 0.0f;
				PxVec3 softClosest, rigidClosest;
				avbdClosestPointsSegments(cache.particles[softEdge.v0].p,
					cache.particles[softEdge.v1].p, rigid0, rigid1, softWeight,
					rigidWeight, softClosest, rigidClosest);
				PxVec3 normal = softClosest - rigidClosest;
				const PxReal distance = normal.magnitude();
				const bool interior = softWeight > featureEpsilon &&
					softWeight < 1.0f - featureEpsilon && rigidWeight > featureEpsilon &&
					rigidWeight < 1.0f - featureEpsilon;
				if(!interior || distance >= box.margin) continue;

				AvbdSurfaceBoxFeatureContact contact;
				PxMemZero(&contact, sizeof(contact));
				contact.particleCount = 2;
				contact.boxIndex = boxIndex;
				contact.softFeature0 = softEdge.v0;
				contact.softFeature1 = softEdge.v1;
				contact.rigidFeature0 = rigidEdgeIndex;
				contact.featureType = 1;
				const PxReal selectedSoftWeight = softWeight;
				const PxReal selectedRigidWeight = rigidWeight;
				contact.particleIndices[0] = softEdge.v0;
				contact.particleIndices[1] = softEdge.v1;
				contact.weights[0] = 1.0f - selectedSoftWeight;
				contact.weights[1] = selectedSoftWeight;
				contact.surfacePoint = rigid0 * (1.0f - selectedRigidWeight) +
					rigid1 * selectedRigidWeight;
				contact.normal = distance > 1.0e-8f ?
					normal * (1.0f / distance) :
					(cache.particles[softEdge.v1].p -
					 cache.particles[softEdge.v0].p).cross(rigid1 - rigid0);
				contact.margin = box.margin;
				contact.k = 1.0e5f;
				contact.lambda = 0.0f;
				const AvbdSurfaceBoxFeatureContact* warm = avbdFindSurfaceBoxWarm(
					previous, boxIndex, 1, softEdge.v0, softEdge.v1, rigidEdgeIndex);
				if(warm && normal.dot(warm->normal) < box.margin)
					contact.normal = warm->normal;
				const PxReal C = (softClosest - contact.surfacePoint).dot(contact.normal) -
					contact.margin;
				const PxReal activeTolerance = PxMax(1.0e-5f,
					1.0e-4f * PxMax(contact.margin, 0.0f));
				if(warm && warm->normal.dot(contact.normal) >= 0.8f &&
					C <= activeTolerance)
				{
					contact.k = warm->k; contact.lambda = warm->lambda;
				}
				if(contact.normal.magnitudeSquared() > 1.0e-12f && contact.normal.isFinite())
				{
					contact.normal.normalize();
					cache.boxFeatureContacts->pushBack(contact);
				}
			}
		}
	}
}

void avbdRefreshSurfaceOgcRegions(AvbdIslandSurfaceCache& cache,
 const DeformableSurface::CpuPlane* planes, PxU32 planeCount,
 const AvbdSoftStaticBox* boxes, PxU32 boxCount,
 const AvbdOGCParams&, PxReal)
{
 if(!cache.particles || !cache.ogcRegions || !cache.ogcExceeded) return;
 for(PxU32 particle=0;particle<cache.nbParticles;++particle)
 {
  const PxVec3 start=cache.particles[particle].pStart;
  avbdOgcResetPointRegion(cache.ogcRegions[particle],start);
  cache.ogcExceeded[particle]=0;
  for(PxU32 plane=0;plane<planeCount;++plane)
   avbdOgcAddHalfSpace(cache.ogcRegions[particle].planes,
    cache.ogcRegions[particle].planeCount,planes[plane].normal,
    PxMax(0.0f,planes[plane].normal.dot(start)+planes[plane].distance),
    PX_MAX_U32,PxVec3(0.0f),PxVec3(0.0f));
 }
 for(PxU32 boxIndex=0;boxIndex<boxCount;++boxIndex)
 {
  const AvbdSoftStaticBox& box=boxes[boxIndex];
  for(PxU32 triangleIndex=0;triangleIndex<cache.nbTriangles;++triangleIndex)
  {
   const AvbdSoftTri& triangle=cache.triangles[triangleIndex];
   const PxU32 ids[3]={triangle.p0,triangle.p1,triangle.p2};
   const PxVec3 points[3]={cache.particles[ids[0]].pStart,
    cache.particles[ids[1]].pStart,cache.particles[ids[2]].pStart};
   const AvbdTrianglePairPlane plane=avbdTriangleBoxPlane(points,
    box.center,box.rotation,box.halfExtent);
   PxVec3 normal=plane.normal;
   // Keep the complete support plane even at slight initial overlap.
   // Switching to an unrelated recovery face can amplify float-scale
   // overlap while every point remains admissible in that different domain.
   const PxVec3 localNormal=box.rotation.rotateInv(normal);
   const PxVec3 support=box.center+box.rotation.rotate(avbdBoxCornerLocal(
    box.halfExtent,avbdBoxSupportCorner(localNormal)));
   // All three supports share one verified plane. Their complete conditions
   // separate the triangle's convex hull from the box, including edge/face
   // crossings missed by endpoint SDFs. No distance ball restricts opening
   // or tangential recovery. The reference positions remain the DCD epoch.
   for(PxU32 corner=0;corner<3;++corner)
    avbdOgcAddHalfSpace(cache.ogcRegions[ids[corner]].planes,
     cache.ogcRegions[ids[corner]].planeCount,normal,
     PxMax(0.0f,normal.dot(points[corner]-support)),PX_MAX_U32,
     PxVec3(0.0f),PxVec3(0.0f));
  }
 }
}

bool avbdSurfaceOgcRefreshRequired(const AvbdIslandSurfaceCache& cache,
	PxReal refreshFraction)
{
	if(!cache.ogcExceeded || cache.nbParticles == 0)
		return false;
	PxU32 exceeded = 0;
	for(PxU32 particle = 0; particle < cache.nbParticles; ++particle)
		exceeded += cache.ogcExceeded[particle] != 0;
	const PxU32 threshold = PxMax(PxU32(1), PxU32(PxCeil(
		PxMax(0.0f, refreshFraction) * PxReal(cache.nbParticles))));
	return exceeded >= threshold;
}
} // namespace

void AvbdDynamicsContext::refreshSurfaceOgcRegions()
{
	for(PxU32 cacheIndex = 0; cacheIndex < mIslandSurfaceCache.size();
		++cacheIndex)
	{
		AvbdIslandSurfaceCache& cache = mIslandSurfaceCache[cacheIndex];
		if(cache.liveStamp != mIslandSurfaceLiveStamp || !cache.surface)
			continue;
		DeformableSurfaceCore& core = cache.surface->getCore();
		const PxReal thickness = PxMax(core.cpuThickness, 1.0e-6f);
		const DeformableSurface::CpuPlane* planes = cache.surface->getCpuPlanes();
		const PxU32 planeCount = PxMin(cache.surface->getNbCpuPlanes(),
			PxU32(DeformableSurface::eMAX_CPU_PLANES));
		AvbdSoftStaticBox boxes[DeformableSurface::eMAX_CPU_STATIC_BOXES];
		const DeformableSurface::CpuStaticBox* hostBoxes =
			cache.surface->getCpuStaticBoxes();
		const PxU32 boxCount = PxMin(cache.surface->getNbCpuStaticBoxes(),
			PxU32(DeformableSurface::eMAX_CPU_STATIC_BOXES));
		for(PxU32 boxIndex = 0; boxIndex < boxCount; ++boxIndex)
		{
			const PxReal margin = PxMax(hostBoxes[boxIndex].restDistance,
				0.5f * thickness);
			avbdFillSdfBox(boxes[boxIndex], hostBoxes[boxIndex].center,
				hostBoxes[boxIndex].halfExtent, margin, 0.5f * thickness,
				hostBoxes[boxIndex].rotation);
		}
		avbdRefreshSurfaceOgcRegions(cache, planes, planeCount, boxes, boxCount,
			mOgc, thickness);
	}
}

void AvbdDynamicsContext::rebuildSurfaceContacts()
{
	for(PxU32 cacheIndex = 0; cacheIndex < mIslandSurfaceCache.size();
		++cacheIndex)
	{
		AvbdIslandSurfaceCache& cache = mIslandSurfaceCache[cacheIndex];
		if(cache.liveStamp != mIslandSurfaceLiveStamp || !cache.surface)
			continue;
		const DeformableSurfaceCore& core = cache.surface->getCore();
		const PxReal thickness = PxMax(core.cpuThickness, 1.0e-6f);
		AvbdSoftStaticBox boxes[DeformableSurface::eMAX_CPU_STATIC_BOXES];
		const DeformableSurface::CpuStaticBox* hostBoxes =
			cache.surface->getCpuStaticBoxes();
		const PxU32 boxCount = PxMin(cache.surface->getNbCpuStaticBoxes(),
			PxU32(DeformableSurface::eMAX_CPU_STATIC_BOXES));
		for(PxU32 boxIndex = 0; boxIndex < boxCount; ++boxIndex)
		{
			const PxReal margin = PxMax(hostBoxes[boxIndex].restDistance,
				0.5f * thickness);
			avbdFillSdfBox(boxes[boxIndex], hostBoxes[boxIndex].center,
				hostBoxes[boxIndex].halfExtent, margin, 0.5f * thickness,
				hostBoxes[boxIndex].rotation);
		}
		avbdRebuildSurfaceBoxFeatureContacts(cache, boxes, boxCount);
	}
}

void AvbdDynamicsContext::prepareIslandDeformableSurfaces(PxReal dt, const PxVec3& gravity)
{
	const IG::IslandSim& islandSim = mIslandManager.getAccurateIslandSim();
	const PxU32 nbNodes = islandSim.getNbActiveNodes(IG::Node::eDEFORMABLE_SURFACE_TYPE);
	const PxNodeIndex* nodeIds = islandSim.getActiveNodes(IG::Node::eDEFORMABLE_SURFACE_TYPE);
	++mIslandSurfaceLiveStamp;
	if(mIslandSurfaceLiveStamp == 0)
		++mIslandSurfaceLiveStamp;
	for(PxU32 n = 0; n < nbNodes; ++n)
	{
		DeformableSurface* surface = static_cast<DeformableSurface*>(
			islandSim.getNode(nodeIds[n]).mObject);
		if(!surface)
			continue;
		PxTriangleMesh* mesh = surface->getTriangleMesh();
		DeformableSurfaceCore& core = surface->getCore();
		if(!mesh || !core.positionInvMass || !core.velocity || !core.restPosition)
			continue;
		const PxU32 nbParticles = mesh->getNbVertices();
		const PxU32 nbTrianglesIn = mesh->getNbTriangles();
		if(nbParticles == 0 || nbTrianglesIn == 0)
			continue;

		AvbdIslandSurfaceCache* cache = getIslandSurfaceCache(surface);
		if(cache && (cache->nbParticles != nbParticles || cache->nbTriangles > nbTrianglesIn))
		{
			cache->liveStamp = 0;
			pruneIslandSurfaceCache();
			cache = NULL;
		}
		if(!cache)
		{
			AvbdIslandSurfaceCache fresh;
			PxMemZero(&fresh, sizeof(fresh));
			fresh.surface = surface;
			fresh.nbParticles = nbParticles;
			fresh.triangles = reinterpret_cast<AvbdSoftTri*>(PX_ALLOC(
				sizeof(AvbdSoftTri) * nbTrianglesIn, "AvbdIslandSurfaceCache::triangles"));
			fresh.particles = reinterpret_cast<AvbdSoftParticle*>(PX_ALLOC(
				sizeof(AvbdSoftParticle) * nbParticles, "AvbdIslandSurfaceCache::particles"));
			fresh.ogcRegions = avbdOgcCreatePointRegions(nbParticles);
			fresh.ogcExceeded = reinterpret_cast<PxU8*>(PX_ALLOC(
				sizeof(PxU8) * nbParticles, "AvbdIslandSurfaceCache::ogcExceeded"));
			fresh.planeContactK = reinterpret_cast<PxReal*>(PX_ALLOC(
				sizeof(PxReal) * nbParticles * DeformableSurface::eMAX_CPU_PLANES,
				"AvbdIslandSurfaceCache::planeContactK"));
			fresh.planeContactLambda = reinterpret_cast<PxReal*>(PX_ALLOC(
				sizeof(PxReal) * nbParticles * DeformableSurface::eMAX_CPU_PLANES,
				"AvbdIslandSurfaceCache::planeContactLambda"));
			fresh.boxContactK = reinterpret_cast<PxReal*>(PX_ALLOC(
				sizeof(PxReal) * nbParticles * DeformableSurface::eMAX_CPU_STATIC_BOXES,
				"AvbdIslandSurfaceCache::boxContactK"));
			fresh.boxContactLambda = reinterpret_cast<PxReal*>(PX_ALLOC(
				sizeof(PxReal) * nbParticles * DeformableSurface::eMAX_CPU_STATIC_BOXES,
				"AvbdIslandSurfaceCache::boxContactLambda"));
			void* featureContactMemory = PX_ALLOC(sizeof(AvbdSurfaceBoxFeatureContactArray),
				"AvbdIslandSurfaceCache::boxFeatureContacts");
			fresh.boxFeatureContacts = featureContactMemory ? PX_PLACEMENT_NEW(
				featureContactMemory, AvbdSurfaceBoxFeatureContactArray) : NULL;
			if(!fresh.triangles || !fresh.particles || !fresh.ogcRegions ||
				!fresh.ogcExceeded || !fresh.planeContactK ||
				!fresh.planeContactLambda ||
				!fresh.boxContactK || !fresh.boxContactLambda || !fresh.boxFeatureContacts)
			{
				PX_FREE(fresh.triangles);
				PX_FREE(fresh.particles);
				avbdOgcDestroyPointRegions(fresh.ogcRegions, fresh.nbParticles);
				PX_FREE(fresh.ogcExceeded);
				PX_FREE(fresh.planeContactK);
				PX_FREE(fresh.planeContactLambda);
				PX_FREE(fresh.boxContactK);
				PX_FREE(fresh.boxContactLambda);
				if(fresh.boxFeatureContacts)
				{
					fresh.boxFeatureContacts->~AvbdSurfaceBoxFeatureContactArray();
					PX_FREE(fresh.boxFeatureContacts);
				}
				continue;
			}
			for(PxU32 i = 0; i < nbParticles; ++i)
			{
				AvbdSoftParticle& p = fresh.particles[i];
				PxMemZero(&p, sizeof(p));
				p.p = core.restPosition[i].getXYZ();
				p.pHat = p.pStart = p.p;
				for(PxU32 plane = 0; plane < DeformableSurface::eMAX_CPU_PLANES; ++plane)
				{
					fresh.planeContactK[i * DeformableSurface::eMAX_CPU_PLANES + plane] = 1.0e4f;
					fresh.planeContactLambda[i * DeformableSurface::eMAX_CPU_PLANES + plane] = 0.0f;
				}
				for(PxU32 box = 0; box < DeformableSurface::eMAX_CPU_STATIC_BOXES; ++box)
				{
					fresh.boxContactK[i * DeformableSurface::eMAX_CPU_STATIC_BOXES + box] = 1.0e5f;
					fresh.boxContactLambda[i * DeformableSurface::eMAX_CPU_STATIC_BOXES + box] = 0.0f;
				}
			}
			for(PxU32 t = 0; t < nbTrianglesIn; ++t)
			{
				PxU32 idx[3];
				if(!avbdReadTriIndices(*mesh, t, idx) || idx[0] >= nbParticles ||
					idx[1] >= nbParticles || idx[2] >= nbParticles)
					continue;
				if(avbdSoftBuildTri(fresh.triangles[fresh.nbTriangles], idx[0],
					idx[1], idx[2], fresh.particles))
					++fresh.nbTriangles;
			}
			if(fresh.nbTriangles == 0)
			{
				PX_FREE(fresh.triangles);
				PX_FREE(fresh.particles);
				avbdOgcDestroyPointRegions(fresh.ogcRegions, fresh.nbParticles);
				PX_FREE(fresh.ogcExceeded);
				PX_FREE(fresh.planeContactK);
				PX_FREE(fresh.planeContactLambda);
				PX_FREE(fresh.boxContactK);
				PX_FREE(fresh.boxContactLambda);
				if(fresh.boxFeatureContacts)
				{
					fresh.boxFeatureContacts->~AvbdSurfaceBoxFeatureContactArray();
					PX_FREE(fresh.boxFeatureContacts);
				}
				continue;
			}
			if(!avbdBuildSurfaceEdgeTopology(fresh))
			{
				PX_FREE(fresh.triangles);
				PX_FREE(fresh.particles);
				PX_FREE(fresh.planeContactK);
				PX_FREE(fresh.planeContactLambda);
				PX_FREE(fresh.boxContactK);
				PX_FREE(fresh.boxContactLambda);
				PX_FREE(fresh.edges);
				PX_FREE(fresh.bends);
				if(fresh.boxFeatureContacts)
				{
					fresh.boxFeatureContacts->~AvbdSurfaceBoxFeatureContactArray();
					PX_FREE(fresh.boxFeatureContacts);
				}
				continue;
			}
			mIslandSurfaceCache.pushBack(fresh);
			cache = &mIslandSurfaceCache.back();
		}
		cache->liveStamp = mIslandSurfaceLiveStamp;

		for(PxU32 i = 0; i < nbParticles; ++i)
		{
			const PxVec4 pv = core.positionInvMass[i];
			AvbdSoftParticle& p = cache->particles[i];
			p.p = p.pStart = p.pHat = pv.getXYZ();
			p.vel = core.velocity[i].getXYZ();
			p.invMass = pv.w;
			p.mass = pv.w > 1.0e-8f ? 1.0f / pv.w : 0.0f;
		}
		PxVec3 g = (core.actorFlags & PxActorFlag::eDISABLE_GRAVITY) ? PxVec3(0.0f) : gravity;
		avbdSoftPredict(cache->particles, nbParticles, g, dt);
	}
	if(!anyLiveDeformableSurface())
		pruneIslandSurfaceCache();
}

namespace
{
AvbdDynamicsContext* asAvbd(Context* ctx)
{
	if(!ctx || ctx->getSolverType() != PxSolverType::eAVBD)
		return NULL;
	return static_cast<AvbdDynamicsContext*>(ctx);
}
} // namespace

bool Dy::avbdKernelTableInfo(Context* ctx, PxU32& deviceKind, bool& ldlt6Bound, bool& ldlt3Bound)
{
	AvbdDynamicsContext* avbd = asAvbd(ctx);
	if(!avbd)
		return false;
	const KernelTable& table = avbd->getKernelTable();
	deviceKind = PxU32(table.device);
	ldlt6Bound = table.isBound(AVBD_LDLT6);
	ldlt3Bound = table.isBound(AVBD_LDLT3);
	return true;
}

Context* Dy::createAVBDDynamicsContext(PxcNpMemBlockPool* memBlockPool,
	Cm::FlushPool& taskPool, PxvSimStats& simStats,
	Cm::VirtualAllocatorCallback& allocator, PxsMaterialManager* materialManager,
	IG::SimpleIslandManager& islandManager, PxU64 contextID,
	PxReal maxBiasCoefficient, PxReal lengthScale, PxSceneFlags sceneFlags)
{
	return PX_NEW(AvbdDynamicsContext)(memBlockPool, taskPool, simStats, allocator,
		materialManager, islandManager, contextID, maxBiasCoefficient, lengthScale,
		sceneFlags);
}

void AvbdDynamicsContext::mergeResults()
{
}

PxU32 AvbdDynamicsContext::findBody(const PxsBodyCore* core) const
{
	if(!core)
		return PX_MAX_U32;
	for(PxU32 i = 0; i < mBodies.size(); ++i)
	{
		if(mBodies[i].core == core)
			return i;
	}
	return PX_MAX_U32;
}

PxTransform AvbdDynamicsContext::bodyPose(PxU32 index, const PxsBodyCore* fallback) const
{
	if(index < mBodies.size())
		return PxTransform(mBodies[index].p, mBodies[index].q);
	if(fallback)
		return fallback->body2World;
	return PxTransform(PxIdentity);
}

PxU32 AvbdDynamicsContext::solverBodyOf(PxU8 indexType, PxU32 solverBody) const
{
	if(indexType != PxsIndexedInteraction::eBODY)
		return PX_MAX_U32;
	if(solverBody >= mBodies.size())
		return PX_MAX_U32;
	return solverBody;
}

PxU32 AvbdDynamicsContext::contactBody(const PxsIndexedContactManager& cm, PxU32 side) const
{
	if(cm.contactManager)
	{
		const PxcNpWorkUnit& unit = cm.contactManager->getWorkUnit();
		const PxsRigidCore* rigidCore = side ? unit.mRigidCore1 : unit.mRigidCore0;
		const PxU32 body = findBody(static_cast<const PxsBodyCore*>(rigidCore));
		if(body != PX_MAX_U32)
			return body;
	}
	const PxU8 type = side ? cm.indexType1 : cm.indexType0;
	if(type == PxsIndexedInteraction::eBODY)
		return solverBodyOf(type, side ? PxU32(cm.solverBody1) : PxU32(cm.solverBody0));
	if(type == PxsIndexedInteraction::eARTICULATION && cm.contactManager)
	{
		const PxcNpWorkUnit& unit = cm.contactManager->getWorkUnit();
		const PxsRigidCore* rc = side ? unit.mRigidCore1 : unit.mRigidCore0;
		return findBody(static_cast<const PxsBodyCore*>(rc));
	}
	return PX_MAX_U32;
}

void AvbdDynamicsContext::initSolverBody(AvbdSolverBody& b, PxsBodyCore& core,
	PxsRigidBody* rigid, const PxVec3& gravity, PxReal dt)
{
	b = AvbdSolverBody();
	b.core = &core;
	b.rigid = rigid;
	b.p = core.body2World.p;
	b.q = core.body2World.q;
	b.pStart = b.p;
	b.qStart = b.q;
	b.pLin = b.p;
	b.qLin = b.q;
	b.linVel = core.linearVelocity;
	b.angVel = core.angularVelocity;
	b.outputLinVel = b.linVel;
	b.outputAngVel = b.angVel;
	b.invMass = core.inverseMass;
	b.invInertia = core.inverseInertia;
	b.disableGravity = core.disableGravity;
	b.isKinematic = core.isKinematic() ? 1 : 0;
	b.hasStaticTouch = 0;
	b.hasContact = 0;
	b.artic = NULL;
	b.linkIndex = 0;
	if(core.fixedBaseLink)
	{
		b.invMass = 0.0f;
		b.isKinematic = 1;
		b.pHat = b.p;
		b.qHat = b.q;
		return;
	}
	if(b.isKinematic)
	{
		// Host supplies the prescribed motion. Keep the DCD pose for anchors
		// and C0; the unified primal consumes its end pose after row prep.
		b.invMass = 0.0f;
		b.invInertia = PxVec3(0.0f);
		b.pHat = b.p + b.linVel * dt;
		const PxReal angle = b.angVel.magnitude() * dt;
		b.qHat = angle > 0.0f ? PxQuat(angle, b.angVel.getNormalized()) * b.q : b.q;
		b.qHat.normalize();
		return;
	}
	if(b.invMass > 0.0f && dt > 0.0f)
	{
		const PxReal invH2 = 1.0f / (dt * dt);
		b.massInvH2 = invH2 / b.invMass;
		PxMat33 localInertia(PxZero);
		localInertia[0][0] = b.invInertia.x > 0.0f ?
			1.0f / b.invInertia.x : 0.0f;
		localInertia[1][1] = b.invInertia.y > 0.0f ?
			1.0f / b.invInertia.y : 0.0f;
		localInertia[2][2] = b.invInertia.z > 0.0f ?
			1.0f / b.invInertia.z : 0.0f;
		const PxMat33 startRotation(b.qStart);
		b.inertiaWorldInvH2 =
			(startRotation * localInertia * startRotation.getTranspose()) * invH2;
	}
	PxVec3 v = b.linVel;
	PxVec3 w = b.angVel;
	const PxReal accelScale = rigid ? rigid->mAccelScale : 1.0f;
	// The inertial target is the undamped BDF1 objective.  Authored damping
	// belongs to the final velocity boundary after pose reconstruction; putting
	// it here as well changes both the objective and the published velocity and
	// therefore damps every constrained mode twice.  Velocity caps likewise
	// apply to the final velocity, not to the position objective.
	bodyCoreComputeUnconstrainedVelocity(gravity, dt, 0.0f, 0.0f,
		accelScale, PX_MAX_F32, PX_MAX_F32, v, w, b.disableGravity != 0);
	b.pHat = b.p + v * dt;
	const PxVec3 halfW = w * (0.5f * dt);
	PxQuat qHat = b.q + PxQuat(halfW.x, halfW.y, halfW.z, 0.0f) * b.q;
	qHat.normalize();
	b.qHat = qHat;
	// Material reconstruction shares the full external-acceleration epoch.
	// Authored damping and velocity caps apply once at final publication.
	b.linVel = v;
	b.angVel = w;
}

void AvbdDynamicsContext::collectArticulationLinks(PxReal dt, const PxVec3& gravity)
{
	const PxU32 nbArtics = mArticulationArray.size();
	PxU32 extra = 0;
	for(PxU32 a = 0; a < nbArtics; ++a)
	{
		if(mArticulationArray[a])
			extra += mArticulationArray[a]->getArticulationData().getLinkCount();
	}
	mBodies.reserve(mBodies.size() + extra);
	for(PxU32 a = 0; a < nbArtics; ++a)
	{
		FeatherstoneArticulation* artic = mArticulationArray[a];
		if(!artic)
			continue;
		ArticulationData& artData = artic->getArticulationData();
		const PxU32 linkCount = artData.getLinkCount();
		ArticulationLink* links = artData.getLinks();
		for(PxU32 i = 0; i < linkCount; ++i)
		{
			if(!links[i].bodyCore)
				continue;
			AvbdSolverBody b;
			initSolverBody(b, *links[i].bodyCore, NULL, gravity, dt);
			b.artic = artic;
			b.linkIndex = i;
			mBodies.pushBack(b);
		}
	}
	buildArticJointSources();
}

void AvbdDynamicsContext::update(Cm::FlushPool& /*flushPool*/,
	PxBaseTask* continuation, PxBaseTask* /*postPartitioningTask*/,
	PxBaseTask* /*lostTouchTask*/, PxvNphaseImplementationContext* nphase,
	PxU32 /*maxPatchesPerCM*/, PxU32 maxArticulationLinks, PxReal dt,
	const PxVec3& gravity, Cm::PinnableBitMap& /*changedHandleMap*/)
{
	mStep=StepState();
    mStep.commonProgram=std::getenv("PHYSX_AVBD_COMMON_STEP")!=NULL;
    mStep.boundedCommon=mStep.commonProgram && std::strcmp(std::getenv("PHYSX_AVBD_COMMON_STEP"),"bounded")==0;
	mActivePrimalTasks=0;mPeakPrimalTasks=0;
	const bool hasIslandWork = updateShared(nphase, dt, gravity);

	PX_PROFILE_ZONE("AVBD.update", mContextID);

	mLocalDomainFailed = false;
	mGravity = gravity;

	// All deformables enter through their Host actors and active IG nodes. Their
	// Particle3 blocks are compiled below beside Rigid6; no second integrator is
	// permitted before or after this backend program.
	prepareIslandDeformableVolumes(dt, gravity);
	prepareIslandDeformableSurfaces(dt, gravity);
	mStep.hasParticleBlocks = anyCoupledDeformableVolume() ||
		anyLiveDeformableSurface();

	if(!hasIslandWork && !mStep.hasParticleBlocks)
		return;

	const IG::IslandSim& islandSim = mIslandManager.getAccurateIslandSim();
	mKinematicCount = islandSim.getNbActiveKinematics();
	const PxU32 islandCount = islandSim.getNbActiveIslands();
	const IG::IslandId* islandIds = islandSim.getActiveIslands();
	const PxU32 bodyCount = islandSim.getNbActiveNodes(IG::Node::eRIGID_BODY_TYPE);
	const PxU32 articCount = islandSim.getNbActiveNodes(IG::Node::eARTICULATION_TYPE);
	const PxU32 contactCount = islandSim.getNbActiveEdges(IG::Edge::eCONTACT_MANAGER);

	if(bodyCount == 0 && articCount == 0 && !mStep.hasParticleBlocks)
		return;

	if(bodyCount > 0 || articCount > 0)
	{
		PxsIslandIndices counts;
		counts.bodies = bodyCount;
		counts.articulations = articCount;
		counts.contactManagers = contactCount;
		counts.constraints = islandSim.getNbActiveEdges(IG::Edge::eCONSTRAINT);

		reserveSharedSolverConstraintsArrays(islandSim, maxArticulationLinks);
		mSolverBodyRemapTable.forceSize_Unsafe(0);
		mSolverBodyRemapTable.resize(bodyCount);

		iterateIslandsNodes(counts, islandCount, islandIds, mBodyCoreArray.begin(),
			mRigidBodyArray.begin(), mArticulationArray.begin(),
			mSolverBodyRemapTable.begin(), mNodeIndexArray.begin());
		const PxU32 nbCms = iterateIslandsContactEdges(counts, islandCount, islandIds,
			mContactList.begin(), mSolverBodyRemapTable.begin());
		mContactList.forceSize_Unsafe(nbCms);

		mBodies.clear();
		mBodies.reserve(bodyCount + 4);
		mBodies.resize(bodyCount);

		const PxReal h = dt;
		for(PxU32 i = 0; i < bodyCount; ++i)
		{
			mBodies[i] = AvbdSolverBody();
			if(!mBodyCoreArray[i] || !mRigidBodyArray[i])
				continue;
			initSolverBody(mBodies[i], *mBodyCoreArray[i], mRigidBodyArray[i], gravity, h);
		}
		// Active kinematics are not dynamic island nodes. Retain them as
		// read-only endpoints so NP and solverPrep do not freeze world anchors.
		const PxNodeIndex* kinematics = islandSim.getActiveKinematics();
		for(PxU32 i = 0; i < mKinematicCount; ++i)
		{
			PxsRigidBody* rigid = getRigidBodyFromIG(islandSim, kinematics[i]);
			if(!rigid || findBody(&rigid->getCore()) != PX_MAX_U32) continue;
			AvbdSolverBody boundary;
			initSolverBody(boundary, rigid->getCore(), rigid, gravity, h);
			mBodies.pushBack(boundary);
		}

		collectArticulationLinks(h, gravity);

	}
	else
	{
		mBodies.clear();
		mContactList.forceSize_Unsafe(0);
	}

	injectHostDynamicSoftRigidBodies(gravity, dt);
	// Compile the current island's non-contact program before contact rows.
	// Contact tangent participation is an objective-ownership decision: the
	// AVBD_2 joint path assigns Position-AL the geometry normal only, whereas a
	// contact-only island also admits the Coulomb position coordinates.
	buildJointSources(islandCount, islandIds);
	buildContactRows();
	mNpContactRowCount = mRows.size();
	mRowSupports.clear();
    mTetrahedronMaterials.clear();
    mElasticFrameMaterials.clear();
	mTriangleDomainGeometry.clear();
	mTrianglePoints.clear();
	compileHeterogeneousBlocks();
	// Point anchors persist; spring damping freezes a new material coordinate
	// each step. Both must be compiled before the common inertial predictor.
	if(!mJoints.empty())
		refreshJointRows(true);
	mIterations = AVBD_ITERS_CONTACT;
	if(mJoints.size())
		mIterations = AVBD_ITERS_JOINT;
	if(mArticJoints.size())
		mIterations = AVBD_ITERS_ARTIC_MAX;
	if(mStep.hasParticleBlocks)
	{
		PxU32 authoredSoftIterations = 1;
		for(PxU32 cacheIndex = 0; cacheIndex < mIslandSoftCache.size(); ++cacheIndex)
		{
			const AvbdIslandSoftCache& cache = mIslandSoftCache[cacheIndex];
			if(cache.coupled && cache.liveStamp == mIslandSoftLiveStamp && cache.volume)
				authoredSoftIterations = PxMax(authoredSoftIterations,
					PxMax(PxU32(AVBD_DEFORMABLE_ITERS),
						PxU32(cache.volume->getCore().solverIterationCounts & 0xff)));
		}
		for(PxU32 cacheIndex = 0; cacheIndex < mIslandSurfaceCache.size();
			++cacheIndex)
		{
			const AvbdIslandSurfaceCache& cache = mIslandSurfaceCache[cacheIndex];
			if(cache.liveStamp == mIslandSurfaceLiveStamp && cache.surface)
				authoredSoftIterations = PxMax(authoredSoftIterations,
					PxU32(cache.surface->getCore().solverIterationCounts & 0xff));
		}
		mIterations = PxMax(mIterations, authoredSoftIterations);
	}

	// Contact/DCD ownership is compiled at the solve-start pose before an
	// inertial warm candidate is admitted.  Otherwise a block already on a
	// zero-distance OGC feature has no directional row yet and can spend an
	// unbounded warm step through that feature.
	if(mStep.hasParticleBlocks)
	{
		rebuildSoftRigidContacts();
		rebuildSurfaceContacts();
		rebuildSoftPairContacts();
	}
	if(mStep.hasParticleBlocks || mNpContactRowCount)
		refreshOgcRegions();
	mStep.rowProgramValid = false;
	if(mStep.hasParticleBlocks)
	{
		// The early preparation froze joint/material rest data at the DCD pose.
		// Those rows are not part of the contact prefix: retaining them here
		// makes subsequent refreshJointRows append a second physical copy.
		mRows.forceSize_Unsafe(mNpContactRowCount);
		mContactRowCount=mNpContactRowCount;
		buildSoftRigidContactRows();
		buildSurfaceContactRows();
		buildTriangleDomainRows();
		refreshJointRows();
		compileRowProgram();
		if(mLocalDomainFailed) { finishStep(); return; }
		compileTrianglePointIncidence();
		mStep.rowProgramValid = true;
	}
	for(PxU32 i = 0; i < mBodies.size(); ++i)
	{
		AvbdSolverBody& boundary = mBodies[i];
		if(boundary.isKinematic)
		{
			boundary.p = boundary.pHat;
			boundary.q = boundary.qHat;
		}
	}
	warmstartBlocks();

	// Condition contact rows in the same pose epoch consumed by the local
	// primal.  The spatial response contains the live world-space lever arm and
	// inertia, so evaluating it before the nonlinear warm pose gives the solver
	// a Hessian for a different configuration.  OGC stiffness remains geometry
	// admission data; this is the dimensionless Position-AL conditioning floor.
	for(PxU32 ri = 0; ri < mContactRowCount; ++ri)
	{
		avbdFloorContactRho(mRows[ri], mBodies, dt);
		if(mRows[ri].lambda < 0.0f)
			avbdFloorLoadedContactTangentRho(mRows[ri], mBodies, dt);
	}

	mStep.contactJointClosure = mJoints.size() && mContactRowCount;
	mStep.minimumJointIterations = mIterations;
	if(mStep.contactJointClosure)
		mIterations = PxMax(mIterations, AVBD_ITERS_CONTACT_JOINT_MAX);
	mStep.convergedContactJointSweeps = 0;
	if(!mStep.hasParticleBlocks)
	{
		refreshJointRows();
		compileRowProgram();
		if(mLocalDomainFailed) { finishStep(); return; }
		mStep.rowProgramValid = true;
	}
	// A point-lock graph has one smooth fixed-point map until contact changes
	// its active Hessian.  AVBD_2 accelerates this no-contact map with the
	// Chebyshev semi-iteration below.  It is deliberately disabled for mixed
	// row programs: those require their own spectral contract, and contact/joint
	// islands already terminate on complementarity closure.
	mStep.useJointChebyshev = mJoints.size() && !mContactRowCount &&
		!mArticJoints.size() && !mStep.hasParticleBlocks;
	for(PxU32 ri = mContactRowCount; ri < mRows.size() && mStep.useJointChebyshev; ++ri)
	{
		const AvbdRow& row = mRows[ri];
		if((row.flags & eAVBD_ROW_INACTIVE) == 0 &&
			(row.flags & eAVBD_ROW_POINT_LOCK) == 0)
			mStep.useJointChebyshev = false;
	}
	mStep.chebyOmega = 1.0f;
	if(mStep.useJointChebyshev)
	{
		mChebyPrevPosScratch.resize(mBodies.size());
		mChebyPrevPrevPosScratch.resize(mBodies.size());
		mChebyPrevRotScratch.resize(mBodies.size());
		mChebyPrevPrevRotScratch.resize(mBodies.size());
		for(PxU32 i = 0; i < mBodies.size(); ++i)
		{
			mChebyPrevPosScratch[i] = mChebyPrevPrevPosScratch[i] = mBodies[i].p;
			mChebyPrevRotScratch[i] = mChebyPrevPrevRotScratch[i] = mBodies[i].q;
		}
	}
	mStep.minimumIterations = mIterations;
	mStep.requiresDomainClosure = false;
	for(PxU32 blockIndex = 0; blockIndex < mBlocks.size(); ++blockIndex)
	{
		const AvbdBlock& block = mBlocks[blockIndex];
		mStep.requiresDomainClosure |= block.type == eAVBD_BLOCK_PARTICLE3 &&
			block.particleKernel == eAVBD_PARTICLE_KERNEL_TET;
	}
	mStep.iterationLimit = mStep.requiresDomainClosure ?
		PxMax(mStep.minimumIterations, AVBD_DEFORMABLE_ITERS_MAX) : mStep.minimumIterations;
	mStep.convergedHeterogeneousSweeps = 0;
	mStep.heterogeneousConverged=!mStep.requiresDomainClosure;
	mStep.contactJointConverged=!mStep.contactJointClosure;
	mStep.lastCoupledDomainStationary=false;

 mStep.workers=continuation ? continuation->getTaskManager()->getCpuDispatcher()->getWorkerCount() : 0;
 if(continuation) { mStep.continuation=continuation;continuation->addReference(); }
 advancePrimal();
}

void AvbdDynamicsContext::advancePrimal()
{
	while (mStep.iteration < mStep.iterationLimit && !mLocalDomainFailed)
	{
		if (!mStep.sweepPrepared)
		{
			const bool refreshedOgcDomain = mStep.iteration > 0 && ogcRefreshRequired();
			if (refreshedOgcDomain)
				refreshOgcRegions(false);
			if (mStep.useJointChebyshev)
			{
				for (PxU32 i = 0; i < mBodies.size(); ++i)
				{
					mChebyPrevPrevPosScratch[i] = mChebyPrevPosScratch[i];
					mChebyPrevPrevRotScratch[i] = mChebyPrevRotScratch[i];
					mChebyPrevPosScratch[i] = mBodies[i].p;
					mChebyPrevRotScratch[i] = mBodies[i].q;
				}
			}
			// The step-start manifold is the DCD epoch.  Recompiling hetero rows
			// mid-step at a crushed pose is a FRESH OGC slam onto both cores, and
			// that iterate is the published pancake.  Certificates may still
			// refresh; new features wait for the next step's DCD.
			bool primalTopologyChanged = false;
			if (mStep.hasParticleBlocks)
				primalTopologyChanged = refreshJointRows();
			// A new DCD epoch initially contains only contact rows. Persisted
			// solverPrep row counts can stay equal even though joints have just
			// been appended to that epoch for the first time.
			primalTopologyChanged |= mRowProgram.rowOffsets.size() != mRows.size() + 1;
			// refreshOgcRegions(false) only clears spent markers; DCD supports and
			// live-read partners remain fixed until the next step. Recompile the
			// execution graph only when its actual row incidence can have changed.
			const bool colorsChanged =
			    mStep.iteration == 0 || primalTopologyChanged || !mStep.rowProgramValid;
			if (!mStep.rowProgramValid || primalTopologyChanged)
			{
				compileRowProgram();
				if(mLocalDomainFailed) { finishStep(); return; }
				if(mStep.hasParticleBlocks) compileTrianglePointIncidence();
				mStep.rowProgramValid = true;
			}
			if (colorsChanged)
				compileBlockColors();
			if(mStep.iteration==0)captureCommonProgram();
            preparePrimalSweep();
            if(mStep.boundedCommon)
            {
                if(!beginBoundedCommon()){mLocalDomainFailed=1;break;}
                mStep.sweepPrepared=true;
            }
            else if(mStep.commonProgram)
            {
                bool stationary=false;
                if(!solveCommonCandidate(stationary)){mLocalDomainFailed=1;break;}
                mStep.lastCoupledDomainStationary=stationary;
                ++mStep.iteration;if(stationary)break;
                if(refreshJointRows())
                {mStep.rowProgramValid=false;for(auto& idle:mPrimalIdleIteration)idle=0;}
                continue;
            }
			mStep.nextColor = 0;
			mStep.sweepPrepared = true;
		}
        if(mStep.boundedCommon)
        {
            // A pending wave is joined before any program/candidate state changes.
            if(mBoundedResponse->status==AvbdBoundedResponse::Running)
            {
                if(!dispatchBoundedWave())return;
                continue;
            }
            bool done=false,stationary=false;
            if(!completeBoundedCommon(done,stationary)){mLocalDomainFailed=1;break;}
            if(!done)continue;
            mStep.lastCoupledDomainStationary=stationary;mStep.sweepPrepared=false;
            ++mStep.iteration;if(stationary)break;
            if(refreshJointRows())mStep.rowProgramValid=false;
            continue;
        }
		while (mStep.nextColor + 1 < mColorOffsets.size())
		{
			const PxU32 begin = mColorOffsets[mStep.nextColor], end = mColorOffsets[mStep.nextColor + 1];
			++mStep.nextColor;
			// Batch independent blocks to amortize dispatcher overhead. Workers claim
			// blocks dynamically because equal block counts need not mean equal work.
			// The advancing worker also solves; none waits for a queued child.
			const PxU32 minimumBlocksPerTask = 2;
			const PxU32 count = PxMin(mStep.workers, (end - begin) / minimumBlocksPerTask);
			if (mStep.continuation && count > 1)
			{
				if (!mColorContinuation)
					mColorContinuation = PX_NEW(AvbdAdvanceTask)(*this, mContextID);
				AvbdAdvanceTask *next = mColorContinuation;
				next->setContinuation(*mStep.continuation->getTaskManager(), NULL);
				mColorCursor = PxI32(begin);
				mColorEnd = end;
				while (mBlockTasks.size() + 1 < count)
					mBlockTasks.pushBack(PX_NEW(AvbdBlockSolveTask)(*this, mContextID));
				for (PxU32 i = 0; i + 1 < count; ++i)
				{
					AvbdBlockSolveTask *task = mBlockTasks[i];
                    task->bounded=false;
					task->setContinuation(next);
					++mStep.submittedTasks;
					task->removeReference();
				}
				solvePrimalBatch();
				if(next->completeInline())
					continue;
				return;
			}
			for (PxU32 i = begin; i < end; ++i)
				solvePrimalBlock(mColorBlocks[i]);
		}
		bool coupledDomainStationary = !mStep.hasParticleBlocks;
		const PxReal primalNormalizedStep = finishPrimalSweep(&coupledDomainStationary);

		mStep.lastCoupledDomainStationary = coupledDomainStationary;
		const bool jointTopologyChanged = refreshJointRows();
		applyDual();
		if (mStep.useJointChebyshev && mStep.iteration >= 2)
		{
			const PxReal rhoSq = AVBD_JOINT_CHEBYSHEV_RHO * AVBD_JOINT_CHEBYSHEV_RHO;
			mStep.chebyOmega = mStep.iteration == 2 ? 2.0f / (2.0f - rhoSq)
			                                        : 1.0f / (1.0f - rhoSq * mStep.chebyOmega * 0.25f);
			mStep.chebyOmega = PxClamp(mStep.chebyOmega, 1.0f, 2.0f);
			for (PxU32 i = 0; i < mBodies.size(); ++i)
			{
				AvbdSolverBody &b = mBodies[i];
				if (b.invMass <= 0.0f || b.isKinematic)
					continue;
				b.p = mChebyPrevPrevPosScratch[i] + (b.p - mChebyPrevPrevPosScratch[i]) * mStep.chebyOmega;
				PxQuat qCurrent = b.q;
				const PxQuat &qPrevious = mChebyPrevPrevRotScratch[i];
				if (qPrevious.dot(qCurrent) < 0.0f)
					qCurrent = -qCurrent;
				b.q = PxQuat(qPrevious.x + mStep.chebyOmega * (qCurrent.x - qPrevious.x),
				             qPrevious.y + mStep.chebyOmega * (qCurrent.y - qPrevious.y),
				             qPrevious.z + mStep.chebyOmega * (qCurrent.z - qPrevious.z),
				             qPrevious.w + mStep.chebyOmega * (qCurrent.w - qPrevious.w))
				          .getNormalized();
				if (b.core && b.core->lockFlags)
				{
					PxVec3 dp = b.p - b.pStart;
					PxVec3 dth = avbdQuatLogWorld(b.qStart, b.q);
					avbdProjectLockedDelta(b, dp, dth);
					b.p = b.pStart;
					b.q = b.qStart;
					avbdApplyDelta(b, dp, dth);
				}
			}
		}
		if (jointTopologyChanged)
			mStep.rowProgramValid = false;
		if (mStep.contactJointClosure && mStep.iteration + 1 >= mStep.minimumJointIterations)
		{
			// NP normals are unilateral AL rows. Their stopping certificate is
			// complementarity plus closing displacement, not a zero raw gap or
			// a small pose step (the joint graph may still have a bending mode).
			bool finiteNpState = true;
			bool hasNpRow = false;
			bool hasSpringObjective = false;
			for(PxU32 ri = mContactRowCount; ri < mRows.size(); ++ri)
				if((mRows[ri].flags & (eAVBD_ROW_DRIVE | eAVBD_ROW_INACTIVE)) == eAVBD_ROW_DRIVE)
					hasSpringObjective = true;
			PxReal residual = 0.0f, closing = 0.0f;
			const PxReal feasibilityTolerance =
			    AVBD_NP_JOINT_CLOSURE_REL_TOL * PxMax(getLengthScale(), 1.0e-6f);
			for (PxU32 ri = 0; ri < mNpContactRowCount; ++ri)
			{
				const AvbdRow &row = mRows[ri];
				if (row.flags & eAVBD_ROW_INACTIVE)
					continue;
				hasNpRow = true;
				const PxReal C = avbdPrimalC(row, mBodies, getLengthScale());
				const PxReal loadDistance = PxMax(0.0f, -row.lambda) / PxMax(row.rho, 1.0e-12f);
				const PxReal relativeDisplacement = row.n.dot(avbdContactRelDisp(row, mBodies));
				if (!PxIsFinite(C) || !PxIsFinite(loadDistance) || !PxIsFinite(relativeDisplacement))
					finiteNpState = false;
				residual = PxMax(residual, PxAbs(PxMin(C, loadDistance)));
				if (C <= 0.0f || loadDistance > 0.0f)
					closing = PxMax(closing, -relativeDisplacement);
			}
			// Contact complementarity cannot certify a finite spring optimum.
			// Its local primal map must also close within the existing budget.
			if (finiteNpState && (!hasSpringObjective || primalNormalizedStep <= 1.0f) &&
			    (hasNpRow ? (residual <= feasibilityTolerance && closing <= feasibilityTolerance)
			              : primalNormalizedStep <= 1.0f))
				++mStep.convergedContactJointSweeps;
			else
				mStep.convergedContactJointSweeps = 0;
			if (mStep.convergedContactJointSweeps >= 2)
			{
				mStep.contactJointConverged = true;
				if (!mStep.requiresDomainClosure)
					break;
			}
		}
		// WebPhysics uses a fixed primal budget, not a pose-map early-exit.
		// Articulation islands already take AVBD_ITERS_ARTIC_MAX sweeps; stopping
		// on two small GS steps leaves gravity's common mode in ker(J) of the
		// stiff D6 locks.  A DCD refresh only replaces the local admissible
		// region -- it is not another predictor or writeback pass.
		if (mStep.requiresDomainClosure && mStep.iteration + 1 >= mStep.minimumIterations)
		{
			// The authored count is a minimum nonlinear budget.  Publication needs
			// both the GS block map and the shared-domain Schur/KKT direction to be
			// stationary while the compiled topology remains unchanged.
			const bool localDomainsClosed = !ogcRefreshRequired();
			if (localDomainsClosed && !jointTopologyChanged && coupledDomainStationary &&
			    primalNormalizedStep <= 1.0f)
				++mStep.convergedHeterogeneousSweeps;
			else
				mStep.convergedHeterogeneousSweeps = 0;
			if (mStep.convergedHeterogeneousSweeps >= 2)
			{
				mStep.heterogeneousConverged = true;
				if (mStep.contactJointConverged)
					break;
			}
		}
		++mStep.iteration;
		mStep.sweepPrepared = false;
	}
	finishStep();
}

void AvbdDynamicsContext::finishStep()
{
    clearCommonPublication();
    if(!mLocalDomainFailed && mStep.requiresDomainClosure && !mStep.lastCoupledDomainStationary)
    {
        mLocalDomainFailed=1;
        std::fprintf(stderr,"[AVBD_COMMON_STEP] stage=publish reason=required_domain_closure status=FAIL\n");
    }
	// The last solverPrep may change row count at the iteration boundary too.
	// Velocity ownership must consume the final support program, even when
	// there is no following primal sweep to rebuild it.
	if(!mLocalDomainFailed && !mStep.rowProgramValid)
		compileRowProgram();
	if (mLocalDomainFailed)
	{
		if(mStep.commonProgram)
		{
			// Rejected backend iterates must not seed a later physical epoch.
			mContactWarm.clear();
			for(auto& row:mRows)row.lambda=row.lambdaT0=row.lambdaT1=0;
			writeJointDualState();
			if(std::getenv("PHYSX_AVBD_COMMON_STATS"))
				std::fprintf(stderr,"[AVBD_COMMON_FRAME] status=REJECTED poseForcePublications=0 bdf=0\n");
		}
		PxGetFoundation().error(
		    PxErrorCode::eINVALID_OPERATION, PX_FL,
		    "AVBD could not verify the local contact/material domain; step not published.");
		goto complete;
	}
	writeJointConstraintWriteback();
	if(mStep.commonProgram)
	{
		for(auto& row:mRows)if(row.forceWriteback)*row.forceWriteback=0;
		for(auto& row:mRows)if(row.forceWriteback)*row.forceWriteback-=row.lambda;
	}
	if (mStep.hasParticleBlocks)
		prepareDeformableVelocities(mDt);
	prepareRigidVelocities(mDt);
	applyHeterogeneousContactMaterial();
	finalizeRigidBodies(mDt);
	if (mStep.hasParticleBlocks)
		finalizeDeformableBlocks(mDt);
	if(mStep.commonProgram && std::getenv("PHYSX_AVBD_COMMON_STATS"))
		std::fprintf(stderr,"[AVBD_COMMON_FRAME] status=ACCEPTED poseForcePublications=1 bdf=1 stationary=%u iterations=%u\n",
			unsigned(mStep.lastCoupledDomainStationary),mStep.iteration);
complete:
    if(mStep.boundedCommon && std::getenv("PHYSX_AVBD_COMMON_STATS"))
        std::fprintf(stderr,"[AVBD_BOUNDED_SCHEDULE] waves=%llu batches=%llu sweeps=%llu tasks=%u peakTasks=%d workers=%u batchLimit=%u\n",
            static_cast<unsigned long long>(mStep.boundedWaves),static_cast<unsigned long long>(mStep.boundedBatches),
            static_cast<unsigned long long>(mStep.boundedSweeps),mStep.submittedTasks,int(mPeakPrimalTasks),mStep.workers,AvbdBoundedResponse::BatchWidth);
	if (std::getenv("PHYSX_AVBD_SCHEDULE_STATS"))
	{
		PxU32 width = 0;
		PxU32 idleSkips=0;
		for(PxU32 i=0;i<mPrimalIdleSkips.size();++i) idleSkips+=mPrimalIdleSkips[i];
		for (PxU32 c = 0; c + 1 < mColorOffsets.size(); ++c)
			width = PxMax(width, mColorOffsets[c + 1] - mColorOffsets[c]);
		std::fprintf(stderr,
		             "[AVBD_SCHEDULE] blocks=%u colors=%u maxWidth=%u tasks=%u peakTasks=%d workers=%u idleSkips=%u\n",
		             mColorBlocks.size(), mColorOffsets.empty() ? 0 : mColorOffsets.size() - 1, width,
		             mStep.submittedTasks, int(mPeakPrimalTasks), mStep.workers,idleSkips);
		std::fprintf(stderr,"[AVBD_STORAGE] bodies=%u rows=%u joints=%u bodyBytes=%llu rowBytes=%llu jointBytes=%llu rowStride=%llu supports=%u triangleDomains=%u trianglePoints=%u volumeCaches=%u surfaceCaches=%u softPairContacts=%u\n",
			mBodies.size(),mRows.size(),mJoints.size(),static_cast<unsigned long long>(PxU64(mBodies.size())*sizeof(AvbdSolverBody)),
			static_cast<unsigned long long>(PxU64(mRows.size())*sizeof(AvbdRow)),static_cast<unsigned long long>(PxU64(mJoints.size())*sizeof(AvbdJointSrc)+PxU64(mJointStates.size())*sizeof(AvbdJointState)),
			static_cast<unsigned long long>(sizeof(AvbdRow)),mRowSupports.size(),mTriangleDomainGeometry.size(),mTrianglePoints.size(),mIslandSoftCache.size(),mIslandSurfaceCache.size(),mSoftPairContacts.size());
		std::fprintf(stderr,"[AVBD_ROW_PROGRAM] rows=%u uniqueSupports=%u blockRefs=%u bytes=%llu\n",
			mRows.size(),mRowProgram.rowBlocks.size(),mRowProgram.blockRows.size(),
			static_cast<unsigned long long>(mRowProgram.bytes()));
        PxU64 groupAttempts=0,groupUnsupported=0,groupSolved=0,groupAccepted=0,groupProducts=0;
        PxU64 frictionAttempts=0,frictionAccepted=0,sharedContactAttempts=0,sharedContactAccepted=0;
        PxU64 materialEvaluations=0,materialEndpointUses=0;
        for(PxU32 i=0;i<mRigidGroups.size();++i)if(mRigidGroups[i].count>1)
        {
            const AvbdRigidGroup& g=mRigidGroups[i];groupAttempts+=g.attempts;
            groupUnsupported+=g.unsupported;groupSolved+=g.kernelSolved;groupAccepted+=g.accepted;groupProducts+=g.products;
            frictionAttempts+=g.frictionAttempts;frictionAccepted+=g.frictionAccepted;
            sharedContactAttempts+=g.sharedContactAttempts;sharedContactAccepted+=g.sharedContactAccepted;
            materialEvaluations+=g.materialEvaluations;materialEndpointUses+=g.materialEndpointUses;
        }
        std::fprintf(stderr,"[AVBD_GROUP_KERNEL] implementation=shared-linear-response attempts=%llu unsupported=%llu solved=%llu accepted=%llu products=%llu frictionAttempts=%llu frictionAccepted=%llu sharedContactAttempts=%llu sharedContactAccepted=%llu\n",
            static_cast<unsigned long long>(groupAttempts),static_cast<unsigned long long>(groupUnsupported),
            static_cast<unsigned long long>(groupSolved),static_cast<unsigned long long>(groupAccepted),static_cast<unsigned long long>(groupProducts),
            static_cast<unsigned long long>(frictionAttempts),static_cast<unsigned long long>(frictionAccepted),
            static_cast<unsigned long long>(sharedContactAttempts),static_cast<unsigned long long>(sharedContactAccepted));
        std::fprintf(stderr,"[AVBD_MATERIAL_ASSEMBLY] evaluations=%llu endpointUses=%llu\n",
            static_cast<unsigned long long>(materialEvaluations),static_cast<unsigned long long>(materialEndpointUses));
		PxU32 rigidCertificates=0,rigidPlanes=0;
		for(PxU32 i=0;i<mBodies.size();++i) if(mBodies[i].ogcRegionValid)
		{ ++rigidCertificates;rigidPlanes+=mBodies[i].ogcRegion.planeCount; }
		// A witness AL row is not a complete convex-feature certificate.
		// Expose coverage separately from the existence of OGC helper code.
		PxU32 npEndViolations=0;double npEndViolation=0;
		for(PxU32 r=0;r<mNpContactRowCount;++r)
		{
			const AvbdRow& row=mRows[r];
			if(row.kernelId!=eAVBD_ROW_KERNEL_NP_CONTACT) continue;
			const AvbdNpDomain& domain=mNpDomains[row.geometryIndex-1];
			const PxTransform poses[2]={row.bodyA<mBodies.size()?PxTransform(mBodies[row.bodyA].p,mBodies[row.bodyA].q):domain.fixedPose[0],
				row.bodyB<mBodies.size()?PxTransform(mBodies[row.bodyB].p,mBodies[row.bodyB].q):domain.fixedPose[1]};
			if(!avbdNpDomainPath(domain,poses,poses)) ++npEndViolations;
			npEndViolation=PxMax(npEndViolation,-avbdNpGap(domain,poses));
		}
		std::fprintf(stderr,"[AVBD_CONTACT_COVERAGE] npRows=%u rigidCertificateBodies=%u rigidCertificatePlanes=%u triangleDomains=%u npCompleteSupportDomains=%u npUnsupported=%u npPolicyExcluded=%u npUnseparated=%u npDomainMode=%u npCertificateEndViolations=%u npCertificateEndMaxViolation=%.9g npAxisRecovered=%u completeRigidNpOgc=partial_np_pairs\n",
			mNpContactRowCount,rigidCertificates,rigidPlanes,mTriangleDomainGeometry.size(),
			mNpDomains.size(),mNpDomainUnsupported,mNpDomainPolicyExcluded,mNpDomainUnseparated,mNpDomainMode,npEndViolations,npEndViolation,mNpDomainAxisRecovered);
	}
	PxBaseTask *continuation = mStep.continuation;
	mStep.continuation = NULL;
	if (continuation)
		continuation->removeReference();
}

void AvbdDynamicsContext::applyHeterogeneousContactMaterial()
{
	if(mBlocks.empty())
		return;

	// Position OGC supplies the physical contact potential.  Its accepted
	// separating velocity is therefore retained; the material solve only adds
	// unilateral impulses when a row is still closing.  Projecting every active
	// row to an equality target turns a resting manifold into an adhesive weld.
	mHeterogeneousMaterialImpulseScratch.resize(mRows.size());
	for(PxU32 rowIndex = 0; rowIndex < mRows.size(); ++rowIndex)
		mHeterogeneousMaterialImpulseScratch[rowIndex] = PxVec3(0.0f);

	auto rowAxisKinematics = [this](const AvbdRow& row, const PxVec3& axis,
		PxReal& velocity, PxReal& response)
	{
		velocity = 0.0f;
		response = 0.0f;
		if(row.kernelId==eAVBD_ROW_KERNEL_CONTACT_FRAME)
		{
			const auto value=avbdContactFrameRow(row,mRowSupports,mBlocks,mBodies,contactGeometry(),PX_MAX_U32,NULL,&axis);
			if(!value.valid) { PxGetFoundation().error(PxErrorCode::eINVALID_OPERATION,PX_FL,"AVBD contact frame invalid during material evaluation");return; }
			avbdForEachContactFrameBlock(row,mRowSupports,[&](PxU32 block)
			{
				const AvbdSoftParticle& particle=*mBlocks[block].particle;
				const PxVec3 j=avbdContactFrameGradient(row,mRowSupports,contactGeometry(),value,block);
				velocity+=j.dot(particle.vel);response+=particle.invMass*j.magnitudeSquared();
			});
			return;
		}
		for(PxU32 supportIndex = row.supportStart;
			supportIndex < row.supportStart + row.supportCount; ++supportIndex)
		{
			if(supportIndex >= mRowSupports.size()) break;
			const AvbdRowSupport& support = mRowSupports[supportIndex];
			if(support.block >= mBlocks.size()) continue;
			const AvbdBlock& block = mBlocks[support.block];
			const PxVec3 linearJacobian = axis * support.weight;
			if(block.type == eAVBD_BLOCK_PARTICLE3)
			{
				if(!block.particle) continue;
				const AvbdSoftParticle& particle = *block.particle;
				velocity += linearJacobian.dot(particle.vel);
				response += particle.invMass * linearJacobian.magnitudeSquared();
			}
			else if(block.type == eAVBD_BLOCK_RIGID6 &&
				block.objectIndex < mBodies.size())
			{
				const AvbdSolverBody& body = mBodies[block.objectIndex];
				if(!body.core || body.invMass <= 0.0f || body.isKinematic) continue;
				const PxVec3 arm = row.geometryIndex ?
                    avbdHeterogeneousPlaneOppositePoint(row,mRowSupports,mBlocks,mBodies)-body.p :
                    body.q.rotate(support.localPoint);
				const PxVec3 angularJacobian = arm.cross(linearJacobian);
				velocity += linearJacobian.dot(body.outputLinVel) +
					angularJacobian.dot(body.outputAngVel);
				response += body.invMass * linearJacobian.magnitudeSquared() +
					angularJacobian.dot(avbdWorldInvInertiaMul(body,
						angularJacobian));
			}
		}
	};
	auto rowCrossResponse = [this](const AvbdRow& row, const PxVec3& axis0,
		const PxVec3& axis1)
	{
		PxReal response = 0.0f;
		if(row.kernelId==eAVBD_ROW_KERNEL_CONTACT_FRAME)
		{
			const auto a=avbdContactFrameRow(row,mRowSupports,mBlocks,mBodies,contactGeometry(),PX_MAX_U32,NULL,&axis0);
			const auto b=avbdContactFrameRow(row,mRowSupports,mBlocks,mBodies,contactGeometry(),PX_MAX_U32,NULL,&axis1);
			if(!a.valid || !b.valid) { PxGetFoundation().error(PxErrorCode::eINVALID_OPERATION,PX_FL,"AVBD contact frame invalid during material response");return response; }
			avbdForEachContactFrameBlock(row,mRowSupports,[&](PxU32 block)
			{
				const PxVec3 j0=avbdContactFrameGradient(row,mRowSupports,contactGeometry(),a,block);
				const PxVec3 j1=avbdContactFrameGradient(row,mRowSupports,contactGeometry(),b,block);
				response+=mBlocks[block].particle->invMass*j0.dot(j1);
			});
			return response;
		}
		for(PxU32 supportIndex = row.supportStart;
			supportIndex < row.supportStart + row.supportCount; ++supportIndex)
		{
			if(supportIndex >= mRowSupports.size()) break;
			const AvbdRowSupport& support = mRowSupports[supportIndex];
			if(support.block >= mBlocks.size()) continue;
			const AvbdBlock& block = mBlocks[support.block];
			const PxVec3 linear0 = axis0 * support.weight;
			const PxVec3 linear1 = axis1 * support.weight;
			if(block.type == eAVBD_BLOCK_PARTICLE3)
			{
				if(!block.particle) continue;
				response += block.particle->invMass *
					linear0.dot(linear1);
			}
			else if(block.type == eAVBD_BLOCK_RIGID6 &&
				block.objectIndex < mBodies.size())
			{
				const AvbdSolverBody& body = mBodies[block.objectIndex];
				if(!body.core || body.invMass <= 0.0f || body.isKinematic) continue;
				const PxVec3 arm = row.geometryIndex ?
                    avbdHeterogeneousPlaneOppositePoint(row,mRowSupports,mBlocks,mBodies)-body.p :
                    body.q.rotate(support.localPoint);
				const PxVec3 angular0 = arm.cross(linear0);
				const PxVec3 angular1 = arm.cross(linear1);
				response += body.invMass * linear0.dot(linear1) +
					angular0.dot(avbdWorldInvInertiaMul(body, angular1));
			}
		}
		return response;
	};
	auto applyRowAxisImpulse = [this](const AvbdRow& row, const PxVec3& axis,
		PxReal impulse)
	{
		if(!PxIsFinite(impulse) || PxAbs(impulse) <= 1.0e-12f) return;
		if(row.kernelId==eAVBD_ROW_KERNEL_CONTACT_FRAME)
		{
			const auto value=avbdContactFrameRow(row,mRowSupports,mBlocks,mBodies,contactGeometry(),PX_MAX_U32,NULL,&axis);
			if(!value.valid) { PxGetFoundation().error(PxErrorCode::eINVALID_OPERATION,PX_FL,"AVBD contact frame invalid during material impulse");return; }
			avbdForEachContactFrameBlock(row,mRowSupports,[&](PxU32 block)
			{
				AvbdSoftParticle& particle=*mBlocks[block].particle;
				particle.vel+=avbdContactFrameGradient(row,mRowSupports,contactGeometry(),value,block)*(particle.invMass*impulse);
			});
			return;
		}
		for(PxU32 supportIndex = row.supportStart;
			supportIndex < row.supportStart + row.supportCount; ++supportIndex)
		{
			if(supportIndex >= mRowSupports.size()) break;
			const AvbdRowSupport& support = mRowSupports[supportIndex];
			if(support.block >= mBlocks.size()) continue;
			const AvbdBlock& block = mBlocks[support.block];
			const PxVec3 linearJacobian = axis * support.weight;
			if(block.type == eAVBD_BLOCK_PARTICLE3)
			{
				if(!block.particle) continue;
				block.particle->vel += linearJacobian *
					(block.particle->invMass * impulse);
			}
			else if(block.type == eAVBD_BLOCK_RIGID6 &&
				block.objectIndex < mBodies.size())
			{
				AvbdSolverBody& body = mBodies[block.objectIndex];
				if(!body.core || body.invMass <= 0.0f || body.isKinematic) continue;
				const PxVec3 arm = row.geometryIndex ?
                    avbdHeterogeneousPlaneOppositePoint(row,mRowSupports,mBlocks,mBodies)-body.p :
                    body.q.rotate(support.localPoint);
				body.outputLinVel += linearJacobian *
					(body.invMass * impulse);
				body.outputAngVel += avbdWorldInvInertiaMul(body,
					arm.cross(linearJacobian)) * impulse;
			}
		}
	};
	// Position OGC owns the heterogeneous normal.  A velocity Signorini on
	// the same rows is the shell/core weld: multi-point vn=0 dumps elastic
	// recovery on a compressed manifold.  Coulomb still consumes the dual
	// load on the offset shell.
	for(PxU32 sweep = 0; sweep < AVBD_MATERIAL_MAX_ITERS; ++sweep)
	{
		PxReal maximumImpulseDelta = 0.0f;
		bool appliedImpulse = false;
		for(PxU32 rowIndex = mNpContactRowCount; rowIndex < mRows.size(); ++rowIndex)
		{
			const AvbdRow& row = mRows[rowIndex];
			if((row.flags & (eAVBD_ROW_CONTACT | eAVBD_ROW_SOFT_PAIR |
				eAVBD_ROW_INACTIVE)) !=
				(eAVBD_ROW_CONTACT | eAVBD_ROW_SOFT_PAIR) || !row.supportCount ||
				row.mu <= 0.0f)
				continue;
			PxVec3 tangent0=row.t0, tangent1=row.t1;
			if(row.kernelId==eAVBD_ROW_KERNEL_CONTACT_FRAME)
				// Frame kernels consume local coordinate axes, including their
				// frame derivatives, rather than world-axis witness impulses.
				avbdOrthonormalBasis(mContactFrameGeometry[row.geometryIndex-1].normalLocal,tangent0,tangent1);
            else if(row.geometryIndex)
                avbdOrthonormalBasis(avbdHeterogeneousNormal(row,mBodies,contactGeometry(),mRowSupports,mBlocks),tangent0,tangent1);
			// Coulomb rides the published OGC load, which is nonzero inside
			// the shell at rest.  It does not get a second vn=0 plane.
			if(row.lambda >= 0.0f)
				continue;
			PxVec3& accumulated = mHeterogeneousMaterialImpulseScratch[rowIndex];
			const PxReal normalCapacity = PxMax(accumulated.x,
				PxAbs(row.lambda) * mDt);
			if(normalCapacity <= 0.0f)
				continue;
			PxReal velocity0 = 0.0f, response00 = 0.0f;
			PxReal velocity1 = 0.0f, response11 = 0.0f;
			rowAxisKinematics(row, tangent0, velocity0, response00);
			rowAxisKinematics(row, tangent1, velocity1, response11);
			const PxReal response01 = rowCrossResponse(row, tangent0, tangent1);
			const PxReal determinant = response00 * response11 -
				response01 * response01;
			if(!PxIsFinite(determinant) || determinant <= 1.0e-12f)
				continue;
			const PxReal old0 = accumulated.y;
			const PxReal old1 = accumulated.z;
			PxReal next0 = old0 + (-response11 * velocity0 +
				response01 * velocity1) / determinant;
			PxReal next1 = old1 + (response01 * velocity0 -
				response00 * velocity1) / determinant;
			// Coulomb capacity is the dual-published OGC load.  The offset
			// shell is not converted into an extra vn=0 plane.
			avbdProjectCoulomb(normalCapacity, row.mu, next0, next1);
			const PxReal delta0 = next0 - old0;
			const PxReal delta1 = next1 - old1;
			accumulated.y = next0;
			accumulated.z = next1;
			applyRowAxisImpulse(row, tangent0, delta0);
			applyRowAxisImpulse(row, tangent1, delta1);
			const PxReal deltaMagnitude = PxSqrt(delta0 * delta0 + delta1 * delta1);
			maximumImpulseDelta = PxMax(maximumImpulseDelta, deltaMagnitude);
			appliedImpulse |= deltaMagnitude > 1.0e-8f;
		}
		if(!appliedImpulse || maximumImpulseDelta <= 1.0e-8f)
			break;
	}

}

void AvbdDynamicsContext::clearIslandSurfaceCache()
{
	for(PxU32 i = 0; i < mIslandSurfaceCache.size(); ++i)
	{
		PX_FREE(mIslandSurfaceCache[i].triangles);
		PX_FREE(mIslandSurfaceCache[i].bends);
		PX_FREE(mIslandSurfaceCache[i].particles);
		avbdOgcDestroyPointRegions(mIslandSurfaceCache[i].ogcRegions, mIslandSurfaceCache[i].nbParticles);
		PX_FREE(mIslandSurfaceCache[i].ogcExceeded);
		PX_FREE(mIslandSurfaceCache[i].edges);
		PX_FREE(mIslandSurfaceCache[i].planeContactK);
		PX_FREE(mIslandSurfaceCache[i].planeContactLambda);
		PX_FREE(mIslandSurfaceCache[i].boxContactK);
		PX_FREE(mIslandSurfaceCache[i].boxContactLambda);
		if(mIslandSurfaceCache[i].boxFeatureContacts)
		{
			mIslandSurfaceCache[i].boxFeatureContacts->~AvbdSurfaceBoxFeatureContactArray();
			PX_FREE(mIslandSurfaceCache[i].boxFeatureContacts);
		}
	}
	mIslandSurfaceCache.forceSize_Unsafe(0);
}

AvbdIslandSurfaceCache* AvbdDynamicsContext::getIslandSurfaceCache(DeformableSurface* surface)
{
	for(PxU32 i = 0; i < mIslandSurfaceCache.size(); ++i)
	{
		if(mIslandSurfaceCache[i].surface == surface)
			return &mIslandSurfaceCache[i];
	}
	return NULL;
}

void AvbdDynamicsContext::pruneIslandSurfaceCache()
{
	PxU32 w = 0;
	for(PxU32 i = 0; i < mIslandSurfaceCache.size(); ++i)
	{
		if(mIslandSurfaceCache[i].liveStamp == mIslandSurfaceLiveStamp)
		{
			if(w != i)
				mIslandSurfaceCache[w] = mIslandSurfaceCache[i];
			++w;
		}
		else
		{
			PX_FREE(mIslandSurfaceCache[i].triangles);
			PX_FREE(mIslandSurfaceCache[i].bends);
			PX_FREE(mIslandSurfaceCache[i].particles);
			avbdOgcDestroyPointRegions(mIslandSurfaceCache[i].ogcRegions, mIslandSurfaceCache[i].nbParticles);
			PX_FREE(mIslandSurfaceCache[i].ogcExceeded);
			PX_FREE(mIslandSurfaceCache[i].edges);
			PX_FREE(mIslandSurfaceCache[i].planeContactK);
			PX_FREE(mIslandSurfaceCache[i].planeContactLambda);
			PX_FREE(mIslandSurfaceCache[i].boxContactK);
			PX_FREE(mIslandSurfaceCache[i].boxContactLambda);
			if(mIslandSurfaceCache[i].boxFeatureContacts)
			{
				mIslandSurfaceCache[i].boxFeatureContacts->~AvbdSurfaceBoxFeatureContactArray();
				PX_FREE(mIslandSurfaceCache[i].boxFeatureContacts);
			}
		}
	}
	mIslandSurfaceCache.forceSize_Unsafe(w);
}
