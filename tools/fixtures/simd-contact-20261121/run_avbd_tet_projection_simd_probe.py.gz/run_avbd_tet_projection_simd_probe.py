"""Validate and replay the complete four-corner projection predicate."""
import sys
from pathlib import Path
from run_avbd_ogc_certificate_probe import ROOT, run_probe

if __name__ == '__main__':
    inputs = [str(Path(a.split('=', 1)[1]).resolve()) for a in sys.argv[1:] if a.startswith('--replay=')]
    raise SystemExit(run_probe(ROOT / 'tools/avbd_tet_projection_simd_probe.cpp', args=inputs,
        compiler_options=['/fp:fast' if '--fast' in sys.argv else '/fp:precise']))
