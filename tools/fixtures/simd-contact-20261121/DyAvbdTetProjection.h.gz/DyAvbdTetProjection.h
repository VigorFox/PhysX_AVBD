// Copyright (c) 2026 NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: BSD-3-Clause
#ifndef DY_AVBD_TET_PROJECTION_H
#define DY_AVBD_TET_PROJECTION_H
#include "foundation/PxVec3.h"
#include "foundation/PxVecMath.h"
#include <limits>

namespace physx { namespace Dy {

template<class T> struct AvbdTetLocalProjection
{
    PxVec3T<T> axis;
    T heights[2][4],weights[2][4];
    T radius=0,scale=0,coefficientScale=0;
    bool ready=false;
    PxU8 attempts=0;

    int screen(const PxVec3T<T>& delta) const
    {
        const T shift=axis.dot(delta);
        T minimum[2]={std::numeric_limits<T>::max(),std::numeric_limits<T>::max()};
        for(PxU32 side=0;side<2;++side)for(PxU32 i=0;i<4;++i)
            minimum[side]=PxMin(minimum[side],(heights[side][i]+weights[side][i]*shift)*(side?T(-1):T(1)));
        const T lower=minimum[0]+minimum[1]-radius;
        // Collision embeddings are evaluated in the Host's PxReal arithmetic.
        const T epsilon=PxMax(std::numeric_limits<T>::epsilon(),T(std::numeric_limits<PxReal>::epsilon()));
        const T error=T(64)*epsilon*(scale+coefficientScale*axis.abs().dot(delta.abs()));
        if(!PxIsFinite(lower) || !(PxAbs(lower)>error))return 0;
        return lower>0?1:-1;
    }
    void prepare(const T (&values)[2][4],const T (&scales)[2],const PxVec3T<T>& normal,T clearance)
    {
        axis=normal;radius=clearance;
        scale=PxMax(scale,scales[0]+scales[1])+PxAbs(radius);
        T coefficientBound=0;
        for(PxU32 side=0;side<2;++side)
        {
            T largest=0;
            for(PxU32 i=0;i<4;++i)
            {
                heights[side][i]=values[side][i];
                largest=PxMax(largest,PxAbs(weights[side][i]));
            }
            coefficientBound+=largest;
        }
        coefficientScale=PxMax(coefficientScale,coefficientBound);
        ready=axis.isFinite() && PxIsFinite(radius) && PxIsFinite(scale) && PxIsFinite(coefficientScale);
    }
};

template<> PX_INLINE int AvbdTetLocalProjection<float>::screen(const PxVec3& delta) const
{
    using namespace aos;
    const auto shift=V4Load(axis.dot(delta));
    const auto first=V4Add(V4LoadU(heights[0]),V4Mul(V4LoadU(weights[0]),shift));
    const auto second=V4Add(V4LoadU(heights[1]),V4Mul(V4LoadU(weights[1]),shift));
    float minimum,maximum;
    FStore(V4ExtractMin(first),&minimum);FStore(V4ExtractMax(second),&maximum);
    const float lower=(minimum-maximum)-radius;
    const float error=64*std::numeric_limits<float>::epsilon()*(scale+coefficientScale*axis.abs().dot(delta.abs()));
    if(!PxIsFinite(lower) || !(PxAbs(lower)>error))return 0;
    return lower>0?1:-1;
}

template<class T> struct AvbdTetLocalQueryArgs
{
    const AvbdTetLocalProjection<T>* projection;
    PxVec3T<T> delta;
    int result;
};

template<class T> PX_INLINE bool avbdTetProjectionScalar(const PxVec3T<T> (&points)[2][4],
    const PxVec3T<T>& axis,const PxVec3T<T>& origin,T radius,
    AvbdTetLocalProjection<T>* local=NULL)
{
    if(local)local->ready=false;
    T minimum[2],heights[2][4],scales[2]={};
    for(PxU32 side=0;side<2;++side)
    {
        const T sign=side?T(-1):T(1);
        minimum[side]=std::numeric_limits<T>::max();
        for(PxU32 i=0;i<4;++i)
        {
            const T h=sign*axis.dot(points[side][i]-origin);
            if(!PxIsFinite(h))return false;
            minimum[side]=PxMin(minimum[side],h);
            if(local)
            {
                heights[side][i]=h*sign;
                scales[side]=PxMax(scales[side],axis.abs().dot((points[side][i]-origin).abs()));
            }
        }
    }
    if(local)local->prepare(heights,scales,axis,radius);
    return minimum[0]+minimum[1]>=radius;
}

template<class T> struct AvbdTetProjection
{
    static bool separated(const PxVec3T<T> (&points)[2][4],const PxVec3T<T>& axis,
        const PxVec3T<T>& origin,T radius,AvbdTetLocalProjection<T>* local=NULL)
    {return avbdTetProjectionScalar(points,axis,origin,radius,local);}
};

template<> struct AvbdTetProjection<float>
{
    // A zero result requests the original scalar predicate at the boundary.
    static int screen(const PxVec3 (&points)[2][4],const PxVec3& axis,
        const PxVec3& origin,float radius,AvbdTetLocalProjection<float>* local=NULL)
    {
        using namespace aos;
        if(local)local->ready=false;
        float minimum[2],scale[2],heights[2][4];
        for(PxU32 side=0;side<2;++side)
        {
            const auto& p=points[side];
            const auto x=V4Sub(V4LoadXYZW(p[0].x,p[1].x,p[2].x,p[3].x),V4Load(origin.x));
            const auto y=V4Sub(V4LoadXYZW(p[0].y,p[1].y,p[2].y,p[3].y),V4Load(origin.y));
            const auto z=V4Sub(V4LoadXYZW(p[0].z,p[1].z,p[2].z,p[3].z),V4Load(origin.z));
            const auto hx=V4Mul(x,V4Load(axis.x)),hy=V4Mul(y,V4Load(axis.y)),hz=V4Mul(z,V4Load(axis.z));
            const auto height=V4Add(V4Add(hx,hy),hz);
            if(!BAllEqTTTT(V4IsGrtrOrEq(V4Load(std::numeric_limits<float>::max()),V4Abs(height))))return -1;
            FStore(side?FNeg(V4ExtractMax(height)):V4ExtractMin(height),&minimum[side]);
            FStore(V4ExtractMax(V4Add(V4Add(V4Abs(hx),V4Abs(hy)),V4Abs(hz))),&scale[side]);
            if(local)V4StoreU(height,heights[side]);
        }
        if(local)local->prepare(heights,scale,axis,radius);
        const float gap=minimum[0]+minimum[1]-radius;
        const float error=16*std::numeric_limits<float>::epsilon()*(scale[0]+scale[1]+PxAbs(radius));
        if(!PxIsFinite(gap) || !(PxAbs(gap)>error))return 0;
        return gap>0?1:-1;
    }
    static bool separated(const PxVec3 (&points)[2][4],const PxVec3& axis,
        const PxVec3& origin,float radius,AvbdTetLocalProjection<float>* local=NULL)
    {
        const int result=screen(points,axis,origin,radius,local);
        return result?result>0:avbdTetProjectionScalar(points,axis,origin,radius);
    }
};

} }
#endif
