#include "avbd/DyAvbdTetProjection.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <limits>
#include <vector>
using namespace physx;
using namespace physx::Dy;

struct ProjectionInput
{
    PxVec3 points[2][4],axis,origin;
    float radius;
};

static bool scalar(const ProjectionInput& a)
{return avbdTetProjectionScalar(a.points,a.axis,a.origin,a.radius);}
static bool simd(const ProjectionInput& a)
{return AvbdTetProjection<float>::separated(a.points,a.axis,a.origin,a.radius);}

template<class T> static unsigned checkEmbeddedProjection()
{
    using V=PxVec3T<T>;
    PxU32 seed=71471,failures=0,certified=0;
    const auto random=[&](){seed=1664525u*seed+1013904223u;return float(seed&0xffffffu)/8388608.f-1;};
    const auto convert=[](const PxVec3& p){return V(p.x,p.y,p.z);};
    for(PxU32 trial=0;trial<12000;++trial)
    {
        const PxVec3 translation=trial%2?PxVec3(0):PxVec3(1000,500,-200);
        const PxVec3 original=translation+PxVec3(random(),random(),random());
        const PxVec3 next=original+PxVec3(random(),random(),random())*.2f;
        const V delta=convert(next)-convert(original);
        const V normal=convert(PxVec3(random(),random(),random()).getNormalized());
        const V origin=convert(translation);
        V initial[2][4],end[2][4];
        T worldScale[2]={},coefficientBounds[2]={};
        AvbdTetLocalProjection<T> local;
        for(PxU32 side=0;side<2;++side)for(PxU32 vertex=0;vertex<4;++vertex)
        {
            PxVec3 before(0),after(0);T scale=0,coefficient=0,coefficientBound=0;
            const float weights[4]={.2f*random(),.3f*random(),.5f*random(),1.f};
            for(PxU32 k=0;k<4;++k)
            {
                const bool unknown=k==vertex || (trial%5==0 && k==(vertex+1)%4);
                const PxVec3 p=unknown?original:translation+PxVec3(random(),random(),random());
                const float w=weights[k];
                before+=p*w;after+=(unknown?next:p)*w;
                scale+=PxAbs(T(w))*normal.abs().dot(convert(p).abs());
                if(unknown){coefficient+=T(w);coefficientBound+=PxAbs(T(w));}
            }
            initial[side][vertex]=convert(before);end[side][vertex]=convert(after);
            local.weights[side][vertex]=coefficient;
            worldScale[side]=PxMax(worldScale[side],scale);
            coefficientBounds[side]=PxMax(coefficientBounds[side],coefficientBound);
        }
        T low=std::numeric_limits<T>::max(),high=-low;
        for(PxU32 i=0;i<4;++i)
        {
            low=PxMin(low,normal.dot(end[0][i]-origin));
            high=PxMax(high,normal.dot(end[1][i]-origin));
        }
        const T radius=trial%3==0?low-high:T(random());
        local.scale=worldScale[0]+worldScale[1]+T(2)*normal.abs().dot(origin.abs());
        local.coefficientScale=coefficientBounds[0]+coefficientBounds[1];
        AvbdTetProjection<T>::separated(initial,normal,origin,radius,&local);
        const int decision=local.screen(delta);
        if(decision)
        {
            ++certified;
            failures+=(decision>0)!=avbdTetProjectionScalar(end,normal,origin,radius);
        }
    }
    std::printf("[TET_EMBEDDED] scalarBytes=%zu trials=12000 certified=%u failures=%u\n",sizeof(T),certified,failures);
    return failures+(certified<1000);
}

int main(int argc,char** argv)
{
    PxU32 seed=71371,failures=0,boundaries=0,localCertified=0;
    const auto random=[&](){seed=1664525u*seed+1013904223u;return float(seed&0xffffffu)/8388608.f-1;};
    for(PxU32 i=0;i<12000;++i)
    {
        ProjectionInput a;
        const float scale=i%3==0?.001f:i%3==1?1.f:100.f;
        a.axis=PxVec3(random(),random(),random()).getNormalized();
        a.origin=PxVec3(random(),random(),random())*scale;
        for(auto& side:a.points)for(auto& p:side)p=a.origin+PxVec3(random(),random(),random())*scale;
        float lo=PX_MAX_F32,hi=-PX_MAX_F32;
        for(PxU32 v=0;v<4;++v)
        {
            lo=PxMin(lo,a.axis.dot(a.points[0][v]-a.origin));
            hi=PxMax(hi,a.axis.dot(a.points[1][v]-a.origin));
        }
        const float touch=lo-hi;
        a.radius=i%4==0?touch:i%4==1?std::nextafter(touch,INFINITY):
            i%4==2?std::nextafter(touch,-INFINITY):random()*scale;
        failures+=scalar(a)!=simd(a);
        boundaries+=AvbdTetProjection<float>::screen(a.points,a.axis,a.origin,a.radius)==0;
        for(PxU32 slot=0;slot<8;++slot)
        {
            AvbdTetLocalProjection<float> local;
            for(auto& side:local.weights)for(auto& w:side)w=0;
            local.weights[slot/4][slot%4]=1;
            AvbdTetProjection<float>::separated(a.points,a.axis,a.origin,a.radius,&local);
            auto shifted=a;
            const auto before=shifted.points[slot/4][slot%4];
            shifted.points[slot/4][slot%4]+=PxVec3(random(),random(),random())*(scale*.2f);
            const auto delta=shifted.points[slot/4][slot%4]-before;
            const int decision=local.screen(delta);
            localCertified+=decision!=0;
            if(decision)failures+=(decision>0)!=scalar(shifted);
        }
        a.points[i%2][i%4].x=std::numeric_limits<float>::quiet_NaN();
        failures+=simd(a);
    }
    std::printf("[TET_PROJECTION] cases=12000 boundaries=%u localCertified=%u failures=%u status=%s\n",
        boundaries,localCertified,failures,failures?"FAIL":"PASS");
    if(failures || boundaries<9000 || localCertified<10000)return 1;
    if(checkEmbeddedProjection<float>() || checkEmbeddedProjection<double>())return 1;
    if(argc<2)return 0;
    FILE* file=std::fopen(argv[1],"rb");
    if(!file)return 2;
    std::vector<ProjectionInput> inputs;
    ProjectionInput a;
    while(std::fread(&a,sizeof(a),1,file)==1)inputs.push_back(a);
    std::fclose(file);
    if(inputs.empty())return 2;
    PxU32 refinements=0,accepted=0;
    for(const auto& input:inputs)
    {
        failures+=scalar(input)!=simd(input);accepted+=simd(input);
        refinements+=AvbdTetProjection<float>::screen(input.points,input.axis,input.origin,input.radius)==0;
    }
    double milliseconds[2][7];
    volatile unsigned sink=0;
    for(unsigned repeat=0;repeat<7;++repeat)for(unsigned order=0;order<2;++order)
    {
        const unsigned vector=(repeat+order)%2;
        const auto start=std::chrono::steady_clock::now();
        unsigned count=0;
        for(unsigned loop=0;loop<64;++loop)for(const auto& input:inputs)
            count+=vector?simd(input):scalar(input);
        milliseconds[vector][repeat]=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
        sink=count;
    }
    for(auto& times:milliseconds)std::sort(times,times+7);
    std::printf("[TET_REPLAY] queries=%zu accepted=%u refinements=%u scalarMs=%.6f simdMs=%.6f ratio=%.6f failures=%u sink=%u\n",
        inputs.size(),accepted,refinements,milliseconds[0][3],milliseconds[1][3],
        milliseconds[1][3]/milliseconds[0][3],failures,unsigned(sink));
    return failures?1:0;
}
