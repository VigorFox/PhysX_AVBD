// Bounded production Table kernels; the test pool is not part of the SDK.
#include "avbd/DyAvbdBoundedResponse.h"
#include "avbd_probe_foundation.h"
#include "avbd_bounded_probe_pool.h"
#include <cstdio>
using namespace physx;using namespace physx::Dy;
static AvbdCommonProgram make(unsigned n,bool star=false,bool fixed=false)
{
    AvbdCommonProgram p;const double inf=std::numeric_limits<double>::infinity();
    for(unsigned b=0;b<n;++b)
    {
        const unsigned dim=b%2?6:3;p.dimensions.pushBack(dim);p.sourceBlocks.pushBack(b);
        AvbdCommonHBlock h={};h.row=h.column=b;
        for(unsigned d=0;d<dim;++d){h.values[6*d+d]=2+.1*d;p.base.pushBack(0);}p.H.pushBack(h);
        if(b)
        {
            h={};h.row=b;h.column=star?0:b-1;h.values[0]=h.values[7]=h.values[14]=star?-.001:-.25;
            p.H.pushBack(h);std::swap(h.row,h.column);p.H.pushBack(h);
            unsigned r=p.mu.size();p.sourceRows.pushBack(r);p.mu.pushBack(.5);p.coulomb.pushBack(!fixed);
            for(unsigned q=0;q<3;++q)
            {p.offset.pushBack(0);p.lower.pushBack(fixed?(q?0:1):(q?-inf:0));p.upper.pushBack(fixed?(q?0:1):inf);p.compliance.pushBack(0);}
            AvbdCommonJBlock j={};j.row=r;j.column=b;j.values[0]=j.values[7]=j.values[14]=1;p.J.pushBack(j);
            j.column=star?0:b-1;j.values[0]=j.values[7]=j.values[14]=-1;p.J.pushBack(j);
        }
    }
    p.finish();return p;
}
static bool check(AvbdCommonProgram& p,AvbdBoundedProbePool& pool,const char* name,bool fixed=false)
{
    PxArray<double> target(p.base.size()),force(p.offset.size(),0),jx(force.size()),reaction(target.size());
    for(unsigned b=0;b<p.dimensions.size();++b)for(unsigned d=0;d<p.dimensions[b];++d)target[p.starts[b]+d]=.01*(1+d);
    for(unsigned r=0;r<p.mu.size();++r){force[3*r]=1+.03*(r%3);if(fixed)force[3*r]=1;else force[3*r+1]=.1*force[3*r];}
    p.hessian(target.begin(),p.base.begin());p.transpose(force.begin(),reaction.begin());p.jacobian(target.begin(),jx.begin());
    for(unsigned d=0;d<target.size();++d)p.base[d]-=reaction[d];
    for(unsigned i=0;i<jx.size();++i)p.offset[i]=-jx[i];
    const auto table=KernelTable::makeAvbdCpuScalar();AvbdBoundedResponse a(p),b(p);a.solve(table);pool.solve(b);
    double error=0,difference=0;for(unsigned d=0;d<target.size();++d)
    {error=std::max(error,std::abs(a.step[d]-target[d]));difference=std::max(difference,std::abs(a.step[d]-b.step[d]));}
    // Independent full operators and original roots, rather than only the
    // executor's reduction tree or a known target displacement.
    PxArray<double> hx(target.size());p.hessian(a.step.begin(),hx.begin());p.transpose(a.force.begin(),reaction.begin());
    double station=0,rootError=0;for(unsigned d=0;d<hx.size();++d)station=std::max(station,std::abs(hx[d]-p.base[d]-reaction[d]));
    p.jacobian(a.step.begin(),jx.begin());
    for(unsigned r=0;r<p.mu.size();++r)
    {double u[3],root[3];for(unsigned q=0;q<3;++q)u[q]=p.offset[3*r+q]+jx[3*r+q]+p.compliance[3*r+q]*a.force[3*r+q];
        avbdCoulombRoot(a.force.begin()+3*r,u,1,p.mu[r],p.lower.begin()+3*r,p.upper.begin()+3*r,p.coulomb[r]!=0,root);
        for(double v:root)rootError=std::max(rootError,std::abs(v));}
    bool bounded=true;for(const auto& node:a.nodes)bounded=bounded && node.count<=unsigned(node.level?AvbdBoundedResponse::FanIn:AvbdBoundedResponse::LeafWidth);
    const bool ok=a.status==AvbdBoundedResponse::Converged && b.status==AvbdBoundedResponse::Converged && error<1.e-7 && difference<1.e-8 && bounded && station<1.e-7 && rootError<1.e-8;
    std::printf("[BOUNDED_CASE] name=%s blocks=%u rows=%u colors=%u depth=%u sweeps=%u error=%.9g threadDifference=%.9g status=%s\n",
        name,p.dimensions.size(),p.mu.size(),a.colorCount,a.maxDepth,a.sweeps,error,difference,ok?"PASS":"FAIL");return ok;
}
int main()
{
    AvbdProbeFoundation foundation;AvbdBoundedProbePool pool;unsigned failed=0;
    auto small=make(16);failed+=!check(small,pool,"coupled_coulomb");
    auto four=make(4);for(unsigned i=2;i<4;++i)
    {AvbdCommonJBlock j={};j.row=0;j.column=i;j.values[0]=j.values[7]=j.values[14]=i==2?1:-1;four.J.pushBack(j);}four.finish();
    failed+=!check(four,pool,"four_support_row");
    auto star=make(1025,true,true);failed+=!check(star,pool,"high_degree_star",true);
    auto chain=make(1025,false,true);failed+=!check(chain,pool,"long_chain",true);
    // A long hard-contact chain is allowed to report unresolved at the fixed
    // cap. Do not confuse a bounded termination contract with convergence.
    auto hard=make(257);hard.base[0]=1;AvbdBoundedResponse longHard(hard);longHard.solve(KernelTable::makeAvbdCpuScalar());
    bool boundedTermination=longHard.status==AvbdBoundedResponse::Converged ||
        (longHard.status==AvbdBoundedResponse::BudgetExhausted && longHard.sweeps==AvbdBoundedResponse::SweepLimit);
    failed+=!boundedTermination;
    std::printf("[BOUNDED_HARD_CHAIN] blocks=257 rows=256 sweeps=%u result=%s budgetContract=%s\n",
        longHard.sweeps,longHard.statusName(),boundedTermination?"PASS":"FAIL");
    // Two bodies must move together from a closed contact, with one shared dual.
    auto closed=make(2);for(auto& h:closed.H)if(h.row!=h.column)h.values[0]=-1;
    closed.base[0]=2;closed.base[3]=-1;closed.coulomb[0]=0;closed.lower[1]=closed.lower[2]=closed.upper[1]=closed.upper[2]=0;
    AvbdBoundedResponse c(closed);pool.solve(c);
    bool ok=c.status==AvbdBoundedResponse::Converged && std::abs(c.step[0]-.5)<1.e-8 && std::abs(c.step[3]-.5)<1.e-8 && std::abs(c.force[0]-1.5)<1.e-8;
    failed+=!ok;std::printf("[BOUNDED_CLOSED_CHAIN] sweeps=%u a=%.9g b=%.9g force=%.9g status=%s\n",c.sweeps,c.step[0],c.step[3],c.force[0],ok?"PASS":"FAIL");
    // A support-free impossible row must exhaust the fixed budget, not pass.
    auto impossible=make(1);impossible.mu.pushBack(0);impossible.coulomb.pushBack(0);impossible.sourceRows.pushBack(0);
    for(unsigned q=0;q<3;++q){impossible.offset.pushBack(q?0:-1);impossible.lower.pushBack(0);impossible.upper.pushBack(q?0:std::numeric_limits<double>::infinity());impossible.compliance.pushBack(0);}impossible.finish();
    AvbdBoundedResponse bad(impossible);bad.solve(KernelTable::makeAvbdCpuScalar());
    ok=bad.status==AvbdBoundedResponse::BudgetExhausted && bad.sweeps==AvbdBoundedResponse::SweepLimit;
    failed+=!ok;std::printf("[BOUNDED_BUDGET] sweeps=%u status=%s\n",bad.sweeps,ok?"PASS":"FAIL");
    // No hidden row truncation or switch to all-island Jacobi.
    auto arity=make(5);for(unsigned i=0;i<5;++i){AvbdCommonJBlock j={};j.row=0;j.column=i;j.values[0]=1;arity.J.pushBack(j);}arity.finish();
    AvbdBoundedResponse unsupported(arity);failed+=unsupported.status!=AvbdBoundedResponse::Unsupported;
    auto clique=make(33);for(unsigned a=0;a<33;++a)for(unsigned b=0;b<33;++b)if(a!=b){AvbdCommonHBlock h={};h.row=a;h.column=b;h.values[0]=.0001;clique.H.pushBack(h);}clique.finish();
    AvbdBoundedResponse tooManyColors(clique);failed+=tooManyColors.status!=AvbdBoundedResponse::Unsupported;
    auto triangular=make(2);for(unsigned i=0;i<triangular.H.size();++i)if(triangular.H[i].row>triangular.H[i].column)
    {triangular.H.remove(i);break;}triangular.finish();AvbdBoundedResponse unsafeColor(triangular);
    failed+=unsafeColor.status!=AvbdBoundedResponse::Unsupported;
    auto indefinite=make(1);indefinite.H[0].values[0]=-1;AvbdBoundedResponse invalid(indefinite);invalid.solve(KernelTable::makeAvbdCpuScalar());
    failed+=invalid.status!=AvbdBoundedResponse::NumericalFailure;
    failed+=pool.peak.load()<2;
    std::printf("[BOUNDED_RESPONSE] threads=1,4 peak=%u leaf=32 fanIn=8 matrix=6 batch=32 sweepLimit=1024 failed=%u status=%s\n",pool.peak.load(),failed,failed?"FAIL":"PASS");return failed?1:0;
}
