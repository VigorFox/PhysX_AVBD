// Copyright (c) 2026 NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: BSD-3-Clause

#include "avbd/DyAvbdInternal.h"
#include "avbd/DyAvbdOgc.h"

#include "DyIslandManager.h"
#include "DyDeformableSurface.h"
#include "PxcNpWorkUnit.h"
#include "PxsContactManager.h"
#include "PxsContactManagerState.h"
#include "PxsContactGeometry.h"
#include "PxsIslandSim.h"
#include "PxsSimpleIslandManager.h"
#include "PxContact.h"
#include "geometry/PxTetrahedronMesh.h"
#include <cstdlib>
#include <cstdio>

using namespace physx;
using namespace Dy;

static bool avbdCompileNpShape(AvbdNpDomain& domain,PxU32 side,
    const PxsContactShapeGeometry& shape,PxU32 body)
{
    if(shape.kind==PxsContactShapeGeometry::eNONE ||
        (shape.kind==PxsContactShapeGeometry::ePLANE && body!=PX_MAX_U32)) return false;
    domain.radius[side]=shape.radius;
    domain.fixedPose[side]=shape.shapeToWorld;
    const PxTransform& local=shape.shapeToBody;
    const PxQuatd q=avbdNpRotation(local.q);
    const PxVec3d p=avbdOgcDouble(local.p);
    const PxU32 count=shape.kind==PxsContactShapeGeometry::ePLANE?1:shape.count;
    for(PxU32 i=0;i<count;++i)
    {
        PxVec3d v(0);
        if(shape.kind==PxsContactShapeGeometry::eVERTICES)
        {
            const PxVec3d vertex=avbdOgcDouble(shape.vertices[i]);
            v=avbdOgcDouble(shape.vertexToShape.column0)*vertex.x+
                avbdOgcDouble(shape.vertexToShape.column1)*vertex.y+
                avbdOgcDouble(shape.vertexToShape.column2)*vertex.z;
        }
        else if(shape.kind==PxsContactShapeGeometry::eBOX)
            v=PxVec3d((i&1)?shape.halfExtents.x:-shape.halfExtents.x,
                (i&2)?shape.halfExtents.y:-shape.halfExtents.y,
                (i&4)?shape.halfExtents.z:-shape.halfExtents.z);
        else if(shape.kind==PxsContactShapeGeometry::eCAPSULE)
            v.x=i?shape.halfExtents.x:-shape.halfExtents.x;
        domain.points[side].pushBack(body==PX_MAX_U32?v:p+q.rotate(v));
    }
    return count!=0;
}

static void avbdFinishVolumeBoxContactRow(AvbdRow& row,
	const PxArray<AvbdRowSupport>& supports, const PxArray<AvbdBlock>& blocks,
	const PxArray<AvbdSolverBody>& bodies,
	const AvbdContactGeometryView& geometry)
{
	if(row.contactStiffness > 0.0f)
	{
		row.rho = PxMin(row.contactStiffness, AVBD_RHO_MAX);
		return;
	}
	// Position-AL triangle/core: k = 0 is the discriminator, not a zero
	// penalty.  Live C0 is unused by the primal (NP alpha broke sitting).
	row.rho = PxMin(1.0e5f, AVBD_RHO_MAX);
	row.C0 = avbdHeterogeneousRowC(row, supports, blocks, bodies, geometry);
}

void AvbdDynamicsContext::buildContactRows()
{
	PxArray<AvbdContactWarm> prev;
	prev.swap(mContactWarm);
	PxArray<PxU8> prevUsed(prev.size());
	for(PxU32 i = 0; i < prevUsed.size(); ++i)
		prevUsed[i] = 0;
	mRows.forceSize_Unsafe(0);
	mContactPlaneGeometry.clear();
	mContactFrameGeometry.clear();
	mNpDomains.clear();
	mNpDomainUnsupported=mNpDomainPolicyExcluded=mNpDomainUnseparated=0;
	mNpDomainAxisRecovered=0;
	const char* domainMode=std::getenv("PHYSX_NP_GEOMETRY_CERTIFICATES");
	mNpDomainMode=domainMode && domainMode[0]=='2'?2u:(domainMode && domainMode[0]=='1'?1u:0u);
	const PxU32 nb = mContactList.size();
	mRows.reserve(nb * 4 + mJoints.size() * AVBD_MAX_JOINT_ROWS
		+ mArticJoints.size() * AVBD_MAX_ARTIC_ROWS + 64);
	mContactWarm.reserve(nb * 4 + 16);

	for(PxU32 i = 0; i < nb; ++i)
	{
		const PxsIndexedContactManager& cm = mContactList[i];
		if(!cm.contactManager)
			continue;

		PxcNpWorkUnit& unit = cm.contactManager->getWorkUnit();
		if((unit.mFlags & PxcNpWorkUnitFlag::eSOFT_BODY) || !unit.mRigidCore0 || !unit.mRigidCore1)
			continue;
		PxsContactManagerOutput& output =
			mOutputIterator.getContactManagerOutput(unit.mNpIndex);
		if(!output.contactPatches || !output.contactPoints || output.nbContacts == 0)
			continue;
		// NP reports every proximity point inside the inertial query distance
		// (contact offset + one-step reach).  Each point is a speculative
		// unilateral Position-AL row, the same contract PhysX uses for
		// speculative contacts: it carries no force while C > 0 and stops the
		// pair on the linearized plane when the step would cross it.

		const PxU32 ia = contactBody(cm, 0);
		const PxU32 ib = contactBody(cm, 1);
		if(ia == PX_MAX_U32 && ib == PX_MAX_U32)
			continue;

		// Iterator, not raw PxContact*: modifiable/extended streams have a
		// different stride. targetVelocity and inv-mass scale are intentionally
		// unread (documented unsupported; smoke PASS unsupported).
		PxContactStreamIterator iter(output.contactPatches, output.contactPoints,
			output.getInternalFaceIndice(), output.nbPatches, output.nbContacts);
		PxU32 streamIndex = 0;
		const PxU32 firstRow=mRows.size();
		bool domainPolicy=(unit.mFlags & (PxcNpWorkUnitFlag::eMODIFIABLE_CONTACT |
			PxcNpWorkUnitFlag::eDISABLE_RESPONSE))==0 && unit.mRestDistance>=0;
		while(iter.hasNextPatch())
		{
			iter.nextPatch();
			if(iter.patch && (iter.patch->internalFlags & PxContactPatch::eFORCE_NO_RESPONSE))
			{
				domainPolicy=false;
				while(iter.hasNextContact())
				{
					iter.nextContact();
					++streamIndex;
				}
				continue;
			}
			PxVec3 n = iter.getContactNormal();
			if(n.normalize() < 1.0e-8f)
			{
				while(iter.hasNextContact())
				{
					iter.nextContact();
					++streamIndex;
				}
				continue;
			}
			PxVec3 t0, t1;
			avbdOrthonormalBasis(n, t0, t1);
			const PxReal mu = PxMax(iter.getStaticFriction(), iter.getDynamicFriction());
			const PxReal rest = PxClamp(iter.getRestitution(), 0.0f, 1.0f);
			const PxU32 materialKey = PxU32(iter.patch->materialIndex0) |
				(PxU32(iter.patch->materialIndex1) << 16);

			while(iter.hasNextContact())
			{
				iter.nextContact();
				const PxU32 idx = streamIndex++;
				PxReal maxImp = iter.getMaxImpulse();
				// Match PhysX contact preparation: the per-point modifier and
				// both public body limits restrict the same normal impulse.
				if(ia<mBodies.size() && mBodies[ia].core)
					maxImp=PxMin(maxImp,mBodies[ia].core->maxContactImpulse);
				if(ib<mBodies.size() && mBodies[ib].core)
					maxImp=PxMin(maxImp,mBodies[ib].core->maxContactImpulse);
				if(maxImp<1.0e15f) domainPolicy=false;
				if(maxImp <= 0.0f)
					continue;
				// C = separation - restDistance (AVBD_2 processedSeparation).
				const PxReal d = iter.getSeparation();

				AvbdRow row;
				PxMemZero(&row, sizeof(row));
				row.bodyA = ia;
				row.bodyB = ib;
				row.n = n;
				row.t0 = t0;
				row.t1 = t1;
				// The contact AL Hessian starts at the dimensionless floor; a stiff
				// initial penalty made a contact row one hundred times stiffer than
				// the reference hard-joint block and allowed a heavy projectile to
				// stretch a spherical-joint graph.
				row.rho = AVBD_CONTACT_PENALTY_MIN;
				row.rhoT0 = AVBD_CONTACT_PENALTY_MIN;
				row.rhoT1 = AVBD_CONTACT_PENALTY_MIN;
				row.lambda = 0.0f;
				row.lambdaT0 = 0.0f;
				row.lambdaT1 = 0.0f;
				row.mu = mu;
				// Passive Coulomb tangents remain Position-AL coordinates even when
				// an endpoint belongs to a hard-joint/articulation program.  Endpoint
				// velocity ownership is compiled later; it must not erase geometry's
				// two tangential coordinates.
				row.positionTangent = 1;
				row.restitution = rest;
				row.minLambda = -PX_MAX_REAL;
				if(maxImp < 1.0e15f && mDt > 0.0f)
					row.minLambda = -maxImp / mDt;
				row.maxLambda = 0.0f;
				row.flags = PxU8(eAVBD_ROW_UNILATERAL | eAVBD_ROW_CONTACT);
				row.forceWriteback =
					output.contactForces ? output.contactForces + idx : NULL;

				const PxVec3 point = iter.getContactPoint();
				if(ia != PX_MAX_U32)
					row.rA = mBodies[ia].q.rotateInv(point - mBodies[ia].p);
				else
					row.rA = point;

				if(ib != PX_MAX_U32)
					row.rB = mBodies[ib].q.rotateInv(point - mBodies[ib].p);
				else
					row.rB = point;
				row.ogcRA = row.rA;
				row.ogcRB = row.rB;

				// Default rigid NP rows rest at the authored rest distance.
				// The explicit complete-domain trial may compile an offset law
				// below after checking the entire pair's response policy.
				const PxReal rawInitialC0 = d - unit.mRestDistance;
				row.contactOffset = rawInitialC0;
				row.contactRadius = 0.0f;
				row.contactStiffness = 0.0f;
				if(ia == PX_MAX_U32 || ib == PX_MAX_U32)
				{
					row.rho *= AVBD_PEN_SCALE_BODY_VS_STATIC;
					row.rhoT0 *= AVBD_PEN_SCALE_BODY_VS_STATIC;
					row.rhoT1 *= AVBD_PEN_SCALE_BODY_VS_STATIC;
				}
				bool persistentPointMatched = false;
				PxU32 matchedWarm = PX_MAX_U32;
				PxReal matchedScore = PX_MAX_F32;
				for(PxU32 w = 0; w < prev.size(); ++w)
				{
					if(prevUsed[w] || prev[w].cm != cm.contactManager ||
						prev[w].materialKey != materialKey)
						continue;
					// AVBD_2 persistence gate (matchAvbdPersistentManifold):
					// dual state only survives an exact geometric match of the
					// preceding frame's point. Cached anchors are body-local,
					// re-expressed at the current pose, so persistent contacts
					// on moving bodies still match while a reshuffled manifold
					// does not. Stream-index identity alone re-applies an
					// impact-scale lambda to a different point: a stale 1e6 N
					// force ejects a resting pair at lambda*h/M tens of m/s
					// and the impulse cascades through the pile.
					const PxVec3 oldWorldA = (ia != PX_MAX_U32)
						? mBodies[ia].p + mBodies[ia].q.rotate(prev[w].detectionRA)
						: prev[w].detectionRA;
					const PxVec3 oldWorldB = (ib != PX_MAX_U32)
						? mBodies[ib].p + mBodies[ib].q.rotate(prev[w].detectionRB)
						: prev[w].detectionRB;
					const PxReal score = 0.5f *
						((oldWorldA - point).magnitudeSquared() +
						 (oldWorldB - point).magnitudeSquared());
					const PxReal corr =
						0.025f * PxMax(getLengthScale(), 1.0e-6f);
					const PxReal normalGate = 0.9659258f; // cos(15 deg)
					if(prev[w].n.dot(row.n) < normalGate ||
						!PxIsFinite(score) || score > corr * corr ||
						score >= matchedScore)
						continue;
					matchedScore = score;
					matchedWarm = w;
				}
				if(matchedWarm != PX_MAX_U32)
				{
					const PxU32 w = matchedWarm;
					prevUsed[w] = 1;
					const PxReal warm = AVBD_ALPHA * AVBD_GAMMA;
					row.rho = PxMax(row.rho, PxClamp(prev[w].rho * AVBD_GAMMA,
						AVBD_CONTACT_PENALTY_MIN, AVBD_CONTACT_PENALTY_MAX));
					row.rhoT0 = PxMax(row.rhoT0, PxClamp(prev[w].rhoT0 * AVBD_GAMMA,
						AVBD_CONTACT_PENALTY_MIN, AVBD_CONTACT_PENALTY_MAX));
					row.rhoT1 = PxMax(row.rhoT1, PxClamp(prev[w].rhoT1 * AVBD_GAMMA,
						AVBD_CONTACT_PENALTY_MIN, AVBD_CONTACT_PENALTY_MAX));
					// A sticking material point owns one inseparable tuple: both local
					// anchors and their normal offset.  Matching uses the fresh detection
					// anchors above; retaining only the dual while rebasing this tuple at
					// every NP refresh erases the elastic displacement stored by Position-AL.
					if(prev[w].stick && mu > 0.0f)
					{
						const PxVec3 oldA = ia != PX_MAX_U32 ?
							mBodies[ia].p + mBodies[ia].q.rotate(prev[w].rA) : prev[w].rA;
						const PxVec3 oldB = ib != PX_MAX_U32 ?
							mBodies[ib].p + mBodies[ib].q.rotate(prev[w].rB) : prev[w].rB;
						const PxVec3 oldDelta = oldA - oldB;
						const PxVec3 tangentDrift = oldDelta - row.n * oldDelta.dot(row.n);
						const PxReal corr = 0.025f * PxMax(getLengthScale(), 1.0e-6f);
						if(prev[w].n.dot(row.n) >= 0.999f &&
							tangentDrift.magnitudeSquared() <= corr * corr)
						{
							row.rA = prev[w].rA;
							row.rB = prev[w].rB;
						}
					}
					// demo3d Eq. 19: lambda <- alpha*gamma*lambda through the
					// geometric persistence gate only.
					row.lambda = PxMin(0.0f, prev[w].lambda * warm);
					const PxVec3 ft = prev[w].t0 * prev[w].lambdaT0
						+ prev[w].t1 * prev[w].lambdaT1;
					row.lambdaT0 = row.t0.dot(ft) * warm;
					row.lambdaT1 = row.t1.dot(ft) * warm;
					avbdProjectCoulomb(row.lambda, row.mu, row.lambdaT0, row.lambdaT1);
					persistentPointMatched = true;
				}
				if(!persistentPointMatched)
					row.flags = PxU8(row.flags | eAVBD_ROW_FRESH);
				// C0 is the signed solve-start continuation.  Clamping a negative
				// value to zero reclassifies every persistent overlap as displacement
				// created by this step; the pose solve then repeats full depenetration
				// and writes that geometric recovery back as impact velocity.  Match
				// the reference contract: retain signed C0, with only a continuous
				// attenuation for a fresh, pathologically deep point.
				PxReal conditionedC0 = rawInitialC0;
				if(!persistentPointMatched)
				{
					const PxReal lengthScale = PxMax(getLengthScale(), 1.0e-6f);
					const PxReal threshold = 0.05f * lengthScale;
					const PxReal maxDepth = 0.20f * lengthScale;
					if(conditionedC0 < -threshold)
					{
						const PxReal t = PxClamp((maxDepth + conditionedC0) /
							(maxDepth - threshold), 0.0f, 1.0f);
						conditionedC0 *= t;
					}
				}
				row.C0 = conditionedC0;
				PxVec3 initialA = row.rA;
				PxVec3 initialB = row.rB;
				if(ia != PX_MAX_U32)
					initialA = mBodies[ia].pStart + mBodies[ia].qStart.rotate(row.rA);
				if(ib != PX_MAX_U32)
					initialB = mBodies[ib].pStart + mBodies[ib].qStart.rotate(row.rB);
				const PxVec3 initialDelta = initialA - initialB;
				row.tangentC0 = initialDelta.dot(row.t0);
				row.tangentC1 = initialDelta.dot(row.t1);
				AvbdContactWarm warm;
				warm.cm = cm.contactManager;
				warm.materialKey = materialKey;
				warm.n = row.n;
				warm.detectionRA = ia != PX_MAX_U32 ?
					mBodies[ia].q.rotateInv(point - mBodies[ia].p) : point;
				warm.detectionRB = ib != PX_MAX_U32 ?
					mBodies[ib].q.rotateInv(point - mBodies[ib].p) : point;
				warm.rA = row.rA;
				warm.rB = row.rB;
				warm.t0 = row.t0;
				warm.t1 = row.t1;
				warm.lambda = row.lambda;
				warm.lambdaT0 = row.lambdaT0;
				warm.lambdaT1 = row.lambdaT1;
				warm.rho = row.rho;
				warm.rhoT0 = row.rhoT0;
				warm.rhoT1 = row.rhoT1;
				warm.contactOffset = row.contactOffset;
				warm.stick = 0;
				mContactWarm.pushBack(warm);
				mRows.pushBack(row);

				if(ia != PX_MAX_U32)
				{
					mBodies[ia].hasContact = 1;
					if(ib == PX_MAX_U32)
						mBodies[ia].hasStaticTouch = 1;
				}
				if(ib != PX_MAX_U32)
				{
					mBodies[ib].hasContact = 1;
					if(ia == PX_MAX_U32)
						mBodies[ib].hasStaticTouch = 1;
				}
			}
		}
		if(!mNpDomainMode) continue;
		if(!domainPolicy) { ++mNpDomainPolicyExcluded;continue; }
		if(firstRow==mRows.size()) continue;
		AvbdNpDomain domain;domain.restDistance=unit.mRestDistance;
		if(!output.geometry ||
			!avbdCompileNpShape(domain,0,output.geometry->shapes[0],ia) ||
			!avbdCompileNpShape(domain,1,output.geometry->shapes[1],ib))
		{ ++mNpDomainUnsupported;continue; }
		const PxTransform poses[2]={ia<mBodies.size()?PxTransform(mBodies[ia].p,mBodies[ia].q):domain.fixedPose[0],
			ib<mBodies.size()?PxTransform(mBodies[ib].p,mBodies[ib].q):domain.fixedPose[1]};
		double best=-DBL_MAX;PxVec3d axis(0);
		for(PxU32 r=firstRow;r<mRows.size();++r)
		{
			domain.normal=avbdOgcDouble(mRows[r].n).getNormalized();
			for(PxU32 s=0;s<2;++s) if(output.geometry->shapes[s].kind==PxsContactShapeGeometry::ePLANE)
				domain.normal=avbdNpRotation(domain.fixedPose[s].q).rotate(PxVec3d(s?1.0:-1.0,0,0));
			const double gap=avbdNpGap(domain,poses);
			if(gap>best) { best=gap;axis=domain.normal; }
		}
		const bool witnessDirectionSeparated=best>=0;
		if(output.geometry->axisValid && output.geometry->separatingAxis.magnitudeSquared()>0)
		{
			domain.normal=output.geometry->separatingAxis.getNormalized();
			const double gap=avbdNpGap(domain,poses);
			if(gap>best) { best=gap;axis=domain.normal; }
		}
		domain.normal=axis;
		if(!avbdNpDomainPath(domain,poses,poses))
		{
			++mNpDomainUnseparated;
			if(const char* path=std::getenv("PHYSX_AVBD_COMMON_FAILED_NP"))
			if(FILE* file=std::fopen(path,"wb"))
			{
				std::fprintf(file,"{\"reason\":\"initial_axis_unseparated\",\"gap\":%.17g,\"axis\":[%.17g,%.17g,%.17g],\"sides\":[",best,axis.x,axis.y,axis.z);
				for(PxU32 s=0;s<2;++s)
				{
					std::fprintf(file,"%s{\"kind\":%u,\"radius\":%.17g,\"points\":[",s?",":"",PxU32(output.geometry->shapes[s].kind),domain.radius[s]);
					for(PxU32 vertex=0;vertex<domain.points[s].size();++vertex)
					{
						const PxVec3d v=avbdOgcDouble(poses[s].p)+avbdNpRotation(poses[s].q).rotate(domain.points[s][vertex]);
						std::fprintf(file,"%s[%.17g,%.17g,%.17g]",vertex?",":"",v.x,v.y,v.z);
					}
					std::fprintf(file,"]}");
				}
				std::fprintf(file,"]}");std::fclose(file);
			}
			continue;
		}
		if(!witnessDirectionSeparated && best>=0) ++mNpDomainAxisRecovered;
		mNpDomains.pushBack(domain);
		mRows[firstRow].kernelId=eAVBD_ROW_KERNEL_NP_CONTACT;
		mRows[firstRow].geometryIndex=mNpDomains.size();
		if(mStep.commonProgram)
		{
			// Replace the reduced witness manifold with the complete normal
			// cone. Each vertex inequality has one force; no second contact pass.
			PxArray<AvbdRow> source;PxArray<AvbdContactWarm> warmSource;
			bool uniform=true;
			for(PxU32 r=firstRow;r<mRows.size();++r)
			{
				source.pushBack(mRows[r]);warmSource.pushBack(mContactWarm[r]);
				uniform=uniform && mRows[r].mu==mRows[firstRow].mu &&
					mContactWarm[r].materialKey==mContactWarm[firstRow].materialKey;
			}
			if(!uniform){++mNpDomainUnsupported;continue;}
			auto& complete=mNpDomains.back();
			// Kinematics may rotate to a prescribed endpoint this step too.
			const bool rotates[2]={ia<mBodies.size(),ib<mBodies.size()};
			avbdNpCompileFeatures(complete,poses,rotates,firstRow);
			mRows.resize(firstRow);mContactWarm.resize(firstRow);
			for(PxU32 f=0;f<complete.count[0]*complete.count[1];++f)
			{
				PxVec3d arms[2];const double gap=avbdNpFeatureGradient(complete,poses,f,arms);
				const PxVec3d a=avbdOgcDouble(poses[0].p)+arms[0]-axis*domain.radius[0];
				const PxVec3d b=avbdOgcDouble(poses[1].p)+arms[1]+axis*domain.radius[1];
				const PxVec3d location=rotates[0] && !rotates[1]?a:!rotates[0] && rotates[1]?b:(a+b)*.5;
				const PxVec3 point(PxReal(location.x),PxReal(location.y),PxReal(location.z));
				PxU32 nearest=0;double distance=DBL_MAX;
				for(PxU32 r=0;r<source.size();++r)
				{
					const PxVec3 anchor=ia<mBodies.size()?poses[0].transform(source[r].rA):source[r].rA;
					const double d=(avbdOgcDouble(anchor)-location).magnitudeSquared();
					if(d<distance){distance=d;nearest=r;}
				}
				AvbdRow row=source[nearest];AvbdContactWarm warm=warmSource[nearest];
				row.kernelId=eAVBD_ROW_KERNEL_NP_CONTACT;row.geometryIndex=mNpDomains.size();
				row.n=PxVec3(PxReal(axis.x),PxReal(axis.y),PxReal(axis.z));avbdOrthonormalBasis(row.n,row.t0,row.t1);
				row.rA=ia<mBodies.size()?poses[0].transformInv(point):point;
				row.rB=ib<mBodies.size()?poses[1].transformInv(point):point;
				row.ogcRA=row.rA;row.ogcRB=row.rB;row.C0=row.contactOffset=PxReal(gap);
				// Do not transfer reduced-manifold multipliers to new feature IDs.
				row.lambda=row.lambdaT0=row.lambdaT1=0;
				warm.n=row.n;warm.rA=row.rA;warm.rB=row.rB;warm.t0=row.t0;warm.t1=row.t1;
				warm.lambda=warm.lambdaT0=warm.lambdaT1=0;
				for(PxU32 k=1;k<=5;++k)
				{
					row.C0=row.contactOffset=PxReal(gap*5/double(k));
					mRows.pushBack(row);mContactWarm.pushBack(warm);
				}
			}
		}
		if(mNpDomainMode==2)
			for(PxU32 r=firstRow;r<mRows.size();++r)
			{
				// Replace, never add to, the same NP normal's Position-AL law.
				// Use the authored shell, not NP's velocity-inflated query reach.
				mRows[r].contactRadius=PxMax(0.0f,output.geometry->contactDistance-unit.mRestDistance);
				mRows[r].contactStiffness=mOgc.contactStiffness;
			}
	}
	mContactRowCount = mRows.size();
    if(mStep.commonProgram && std::getenv("PHYSX_AVBD_COMMON_STATS"))
    {
        PxU64 pairs=0,largest=0;PxU32 side0=0,side1=0;
        for(const auto& domain:mNpDomains)if(domain.rowStart!=PX_MAX_U32)
        {const PxU64 count=PxU64(domain.count[0])*domain.count[1];pairs+=count;
            if(count>largest){largest=count;side0=domain.count[0];side1=domain.count[1];}}
        std::fprintf(stderr,"[AVBD_NP_CARDINALITY] domains=%u pairs=%llu largest=%llu side0=%u side1=%u rows=%u\n",
            mNpDomains.size(),static_cast<unsigned long long>(pairs),static_cast<unsigned long long>(largest),side0,side1,mContactRowCount);
    }

}

void AvbdDynamicsContext::buildSoftRigidContactRows()
{
	mRows.reserve(mRows.size() + 64);
	for(PxU32 cacheIndex = 0; cacheIndex < mIslandSoftCache.size(); ++cacheIndex)
	{
		AvbdIslandSoftCache& cache = mIslandSoftCache[cacheIndex];
		DeformableVolume* vol = cache.volume;
		if(!vol || !cache.coupled || cache.liveStamp != mIslandSoftLiveStamp ||
			!cache.boxFeatureContacts) continue;
		// World contact is not a component-finalization side channel.  Compile the
		// ground offset potential into the same row program as soft/soft and
		// soft/rigid contact, with one 3x3 support per particle.
		for(PxU32 particleIndex = 0; particleIndex < cache.nbParticles;
			++particleIndex)
		{
			if(cache.particles[particleIndex].invMass <= 0.0f)
				continue;
			AvbdRow row;
			PxMemZero(&row, sizeof(row));
			row.bodyA = row.bodyB = PX_MAX_U32;
			row.supportStart = mRowSupports.size();
			row.n = PxVec3(0.0f, 1.0f, 0.0f);
			avbdOrthonormalBasis(row.n, row.t0, row.t1);
			AvbdRowSupport support;
			support.block = cache.blockStart + particleIndex;
			support.weight = 1.0f;
			support.localPoint = PxVec3(0.0f);
			mRowSupports.pushBack(support);
			row.supportCount = 1;
			row.C0 = -mOgc.contactRadius;
			row.contactOffset = -mOgc.contactRadius;
			row.contactRadius = mOgc.contactRadius;
			row.contactStiffness = mOgc.contactStiffness;
			row.rho = PxMin(row.contactStiffness, AVBD_RHO_MAX);
			row.mu = PxMax(vol->getCore().cpuDynamicFriction, 0.0f);
			row.minLambda = -PX_MAX_REAL;
			row.maxLambda = 0.0f;
			row.flags = PxU8(eAVBD_ROW_UNILATERAL | eAVBD_ROW_CONTACT |
				eAVBD_ROW_HETEROGENEOUS);
			mRows.pushBack(row);
		}
		const PxU32 nDyn = vol->getNbCpuDynamicBoxes();
		const PxU32 nStatic = vol->getNbCpuStaticBoxes();
		AvbdSoftStaticBox sdfBoxes[AVBD_SOFT_MAX_STATIC_BOXES];
		PxU32 sdfBoxCount = 0;
		fillVolumeSdfBoxes(*vol, sdfBoxes, sdfBoxCount);
		// Static geometry has no 6x6 unknown, but its offset energy belongs in
		// the same heterogeneous row program.  OGC regions alone only certify
		// admissibility; omitting this force leaves the material with no boundary
		// objective and allows a volume to remain crushed against the obstacle.
		for(PxU32 ci = 0; ci < cache.boxFeatureContacts->size(); ++ci)
		{
			const AvbdVolumeBoxFeatureContact& contact =
				(*cache.boxFeatureContacts)[ci];
			if(contact.featureType > 4 || contact.boxIndex >= nStatic ||
				contact.boxIndex >= sdfBoxCount)
				continue;
			const AvbdSoftStaticBox& sdfBox = sdfBoxes[contact.boxIndex];
			const PxVec3 rigidPoint = sdfBox.center +
				sdfBox.rotation.rotate(contact.rigidLocalPoint);
			AvbdRow row;
			PxMemZero(&row, sizeof(row));
			row.bodyA = row.bodyB = PX_MAX_U32;
			row.supportStart = mRowSupports.size();
			row.n = contact.normal;
			avbdOrthonormalBasis(row.n, row.t0, row.t1);
			for(PxU32 supportIndex = 0;
				supportIndex < contact.particleCount; ++supportIndex)
			{
				const PxU32 particleIndex = contact.particleIndices[supportIndex];
				if(particleIndex >= cache.nbParticles)
					continue;
				AvbdRowSupport support;
				support.block = cache.blockStart + particleIndex;
				support.weight = contact.weights[supportIndex];
				support.localPoint = PxVec3(0.0f);
				mRowSupports.pushBack(support);
			}
			row.supportCount = PxU16(mRowSupports.size() - row.supportStart);
			if(!row.supportCount)
				continue;
			row.C0 = -contact.margin;
			row.contactOffset = -contact.margin - row.n.dot(rigidPoint);
			row.contactRadius = contact.margin;
			row.contactStiffness = contact.k;
			avbdFinishVolumeBoxContactRow(row, mRowSupports, mBlocks, mBodies, contactGeometry());
			row.lambda = contact.lambda;
			row.mu = PxMax(vol->getCore().cpuDynamicFriction, 0.0f);
			row.minLambda = -PX_MAX_REAL;
			row.maxLambda = 0.0f;
			row.flags = PxU8(eAVBD_ROW_UNILATERAL | eAVBD_ROW_CONTACT |
				eAVBD_ROW_HETEROGENEOUS);
			mRows.pushBack(row);
		}
		if(nDyn == 0) continue;
		const DeformableVolume::CpuDynamicBox* hostDyn = vol->getCpuDynamicBoxes();
		for(PxU32 d = 0; d < nDyn; ++d)
		{
			const PxU32 boxIndex = nStatic + d;
			bool hasFeature = false;
			for(PxU32 ci = 0; ci < cache.boxFeatureContacts->size(); ++ci)
				hasFeature |= (*cache.boxFeatureContacts)[ci].featureType <= 4 &&
					(*cache.boxFeatureContacts)[ci].boxIndex == boxIndex;
			if(!hasFeature) continue;
			PxsBodyCore* bodyCore = hostDyn[d].bodyCore;
			if(!bodyCore) continue;
			PxU32 bodyIdx = findBody(bodyCore);
			if(bodyIdx == PX_MAX_U32)
			{
				if(bodyCore->isKinematic() || bodyCore->inverseMass == 0.0f)
					continue;
				// 6x6 blocks are compiled before this row program.  A body
				// pushed here has no Rigid6 block, so its Jacobian would land
				// on a particle slot and the box would clamp the soft.  Wake
				// for the next step instead of adding an unsolved unknown.
				if(bodyCore->wakeCounter <= 0.0f)
					bodyCore->wakeCounter = AVBD_SOFT_RIGID_WAKE_COUNTER;
				continue;
			}
			AvbdSolverBody& rb = mBodies[bodyIdx];
			if(rb.invMass == 0.0f || rb.isKinematic)
				continue;

			AvbdSoftStaticBox sdfBox;
			avbdFillHostDynSdfBox(sdfBox, hostDyn[d], &rb, mOgc.contactRadius);
			for(PxU32 ci = 0; ci < cache.boxFeatureContacts->size(); ++ci)
			{
				const AvbdVolumeBoxFeatureContact& contact =
					(*cache.boxFeatureContacts)[ci];
				if(contact.featureType > 4 || contact.boxIndex != boxIndex) continue;
				const PxVec3 rigidPoint = sdfBox.center +
					sdfBox.rotation.rotate(contact.rigidLocalPoint);
				AvbdRow row;
				PxMemZero(&row, sizeof(row));
				row.bodyA = bodyIdx;
				row.bodyB = PX_MAX_U32;
				row.supportStart = mRowSupports.size();
				row.n = contact.normal;
				avbdOrthonormalBasis(row.n, row.t0, row.t1);
				row.rA = rb.q.rotateInv(rigidPoint - rb.p);
                if(contact.featureType==3)
                {
                    AvbdContactPlaneGeometry geometry;
                    geometry.normalLocal=rb.q.rotateInv(contact.normal);
                    mContactPlaneGeometry.pushBack(geometry);
                    row.geometryIndex=mContactPlaneGeometry.size();
                }

				for(PxU32 supportIndex = 0;
					supportIndex < contact.particleCount; ++supportIndex)
				{
					const PxU32 particleIndex = contact.particleIndices[supportIndex];
					if(particleIndex >= cache.nbParticles)
						continue;
					AvbdRowSupport support;
					support.block = cache.blockStart + particleIndex;
					support.weight = contact.weights[supportIndex];
					support.localPoint = PxVec3(0.0f);
					mRowSupports.pushBack(support);
				}
				AvbdRowSupport rigidSupport;
				rigidSupport.block = bodyIdx;
				rigidSupport.weight = -1.0f;
				rigidSupport.localPoint = row.rA;
				mRowSupports.pushBack(rigidSupport);
				row.supportCount = PxU16(mRowSupports.size() - row.supportStart);
				row.C0 = -contact.margin;
				row.contactOffset = -contact.margin;
				row.contactRadius = contact.margin;
				row.contactStiffness = contact.k;
				avbdFinishVolumeBoxContactRow(row, mRowSupports, mBlocks, mBodies, contactGeometry());
				row.lambda = contact.lambda;
				// Host geometry does not yet publish a rigid material record for
				// this reduced box fact.  The deformable endpoint's authored
				// coefficient still owns its half of the Coulomb contract; zeroing
				// the row here erased all tangential action and reaction.
				row.mu = PxMax(vol->getCore().cpuDynamicFriction, 0.0f);
				row.minLambda = -PX_MAX_REAL;
				row.maxLambda = 0.0f;
				row.flags = PxU8(eAVBD_ROW_UNILATERAL | eAVBD_ROW_CONTACT |
					eAVBD_ROW_HETEROGENEOUS);
				row.forceWriteback = NULL;
				mRows.pushBack(row);
				// The opposite endpoint is a dynamic deformable block.  It is a
				// contact for warm-start ownership, but never a world support for
				// gravity initialization or sleep classification.
				rb.hasContact = 1;
			}
		}
	}
	for(PxU32 contactIndex = 0; contactIndex < mSoftPairContacts.size();
		++contactIndex)
	{
		const AvbdSoftPairContact& contact = mSoftPairContacts[contactIndex];
		if(contact.queryCache >= mIslandSoftCache.size() ||
			contact.targetCache >= mIslandSoftCache.size())
			continue;
		const AvbdIslandSoftCache& query = mIslandSoftCache[contact.queryCache];
		const AvbdIslandSoftCache& target = mIslandSoftCache[contact.targetCache];
		PxU32 frameFace=contact.targetFace;
		if(contact.featureType==1)
		{
			frameFace=PX_MAX_U32;
			for(PxU32 e=0;e<target.nbBoundaryEdges;++e)
			{
				const AvbdSoftBoundaryEdgeTopology& edge=target.boundaryEdges[e];
				if(edge.v0==contact.targetFace && edge.v1==contact.targetFeature1)
				{ frameFace=edge.face0;break; }
			}
		}
		if(frameFace>=target.nbBoundaryFaces) {
			PxGetFoundation().error(PxErrorCode::eDEBUG_INFO,PX_FL,
				"AVBD domain diagnostic: invalid contact-frame face.");
			mLocalDomainFailed=true;return;
		}
		AvbdContactFrameGeometry frame={};
		AvbdRow row;
		PxMemZero(&row, sizeof(row));
		row.bodyA = PX_MAX_U32;
		row.bodyB = PX_MAX_U32;
		row.supportStart = mRowSupports.size();
		row.n = contact.normal;
		avbdOrthonormalBasis(row.n, row.t0, row.t1);
		for(PxU32 supportIndex = 0;
			supportIndex < contact.queryParticleCount; ++supportIndex)
		{
			const PxU32 particleIndex = contact.queryParticleIndices[supportIndex];
			if(particleIndex >= query.nbParticles)
				continue;
			AvbdRowSupport support;
			support.block = query.blockStart + particleIndex;
			support.weight = contact.queryWeights[supportIndex];
			support.localPoint = PxVec3(0.0f);
			mRowSupports.pushBack(support);
		}
		frame.supportEnds[0]=PxU16(mRowSupports.size()-row.supportStart);
		for(PxU32 supportIndex = 0;
			supportIndex < contact.targetParticleCount; ++supportIndex)
		{
			const PxU32 particleIndex = contact.targetParticleIndices[supportIndex];
			if(particleIndex >= target.nbParticles)
				continue;
			AvbdRowSupport support;
			support.block = target.blockStart + particleIndex;
			support.weight = contact.targetWeights[supportIndex];
			support.localPoint = PxVec3(0.0f);
			mRowSupports.pushBack(support);
		}
		frame.supportEnds[1]=PxU16(mRowSupports.size()-row.supportStart);
		const AvbdSoftBoundaryFace& face=target.boundaryFaces[frameFace];
		for(PxU32 corner=0;corner<3;++corner)
		{
			const AvbdSoftEmbeddedPoint& point=target.collisionPoints[face.vertices[corner]];
			for(PxU32 i=0;i<point.count;++i)
			{
				AvbdRowSupport support={};support.block=target.blockStart+point.particleIndices[i];
				support.weight=point.weights[i];mRowSupports.pushBack(support);
			}
			frame.supportEnds[corner+2]=PxU16(mRowSupports.size()-row.supportStart);
		}
		PxVec3d points[5];
		avbdContactFramePoints(frame,mRowSupports.begin()+row.supportStart,
			[&](const AvbdRowSupport& support){return avbdBlockSupportPoint(mBlocks[support.block],support,mBodies);},points);
		PxVec3d t,y,z;double edgeLength,crossLength;
		if(!avbdContactFrameBasis(points,t,y,z,edgeLength,crossLength)) {
			PxGetFoundation().error(PxErrorCode::eDEBUG_INFO,PX_FL,
				"AVBD domain diagnostic: degenerate contact frame.");
			mLocalDomainFailed=true;return;
		}
		const PxVec3d normal=avbdOgcDouble(contact.normal);
		frame.normalLocal=PxVec3(PxReal(t.dot(normal)),PxReal(y.dot(normal)),PxReal(z.dot(normal)));
		mContactFrameGeometry.pushBack(frame);
		row.kernelId=eAVBD_ROW_KERNEL_CONTACT_FRAME;row.geometryIndex=mContactFrameGeometry.size();
		row.supportCount = PxU16(mRowSupports.size() - row.supportStart);
		if(row.supportCount < 2)
		{
			mRowSupports.forceSize_Unsafe(row.supportStart);
			continue;
		}
		row.C0 = -contact.margin;
		row.contactOffset = -contact.margin;
		row.contactRadius = contact.margin;
		row.contactStiffness = contact.k;
		row.rho = contact.k;
		row.lambda = 0.0f;
		const PxReal queryFriction = query.volume ?
			PxMax(query.volume->getCore().cpuDynamicFriction, 0.0f) : 0.0f;
		const PxReal targetFriction = target.volume ?
			PxMax(target.volume->getCore().cpuDynamicFriction, 0.0f) : 0.0f;
		row.mu = 0.5f * (queryFriction + targetFriction);
		row.minLambda = -PX_MAX_REAL;
		row.maxLambda = 0.0f;
		row.flags = PxU8(eAVBD_ROW_UNILATERAL | eAVBD_ROW_CONTACT |
			eAVBD_ROW_HETEROGENEOUS);
		row.forceWriteback = NULL;
		mRows.pushBack(row);
	}
	mContactRowCount = mRows.size();
}

void AvbdDynamicsContext::buildSurfaceContactRows()
{
	for(PxU32 cacheIndex = 0; cacheIndex < mIslandSurfaceCache.size();
		++cacheIndex)
	{
		AvbdIslandSurfaceCache& cache = mIslandSurfaceCache[cacheIndex];
		if(cache.liveStamp != mIslandSurfaceLiveStamp || !cache.surface ||
			!cache.particles)
			continue;
		const DeformableSurfaceCore& core = cache.surface->getCore();
		const PxReal thickness = PxMax(core.cpuThickness, 1.0e-6f);
		const PxReal friction = PxMax(core.cpuDynamicFriction, 0.0f);
		const DeformableSurface::CpuPlane* planes = cache.surface->getCpuPlanes();
		const PxU32 planeCount = PxMin(cache.surface->getNbCpuPlanes(),
			PxU32(DeformableSurface::eMAX_CPU_PLANES));
		const DeformableSurface::CpuStaticBox* hostBoxes =
			cache.surface->getCpuStaticBoxes();
		const PxU32 boxCount = PxMin(cache.surface->getNbCpuStaticBoxes(),
			PxU32(DeformableSurface::eMAX_CPU_STATIC_BOXES));
		AvbdSoftStaticBox boxes[DeformableSurface::eMAX_CPU_STATIC_BOXES];
		for(PxU32 boxIndex = 0; boxIndex < boxCount; ++boxIndex)
		{
			const PxReal margin = PxMax(hostBoxes[boxIndex].restDistance,
				0.5f * thickness);
			avbdFillSdfBox(boxes[boxIndex], hostBoxes[boxIndex].center,
				hostBoxes[boxIndex].halfExtent, margin, 0.5f * thickness,
				hostBoxes[boxIndex].rotation);
		}

		auto appendParticleRow = [&](PxU32 particleIndex, const PxVec3& normal,
			PxReal offset, PxReal radius, PxReal stiffness, PxReal lambda)
		{
			if(particleIndex >= cache.nbParticles ||
				cache.particles[particleIndex].invMass <= 0.0f ||
				!normal.isFinite() || normal.magnitudeSquared() <= 1.0e-12f)
				return;
			AvbdRow row;
			PxMemZero(&row, sizeof(row));
			row.bodyA = row.bodyB = PX_MAX_U32;
			row.supportStart = mRowSupports.size();
			row.n = normal.getNormalized();
			avbdOrthonormalBasis(row.n, row.t0, row.t1);
			AvbdRowSupport support;
			support.block = cache.blockStart + particleIndex;
			support.weight = 1.0f;
			support.localPoint = PxVec3(0.0f);
			mRowSupports.pushBack(support);
			row.supportCount = 1;
			row.C0 = row.n.dot(cache.particles[particleIndex].p) + offset;
			row.contactOffset = offset;
			row.contactRadius = radius;
			row.contactStiffness = stiffness;
			row.rho = PxMin(stiffness, AVBD_RHO_MAX);
			row.lambda = lambda;
			row.mu = friction;
			row.minLambda = -PX_MAX_REAL;
			row.maxLambda = 0.0f;
			row.flags = PxU8(eAVBD_ROW_UNILATERAL | eAVBD_ROW_CONTACT |
				eAVBD_ROW_HETEROGENEOUS);
			mRows.pushBack(row);
		};

		for(PxU32 particleIndex = 0; particleIndex < cache.nbParticles;
			++particleIndex)
		{
			for(PxU32 planeIndex = 0; planeIndex < planeCount; ++planeIndex)
			{
				const PxReal radius = PxMax(planes[planeIndex].restDistance,
					0.5f * thickness);
				const PxU32 stateIndex = particleIndex *
					DeformableSurface::eMAX_CPU_PLANES + planeIndex;
				appendParticleRow(particleIndex, planes[planeIndex].normal,
					planes[planeIndex].distance - radius, radius,
					mOgc.contactStiffness, cache.planeContactLambda[stateIndex]);
			}
			for(PxU32 boxIndex = 0; boxIndex < boxCount; ++boxIndex)
			{
				PxReal sdf;
				PxVec3 normal;
				if(!avbdSoftEvalBoxSdf(cache.particles[particleIndex].p,
					boxes[boxIndex], sdf, normal))
					continue;
				const PxReal radius = boxes[boxIndex].margin;
				const PxReal offset = sdf - radius - normal.dot(
					cache.particles[particleIndex].p);
				const PxU32 stateIndex = particleIndex *
					DeformableSurface::eMAX_CPU_STATIC_BOXES + boxIndex;
				appendParticleRow(particleIndex, normal, offset, radius,
					mOgc.contactStiffness, cache.boxContactLambda[stateIndex]);
			}
		}

		if(!cache.boxFeatureContacts)
			continue;
		for(PxU32 contactIndex = 0;
			contactIndex < cache.boxFeatureContacts->size(); ++contactIndex)
		{
			const AvbdSurfaceBoxFeatureContact& contact =
				(*cache.boxFeatureContacts)[contactIndex];
			// Type 0: one canonical nearest triangle per rigid vertex.  Type 3
			// triangle/core rows are a different certificate and must not be
			// dropped by that filter.
			if(contact.featureType == 0)
			{
				PxVec3 query(0.0f);
				for(PxU32 supportIndex = 0;
					supportIndex < contact.particleCount; ++supportIndex)
					if(contact.particleIndices[supportIndex] < cache.nbParticles)
						query += cache.particles[contact.particleIndices[supportIndex]].p *
							contact.weights[supportIndex];
				const PxReal distanceSquared =
					(query - contact.surfacePoint).magnitudeSquared();
				bool canonical = true;
				for(PxU32 otherIndex = 0;
					otherIndex < cache.boxFeatureContacts->size(); ++otherIndex)
				{
					if(otherIndex == contactIndex)
						continue;
					const AvbdSurfaceBoxFeatureContact& other =
						(*cache.boxFeatureContacts)[otherIndex];
					if(other.featureType != 0 || other.boxIndex != contact.boxIndex ||
						other.rigidFeature0 != contact.rigidFeature0)
						continue;
					PxVec3 otherQuery(0.0f);
					for(PxU32 supportIndex = 0;
						supportIndex < other.particleCount; ++supportIndex)
						if(other.particleIndices[supportIndex] < cache.nbParticles)
							otherQuery += cache.particles[
								other.particleIndices[supportIndex]].p *
								other.weights[supportIndex];
					const PxReal otherDistanceSquared =
						(otherQuery - other.surfacePoint).magnitudeSquared();
					if(otherDistanceSquared < distanceSquared - 1.0e-12f ||
						(PxAbs(otherDistanceSquared - distanceSquared) <= 1.0e-12f &&
							otherIndex < contactIndex))
					{
						canonical = false;
						break;
					}
				}
				if(!canonical)
					continue;
			}
			if(!contact.normal.isFinite() ||
				contact.normal.magnitudeSquared() <= 1.0e-12f)
				continue;
			AvbdRow row;
			PxMemZero(&row, sizeof(row));
			row.bodyA = row.bodyB = PX_MAX_U32;
			row.supportStart = mRowSupports.size();
			row.n = contact.normal.getNormalized();
			avbdOrthonormalBasis(row.n, row.t0, row.t1);
			for(PxU32 supportIndex = 0;
				supportIndex < contact.particleCount; ++supportIndex)
			{
				const PxU32 particleIndex = contact.particleIndices[supportIndex];
				if(particleIndex >= cache.nbParticles)
					continue;
				AvbdRowSupport support;
				support.block = cache.blockStart + particleIndex;
				support.weight = contact.weights[supportIndex];
				support.localPoint = PxVec3(0.0f);
				mRowSupports.pushBack(support);
			}
			row.supportCount = PxU16(mRowSupports.size() - row.supportStart);
			if(!row.supportCount)
				continue;
			row.contactOffset = -row.n.dot(contact.surfacePoint) - contact.margin;
			row.C0 = avbdHeterogeneousRowC(row, mRowSupports, mBlocks, mBodies, contactGeometry());
			row.contactRadius = contact.margin;
			row.contactStiffness = contact.k;
			row.rho = PxMin(contact.k, AVBD_RHO_MAX);
			row.lambda = contact.lambda;
			row.mu = friction;
			row.minLambda = -PX_MAX_REAL;
			row.maxLambda = 0.0f;
			row.flags = PxU8(eAVBD_ROW_UNILATERAL | eAVBD_ROW_CONTACT |
				eAVBD_ROW_HETEROGENEOUS);
			mRows.pushBack(row);
		}
	}
	mContactRowCount = mRows.size();
}
