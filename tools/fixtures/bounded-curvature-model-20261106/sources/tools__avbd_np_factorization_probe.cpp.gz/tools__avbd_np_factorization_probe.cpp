// Mechanism only: an implicit normal-row separation oracle, not a new solver.
#include "avbd/DyAvbdNpDomain.h"
#include "avbd_probe_foundation.h"
#include <random>
#include <cstdio>
using namespace physx;using namespace physx::Dy;
int main()
{
    AvbdProbeFoundation foundation;std::mt19937 rng(98135);std::normal_distribution<double> random;
    unsigned failures=0,cases=0;double worst=0;PxU64 exhaustiveCalls=0,factorCalls=0;
    for(unsigned test=0;test<20;++test)
    {
        AvbdNpDomain domain;domain.normal=PxVec3d(random(rng),random(rng),random(rng)).getNormalized();
        domain.radius[0]=.1;domain.radius[1]=.2;domain.restDistance=.01;
        const unsigned sizes[2]={test%2?32u:64u,test%2?48u:96u};
        for(unsigned s=0;s<2;++s){domain.count[s]=sizes[s];for(unsigned i=0;i<sizes[s];++i)domain.points[s].pushBack(PxVec3d(random(rng),random(rng),random(rng)));}
        PxTransform start[2]={PxTransform(PxVec3(0,0,0)),PxTransform(PxVec3(0,2,0))},end[2];
        for(unsigned s=0;s<2;++s)end[s]=PxTransform(start[s].p+PxVec3(.03f,-.02f,.01f),PxQuat(float(random(rng)),PxVec3(1.f,.3f,.7f).getNormalized()));
        const PxVec3d dp[2]={PxVec3d(.03,-.04,.07),PxVec3d(-.02,.02,-.03)},dt[2]={PxVec3d(.2,-.1,.3),PxVec3d(-.1,.2,.1)};
        auto linear=[&](const AvbdNpPathFeature& f,unsigned k)
        {return f.gap[k]+domain.normal.dot(dp[0]-dp[1])+f.angular[k][0].dot(dt[0])+f.angular[k][1].dot(dt[1]);};
        const auto base=avbdNpPathFeature(domain,start,end,0);++factorCalls;
        double lo[5],hi[5],reference[5];unsigned a[5]={},b[5]={};
        for(unsigned k=0;k<5;++k)lo[k]=hi[k]=reference[k]=DBL_MAX;
        for(unsigned i=0;i<sizes[0];++i)
        {const auto f=avbdNpPathFeature(domain,start,end,i*sizes[1]);++factorCalls;failures+=!f.valid;
            for(unsigned k=0;k<5;++k)if(linear(f,k)<lo[k]){lo[k]=linear(f,k);a[k]=i;}}
        for(unsigned j=0;j<sizes[1];++j)
        {const auto f=avbdNpPathFeature(domain,start,end,j);++factorCalls;failures+=!f.valid;
            for(unsigned k=0;k<5;++k)if(linear(f,k)<hi[k]){hi[k]=linear(f,k);b[k]=j;}}
        for(unsigned i=0;i<sizes[0];++i)for(unsigned j=0;j<sizes[1];++j)
        {const auto f=avbdNpPathFeature(domain,start,end,i*sizes[1]+j);++exhaustiveCalls;failures+=!f.valid;
            for(unsigned k=0;k<5;++k)reference[k]=std::min(reference[k],linear(f,k));}
        for(unsigned k=0;k<5;++k)
        {
            const auto witness=avbdNpPathFeature(domain,start,end,a[k]*sizes[1]+b[k]);++factorCalls;
            const double error=std::max(std::abs(lo[k]+hi[k]-linear(base,k)-reference[k]),std::abs(linear(witness,k)-reference[k]));
            worst=std::max(worst,error);failures+=error>1.e-11;++cases;
        }
    }
    std::printf("[NP_FACTORIZATION] cases=%u fullCalls=%llu factorCalls=%llu error=%.12g failures=%u production=0\n",
        cases,static_cast<unsigned long long>(exhaustiveCalls),static_cast<unsigned long long>(factorCalls),worst,failures);
    return failures?1:0;
}
