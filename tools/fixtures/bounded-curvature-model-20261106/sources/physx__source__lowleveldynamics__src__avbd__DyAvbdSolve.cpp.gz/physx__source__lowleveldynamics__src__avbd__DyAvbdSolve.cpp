// Copyright (c) 2026 NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: BSD-3-Clause
//
// Rigid step = demo3d solver.cpp + manifold.cpp, then PhysX bounce only.
// ASCII comments: MSVC C4819 on code page 936.

#include "avbd/DyAvbdInternal.h"
#include "avbd/DyAvbdRigidMetric.h"
#include "avbd/DyAvbdBlockGroup.h"
#include "avbd/DyAvbdCommonResponse.h"
#include "avbd/DyAvbdBoundedResponse.h"
#include "avbd/DyAvbdCommonResidual.h"
#include "avbd/DyAvbdCurvatureMetric.h"
#include "avbd/DyAvbdProgramSchedule.h"
#include <cstdio>
#include <string>
#include <cstdlib>
#include "avbd/DyAvbdKernelsScalar.h"
#include "avbd/DyKernelTable.h"
#include "DyFeatherstoneArticulation.h"
#include "DySleep.h"

using namespace physx;
using namespace Dy;

template<class Bodies>
static AvbdElasticFrameEvaluation evaluateElasticFrame(const AvbdRow& row,
    const PxArray<AvbdElasticFrameMaterial>& materials,const Bodies& bodies,
    const KernelTable& kernels,bool derivatives,bool curvature=true)
{
    const PxTransform poses[2]={PxTransform(bodies[row.bodyA].p,bodies[row.bodyA].q),
        PxTransform(bodies[row.bodyB].p,bodies[row.bodyB].q)};
    AvbdElasticFrameEvaluation result;
    AvbdElasticFrameArgs args={&materials[row.geometryIndex-1],poses,derivatives,&result,curvature};
    kernels.launch(AVBD_ELASTIC_FRAME_MATERIAL,&args);return result;
}

template<class Bodies>
static void tetrahedronPoints(const AvbdRow& row, const PxArray<AvbdRowSupport>& supports,
    const Bodies& bodies, PxVec3d* points)
{
    for(PxU32 s=0;s<4;++s)
    {
        const AvbdRowSupport& support=supports[row.supportStart+s];
        const PxVec3 p=support.block<bodies.size() ?
            (support.localPoint.isZero() ? bodies[support.block].p :
                avbdWorldPoint(bodies[support.block],support.localPoint)) : support.localPoint;
        points[s]=PxVec3d(p.x,p.y,p.z);
    }
}

template<class OldBodies,class NewBodies>
static bool tetrahedronPath(const AvbdRow& row,const AvbdTetrahedronMaterial& material,
    const PxArray<AvbdRowSupport>& supports,const OldBodies& oldPoses,const NewBodies& newPoses)
{
    PxVec3d p[4],q[4]; double errors[4]={};
    tetrahedronPoints(row,supports,oldPoses,p); tetrahedronPoints(row,supports,newPoses,q);
    for(PxU32 s=0;s<4;++s)
    {
        const AvbdRowSupport& support=supports[row.supportStart+s];
        // COM anchors follow the translation chord exactly. Their rotations
        // cannot contribute to this path bound, so do not compute four logs.
        if(support.block>=oldPoses.size() || support.localPoint.isZero() ||
            oldPoses[support.block].q==newPoses[support.block].q) continue;
        const double angle=avbdAcceptedRotationDisplacement(oldPoses[support.block].q,newPoses[support.block].q).magnitude();
        errors[s]=double(support.localPoint.magnitude())*angle*angle/8.0;
    }
    return avbdTetrahedronPathAdmissible(material,p,q,errors);
}

AvbdTetrahedronEvaluation AvbdDynamicsContext::evaluateTetrahedron(const AvbdRow& row,
    PxU32 candidateIndex,const PxTransform* candidate) const
{
    PxVec3d points[4];
    if(candidate)
    {
        const AvbdRigidPoseView poses={mBodies,&candidateIndex,candidate,1};
        tetrahedronPoints(row,mRowSupports,poses,points);
    }
    else tetrahedronPoints(row,mRowSupports,mBodies,points);
    AvbdTetrahedronEvaluation result;
    AvbdTetrahedronArgs args={&mTetrahedronMaterials[row.geometryIndex-1],points,&result};
    mKernels.launch(AVBD_TETRAHEDRON_MATERIAL,&args);
    return result;
}

// Start every responding Rigid6 at the common BDF1 inertial target.
// Keep the world rotation chart and public locked axes used by primal.
static bool avbdRigidWarmCandidate(const AvbdSolverBody& b,PxTransform& candidate)
{
	// A log followed by normalized Euler retraction shortens finite rotations.
	// The inertial target is already a pose; preserve a common finite motion.
	candidate.p=b.pHat;
	candidate.q=b.qHat;
	if(b.core && b.core->lockFlags)
	{
		PxVec3 dp=b.pHat-b.p;
		PxQuat relative=b.qHat*b.q.getConjugate();
		if(relative.w<0.0f) relative=-relative;
		// Invert normalize((1,dtheta/2)*q), then project its world axes.
		// A half turn is outside this chart and cannot be silently shortened.
		if(!(relative.w>0.0f)) return false;
		PxVec3 dth=relative.getImaginaryPart()*(2.0f/relative.w);
		if(!dth.isFinite()) return false;
		avbdProjectLockedDelta(b,dp,dth);
		candidate=PxTransform(b.p,b.q);
		avbdApplyDelta(candidate,dp,dth);
	}
	return candidate.p.isFinite() && candidate.q.isFinite();
}

bool AvbdDynamicsContext::admitWarmstartCandidate(const AvbdProgramSubset* subset,PxReal fraction)
{
	// Candidate storage is private until the compiled hard geometry/material
	// domains accept it. Certified NP pairs additionally admit their complete
	// finite support path. The normal law is selected by the compiled row.
	// The inertial objective and DCD epoch stay intact.
	PxArray<PxTransform> poses(mBodies.size());
	PxArray<PxU8> selected(mBodies.size(),subset?0:1);
	if(subset)for(PxU32 b:subset->blocks)selected[b]=1;
	const AvbdRigidPoseView bodies={mBodies,NULL,poses.begin(),poses.size()};
	const PxU32 particleStart=mBodies.size();
	const PxU32 particleCount=mBlocks.size()-particleStart;
	PxArray<AvbdBlock> candidateBlocks;
	if(particleCount) candidateBlocks=mBlocks;
	const PxArray<AvbdBlock>& blocks=particleCount?candidateBlocks:mBlocks;
	PxArray<AvbdSoftParticle> particles;
	particles.resize(particleCount);
	PxArray<AvbdIslandSoftCache> caches(mIslandSoftCache);
	for(PxU32 i=0;i<bodies.size();++i)
	{
		const AvbdSolverBody& b=mBodies[i];
		poses[i]=PxTransform(b.p,b.q);
		if(!selected[i] || b.invMass==0.0f || b.isKinematic) continue;
		if(!avbdRigidWarmCandidate(b,poses[i])) return false;
		if(fraction<1.f)
		{
			poses[i].p=b.p+(poses[i].p-b.p)*fraction;
			PxQuat target=poses[i].q;if(b.q.dot(target)<0)target=-target;
			poses[i].q=(b.q*(1.f-fraction)+target*fraction).getNormalized();
		}
	}
	for(PxU32 i=particleStart;i<blocks.size();++i)
	{
		AvbdBlock& block=candidateBlocks[i];
		if(block.type!=eAVBD_BLOCK_PARTICLE3 || !block.particle) continue;
		AvbdSoftParticle& particle=particles[i-particleStart];
		particle=*block.particle;
		block.particle=&particle;
		if(particle.invMass>0.0f) particle.p=particle.pHat;
		if(!particle.p.isFinite()) return false;
	}
	for(PxU32 i=0;i<caches.size();++i)
	{
		AvbdIslandSoftCache& cache=caches[i];
		if(!cache.coupled || cache.liveStamp!=mIslandSoftLiveStamp || !cache.particles) continue;
		cache.particles=particles.begin()+(cache.blockStart-particleStart);
		for(PxU32 j=0;j<cache.nbTets;++j)
		{
			const PxReal oldDet=avbdSoftTetDomain(cache.tets[j],0,mIslandSoftCache[i].particles).determinant;
			const PxReal newDet=avbdSoftTetDomain(cache.tets[j],0,cache.particles).determinant;
			const PxReal tolerance=4.0f*PX_EPS_F32*(PxAbs(oldDet)+PxAbs(newDet));
			if(!PxIsFinite(newDet) || newDet<PxMin(0.05f,oldDet)-tolerance) return false;
		}
	}
	for(PxU32 i=0;i<blocks.size();++i)
	{
		const AvbdBlock& block=blocks[i];
		if(block.type!=eAVBD_BLOCK_PARTICLE3 || !block.particle || !block.ogcRegion) continue;
		const AvbdOgcPointRegion live=avbdOgcPointRegionAgainstCommittedRigid(
			*block.ogcRegion,bodies,caches);
		if(!avbdOgcPointContains(live,block.particle->p)) return false;
	}
	for(PxU32 i=0;i<bodies.size();++i)
	{
		const AvbdSolverBody& b=mBodies[i];
		if(!selected[i] || !b.ogcRegionValid) continue;
		AvbdOgcRigidRegion live=b.ogcRegion;
		for(PxU32 j=0;j<live.planeCount;++j)
			live.planes[j].partnerDelta=avbdOgcLivePartnerDelta(live.planes[j],bodies,caches);
		if(!avbdOgcRigidContains(live,poses[i].p,poses[i].q)) return false;
	}
	const PxU32 rowCount=subset?subset->rows.size():mRows.size();
	for(PxU32 slot=0;slot<rowCount;++slot)
	{
		const PxU32 i=subset?subset->rows[slot]:slot;
		const AvbdRow& row=mRows[i];
        if(mNpDomainMode==2 && !avbdNpCandidateAdmissible(row,mNpDomains,mBodies,bodies,mKernels)) return false;
        if(row.kernelId==eAVBD_ROW_KERNEL_TETRAHEDRON)
        {
            if(!tetrahedronPath(row,mTetrahedronMaterials[row.geometryIndex-1],mRowSupports,mBodies,bodies)) return false;
            continue;
        }
		if(row.kernelId==eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN)
		{
			AvbdOgcProjectionPlane planes[9];
			avbdCompileTriangleDomain(row,mTriangleDomainGeometry[row.geometryIndex-1],
				mRowSupports,blocks,bodies,PX_MAX_U32,mKernels,planes);
			for(PxU32 j=0;j<9;++j) if(planes[j].b>planes[j].roundoff) return false;
			continue;
		}
		if((row.flags&(eAVBD_ROW_CONTACT|eAVBD_ROW_INACTIVE))!=eAVBD_ROW_CONTACT) continue;
		if(row.supportCount)
		{
			if(!avbdHeterogeneousCandidateAdmissible(row,mRowSupports,mBlocks,mBodies,
				blocks,bodies,contactGeometry())) return false;
		}
	}
	// Publish only the accepted poses; velocities, targets, duals and certificates
	// are unchanged. This is an initial guess, never a parallel primal sweep.
	for(PxU32 i=0;i<mBodies.size();++i) { mBodies[i].p=bodies[i].p; mBodies[i].q=bodies[i].q; }
	for(PxU32 i=particleStart;i<mBlocks.size();++i)
		if(mBlocks[i].type==eAVBD_BLOCK_PARTICLE3 && mBlocks[i].particle)
			mBlocks[i].particle->p=particles[i-particleStart].p;
	return true;
}

void AvbdDynamicsContext::warmstartBlocks()
{
    const char* mode=std::getenv("PHYSX_AVBD_COMMON_STEP");
    if(mode && std::strcmp(mode,"patch")==0 && !mStep.hasParticleBlocks)
    {
        compileRowProgram();if(mLocalDomainFailed)return;
        PxArray<PxU32> components;const auto responds=[&](PxU32 b){return b<mBodies.size() && avbdBodyResponds(mBodies[b]);};
        mRowProgram.components(components,responds,[&](PxU32 r){return !(mRows[r].flags&eAVBD_ROW_INACTIVE);});
        for(PxU32 b=0;b<components.size();++b)if(components[b]==b && responds(b))
        {
            AvbdProgramSubset subset;
            for(PxU32 k=0;k<components.size();++k)if(components[k]==b && responds(k))subset.blocks.pushBack(k);
            subset.collectRows(mRowProgram);PxReal fraction=1.f;bool accepted=false;
            for(PxU32 search=0;search<16;++search,fraction*=.5f)
                if(admitWarmstartCandidate(&subset,fraction)){accepted=true;break;}
            if(std::getenv("PHYSX_AVBD_COMMON_STATS"))std::fprintf(stderr,
                "[AVBD_PATCH_GUESS] blocks=%u fraction=%.9g accepted=%u\n",subset.blocks.size(),double(fraction),unsigned(accepted));
        }
        return;
    }
    // Try the common inertial guess without publishing a partial state.
    // If it is inadmissible, retain the DCD poses as the initial iterate.
    // Projecting pHat block by block can inject elastic energy before the
    // energy-consistent primal solve. Normal GS still solves the same pHat.
    (void)admitWarmstartCandidate();
}

// Heterogeneous (particle-supported) contact normal is the OGC offset
// potential shared with the 3x3 particle blocks. The returned coefficient is
// dE/dd (negative inside the offset shell), in AvbdRow's force sign
// convention. A finite maxImpulse saturates the potential derivative and
// therefore removes the local curvature once the authored limit is reached.
static PxReal avbdJointEndpointMobility(const AvbdSolverBody& b,
	const PxVec3& jLin, const PxVec3& jAng)
{
	if(!avbdBodyResponds(b))
		return 0.0f;
	const PxVec3 jAngLocal = b.qStart.rotateInv(jAng);
	return b.invMass * jLin.magnitudeSquared() +
		jAngLocal.x * jAngLocal.x * b.invInertia.x +
		jAngLocal.y * jAngLocal.y * b.invInertia.y +
		jAngLocal.z * jAngLocal.z * b.invInertia.z;
}

static PxReal avbdDrivePenalty(const AvbdRow& row,
	const PxArray<AvbdSolverBody>& bodies)
{
	PxReal penalty = row.rho;
	if(!row.accelerationDrive)
		return penalty;
	PxReal mobility = 0.0f;
	if(row.bodyA < bodies.size())
		mobility += avbdJointEndpointMobility(
			bodies[row.bodyA], row.jLinA, row.jAngA);
	if(row.bodyB < bodies.size())
		mobility += avbdJointEndpointMobility(
			bodies[row.bodyB], row.jLinB, row.jAngB);
	return mobility > 1.0e-12f && PxIsFinite(mobility) ?
		penalty / mobility : penalty;
}

static PxReal avbdHardJointPenalty(const AvbdRow& row,
	const PxArray<AvbdSolverBody>& bodies, PxReal invH2,
	PxReal* dualStep = NULL)
{
	if(dualStep)
		*dualStep = row.rho;
	if(row.flags & (eAVBD_ROW_CONTACT | eAVBD_ROW_DRIVE |
		eAVBD_ROW_INACTIVE | eAVBD_ROW_SOFT_PAIR))
		return row.rho;
	if(row.flags & eAVBD_ROW_POINT_LOCK)
	{
		// AVBD_2 LocalJointSolve + JointDualPhase form a matched pair:
		// a stiff primal anchor with an inertial-scale, relaxed dual step.
		// Applying the full primal penalty to dual destabilizes accelerated
		// cyclic point-lock graphs. Static endpoints do not contribute mass.
		PxReal minMass = PX_MAX_F32, maxMass = 0.0f;
		const PxU32 endpoints[2] = {row.bodyA, row.bodyB};
		for(PxU32 side = 0; side < 2; ++side)
		{
			if(endpoints[side] >= bodies.size() || !avbdBodyResponds(bodies[endpoints[side]]))
				continue;
			const PxReal mass = 1.0f / bodies[endpoints[side]].invMass;
			minMass = PxMin(minMass, mass);
			maxMass = PxMax(maxMass, mass);
		}
		if(maxMass > 0.0f)
		{
			const PxReal massH2 = minMass * invH2;
			if(dualStep)
				*dualStep = PxMin(massH2, row.rho * (row.rho / (row.rho + massH2)));
			return PxMax(row.rho, maxMass * invH2);
		}
	}
	// Other solverPrep/articulation 1D rows retain the demo3d update:
	// one penalty shared by both endpoints and dual, with a spatial effective
	// mass floor 1 / (h^2 J M^-1 J^T). Their adaptive rho is independent of
	// the fixed point-lock policy above.
	PxReal mobility = 0.0f;
	if(row.bodyA < bodies.size())
		mobility += avbdJointEndpointMobility(bodies[row.bodyA], row.jLinA, row.jAngA);
	if(row.bodyB < bodies.size())
		mobility += avbdJointEndpointMobility(bodies[row.bodyB], row.jLinB, row.jAngB);
	PxReal penalty = row.rho;
	if(PxIsFinite(mobility) && mobility > 1.0e-12f)
	{
		const PxReal massH2 = invH2 / mobility;
		if(PxIsFinite(massH2) && massH2 > 0.0f)
			penalty = PxMax(row.rho, massH2);
	}
	if(dualStep)
		*dualStep = penalty;
	return penalty;
}

static void initializeRigidMaterial(const AvbdSolverBody& b,PxReal H[6][6],PxReal g[6],const AvbdBodyPose* candidate=NULL)
{
	for(PxU32 rr = 0; rr < 6; ++rr)
	{
		g[rr] = 0.0f;
		for(PxU32 cc = 0; cc < 6; ++cc)
			H[rr][cc] = 0.0f;
	}
	H[0][0] = H[1][1] = H[2][2] = b.massInvH2;
	const AvbdRotationPotential rotation =
		avbdRotationInertialPotential(b.qHat, candidate?candidate->q:b.q, b.inertiaWorldInvH2);
	for(PxU32 rr = 0; rr < 3; ++rr)
		for(PxU32 cc = 0; cc < 3; ++cc)
			H[rr + 3][cc + 3] = rotation.gaussNewton[rr][cc];

	const PxVec3 dp = (candidate?candidate->p:b.p) - b.pHat;
	g[0] = b.massInvH2 * dp.x;
	g[1] = b.massInvH2 * dp.y;
	g[2] = b.massInvH2 * dp.z;

	const PxVec3 ga = rotation.gradient;
	g[3] = ga.x;
	g[4] = ga.y;
	g[5] = ga.z;

}

bool AvbdDynamicsContext::accumulateRigidMaterialRow(PxU32 ri,
    const PxU32* blocks,PxU32 count,AvbdRigidAssembly* assemblies)
{
    const AvbdRow& row=mRows[ri];
    if(row.kernelId==eAVBD_ROW_KERNEL_ELASTIC_FRAME)
    {
        const auto e=evaluateElasticFrame(row,mElasticFrameMaterials,mBodies,mKernels,true);
        if(!e.valid){PxAtomicExchange(&mLocalDomainFailed,1);return true;}
        const PxU32 endpoints[2]={row.bodyA,row.bodyB};
        avbdAssembleElasticFrame(ri,e,endpoints,blocks,count,assemblies);return true;
    }
    if(row.kernelId==eAVBD_ROW_KERNEL_TETRAHEDRON)
    {
        const auto e=evaluateTetrahedron(row);
        if(!e.valid){PxAtomicExchange(&mLocalDomainFailed,1);return true;}
        PxU32 supports[4];PxVec3 arms[4];
        for(PxU32 s=0;s<4;++s)
        {
            const auto& support=mRowSupports[row.supportStart+s];supports[s]=support.block;
            arms[s]=support.block<mBodies.size()?mBodies[support.block].q.rotate(support.localPoint):PxVec3(0);
        }
        avbdAssembleTetrahedron(ri,e,supports,arms,blocks,count,assemblies);return true;
    }
    return false;
}

bool AvbdDynamicsContext::compileCommonProgram(AvbdCommonProgram& p,const char*& reason,const AvbdRigidPoseView* candidate,
    const AvbdProgramSubset* subset,bool buildH,bool preserveCurvature)
{
    const AvbdRigidPoseView current={mBodies,NULL,NULL,0};const auto& poses=candidate?*candidate:current;
    reason="invalid_input";
    for(PxU32 b=0;b<mBlocks.size();++b)if(mBlocks[b].type!=eAVBD_BLOCK_RIGID6)
    {reason="particle_material_uncompiled";return false;}
    PxArray<PxU32> index(mBodies.size(),PX_MAX_U32);
    const PxU32 blockCount=subset?subset->blocks.size():mBodies.size();
    for(PxU32 slot=0;slot<blockCount;++slot)
    {
        const PxU32 b=subset?subset->blocks[slot]:slot;if(!avbdBodyResponds(mBodies[b]))continue;
        index[b]=p.dimensions.size();p.dimensions.pushBack(6);p.sourceBlocks.pushBack(b);
        const auto pose=poses[b];
        const auto& body=mBodies[b];const PxVec3d dp=avbdOgcDouble(pose.p)-avbdOgcDouble(body.pHat);
        const PxMat33d inertia(avbdOgcDouble(body.inertiaWorldInvH2.column0),
            avbdOgcDouble(body.inertiaWorldInvH2.column1),avbdOgcDouble(body.inertiaWorldInvH2.column2));
        const auto rotation=avbdRotationInertialPotential<double>(avbdNpRotation(body.qHat),avbdNpRotation(pose.q),inertia);
        for(PxU32 d=0;d<3;++d)
        {
            p.energyPairs.pushBack({dp[d],double(body.massInvH2)*dp[d]});
            p.energyPairs.pushBack({rotation.coordinate[d],rotation.conjugate[d]});
        }
        const PxU32 locked=mBodies[b].core?PxU32(mBodies[b].core->lockFlags):0;
        AvbdCommonHBlock entry={};entry.row=entry.column=index[b];
        for(PxU32 d=0;d<6;++d)
        {
            p.base.pushBack(locked&(1u<<d)?0:-(d<3?double(body.massInvH2)*dp[d]:rotation.gradient[d-3]));
            for(PxU32 k=0;k<6;++k)entry.values[6*d+k]=(locked&((1u<<d)|(1u<<k)))?(d==k?1:0):
                d<3?(d==k?double(body.massInvH2):0):k<3?0:rotation.gaussNewton[d-3][k-3];
        }
        if(buildH)p.H.pushBack(entry);
    }
    AvbdNpPathFeature cachedPath={};PxU32 cachedDomain=PX_MAX_U32,cachedFeature=PX_MAX_U32;
    const PxU32 rowCount=subset?subset->rows.size():mRows.size();
    for(PxU32 slot=0;slot<rowCount;++slot)
    {
        const PxU32 r=subset?subset->rows[slot]:slot;
        const AvbdRow& row=mRows[r];if(row.flags&eAVBD_ROW_INACTIVE)continue;
        if(row.kernelId==eAVBD_ROW_KERNEL_ELASTIC_FRAME || row.kernelId==eAVBD_ROW_KERNEL_TETRAHEDRON)
        {
            PxU32 ids[4],count=0;bool overflow=false;
            mRowProgram.forEachBlock(r,[&](PxU32 b)
            {if(b<index.size() && index[b]!=PX_MAX_U32){if(count<4)ids[count++]=b;else overflow=true;}});
            if(overflow){reason="material_support_overflow";return false;}
            const PxU32 rank=row.kernelId==eAVBD_ROW_KERNEL_ELASTIC_FRAME?9:1,offsets[2]={0,rank};
            AvbdRigidAssemblyT<double> assembled[4]={};AvbdGroupFactor factors[9]={};
            double frameH[81]={};
            for(PxU32 s=0;s<count;++s)
            {
                auto& a=assembled[s];a.coupledRows=&r;a.count=1;a.member=s;a.factorOffsets=offsets;
                a.factors=factors;a.consistent=true;a.lockedMask=mBodies[ids[s]].core?PxU32(mBodies[ids[s]].core->lockFlags):0;
            }
            if(rank==9)
            {
                const auto e=evaluateElasticFrame(row,mElasticFrameMaterials,poses,mKernels,true,buildH);
                if(!e.valid){reason="invalid_frame_material";return false;}
                if(preserveCurvature && buildH && p.metricH.empty())p.metricH=p.H;
                for(PxU32 k=0;k<FINITE_JOINT_ROWS;++k)p.energyPairs.pushBack({e.energyPairs[k][0],e.energyPairs[k][1]});
                const PxU32 ends[2]={row.bodyA,row.bodyB};avbdAssembleElasticFrame(r,e,ends,ids,count,assembled);
                if(preserveCurvature && buildH)for(PxU32 k=0;k<81;++k)frameH[k]=e.hessian[k];
            }
            else
            {
                PxVec3d points[4];tetrahedronPoints(row,mRowSupports,poses,points);
                AvbdTetrahedronEvaluation e;AvbdTetrahedronArgs args={&mTetrahedronMaterials[row.geometryIndex-1],points,&e};
                mKernels.launch(AVBD_TETRAHEDRON_MATERIAL,&args);if(!e.valid){reason="invalid_tet_material";return false;}
                p.materialEnergies.pushBack(e.energy);
                PxU32 supports[4];PxVec3 arms[4];
                for(PxU32 s=0;s<4;++s)
                {const auto& v=mRowSupports[row.supportStart+s];supports[s]=v.block;arms[s]=v.block<mBodies.size()?poses[v.block].q.rotate(v.localPoint):PxVec3(0);}
                avbdAssembleTetrahedron(r,e,supports,arms,ids,count,assembled);
            }
            for(PxU32 s=0;s<count;++s)
            {
                if(!assembled[s].consistent){reason="inconsistent_material";return false;}
                for(PxU32 d=0;d<6;++d)if(!(assembled[s].lockedMask&(1u<<d)))p.base[6*index[ids[s]]+d]-=assembled[s].gradient[d];
                for(PxU32 t=0;buildH && t<count;++t)
                {
                    AvbdCommonHBlock entry={};entry.row=index[ids[s]];entry.column=index[ids[t]];
                    // The PSD operator is the numerical metric. In the bounded
                    // native-frame path retain the original signed second
                    // variation in the model, including every cross-body term.
                    for(PxU32 f=0;f<rank;++f)for(PxU32 d=0;d<6;++d)for(PxU32 k=0;k<6;++k)
                        entry.values[6*d+k]+=double(factors[f].curvature)*factors[f].jacobian[s][d]*double(factors[f].jacobian[t][k]);
                    if(!p.metricH.empty())
                    {
                        p.metricH.pushBack(entry);
                        if(rank==9)
                        {
                            for(double& v:entry.values)v=0;
                            const PxU32 ends[2]={row.bodyA,row.bodyB};
                            for(PxU32 a=0;a<2;++a)if(ends[a]==ids[s])for(PxU32 b=0;b<2;++b)if(ends[b]==ids[t])
                                for(PxU32 d=0;d<6;++d)for(PxU32 k=0;k<6;++k)
                                    if(!(assembled[s].lockedMask&(1u<<d)) && !(assembled[t].lockedMask&(1u<<k)))
                                        entry.values[6*d+k]+=(a && d<3?-1:1)*(b && k<3?-1:1)*
                                            frameH[9*(d<3?d:d+3*a)+(k<3?k:k+3*b)];
                        }
                    }
                    p.H.pushBack(entry);
                }
            }
            continue;
        }
        if(row.supportCount || (row.kernelId!=eAVBD_ROW_KERNEL_CONSTRAINT &&
            row.kernelId!=eAVBD_ROW_KERNEL_NP_CONTACT && row.kernelId!=eAVBD_ROW_KERNEL_FINITE_SPRING))
        {reason="row_kernel_uncompiled";return false;}
        const bool contact=(row.flags&eAVBD_ROW_CONTACT)!=0;
        if(contact && row.mu>0 && !row.positionTangent)
        {reason="velocity_contact_uncompiled";return false;}
        const PxU32 group=p.mu.size();const bool friction=contact && row.mu>0;
        p.sourceRows.pushBack(r);p.mu.pushBack(friction?row.mu:0);p.coulomb.pushBack(friction?1:0);
        const AvbdNpDomain* domain=row.kernelId==eAVBD_ROW_KERNEL_NP_CONTACT?&mNpDomains[row.geometryIndex-1]:NULL;
        PxVec3d normalAngular[2];double C=avbdEvalC(row,poses);
        if(domain)
        {
            const PxTransform states[2]={row.bodyA<poses.size()?PxTransform(poses[row.bodyA].p,poses[row.bodyA].q):domain->fixedPose[0],
                row.bodyB<poses.size()?PxTransform(poses[row.bodyB].p,poses[row.bodyB].q):domain->fixedPose[1]};
            if(domain->rowStart==PX_MAX_U32)
            {
                PxVec3d arms[2];C=avbdNpGapGradient(*domain,states,arms);
                for(PxU32 s=0;s<2;++s)normalAngular[s]=arms[s].cross(domain->normal*(s?-1.:1.));
            }
            else
            {
                const PxTransform start[2]={row.bodyA<mBodies.size()?PxTransform(mBodies[row.bodyA].pStart,mBodies[row.bodyA].qStart):domain->fixedPose[0],
                    row.bodyB<mBodies.size()?PxTransform(mBodies[row.bodyB].pStart,mBodies[row.bodyB].qStart):domain->fixedPose[1]};
                const PxU32 feature=(r-domain->rowStart)/5,k=(r-domain->rowStart)%5;
                if(cachedDomain!=row.geometryIndex || cachedFeature!=feature)
                {cachedPath=avbdNpPathFeature(*domain,start,states,feature);cachedDomain=row.geometryIndex;cachedFeature=feature;}
                if(!cachedPath.valid){reason="singular_np_path";return false;}
                C=cachedPath.gap[k];for(PxU32 s=0;s<2;++s)normalAngular[s]=cachedPath.angular[k][s];
            }
        }
        PxVec3d rel(0);
        if(contact)
        {
            PxVec3d points[2]={avbdOgcDouble(row.ogcRA),avbdOgcDouble(row.ogcRB)};
            const PxU32 ids[2]={row.bodyA,row.bodyB};const PxVec3 anchors[2]={row.rA,row.rB},normals[2]={row.ogcRA,row.ogcRB};
            for(PxU32 s=0;s<2;++s)if(ids[s]<poses.size())
            {
                const auto body=poses[ids[s]];
                rel+=avbdNpPointMotion(body.p,body.q,body.pStart,body.qStart,anchors[s])*(s?-1.:1.);
                points[s]=avbdOgcDouble(body.p)+avbdNpRotation(body.q).rotate(avbdOgcDouble(normals[s]));
            }
            if(!domain)C=avbdOgcDouble(row.n).dot(points[0]-points[1])+double(row.contactOffset);
        }
        const double stiffness=(row.flags&eAVBD_ROW_DRIVE)?double(avbdDrivePenalty(row,mBodies)):0;
        if((row.flags&eAVBD_ROW_DRIVE) && !(stiffness>0)) {reason="invalid_drive";return false;}
        // PX_MAX_REAL is PhysX's unbounded sentinel, not an authored finite
        // cap. Treating it as finite multiplies roundoff gap by ~1e38 in the
        // upper-bound complementarity check and can prevent termination.
        auto bound=[](PxReal v)->double
        {return v==PX_MAX_REAL?std::numeric_limits<double>::infinity():
            v==-PX_MAX_REAL?-std::numeric_limits<double>::infinity():double(v);};
        for(PxU32 q=0;q<3;++q)
        {
            p.offset.pushBack(q==0?C:(friction?avbdOgcDouble(q==1?row.t0:row.t1).dot(rel):0));
            p.compliance.pushBack(q==0 && stiffness>0?1/stiffness:0);
            p.lower.pushBack(q==0?(contact?0:-bound(row.maxLambda)):(friction?-std::numeric_limits<double>::infinity():0));
            p.upper.pushBack(q==0?-bound(row.minLambda):(friction?std::numeric_limits<double>::infinity():0));
        }
        bool valid=true;
        mRowProgram.forEachBlock(r,[&](PxU32 b)
        {
            if(b>=index.size()){valid=false;return;}if(index[b]==PX_MAX_U32)return;
            PxReal value;PxVec3 linear,angular;
            if(!linearizeRigidRow(row,b,value,linear,angular,&poses)){valid=false;return;}
            AvbdCommonJBlock entry={};entry.row=group;entry.column=index[b];
            const PxU32 locked=mBodies[b].core?PxU32(mBodies[b].core->lockFlags):0;
            for(PxU32 q=0;q<(friction?3u:1u);++q)
            {
                if(contact && (q || !domain))
                {
                    const bool a=row.bodyA==b;const PxVec3d n=avbdOgcDouble(q?(q==1?row.t0:row.t1):row.n)*(a?1.:-1.);
                    const PxVec3 anchor=q?(a?row.rA:row.rB):(a?row.ogcRA:row.ogcRB);
                    const PxVec3d torque=avbdNpRotation(poses[b].q).rotate(avbdOgcDouble(anchor)).cross(n);
                    for(PxU32 d=0;d<3;++d)
                    {entry.values[6*q+d]=(locked&(1u<<d))?0:n[d];entry.values[6*q+d+3]=(locked&(1u<<(d+3)))?0:torque[d];}
                    continue;
                }
                for(PxU32 d=0;d<3;++d)
                {entry.values[6*q+d]=(locked&(1u<<d))?0:linear[d];entry.values[6*q+d+3]=(locked&(1u<<(d+3)))?0:angular[d];}
                if(q==0 && domain)
                {
                    const PxU32 side=row.bodyA==b?0:1;const PxVec3d n=domain->normal*(side?-1.:1.);
                    const PxVec3d torque=normalAngular[side];
                    for(PxU32 d=0;d<3;++d)
                    {entry.values[d]=(locked&(1u<<d))?0:n[d];entry.values[d+3]=(locked&(1u<<(d+3)))?0:torque[d];}
                }
            }
            p.J.pushBack(entry);
        });
        if(!valid){reason="row_linearization_failed";return false;}
    }
    if(!p.finish()){reason="numeric_program_invalid";return false;}
    if(!p.metricH.empty())for(PxU32 e=0;e<p.H.size();++e)if(p.H[e].row==p.H[e].column)
        if(!avbdRegularizeLocalCurvature(p.H[e].values,p.metricBlock(e).values,p.dimensions[p.H[e].row]))
        {reason="invalid_local_curvature";return false;}

    reason="ok";return true;
}

bool AvbdDynamicsContext::commonCapability()
{
    for(const auto& block:mBlocks)if(block.type!=eAVBD_BLOCK_RIGID6)
    {std::fprintf(stderr,"[AVBD_COMMON_STEP] stage=compile reason=particle_material_uncompiled status=FAIL\n");return false;}
    const char* unsupported=NULL;
    if(mNpDomainUnsupported || mNpDomainUnseparated)unsupported="np_geometry_or_initial_recovery_uncompiled";
    for(const auto& domain:mNpDomains)if(domain.restDistance<0)unsupported="negative_rest_distance_uncompiled";
    for(const auto& row:mRows)if(!(row.flags&eAVBD_ROW_INACTIVE) && row.restitution>0)unsupported="restitution_uncompiled";
    if(unsupported)
    {std::fprintf(stderr,"[AVBD_COMMON_STEP] stage=capability reason=%s status=FAIL\n",unsupported);return false;}
    return true;
}

bool AvbdDynamicsContext::solveCommonCandidate(bool& stationary)
{
    if(!commonCapability())return false;
    PxArray<PxU32> components;const auto responds=[&](PxU32 b)
    {return b<mBodies.size() && avbdBodyResponds(mBodies[b]);};
    const char* mode=std::getenv("PHYSX_AVBD_COMMON_STEP");
    if(mode && std::strcmp(mode,"patch")==0)
    {
        AvbdProgramSchedule schedule;
        schedule.compile(mRowProgram,responds,[&](PxU32 r){return !(mRows[r].flags&eAVBD_ROW_INACTIVE);},[&](PxU32 r)
        {return mRows[r].kernelId==eAVBD_ROW_KERNEL_ELASTIC_FRAME || mRows[r].kernelId==eAVBD_ROW_KERNEL_TETRAHEDRON;});
        stationary=true;PxU32 skipped=0;
        for(PxU32 c=0;c+1<schedule.colorOffsets.size();++c)
            for(PxU32 s=schedule.colorOffsets[c];s<schedule.colorOffsets[c+1];++s)
            {
                const PxU32 g=schedule.colorGroups[s];const auto& subset=schedule.groups[g];bool closed=false;
                const PxU32 idle=mPrimalIdleIteration[subset.blocks[0]];bool unchanged=idle!=0;
                for(PxU32 b:subset.blocks)unchanged=unchanged && mPrimalIdleIteration[b]==idle && mPrimalChangedIteration[b]<idle;
                for(PxU32 r:subset.rows)if(unchanged)
                {
                    const auto kernel=mRows[r].kernelId;
                    unchanged=kernel==eAVBD_ROW_KERNEL_ELASTIC_FRAME || kernel==eAVBD_ROW_KERNEL_TETRAHEDRON || kernel==eAVBD_ROW_KERNEL_NP_CONTACT;
                    mRowProgram.forEachBlock(r,[&](PxU32 b){unchanged=unchanged && mPrimalChangedIteration[b]<idle;});
                }
                if(unchanged){++skipped;continue;}
                if(!solveCommonComponent(schedule.groups[g],closed))
                {
                    if(std::getenv("PHYSX_AVBD_COMMON_STATS"))std::fprintf(stderr,
                        "[AVBD_PATCH_FAILURE] iteration=%u group=%u blocks=%u rows=%u firstBlock=%u\n",
                        mStep.iteration,g,schedule.groups[g].blocks.size(),schedule.groups[g].rows.size(),schedule.groups[g].blocks[0]);
                    return false;
                }
                for(PxU32 b:subset.blocks)mPrimalIdleIteration[b]=closed?mStep.iteration+1:0;
                stationary=stationary && closed;
            }
        if(stationary)
        {
            // Conditional patch equilibria alone cannot qualify a collective
            // weak mode. Only near a quiet sweep check the original full-H
            // correction, without a new force solve or a physical update.
            AvbdCommonProgram p;const char* reason;
            if(!compileCommonProgram(p,reason))return false;
            PxArray<double> force(p.offset.size()),tolerance(p.base.size());
            for(PxU32 r=0;r<p.sourceRows.size();++r)
            {const auto& row=mRows[p.sourceRows[r]];force[3*r]=-row.lambda;force[3*r+1]=-row.lambdaT0;force[3*r+2]=-row.lambdaT1;}
            for(PxU32 b=0;b<p.sourceBlocks.size();++b)for(PxU32 d=0;d<6;++d)
                tolerance[6*b+d]=d<3?getLengthScale()*AVBD_ARTIC_POSITION_REL_TOL:AVBD_ARTIC_ROTATION_TOL;
            const AvbdCommonResidual metric(p);stationary=metric.smallRoot(p,force.begin(),tolerance.begin());
            if(stationary)
            {
                AvbdLocalResponse response(p,mKernels);PxArray<double> rhs(p.base.size()),correction(p.base.size());
                p.transpose(force.begin(),rhs.begin());for(PxU32 d=0;d<rhs.size();++d)rhs[d]+=p.base[d];
                if(!response.material(rhs.begin(),correction.begin()))return false;
                for(PxU32 d=0;d<rhs.size();++d)stationary=stationary && std::abs(correction[d])<=tolerance[d];
            }
        }
        writeJointDualState();
        if(std::getenv("PHYSX_AVBD_COMMON_STATS"))std::fprintf(stderr,
            "[AVBD_PATCH_SWEEP] iteration=%u groups=%u colors=%u maxBlocks=%u skipped=%u stationary=%u\n",
            mStep.iteration,schedule.groups.size(),schedule.colorOffsets.size()-1,schedule.maximumBlocks,skipped,unsigned(stationary));
        return true;
    }
    mRowProgram.components(components,responds,[&](PxU32 r){return !(mRows[r].flags&eAVBD_ROW_INACTIVE);});
    // A closed, disconnected component with step-constant payloads cannot
    // change while another component iterates. Reuse the existing idle state;
    // solverPrep/artic coordinates conservatively reevaluate after refresh.
    PxArray<PxU8> constant(components.size(),1);
    for(PxU32 r=0;r<mRows.size();++r)
        if(mRows[r].kernelId!=eAVBD_ROW_KERNEL_NP_CONTACT && mRows[r].kernelId!=eAVBD_ROW_KERNEL_ELASTIC_FRAME &&
            mRows[r].kernelId!=eAVBD_ROW_KERNEL_TETRAHEDRON)
            mRowProgram.forEachBlock(r,[&](PxU32 b){if(responds(b))constant[components[b]]=0;});
    stationary=true;PxU32 count=0,skipped=0;
    for(PxU32 b=0;b<components.size();++b)if(components[b]==b && responds(b))
    {
        ++count;bool idle=constant[b]!=0;
        for(PxU32 k=0;k<components.size() && idle;++k)if(components[k]==b && responds(k))idle=mPrimalIdleIteration[k]!=0;
        if(idle){++skipped;continue;}
        AvbdProgramSubset subset;
        for(PxU32 k=0;k<components.size();++k)if(components[k]==b && responds(k))subset.blocks.pushBack(k);
        subset.collectRows(mRowProgram);
        bool closed=false;if(!solveCommonComponent(subset,closed))return false;
        stationary=stationary && closed;
        for(PxU32 k=0;k<components.size();++k)if(components[k]==b && responds(k))mPrimalIdleIteration[k]=closed?mStep.iteration+1:0;
    }
    writeJointDualState();
    if(std::getenv("PHYSX_AVBD_COMMON_STATS"))
        std::fprintf(stderr,"[AVBD_COMMON_COMPONENTS] iteration=%u count=%u skipped=%u stationary=%u\n",mStep.iteration,count,skipped,unsigned(stationary));
    return true;
}

// Numerical and candidate scratch for ONE existing row program. The pending
// request permits the Host continuation to yield without retaining stack data.
// Original physical poses and duals remain owned by mBodies/mRows until admission.
namespace physx { namespace Dy {
struct AvbdCommonPublication : public PxUserAllocated
{
    enum Phase {Direction,SecondOrder,Correction,Trial,Admission,DirectionCertificate};
    Phase phase=Direction;
    AvbdProgramSubset subset;
    AvbdCommonProgram p,actual,linear;
    AvbdCommonResidual metric;
    AvbdCommonResponse* reference=NULL;
    PxArray<double> previous,force,step,trial,motionTolerance,rhs,correction,originalOffset;
    PxArray<double> uncorrectedStep,uncorrectedForce;
    PxArray<PxTransform> candidate;
    AvbdCoulombNcpResult result={},uncorrectedResult={};
    double initial=0,requested=0,fraction=1,lastMerit=std::numeric_limits<double>::infinity();
    double uncorrectedRequested=0,correctionRatio=0;
    PxU32 search=0,secondOrderSearch=PX_MAX_U32,uncorrectedGroups=0,correctionIndex=PX_MAX_U32;
    PxU32 activeGroups=0,materialProducts=0,numericalSweeps=0;
    bool patch=false,bounded=false,solved=false,valid=true,secondOrderAttempted=false;
    bool closed=false,rootSmall=false,finished=false;
    const char* rejection="none";
    AvbdCommonPublication():metric(p){}
    ~AvbdCommonPublication(){PX_DELETE(reference);}
};
} }

void AvbdDynamicsContext::clearCommonPublication()
{
    PX_DELETE(mBoundedResponse);PX_DELETE(mCommonPublication);
    mBoundedResponse=NULL;mCommonPublication=NULL;mBoundedCursor=0;
}

bool AvbdDynamicsContext::beginCommonPublication(const AvbdProgramSubset& subset,bool bounded)
{
    clearCommonPublication();mCommonPublication=PX_NEW(AvbdCommonPublication)();
    auto& s=*mCommonPublication;s.subset=subset;s.bounded=bounded;
    const char* mode=std::getenv("PHYSX_AVBD_COMMON_STEP");s.patch=mode && std::strcmp(mode,"patch")==0;
    const char* reason="ok";auto& p=s.p;
    if(!compileCommonProgram(p,reason,NULL,&subset,true,bounded))
    {std::fprintf(stderr,"[AVBD_COMMON_STEP] iteration=%u stage=compile reason=%s status=FAIL\n",mStep.iteration,reason);return false;}
    s.previous.resize(p.offset.size());s.force.resize(p.offset.size());
    for(PxU32 r=0;r<p.sourceRows.size();++r)
    {
        const auto& row=mRows[p.sourceRows[r]];
        s.previous[3*r]=-double(row.lambda);s.previous[3*r+1]=-double(row.lambdaT0);s.previous[3*r+2]=-double(row.lambdaT1);
        for(PxU32 q=0;q<3;++q)s.force[3*r+q]=(s.patch || bounded)?0:s.previous[3*r+q];
    }
    s.motionTolerance.resize(p.base.size());
    for(PxU32 b=0;b<p.sourceBlocks.size();++b)for(PxU32 d=0;d<6;++d)
        s.motionTolerance[6*b+d]=d<3?getLengthScale()*AVBD_ARTIC_POSITION_REL_TOL:AVBD_ARTIC_ROTATION_TOL;
    if(!bounded)
    {
        s.reference=PX_NEW(AvbdCommonResponse)(p,mKernels,s.patch || (mode && std::strcmp(mode,"local")==0));
        if(s.reference->local)s.reference->local->motionTolerance=s.motionTolerance;
    }
    s.metric=AvbdCommonResidual(p);s.initial=s.metric.evaluate(p,s.previous.begin());
    s.candidate.resize(s.patch?p.sourceBlocks.size():mBodies.size());s.trial.resize(s.force.size());
    return true;
}

bool AvbdDynamicsContext::solveCommonComponent(const AvbdProgramSubset& subset,bool& stationary)
{
    if(!beginCommonPublication(subset,false)){clearCommonPublication();return false;}
    auto& s=*mCommonPublication;bool ok=true;
    do
    {
        if(s.phase==AvbdCommonPublication::Correction)s.solved=s.reference->material(s.rhs.begin(),s.correction.begin());
        else s.solved=s.reference->solve(s.step,s.force,s.result,s.patch);
        s.valid=s.reference->valid;s.activeGroups=s.reference->activeGroups;s.materialProducts=s.reference->materialProducts;
        ok=resumeCommonPublication(stationary);
    } while(ok && !s.finished);
    clearCommonPublication();return ok;
}

bool AvbdDynamicsContext::beginBoundedCommon()
{
    if(!commonCapability())return false;
    clearCommonPublication();PxArray<PxU32> components;
    const auto responds=[&](PxU32 b){return b<mBodies.size() && avbdBodyResponds(mBodies[b]);};
    mRowProgram.components(components,responds,[&](PxU32 r){return !(mRows[r].flags&eAVBD_ROW_INACTIVE);});
    // CSR only schedules the existing connected row program. A static support
    // is an input, not a bridge that couples independent dynamic searches.
    auto& offsets=mStep.commonOffsets;offsets.resize(components.size()+1);
    for(auto& value:offsets)value=0;
    for(PxU32 b=0;b<components.size();++b)if(responds(b))++offsets[components[b]+1];
    for(PxU32 b=1;b<offsets.size();++b)offsets[b]+=offsets[b-1];
    mStep.commonBlocks.resize(offsets.back());PxArray<PxU32> cursor=offsets;
    for(PxU32 b=0;b<components.size();++b)if(responds(b))mStep.commonBlocks[cursor[components[b]]++]=b;
    mStep.commonConstant.resize(components.size());for(auto& value:mStep.commonConstant)value=1;
    for(PxU32 r=0;r<mRows.size();++r)
        if(mRows[r].kernelId!=eAVBD_ROW_KERNEL_NP_CONTACT && mRows[r].kernelId!=eAVBD_ROW_KERNEL_ELASTIC_FRAME &&
           mRows[r].kernelId!=eAVBD_ROW_KERNEL_TETRAHEDRON)
            mRowProgram.forEachBlock(r,[&](PxU32 b){if(responds(b))mStep.commonConstant[components[b]]=0;});
    mStep.commonComponent=0;mStep.commonClosed=true;
    return nextBoundedCommonComponent();
}

bool AvbdDynamicsContext::nextBoundedCommonComponent()
{
    const auto& offsets=mStep.commonOffsets;
    for(;mStep.commonComponent+1<offsets.size();++mStep.commonComponent)
    {
        const PxU32 c=mStep.commonComponent,begin=offsets[c],end=offsets[c+1];if(begin==end)continue;
        bool idle=mStep.commonConstant[c]!=0;
        for(PxU32 i=begin;i<end && idle;++i)idle=mPrimalIdleIteration[mStep.commonBlocks[i]]!=0;
        if(idle)continue;
        AvbdProgramSubset subset;
        for(PxU32 i=begin;i<end;++i)subset.blocks.pushBack(mStep.commonBlocks[i]);
        subset.collectRows(mRowProgram);
        if(!beginCommonPublication(subset,true))return false;
        startBoundedResponse();return true;
    }
    return true;
}

void AvbdDynamicsContext::startBoundedResponse()
{
    auto& s=*mCommonPublication;PX_DELETE(mBoundedResponse);mBoundedResponse=NULL;
    if(s.phase==AvbdCommonPublication::Correction || s.phase==AvbdCommonPublication::DirectionCertificate)
    {
        // The original complete PSD metric defines the unchanged engineering
        // certificate; the model operator can retain signed material curvature.
        // Both requests use the identical bounded 3/6 block executor.
        if(s.linear.dimensions.empty())
        {s.linear.dimensions=s.p.dimensions;s.linear.sourceBlocks=s.p.sourceBlocks;
         s.linear.H=s.p.metricH.empty()?s.p.H:s.p.metricH;s.linear.base=s.rhs;s.linear.finish();}
        else s.linear.base=s.rhs;
        mBoundedResponse=PX_NEW(AvbdBoundedResponse)(s.linear);
    }
    else mBoundedResponse=PX_NEW(AvbdBoundedResponse)(s.p,s.force.begin());
    mBoundedCursor=0;
}

bool AvbdDynamicsContext::completeBoundedCommon(bool& done,bool& stationary)
{
    if(!mBoundedResponse){done=true;stationary=mStep.commonClosed;writeJointDualState();return true;}
    auto& s=*mCommonPublication;const auto& response=*mBoundedResponse;done=false;
    s.solved=response.status==AvbdBoundedResponse::Converged;
    s.valid=response.status!=AvbdBoundedResponse::NumericalFailure && response.status!=AvbdBoundedResponse::Unsupported;
    s.numericalSweeps+=response.sweeps;
    mStep.boundedSweeps+=response.sweeps;
    if(std::getenv("PHYSX_AVBD_COMMON_STATS"))std::fprintf(stderr,
        "[AVBD_BOUNDED_RESPONSE] iteration=%u phase=%u blocks=%u rows=%u colors=%u sweeps=%u error=%.9g status=%s\n",
        mStep.iteration,unsigned(s.phase),response.p.dimensions.size(),response.p.mu.size(),response.colorCount,
        response.sweeps,response.error,response.statusName());
    if(!s.solved && s.phase!=AvbdCommonPublication::Correction && s.phase!=AvbdCommonPublication::DirectionCertificate)
        if(const char* path=std::getenv("PHYSX_AVBD_COMMON_FAILED_NCP"))
        {FILE* file=std::fopen(path,"wb");if(file){s.p.write(file,&response.force,&s.motionTolerance);std::fclose(file);}}
    if(s.phase==AvbdCommonPublication::Correction || s.phase==AvbdCommonPublication::DirectionCertificate)s.correction=response.step;
    else
    {
        s.step=response.step;s.force=response.force;s.activeGroups=0;
        for(PxU8 active:response.enabled)s.activeGroups+=active!=0;
        s.result={s.solved,response.sweeps,0,response.sweeps,response.error};
    }
    PX_DELETE(mBoundedResponse);mBoundedResponse=NULL;
    if(!resumeCommonPublication(stationary))return false;
    done=s.finished;
    if(done)
    {
        mStep.commonClosed=mStep.commonClosed && stationary;
        for(PxU32 b:s.subset.blocks)mPrimalIdleIteration[b]=stationary?mStep.iteration+1:0;
        ++mStep.commonComponent;clearCommonPublication();
        if(!nextBoundedCommonComponent())return false;
        done=mBoundedResponse==NULL;stationary=mStep.commonClosed;
        if(done)writeJointDualState();
    }
    else startBoundedResponse();
    return true;
}

bool AvbdDynamicsContext::resumeCommonPublication(bool& stationary)
{
    auto& publication=*mCommonPublication;auto& p=publication.p;const auto& subset=publication.subset;
    auto& previous=publication.previous;auto& force=publication.force;auto& step=publication.step;auto& trial=publication.trial;
    auto& candidate=publication.candidate;auto& motionTolerance=publication.motionTolerance;auto& actual=publication.actual;
    auto& result=publication.result;auto& requested=publication.requested;auto& fraction=publication.fraction;auto& search=publication.search;
    auto& initial=publication.initial;auto& lastMerit=publication.lastMerit;auto& rejection=publication.rejection;
    auto& secondOrderAttempted=publication.secondOrderAttempted;auto& secondOrderSearch=publication.secondOrderSearch;
    auto& uncorrectedStep=publication.uncorrectedStep;auto& uncorrectedForce=publication.uncorrectedForce;
    auto& uncorrectedResult=publication.uncorrectedResult;auto& uncorrectedRequested=publication.uncorrectedRequested;
    auto& uncorrectedGroups=publication.uncorrectedGroups;auto& closed=publication.closed;auto& rootSmall=publication.rootSmall;
    auto& correctionRatio=publication.correctionRatio;auto& correctionIndex=publication.correctionIndex;
    const AvbdCommonResidual& metric=publication.metric;
    const AvbdRigidPoseView poses={mBodies,publication.patch?p.sourceBlocks.begin():NULL,candidate.begin(),candidate.size()};
    stationary=false;const char* reason="ok";
    auto failed=[&](const char* stage)
    {std::fprintf(stderr,"[AVBD_COMMON_STEP] iteration=%u stage=%s reason=%s status=FAIL\n",mStep.iteration,stage,reason);return false;};
    auto captureCandidate=[&]()
    {
    if(const char* path=std::getenv("PHYSX_AVBD_COMMON_FAILED_CANDIDATE"))
    {
        FILE* file=std::fopen(path,"wb");if(file){p.write(file,&previous,&motionTolerance);std::fclose(file);}
        // Diagnostic only: distinguish material PSD projection from the
        // original second variation. No captured operator enters execution.
        const std::string curvaturePath=std::string(path)+".curvature.json";
        file=std::fopen(curvaturePath.c_str(),"wb");
        if(file)
        {
            std::fprintf(file,"{\"frames\":[");bool first=true;
            for(PxU32 r:subset.rows)
            {
                const auto& row=mRows[r];
                if((row.flags&eAVBD_ROW_INACTIVE) || row.kernelId!=eAVBD_ROW_KERNEL_ELASTIC_FRAME)continue;
                const auto& m=mElasticFrameMaterials[row.geometryIndex-1];
                const PxTransform endpoints[2]={PxTransform(mBodies[row.bodyA].p,mBodies[row.bodyA].q),PxTransform(mBodies[row.bodyB].p,mBodies[row.bodyB].q)};
                const auto e=avbdEvaluateElasticFrame(m,endpoints,true);
                std::fprintf(file,"%s{\"row\":%u,\"a\":%u,\"b\":%u,\"valid\":%s,\"raw\":[",first?"":",",r,row.bodyA,row.bodyB,e.valid?"true":"false");first=false;
                for(PxU32 j=0;j<81;++j)std::fprintf(file,"%s%.17g",j?",":"",e.hessian[j]);
                std::fprintf(file,"],\"projected\":[");
                for(PxU32 j=0;j<9;++j)for(PxU32 k=0;k<9;++k)
                {double value=0;for(PxU32 z=0;z<9;++z)value+=double(PxReal(e.root[z][j<6?j:j+3]))*double(PxReal(e.root[z][k<6?k:k+3]));
                    std::fprintf(file,"%s%.17g",j||k?",":"",value);}
                std::fprintf(file,"]}");
            }
            std::fprintf(file,"]}\n");std::fclose(file);
        }
        const std::string detail=std::string(path)+".trial.json";file=std::fopen(detail.c_str(),"wb");
        if(file)
        {
            std::fprintf(file,"{\"actual\":");actual.write(file);
            auto values=[&](const char* name,const PxArray<double>& array)
            {std::fprintf(file,",\"%s\":[",name);for(PxU32 d=0;d<array.size();++d)std::fprintf(file,"%s%.17g",d?",":"",array[d]);std::fprintf(file,"]");};
            values("step",step);values("force",force);values("storedForce",trial);
            PxArray<double> from,to;
            for(PxU32 b:p.sourceBlocks)
            {
                const auto end=poses[b];const auto& body=mBodies[b];
                for(PxU32 d=0;d<3;++d){from.pushBack(body.p[d]);to.pushBack(end.p[d]);}
                const double a[4]={body.q.x,body.q.y,body.q.z,body.q.w},z[4]={end.q.x,end.q.y,end.q.z,end.q.w};
                for(PxU32 d=0;d<4;++d){from.pushBack(a[d]);to.pushBack(z[d]);}
            }
            values("from",from);values("to",to);std::fprintf(file,"}\n");std::fclose(file);
        }
    }
    };
    if(publication.phase==AvbdCommonPublication::Direction)
    {
        if(!publication.solved)
        {
            if(!publication.bounded || !publication.valid){reason="frozen_response_unresolved";return failed("solve");}
            // Qualify an inexact DIRECTION using the existing engineering
            // scales; this is not permission to publish an unfinished frame.
            PxArray<double> tolerance=motionTolerance;
            for(double& value:tolerance)value*=.1;
            if(!metric.smallRoot(p,force.begin(),tolerance.begin(),step.begin()))
            {reason="inexact_direction_root";return failed("certificate");}
            publication.rhs.resize(p.base.size());publication.correction.resize(p.base.size());
            p.hessian(step.begin(),publication.correction.begin());p.transpose(force.begin(),publication.rhs.begin());
            for(PxU32 d=0;d<p.base.size();++d)publication.rhs[d]+=p.base[d]-publication.correction[d];
            publication.phase=AvbdCommonPublication::DirectionCertificate;
            return true;
        }
        requested=0;for(PxU32 d=0;d<step.size();++d)requested=std::max(requested,std::abs(step[d])/motionTolerance[d]);
        publication.phase=AvbdCommonPublication::Trial;
    }
    else if(publication.phase==AvbdCommonPublication::DirectionCertificate)
    {
        if(!publication.solved){reason="inexact_direction_h_unresolved";return failed("certificate");}
        double ratio=0;for(PxU32 d=0;d<publication.correction.size();++d)
            ratio=std::max(ratio,std::abs(publication.correction[d])/(.1*motionTolerance[d]));
        if(!(ratio<=1)){reason="inexact_direction_correction";return failed("certificate");}
        mStep.requiresDomainClosure=true;
        if(std::getenv("PHYSX_AVBD_COMMON_STATS"))std::fprintf(stderr,
            "[AVBD_COMMON_DIRECTION_CERTIFICATE] iteration=%u correction=%.9g strict=FAIL direction=PASS\n",mStep.iteration,ratio);
        requested=0;for(PxU32 d=0;d<step.size();++d)requested=std::max(requested,std::abs(step[d])/motionTolerance[d]);
        publication.phase=AvbdCommonPublication::Trial;
    }
    else if(publication.phase==AvbdCommonPublication::SecondOrder)
    {
        p.offset.swap(publication.originalOffset);
        if(!publication.valid){reason="second_order_material_unresolved";return failed("solve");}
        ++search;fraction=.5;
        if(!publication.solved)
        {
            step.swap(uncorrectedStep);force.swap(uncorrectedForce);result=uncorrectedResult;
            requested=uncorrectedRequested;publication.activeGroups=uncorrectedGroups;
        }
        else
        {
            secondOrderSearch=search;fraction=1;
            requested=0;for(PxU32 d=0;d<step.size();++d)requested=std::max(requested,std::abs(step[d])/motionTolerance[d]);
        }
        publication.phase=AvbdCommonPublication::Trial;
    }
    else if(publication.phase==AvbdCommonPublication::Correction)
    {
        closed=publication.solved;
        for(PxU32 d=0;d<publication.correction.size();++d)
        {const double ratio=std::abs(publication.correction[d])/motionTolerance[d];
            if(ratio>correctionRatio){correctionRatio=ratio;correctionIndex=d;}closed=closed && ratio<=1;}
        if(publication.bounded && !publication.solved){reason="bounded_certificate_unresolved";return failed("certificate");}
        publication.phase=AvbdCommonPublication::Admission;
    }
    for(;search<16;++search,fraction*=.5,publication.phase=AvbdCommonPublication::Trial)
    {
        if(publication.phase==AvbdCommonPublication::Trial)
        {
        // SOC is one full-step candidate, not a replacement direction merely
        // because its shifted linear system converged. If actual admission
        // rejects it, resume backtracking the original coupled pose/force pair.
        if(search>secondOrderSearch)
        {
            step.swap(uncorrectedStep);force.swap(uncorrectedForce);result=uncorrectedResult;
            requested=uncorrectedRequested;publication.activeGroups=uncorrectedGroups;
            secondOrderSearch=PX_MAX_U32;fraction=.5;
        }
        // Inexact roots may point slightly inward at a nearly active plane.
        // Start ordinary backtracking inside its exact affine boundary instead
        // of spending all trials above it. A zero bound is not convergence.
        if(search && search!=secondOrderSearch)
            fraction=PxMin(fraction,.5*p.linearFeasibleFraction(step.begin()));
        for(PxU32 i=0;i<candidate.size();++i)
        {const PxU32 b=publication.patch?p.sourceBlocks[i]:i;candidate[i]=PxTransform(mBodies[b].p,mBodies[b].q);}
        for(PxU32 s=0;s<p.sourceBlocks.size();++s)
        {
            const PxU32 b=p.sourceBlocks[s],i=publication.patch?s:b;PxVec3d dth;
            for(PxU32 d=0;d<3;++d)
            {candidate[i].p[d]=PxReal(double(mBodies[b].p[d])+fraction*step[6*s+d]);dth[d]=fraction*step[6*s+d+3];}
            // Locked coordinates were eliminated in H/J. Round the common
            // retraction once; float renormalization can rotate even a zero step.
            candidate[i].q=avbdStoredRotationIncrement(mBodies[b].q,dth);
        }
        // Select a representable point inside the proposal's FLOAT CELL,
        // reusing the existing lattice publisher. This is quantization, not
        // a new geometric correction or a change to the coupled force.
        for(PxU32 s=0;s<p.sourceBlocks.size();++s)
        {
            const PxU32 b=p.sourceBlocks[s],i=publication.patch?s:b;AvbdOgcProjectionPlanes planes;
            for(PxU32 j=mRowProgram.blockOffsets[b];j<mRowProgram.blockOffsets[b+1];++j)
            {
                const PxU32 r=mRowProgram.blockRows[j];const auto& row=mRows[r];
                if(row.kernelId!=eAVBD_ROW_KERNEL_NP_CONTACT || (row.flags&eAVBD_ROW_INACTIVE))continue;
                const auto& domain=mNpDomains[row.geometryIndex-1];
                if(domain.rowStart!=PX_MAX_U32 && r!=domain.rowStart)continue;
                const PxTransform ends[2]={row.bodyA<poses.size()?PxTransform(poses[row.bodyA].p,poses[row.bodyA].q):domain.fixedPose[0],
                    row.bodyB<poses.size()?PxTransform(poses[row.bodyB].p,poses[row.bodyB].q):domain.fixedPose[1]};
                AvbdOgcProjectionPlane plane;plane.n=domain.normal*(row.bodyA==b?1.:-1.);
                const PxTransform start[2]={row.bodyA<mBodies.size()?PxTransform(mBodies[row.bodyA].pStart,mBodies[row.bodyA].qStart):domain.fixedPose[0],
                    row.bodyB<mBodies.size()?PxTransform(mBodies[row.bodyB].pStart,mBodies[row.bodyB].qStart):domain.fixedPose[1]};
                const double gap=domain.rowStart==PX_MAX_U32?avbdNpGap(domain,ends):avbdNpPathGap(domain,start,ends);
                plane.b=plane.n.dot(avbdOgcDouble(candidate[i].p)-avbdOgcDouble(mBodies[b].p))-gap;
                planes.pushBack(plane);
            }
            const PxVec3d dp(fraction*step[6*s],fraction*step[6*s+1],fraction*step[6*s+2]);
            PxVec3 stored;
            if(avbdOgcPublishRegionPoint(mBodies[b].p,dp,planes,PX_MAX_F32,stored))candidate[i].p=stored;
        }
        for(PxU32 i=0;i<trial.size();++i)
        {
            // Force the actual publication precision, including /fp:fast.
            volatile PxReal stored=PxReal(previous[i]+fraction*(force[i]-previous[i]));trial[i]=stored;
        }
        bool admissible=true;
        for(PxU32 b:p.sourceBlocks)
        {
            const auto end=poses[b];
            if(!end.p.isFinite() || !end.q.isFinite()){admissible=false;break;}
            const auto& body=mBodies[b];
            if(body.ogcRegionValid)
            {
                AvbdOgcRigidRegion live=body.ogcRegion;
                for(PxU32 k=0;k<live.planeCount;++k)live.planes[k].partnerDelta=avbdOgcLivePartnerDelta(live.planes[k],poses,mIslandSoftCache);
                if(!avbdOgcRigidContains(live,end.p,end.q))
                {if(search==15 && std::getenv("PHYSX_AVBD_COMMON_STATS"))std::fprintf(stderr,"[AVBD_COMMON_GEOMETRY_END] body=%u kind=body_region fraction=%.17g\n",b,fraction);admissible=false;break;}
            }
        }
        for(PxU32 rowIndex:subset.rows)if(admissible && !(mRows[rowIndex].flags&eAVBD_ROW_INACTIVE))
        {
            const auto& row=mRows[rowIndex];
            if(row.kernelId==eAVBD_ROW_KERNEL_NP_CONTACT)
            {
                const PxU32 first=mNpDomains[row.geometryIndex-1].rowStart;
                if(first!=PX_MAX_U32 && PxU32(&row-mRows.begin())!=first)continue;
            }
            if(!avbdNpCandidateAdmissible(row,mNpDomains,mBodies,poses,mKernels))
            {
                admissible=false;
                if((search==0 && avbdCommonVerbose()) || (search==15 && std::getenv("PHYSX_AVBD_COMMON_STATS")))
                {
                    const auto& domain=mNpDomains[row.geometryIndex-1];PxTransform ends[2],starts[2],dcd[2];
                    const PxU32 ids[2]={row.bodyA,row.bodyB};
                    for(PxU32 s=0;s<2;++s)
                    {ends[s]=ids[s]<mBodies.size()?PxTransform(poses[ids[s]].p,poses[ids[s]].q):domain.fixedPose[s];
                     starts[s]=ids[s]<mBodies.size()?PxTransform(mBodies[ids[s]].p,mBodies[ids[s]].q):domain.fixedPose[s];
                     dcd[s]=ids[s]<mBodies.size()?PxTransform(mBodies[ids[s]].pStart,mBodies[ids[s]].qStart):domain.fixedPose[s];}
                    std::fprintf(stderr,"[AVBD_COMMON_GEOMETRY] a=%u b=%u domain=%u current=%.17g candidate=%.17g witness=%.17g\n",
                        row.bodyA,row.bodyB,row.geometryIndex,avbdNpGap(domain,starts),avbdNpGap(domain,ends),double(avbdEvalC(row,poses)));
                    if(search==15)
                    {
                        PxArray<double> delta(step.size()),linear(p.offset.size());
                        for(PxU32 s=0;s<p.sourceBlocks.size();++s)
                        {const PxU32 b=p.sourceBlocks[s];const auto end=poses[b];
                            const PxVec3d dp=avbdOgcDouble(end.p)-avbdOgcDouble(mBodies[b].p),dt=avbdAcceptedRotationDisplacementDouble(mBodies[b].q,end.q);
                            for(PxU32 d=0;d<3;++d){delta[6*s+d]=dp[d];delta[6*s+3+d]=dt[d];}}
                        p.jacobian(delta.begin(),linear.begin());double predicted=DBL_MAX;
                        for(PxU32 r=0;r<p.sourceRows.size();++r)if(mRows[p.sourceRows[r]].geometryIndex==row.geometryIndex)
                            predicted=PxMin(predicted,p.offset[3*r]+linear[3*r]);
                        std::fprintf(stderr,"[AVBD_COMMON_GEOMETRY_END] domain=%u fraction=%.17g currentPath=%.17g proposalPath=%.17g linearPath=%.17g\n",
                            row.geometryIndex,fraction,avbdNpPathGap(domain,dcd,starts),avbdNpPathGap(domain,dcd,ends),predicted);
                    }
                }
            }
            if(row.kernelId==eAVBD_ROW_KERNEL_TETRAHEDRON &&
                !tetrahedronPath(row,mTetrahedronMaterials[row.geometryIndex-1],mRowSupports,mBodies,poses))admissible=false;
        }
        if(!admissible)
        {
            rejection="geometry";
            // A tangent SQP direction may violate a curved boundary by O(d^2)
            // at EVERY step length (Maratos effect). Correct the constraint
            // linearization once, resolving the SAME H/J for pose AND force.
            // This never projects a pose independently of its reaction.
            if(!secondOrderAttempted && search==0)
            {
                AvbdCommonProgram nonlinear;
                if(compileCommonProgram(nonlinear,reason,&poses,&subset,false))
                {
                    PxArray<double> linear(p.offset.size());p.jacobian(step.begin(),linear.begin());
                    publication.originalOffset=p.offset;
                    uncorrectedStep=step;uncorrectedForce=force;uncorrectedResult=result;
                    uncorrectedRequested=requested;uncorrectedGroups=publication.activeGroups;
                    for(PxU32 i=0;i<p.offset.size();++i)p.offset[i]=nonlinear.offset[i]-linear[i];
                    if(publication.patch || publication.bounded)for(double& f:force)f=0;
                    secondOrderAttempted=true;publication.phase=AvbdCommonPublication::SecondOrder;
                    return true; // Resume after the same numerical executor joins.
                }
            }
            continue;
        }
        publication.actual=AvbdCommonProgram();
        if(!compileCommonProgram(actual,reason,&poses,&subset,false)){rejection=reason;continue;}
        lastMerit=metric.evaluate(actual,trial.begin());
        // Engineering closure uses the existing physical displacement scales,
        // not monotone decrease below the float storage floor. Verify BOTH
        // nonlinear stationarity and the original force law at this exact pair.
        publication.closed=false;publication.correctionRatio=0;publication.correctionIndex=PX_MAX_U32;
        publication.rootSmall=metric.smallRoot(actual,trial.begin(),motionTolerance.begin());
        if(publication.rootSmall)
        {
            publication.rhs.resize(actual.base.size());publication.correction.resize(actual.base.size());
            actual.transpose(trial.begin(),publication.rhs.begin());
            for(PxU32 d=0;d<publication.rhs.size();++d)publication.rhs[d]+=actual.base[d];
            publication.phase=AvbdCommonPublication::Correction;
            return true; // Full-H certificate, never a physical correction.
        }
        publication.phase=AvbdCommonPublication::Admission;
        }
        PxArray<double> delta(step.size());
        for(PxU32 s=0;s<p.sourceBlocks.size();++s)
        {
            const PxU32 b=p.sourceBlocks[s];const auto& body=mBodies[b];
            const PxVec3d dp=avbdOgcDouble(poses[b].p)-avbdOgcDouble(body.p),
                dth=avbdAcceptedRotationDisplacementDouble(body.q,poses[b].q);
            for(PxU32 d=0;d<3;++d){delta[6*s+d]=dp[d];delta[6*s+d+3]=dth[d];}
        }
        double work=0,slope=0;
        const bool descent=AvbdCommonResidual::workDescent(p,actual,force.begin(),delta.begin(),work,slope);
        if(avbdCommonVerbose() && (search==0 || search==15 || mStep.iteration>=9))
        {
            std::fprintf(stderr,"[AVBD_COMMON_TRIAL] iteration=%u search=%u fraction=%.9g initial=%.17g residual=%.17g work=%.17g slope=%.17g closed=%u descent=%u\n",
                mStep.iteration,search,fraction,initial,lastMerit,work,slope,unsigned(closed),unsigned(descent));
            std::fprintf(stderr,"[AVBD_COMMON_CLOSURE] rootSmall=%u correction=%.9g body=%u coordinate=%u\n",
                unsigned(rootSmall),correctionRatio,correctionIndex==PX_MAX_U32?PX_MAX_U32:p.sourceBlocks[correctionIndex/6],correctionIndex%6);
            if(search==15 && !descent)
            {
                PxArray<double> linear(p.offset.size());p.jacobian(delta.begin(),linear.begin());
                PxU32 worst=PX_MAX_U32;double defect=-1;
                for(PxU32 i=0;i<p.offset.size();++i)
                {const double error=std::abs(force[i]*(actual.offset[i]-p.offset[i]-linear[i]));
                    if(error>defect){defect=error;worst=i;}}
                if(worst!=PX_MAX_U32)std::fprintf(stderr,"[AVBD_COMMON_DIRECTION] row=%u coordinate=%u C=%.17g actual=%.17g linear=%.17g force=%.17g\n",
                    p.sourceRows[worst/3],worst%3,p.offset[worst],actual.offset[worst]-p.offset[worst],linear[worst],force[worst]);
            }
        }
        if(publication.bounded && !result.converged && closed && std::getenv("PHYSX_AVBD_COMMON_STATS"))
            std::fprintf(stderr,"[AVBD_COMMON_CERTIFIED_INEXACT] iteration=%u rootSmall=%u correction=%.9g strict=FAIL actual=PASS\n",
                mStep.iteration,unsigned(rootSmall),correctionRatio);
        if(!(closed || descent))
        {rejection="nonlinear_work";continue;}
        // Retain the exact unfinished candidate at the outer budget boundary,
        // before Backend commit changes the diagnostic from/to pair.
        if(!closed && mStep.iteration+1>=mStep.iterationLimit)captureCandidate();
        for(PxU32 s=0;s<p.sourceBlocks.size();++s)
        {
            const PxU32 b=p.sourceBlocks[s];
            const auto end=poses[b];
            if(mBodies[b].p!=end.p || !(mBodies[b].q==end.q))mPrimalChangedIteration[b]=mStep.iteration+1;
            mBodies[b].p=end.p;mBodies[b].q=end.q;
        }
        for(PxU32 r=0;r<p.sourceRows.size();++r)
        {
            const PxU32 i=p.sourceRows[r];auto& row=mRows[i];
            row.lambda=-PxReal(trial[3*r]);row.lambdaT0=-PxReal(trial[3*r+1]);row.lambdaT1=-PxReal(trial[3*r+2]);
            if(i<mContactWarm.size())
            {auto& warm=mContactWarm[i];warm.lambda=row.lambda;warm.lambdaT0=row.lambdaT0;warm.lambdaT1=row.lambdaT1;}
        }
        stationary=closed && (!publication.patch || requested*fraction<=1);
        publication.finished=true;
        if(avbdCommonVerbose())std::fprintf(stderr,
            "[AVBD_COMMON_STEP] iteration=%u blocks=%u groups=%u fraction=%.9g requested=%.9g initial=%.9g residual=%.9g activeGroups=%u materialProducts=%u secondOrder=%u status=PASS storage=backend_iterate\n",
            mStep.iteration,p.dimensions.size(),p.mu.size(),fraction,requested,initial,lastMerit,publication.activeGroups,publication.materialProducts,unsigned(secondOrderAttempted));
        return true;
    }
    reason=rejection;std::fprintf(stderr,"[AVBD_COMMON_REJECT] requested=%.9g initial=%.9g residual=%.9g\n",requested,initial,lastMerit);
    captureCandidate();
    return failed("accept");
}

// Explicit diagnostic capture only. The compiler owns no pose or dual and
// cannot publish an unverified frozen candidate into the physical step.
void AvbdDynamicsContext::captureCommonProgram()
{
    const char* path=std::getenv("PHYSX_AVBD_COMMON_CAPTURE");if(!path || !path[0])return;
    const char* minimum=std::getenv("PHYSX_AVBD_COMMON_CAPTURE_CONTACTS");
    if(minimum && mContactRowCount<PxU32(std::strtoul(minimum,NULL,10)))return;
    const char* load=std::getenv("PHYSX_AVBD_COMMON_CAPTURE_LOAD");
    if(load)
    {
        double maximum=0;for(PxU32 r=0;r<mContactRowCount;++r)maximum=std::max(maximum,-double(mRows[r].lambda));
        if(maximum<std::strtod(load,NULL))return;
    }
    static PxI32 claimed=0;if(PxAtomicCompareExchange(&claimed,0,0)!=0)return;
    AvbdCommonProgram p;const char* reason;const bool complete=compileCommonProgram(p,reason);
    AvbdCommonResponse response(p,mKernels);PxArray<double> step,force;
    const char* closing=std::getenv("PHYSX_AVBD_COMMON_CAPTURE_CLOSING");
    if(complete && closing)
    {
        step.resize(p.base.size());PxArray<double> motion(p.offset.size());
        if(response.material(p.base.begin(),step.begin()))
        {
            p.jacobian(step.begin(),motion.begin());double gap=0;
            for(PxU32 r=0;r<p.sourceRows.size();++r)if(mRows[p.sourceRows[r]].flags&eAVBD_ROW_CONTACT)
                gap=std::min(gap,p.offset[3*r]+motion[3*r]);
            if(gap>=-std::strtod(closing,NULL))return;
        }
    }
    if(PxAtomicCompareExchange(&claimed,1,0)!=0)return;
    FILE* file=std::fopen(path,"wb");if(!file)return;
    const char* solveOption=std::getenv("PHYSX_AVBD_COMMON_CAPTURE_SOLVE");
    const bool attempted=solveOption && std::atoi(solveOption)!=0;
    std::fprintf(file,"{\"schema\":1,\"complete\":%s,\"reason\":\"%s\",\"sourceRowCount\":%u,\"sourceBlockCount\":%u,\"dt\":%.17g,",
        complete?"true":"false",reason,mRows.size(),mBlocks.size(),double(mDt));
    std::fprintf(file,"\"tableSolveAttempted\":%s,",attempted?"true":"false");
    auto array=[&](const char* name,const auto& values)
    {std::fprintf(file,"\"%s\":[",name);for(PxU32 i=0;i<values.size();++i)
        {const double v=double(values[i]);std::fprintf(file,"%s",i?",":"");
            if(std::isfinite(v))std::fprintf(file,"%.17g",v);else std::fprintf(file,"\"%s\"",std::isnan(v)?"nan":v<0?"-inf":"inf");}
        std::fprintf(file,"],");};
    array("dimensions",p.dimensions);array("sourceBlocks",p.sourceBlocks);array("sourceRows",p.sourceRows);
    array("base",p.base);array("offset",p.offset);array("lower",p.lower);array("upper",p.upper);array("compliance",p.compliance);
    array("mu",p.mu);array("coulomb",p.coulomb);
    auto matrix=[&](const char* name,const auto& entries,PxU32 width)
    {
        std::fprintf(file,"\"%s\":[",name);
        for(PxU32 e=0;e<entries.size();++e)
        {std::fprintf(file,"%s[%u,%u",e?",":"",entries[e].row,entries[e].column);for(PxU32 k=0;k<width;++k)std::fprintf(file,",%.17g",entries[e].values[k]);std::fprintf(file,"]");}
        std::fprintf(file,"]");
    };
    matrix("H",p.H,36);std::fprintf(file,",");matrix("J",p.J,18);std::fprintf(file,"}\n");
    // Preserve a complete input even if a diagnostic solve is interrupted.
    std::fflush(file);
    AvbdCoulombNcpResult result={};const bool solved=complete && attempted && response.solve(step,force,result);
    std::fseek(file,-2,SEEK_END);std::fprintf(file,",");
    array("tableStep",step);array("tableForce",force);
    std::fprintf(file,"\"tableSolved\":%s,\"tableIterations\":%u,\"materialSolves\":%u,\"materialProducts\":%u}\n",
        solved?"true":"false",result.iterations,response.materialSolves,response.materialProducts);
    const bool written=std::ferror(file)==0;std::fclose(file);
    std::fprintf(stderr,"[AVBD_COMMON_CAPTURE] complete=%u written=%u reason=%s blocks=%u groups=%u hBlocks=%u jBlocks=%u tableSolved=%u materialProducts=%u publication=none\n",
        unsigned(complete),unsigned(written),reason,p.dimensions.size(),p.mu.size(),p.H.size(),p.J.size(),unsigned(solved),response.materialProducts);
}

bool AvbdDynamicsContext::linearizeRigidRow(const AvbdRow& row,PxU32 i,
    PxReal& C,PxVec3& jLin,PxVec3& jAng,const AvbdRigidPoseView* candidate) const
{
    const AvbdRigidPoseView current={mBodies,NULL,NULL,0};const auto& poses=candidate?*candidate:current;
    const auto b=poses[i];
	const bool isA = (row.bodyA == i);
	const bool isB = (row.bodyB == i);
	if(!isA && !isB)
		return false;

	C=0;
	if(row.flags & eAVBD_ROW_POINT_LOCK)
	{
		C = avbdEvalC(row, poses);
		const PxVec3 axis = row.n;
		if(isA)
		{
			jLin = axis;
			jAng = b.q.rotate(row.rA).cross(axis);
		}
		else
		{
			jLin = -axis;
			jAng = b.q.rotate(row.rB).cross(-axis);
		}
	}
	else if(row.articJoint)
	{
		PxVec3 jLinA, jAngA, jLinB, jAngB;
		if(!avbdEvalArticRow(row, poses, jLinA, jAngA, jLinB, jAngB, C))
			return false;
		jLin = isA ? jLinA : jLinB;
		jAng = isA ? jAngA : jAngB;
	}
	else
	{
		if(row.supportCount)
		{
			C = avbdHeterogeneousPositionAl(row) ?
				avbdHeterogeneousAlC(row, mRowSupports, mBlocks, mBodies, contactGeometry()) :
				avbdHeterogeneousRowC(row, mRowSupports, mBlocks, mBodies, contactGeometry());
			jLin = PxVec3(0.0f);
			jAng = PxVec3(0.0f);
			for(PxU32 supportIndex = row.supportStart;
				supportIndex < row.supportStart + row.supportCount;
				++supportIndex)
			{
				if(supportIndex >= mRowSupports.size())
					break;
				const AvbdRowSupport& support = mRowSupports[supportIndex];
				if(support.block != i || support.block >= mBlocks.size())
					continue;
				PxVec3 supportLin, supportAng;
				if(avbdHeterogeneousSupportJacobian(row, support,
					mBlocks[support.block], mBodies, contactGeometry(), mRowSupports, mBlocks, supportLin, supportAng))
				{
					jLin += supportLin;
					jAng += supportAng;
				}
			}
		}
		else
		{
			C = avbdEvalC(row, poses);
			if(row.flags & eAVBD_ROW_CONTACT)
			{
				const PxReal sign = isA ? 1.0f : -1.0f;
				const PxVec3 rWorld = isA ? b.q.rotate(row.ogcRA) : b.q.rotate(row.ogcRB);
				jLin = row.n * sign;
				jAng = rWorld.cross(jLin);
			}
			else
			{
				jLin = isA ? row.jLinA : row.jLinB;
				jAng = isA ? row.jAngA : row.jAngB;
				const PxVec3 positionGradient=avbdRotationChartGradient(b.qLin,b.q,jAng);
				if(row.integratedAngular)
					jAng=avbdRotationChartGradient(b.qStart,b.q,jAng);
				else if((row.flags&eAVBD_ROW_DRIVE) && row.kernelId!=eAVBD_ROW_KERNEL_FINITE_SPRING)
				{
					const PxReal total=row.driveStiffness+row.driveDampingOverDt;
					jAng=total>0.0f ? (positionGradient*row.driveStiffness+
						avbdRotationChartGradient(b.qStart,b.q,jAng)*row.driveDampingOverDt)/total : PxVec3(0.0f);
				}
				else jAng=positionGradient;
			}
		}
	}

	return true;
}

void AvbdDynamicsContext::accumulateRigidConstraintRow(PxU32 i,PxU32 ri,
    PxReal invH2,AvbdRigidAssembly& destination)
{
    const AvbdSolverBody& b=mBodies[i];const AvbdRow& row=mRows[ri];
    PxReal (&H)[6][6]=destination.hessian;PxReal (&g)[6]=destination.gradient;
    AvbdRigidAssembly* assembly=&destination;
        PxReal C=0;PxVec3 jLin,jAng;
        if(!linearizeRigidRow(row,i,C,jLin,jAng))return;
        if(row.articJoint)C=avbdArticPrimalC(row,C);
        else if((row.flags&eAVBD_ROW_CONTACT) && !row.supportCount && !(row.contactRadius>0))
            C-=AVBD_ALPHA*PxMin(row.C0,0.0f);
        const bool isA=row.bodyA==i;

		PxReal penalty = (row.flags & eAVBD_ROW_DRIVE) ?
			avbdDrivePenalty(row, mBodies) :
			avbdHardJointPenalty(row, mBodies, invH2);
		if((row.flags & eAVBD_ROW_CONTACT) && !mJoints.empty() &&
			b.invMass > 1.0e-12f)
		{
			// Endpoint conditioning belongs to the block metric. The contact
			// force below must still use the shared row penalty on both ends.
			penalty = PxMax(penalty,
				AVBD_CONTACT_JOINT_BOOST_FRACTION * invH2 / b.invMass);
		}
		const PxReal raw = penalty * C + row.lambda;
		const bool ogcContact = (row.flags & eAVBD_ROW_CONTACT) != 0;
		// Every non-contact row has force bounds (bilateral rows carry
		// +-PX_MAX_REAL).  A saturated row contributes its bound and no
		// Hessian, which is how a joint limit stays inactive while inside.
		const bool saturatedDrive = !ogcContact &&
			(raw < row.minLambda || raw > row.maxLambda);
		const PxReal driveClamped = saturatedDrive ?
			PxMin(row.maxLambda, PxMax(row.minLambda, raw)) : raw;
		// Default NP rigid contact is Position-AL (demo3d / WebPhysics):
		// Fn = min(0, rho*C + lambda) with lambda carrying the resting load, so
		// the pair rests at the authored rest distance independent of load.  A
		// pure offset potential would rest at r - W/(N k): light bodies float on
		// the shell, heavy stacks sink into it.  The OGC region stays the
		// non-penetration certificate; it is not the load carrier. The explicit
		// NP trial replaces this force with the shared normal envelope below.
		PxReal coeff = ((row.flags & eAVBD_ROW_CONTACT) &&
			(row.flags & eAVBD_ROW_UNILATERAL)) ? PxMin(0.0f, raw) : driveClamped;
		PxReal hessianCoeff = saturatedDrive ? 0.0f : penalty;
		if(ogcContact && !row.supportCount)
		{
			// One normal law for primal, dual, force limits and energy. Using
			// the endpoint metric here gives unequal action/reaction forces.
			const AvbdContactPotential potential=avbdNpContactPotential(row,C);
			coeff=potential.gradient;
			// The envelope curvature is bounded by rho for every gap. Retain
			// that global majorizer, including when Coulomb has no scalar
			// line search; a pointwise log curvature is not such a bound.
		}
		if(ogcContact && row.supportCount)
		{
			// Both block dimensions and dual consume the same row potential.
			// Partner mobility belongs in the solve metric, never in its force.
			const AvbdContactPotential potential =
				avbdHeterogeneousContactPotential(row, C);
			coeff = potential.gradient;
			hessianCoeff = potential.curvature;
		}
        // Endpoint conditioning is diagonal-only. Shared NP cross terms use
        // the same row coefficient on both ends, preserving an SPD metric.
        if(assembly) assembly->record(ri,jLin,jAng,ogcContact && !row.supportCount?row.rho:hessianCoeff);
		avbdAddOuter(H, jLin, jAng, hessianCoeff);
		g[0] += jLin.x * coeff;
		g[1] += jLin.y * coeff;
		g[2] += jLin.z * coeff;
		g[3] += jAng.x * coeff;
		g[4] += jAng.y * coeff;
		g[5] += jAng.z * coeff;

		// demo3d updatePrimal always stamps tangential K, sliding or not.
		if((row.flags & eAVBD_ROW_CONTACT) && row.mu > 0.0f &&
			row.positionTangent)
		{
			const PxVec3 rel = avbdContactRelDisp(row, mBodies);
			const PxReal sign = isA ? 1.0f : -1.0f;
			const PxVec3 rWorld = isA ? b.q.rotate(row.rA) : b.q.rotate(row.rB);
			const PxVec3 j0 = row.t0 * sign;
			const PxVec3 a0 = rWorld.cross(j0);
			const PxVec3 j1 = row.t1 * sign;
			const PxVec3 a1 = rWorld.cross(j1);
			const PxReal c0 = (1.0f - AVBD_ALPHA) * row.tangentC0 + row.t0.dot(rel);
			const PxReal c1 = (1.0f - AVBD_ALPHA) * row.tangentC1 + row.t1.dot(rel);
			PxReal tangentPenalty0 = row.rhoT0;
			PxReal tangentPenalty1 = row.rhoT1;
			if(!mJoints.empty() && b.invMass > 1.0e-12f)
			{
				const PxReal floor = AVBD_CONTACT_JOINT_BOOST_FRACTION * invH2 / b.invMass;
				tangentPenalty0 = PxMax(tangentPenalty0, floor);
				tangentPenalty1 = PxMax(tangentPenalty1, floor);
			}
			PxReal f0 = row.rhoT0 * c0 + row.lambdaT0;
			PxReal f1 = row.rhoT1 * c1 + row.lambdaT1;
			avbdProjectCoulomb(coeff, row.mu, f0, f1);
			// demo3d stamps the tangential Hessian for both endpoints in stick
			// and slip.  A maximal-coordinate link is not a different material:
			// omitting only its half of the Hessian breaks the shared friction
			// potential and lets cargo drift across a moving link.
			avbdAddOuter(H, j0, a0, tangentPenalty0);
			avbdAddOuter(H, j1, a1, tangentPenalty1);
            if(assembly)
            {
                assembly->record(ri,j0,a0,row.rhoT0,1);
                assembly->record(ri,j1,a1,row.rhoT1,2);
            }
			g[0] += j0.x * f0 + j1.x * f1;
			g[1] += j0.y * f0 + j1.y * f1;
			g[2] += j0.z * f0 + j1.z * f1;
			g[3] += a0.x * f0 + a1.x * f1;
			g[4] += a0.y * f0 + a1.y * f1;
			g[5] += a0.z * f0 + a1.z * f1;
		}
}

void AvbdDynamicsContext::solvePrimalBody(PxU32 i, PxReal invH2,
	PxVec3& outDp, PxVec3& outDth, PxVec3& gradientLinear,
	PxVec3& gradientAngular,PxReal (*metric)[6])
{
	outDp = PxVec3(0.0f);
	outDth = PxVec3(0.0f);
	gradientLinear = gradientAngular = PxVec3(0.0f);
	AvbdSolverBody& b = mBodies[i];
	if(b.invMass == 0.0f || b.isKinematic)
		return;

    AvbdRigidAssembly output={};
    PxReal (&H)[6][6]=output.hessian;PxReal (&g)[6]=output.gradient;
    const PxU32 locked=b.core?PxU32(b.core->lockFlags):0;
    output.lockedMask=locked;
    initializeRigidMaterial(b,H,g);
	const PxU32 rowBegin = mRowProgram.blockOffsets[i];
	const PxU32 rowEnd = mRowProgram.blockOffsets[i + 1];
	for(PxU32 slot = rowBegin; slot < rowEnd; ++slot)
	{
		const PxU32 ri = mRowProgram.blockRows[slot];
		AvbdRow& row = mRows[ri];
		if((row.flags & eAVBD_ROW_INACTIVE) || row.kernelId==eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN)
			continue;
        if(accumulateRigidMaterialRow(ri,&i,1,&output))
        { if(mLocalDomainFailed)return;continue; }
        accumulateRigidConstraintRow(i,ri,invH2,output);
	}

    avbdKernelRestrict6(H,g,locked);
	gradientLinear = PxVec3(g[0], g[1], g[2]);
	gradientAngular = PxVec3(g[3], g[4], g[5]);
	for(PxU32 d = 0; d < 6; ++d)
		H[d][d] += AVBD_REG;
	if(metric) PxMemCopy(metric,H,sizeof(H));

	PxReal rhs[6];
	for(PxU32 d = 0; d < 6; ++d)
		rhs[d] = -g[d];
	PxReal x[6];
	bool ok = false;
	AvbdLdlt6Args args;
	args.A = H;
	args.b = rhs;
	args.x = x;
	args.ok = &ok;
	mKernels.launch(AVBD_LDLT6, &args);
	if(!ok)
	{
		return;
	}
	PxVec3 dpSolve(x[0], x[1], x[2]);
	PxVec3 dthSolve(x[3], x[4], x[5]);
	avbdProjectLockedDelta(b, dpSolve, dthSolve);

	outDp = dpSolve;
	outDth = dthSolve;
}

void AvbdDynamicsContext::compileHeterogeneousBlocks()
{
	mBlocks.clear();
	mBlocks.reserve(mBodies.size() + mSoftParticleScratch.size());
	for(PxU32 bodyIndex = 0; bodyIndex < mBodies.size(); ++bodyIndex)
	{
		AvbdBlock block;
		block.objectIndex = bodyIndex;
		block.stateIndex = PX_MAX_U32;
		block.particle = NULL;
		block.ogcRegion = NULL;
		block.ogcExceeded = NULL;
		block.type = eAVBD_BLOCK_RIGID6;
		block.particleKernel = eAVBD_PARTICLE_KERNEL_NONE;
		mBlocks.pushBack(block);
	}
	for(PxU32 cacheIndex = 0; cacheIndex < mIslandSoftCache.size(); ++cacheIndex)
	{
		AvbdIslandSoftCache& cache = mIslandSoftCache[cacheIndex];
		cache.blockStart = mBlocks.size();
		if(!cache.coupled || cache.liveStamp != mIslandSoftLiveStamp ||
			!cache.particles)
			continue;
		mBlocks.reserve(mBlocks.size() + cache.nbParticles);
		for(PxU32 particleIndex = 0; particleIndex < cache.nbParticles;
			++particleIndex)
		{
			AvbdBlock block;
			block.objectIndex = cacheIndex;
			block.stateIndex = particleIndex;
			block.particle = cache.particles + particleIndex;
			block.ogcRegion = cache.ogcRegions ? cache.ogcRegions + particleIndex : NULL;
			block.ogcExceeded = cache.ogcExceeded ? cache.ogcExceeded + particleIndex : NULL;
			block.type = eAVBD_BLOCK_PARTICLE3;
			block.particleKernel = eAVBD_PARTICLE_KERNEL_TET;
			mBlocks.pushBack(block);
		}
	}
	for(PxU32 cacheIndex = 0; cacheIndex < mIslandSurfaceCache.size(); ++cacheIndex)
	{
		AvbdIslandSurfaceCache& cache = mIslandSurfaceCache[cacheIndex];
		cache.blockStart = mBlocks.size();
		if(cache.liveStamp != mIslandSurfaceLiveStamp || !cache.particles)
			continue;
		mBlocks.reserve(mBlocks.size() + cache.nbParticles);
		for(PxU32 particleIndex = 0; particleIndex < cache.nbParticles;
			++particleIndex)
		{
			AvbdBlock block;
			block.objectIndex = cacheIndex;
			block.stateIndex = particleIndex;
			block.particle = cache.particles + particleIndex;
			block.ogcRegion = cache.ogcRegions ? cache.ogcRegions + particleIndex : NULL;
			block.ogcExceeded = cache.ogcExceeded ? cache.ogcExceeded + particleIndex : NULL;
			block.type = eAVBD_BLOCK_PARTICLE3;
			block.particleKernel = eAVBD_PARTICLE_KERNEL_TRIANGLE;
			mBlocks.pushBack(block);
		}
	}
}

void AvbdDynamicsContext::compileRowProgram()
{
    const bool valid = mRowProgram.compile(mRows.size(), mBlocks.size(),
        [&](PxU32 index, const auto& emit)
    {
        const AvbdRow& row = mRows[index];
        if((row.bodyA != PX_MAX_U32 && row.bodyA >= mBodies.size()) ||
            (row.bodyB != PX_MAX_U32 && row.bodyB >= mBodies.size()) ||
            row.supportStart > mRowSupports.size() ||
            row.supportCount > mRowSupports.size() - row.supportStart) return false;
        emit(row.bodyA); emit(row.bodyB);
        for(PxU32 s = row.supportStart; s < row.supportStart + row.supportCount; ++s)
            emit(mRowSupports[s].block);
        return true;
    });
    if(!valid)
    {
        PxGetFoundation().error(PxErrorCode::eINVALID_OPERATION, PX_FL,
            "AVBD row contains an undeclared block or invalid support range; step not published.");
        PxAtomicExchange(&mLocalDomainFailed, 1);
    }
}

void AvbdDynamicsContext::compileVelocityComponents(PxArray<PxU32>& parents) const
{
    mRowProgram.components(parents, [&](PxU32 index)
    {
        const AvbdBlock& block = mBlocks[index];
        return block.type == eAVBD_BLOCK_RIGID6 ? avbdBodyResponds(mBodies[block.objectIndex]) :
            block.particle && block.particle->invMass > 0.0f;
    }, [&](PxU32 row) { return !(mRows[row].flags & eAVBD_ROW_INACTIVE); });
}

void AvbdDynamicsContext::clipRigidContactStep(PxU32 i, PxVec3& dp,
	PxVec3& dth) const
{
  // Directional pair trust region.  A core-overlap row retains the soft
  // endpoint's remaining inertial displacement so both endpoints leave the
  // invalid topology coherently.  Once live clearance is positive, row C
  // owns the shell and replaying pHat-p would oppose elastic separation.
  if(i + 1 >= mRowProgram.blockOffsets.size())
    return;
  const PxReal tolerance = 1.0e-6f;
  auto candidateGap = [&](const AvbdRow& row, PxReal fraction)
  {
    PxTransform candidateBody(mBodies[i].p,mBodies[i].q);
    avbdApplyDelta(candidateBody,dp*fraction,dth*fraction);
    const AvbdRigidPoseView poses={mBodies,&i,&candidateBody,1};
    return avbdHeterogeneousRowC(row,mRowSupports,mBlocks,poses,contactGeometry())+
      PxReal(avbdHeterogeneousAdmissionOffset(row));
  };
  auto rigidJacobian = [&](const AvbdRow& row, PxVec3& jLin, PxVec3& jAng)
  {
    jLin = PxVec3(0.0f);
    jAng = PxVec3(0.0f);
    for(PxU32 supportIndex = row.supportStart;
        supportIndex < row.supportStart + row.supportCount; ++supportIndex)
    {
      if(supportIndex >= mRowSupports.size()) break;
      const AvbdRowSupport& support = mRowSupports[supportIndex];
      if(support.block != i || support.block >= mBlocks.size())
        continue;
      PxVec3 supportLin, supportAng;
      if(avbdHeterogeneousSupportJacobian(row, support,
          mBlocks[support.block], mBodies, contactGeometry(), mRowSupports, mBlocks, supportLin, supportAng))
      {
        jLin += supportLin;
        jAng += supportAng;
      }
    }
  };
  for(PxU32 slot = mRowProgram.blockOffsets[i];
      slot < mRowProgram.blockOffsets[i + 1]; ++slot)
  {
    if(slot >= mRowProgram.blockRows.size()) break;
    const PxU32 rowIndex = mRowProgram.blockRows[slot];
    if(rowIndex >= mRows.size()) continue;
    const AvbdRow& row = mRows[rowIndex];
    if((row.flags & (eAVBD_ROW_CONTACT | eAVBD_ROW_SOFT_PAIR |
        eAVBD_ROW_INACTIVE)) !=
        (eAVBD_ROW_CONTACT | eAVBD_ROW_SOFT_PAIR) || !row.supportCount)
      continue;
    const PxReal currentGap = avbdHeterogeneousRowC(row, mRowSupports,
        mBlocks, mBodies, contactGeometry()) +
        PxReal(avbdHeterogeneousAdmissionOffset(row));
    const PxReal lower = PxReal(avbdHeterogeneousAdmissionLower(row,
        double(currentGap)));
    const PxReal rel0 = candidateGap(row, 0.0f);
    const PxReal rel1 = candidateGap(row, 1.0f);
    if(!PxIsFinite(currentGap) || !PxIsFinite(lower) ||
      !PxIsFinite(rel0) || !PxIsFinite(rel1))
    {
      dp = PxVec3(0.0f);
      dth = PxVec3(0.0f);
      return;
    }
    // The contact shell bounds the potential support, not outward motion.
    // Inertial separation must survive warmstart and final BDF unchanged.
    if(rel1 >= lower - tolerance)
      continue;
    if(rel0 > lower + tolerance)
    {
      PxReal lo = 0.0f, hi = 1.0f;
      for(PxU32 iteration = 0; iteration < 10; ++iteration)
      {
        const PxReal mid = 0.5f * (lo + hi);
		if(candidateGap(row, mid) >= lower + tolerance) lo = mid;
        else hi = mid;
      }
      dp *= lo;
      dth *= lo;
      continue;
    }
    PxVec3 jLin, jAng;
    rigidJacobian(row, jLin, jAng);
    const PxReal vn = jLin.dot(dp) + jAng.dot(dth);
    const PxReal metric = jLin.magnitudeSquared() + jAng.magnitudeSquared();
    if(vn < 0.0f && metric > 1.0e-20f)
    {
      const PxReal s = vn / metric;
      dp -= jLin * s;
      dth -= jAng * s;
    }
  }
}

// Final-pose admission follows every candidate transformation.  Checking the
// Newton direction before OGC projection is insufficient: that projection can
// cross another contact, and finite rotation is not its tangent Jacobian.
// Initially overlapping rows may recover, but may not deepen their gap.
bool AvbdDynamicsContext::projectNpCandidate(PxU32 i,PxTransform& candidate) const
{
    if(mNpDomainMode!=2) return true;
    if(i+1>=mRowProgram.blockOffsets.size()) return true;
    AvbdOgcProjectionPlanes planes;
    const PxVec3& anchor=mBodies[i].p;
    const PxVec3d target=avbdOgcDouble(candidate.p)-avbdOgcDouble(anchor);
    for(PxU32 slot=mRowProgram.blockOffsets[i];slot<mRowProgram.blockOffsets[i+1];++slot)
    {
        const AvbdRow& row=mRows[mRowProgram.blockRows[slot]];
        if(row.kernelId!=eAVBD_ROW_KERNEL_NP_CONTACT) continue;
        const AvbdNpDomain& domain=mNpDomains[row.geometryIndex-1];
        const PxU32 indices[2]={row.bodyA,row.bodyB};PxTransform poses[2];
        for(PxU32 s=0;s<2;++s)
            poses[s]=indices[s]==i?candidate:(indices[s]<mBodies.size()?
                PxTransform(mBodies[indices[s]].p,mBodies[indices[s]].q):domain.fixedPose[s]);
        AvbdOgcProjectionPlane plane;
        plane.n=domain.normal*(row.bodyA==i?1.0:-1.0);
        plane.b=plane.n.dot(target)-avbdNpGap(domain,poses);
        plane.roundoff=0;
        planes.pushBack(plane);
    }
    if(planes.empty()) return true;
    // Geometry restoration must stay in the same public motion subspace as
    // the Newton proposal. Projecting in unrestricted R^3 can move a locked
    // axis even when avbdProjectLockedDelta removed that component above.
    if(mBodies[i].core)
        for(PxU32 axis=0;axis<3;++axis)
            if(mBodies[i].core->lockFlags & PxRigidDynamicLockFlag::Enum(1u<<axis))
            {
                AvbdOgcProjectionPlane plane;
                plane.n=PxVec3d(0);plane.n[axis]=1;plane.b=plane.roundoff=0;
                planes.pushBack(plane);plane.n[axis]=-1;planes.pushBack(plane);
            }
    avbdOgcCompactParallelPlanes(planes);
    PxVec3d projected;
    if(!avbdOgcProjectHalfSpacesExact(planes,target,projected,PxMat33d(PxIdentity))) return false;
    return avbdOgcPublishRegionPoint(anchor,projected,planes,PX_MAX_F32,candidate.p,&anchor);
}

bool AvbdDynamicsContext::rigidContactCandidateAdmissible(PxU32 i,
 const PxTransform& candidate) const
{
 if(!candidate.p.isFinite() || !candidate.q.isFinite()) return false;
 if(mBodies[i].ogcRegionValid)
 {
  AvbdOgcRigidRegion live=mBodies[i].ogcRegion;
  for(PxU32 k=0;k<live.planeCount;++k)
   live.planes[k].partnerDelta=avbdOgcLivePartnerDelta(live.planes[k],mBodies,mIslandSoftCache);
  if(!avbdOgcRigidContains(live,candidate.p,candidate.q)) return false;
 }
 if(i + 1 >= mRowProgram.blockOffsets.size()) return true;
 const AvbdRigidPoseView poses = {mBodies,&i,&candidate,1};
 for(PxU32 slot=mRowProgram.blockOffsets[i];slot<mRowProgram.blockOffsets[i+1];++slot)
 {
  const AvbdRow& row=mRows[mRowProgram.blockRows[slot]];
  if(mNpDomainMode==2 && !avbdNpCandidateAdmissible(row,mNpDomains,mBodies,poses,mKernels)) return false;
  if(row.kernelId==eAVBD_ROW_KERNEL_TETRAHEDRON)
  {
   if(!tetrahedronPath(row,mTetrahedronMaterials[row.geometryIndex-1],mRowSupports,mBodies,poses)) return false;
   continue;
  }
  if(!row.supportCount || !(row.flags&eAVBD_ROW_CONTACT) ||
   (row.flags&eAVBD_ROW_INACTIVE)) continue;
  if(!avbdHeterogeneousCandidateAdmissible(row,mRowSupports,mBlocks,mBodies,
   mBlocks,poses,contactGeometry())) return false;
 }
 return true;
}

template<class PoseView>
double AvbdDynamicsContext::rigidRowEnergy(PxU32 index,PxU32 block,
    const PoseView& poses,PxReal invH2) const
{
    const AvbdRow& row=mRows[index];
    if((row.flags&eAVBD_ROW_INACTIVE) || row.kernelId==eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN) return 0;
    if(row.kernelId==eAVBD_ROW_KERNEL_ELASTIC_FRAME)
    {
        const auto e=evaluateElasticFrame(row,mElasticFrameMaterials,poses,mKernels,false);
        return e.valid?e.energy:double(PX_MAX_F32);
    }
    if(row.kernelId==eAVBD_ROW_KERNEL_TETRAHEDRON)
    {
        PxVec3d points[4];tetrahedronPoints(row,mRowSupports,poses,points);
        AvbdTetrahedronEvaluation e;
        AvbdTetrahedronArgs args={&mTetrahedronMaterials[row.geometryIndex-1],points,&e};
        mKernels.launch(AVBD_TETRAHEDRON_MATERIAL,&args);
        return e.valid ? e.energy : double(PX_MAX_F32);
    }
    if(row.supportCount && (row.flags&eAVBD_ROW_CONTACT))
        return avbdHeterogeneousContactPotential(row,
            avbdHeterogeneousRowC(row,mRowSupports,mBlocks,poses,contactGeometry())).energy;
    const PxReal C=avbdPrimalC(row,poses,getLengthScale());
    PxReal penalty=(row.flags&eAVBD_ROW_DRIVE) ? avbdDrivePenalty(row,mBodies) : avbdHardJointPenalty(row,mBodies,invH2);
    PX_UNUSED(block);
    return (row.flags&(eAVBD_ROW_CONTACT|eAVBD_ROW_UNILATERAL))==(eAVBD_ROW_CONTACT|eAVBD_ROW_UNILATERAL) ?
        avbdNpContactPotential(row,C).energy :
        avbdBoundedRowEnergy(C,penalty,row.lambda,row.minLambda,row.maxLambda);
}

PxReal AvbdDynamicsContext::rigidBlockEnergy(PxU32 i,
    const PxTransform& candidate,PxReal invH2) const
{
    const AvbdSolverBody& original=mBodies[i];
    const AvbdRigidPoseView poses={mBodies,&i,&candidate,1};
    const PxVec3 dp=candidate.p-original.pHat;
    PxReal energy=0.5f*original.massInvH2*dp.magnitudeSquared()+
        avbdRotationInertialPotential(original.qHat,candidate.q,original.inertiaWorldInvH2).energy;
    for(PxU32 slot=mRowProgram.blockOffsets[i];slot<mRowProgram.blockOffsets[i+1];++slot)
        // The four-point potential is evaluated in double. Round the sum,
        // not the individual contribution before Armijo admission.
        energy=PxReal(double(energy)+rigidRowEnergy(mRowProgram.blockRows[slot],i,poses,invH2));
    return energy;
}

bool AvbdDynamicsContext::solvePrimalRigidGroup(PxU32 root,PxReal invH2)
{
    AvbdRigidGroup& group=mRigidGroups[root];++group.attempts;
    bool scalarObjective=true,sharedContact=false;
    for(PxU32 r=0;r<group.rowCount;++r)
    {
        const AvbdRigidGroupRow& entry=mRigidGroupRows[group.rowStart+r];
        const AvbdRow& row=mRows[entry.row];
        if(row.flags&eAVBD_ROW_INACTIVE) continue;
        if((row.flags&eAVBD_ROW_CONTACT) && row.supportCount && entry.supportCount>1)
        { ++group.unsupported;return false; }
        if(row.positionTangent && row.mu>0) scalarObjective=false;
        if((row.flags&eAVBD_ROW_CONTACT) && entry.supportCount>1) sharedContact=true;
    }
    if(!scalarObjective)++group.frictionAttempts;
    if(sharedContact)++group.sharedContactAttempts;
    PxTransform original[4],candidate[4];
    AvbdRigidAssembly assemblies[4];
    PxReal diagonal[4][6][6],gradient[4][6],step[4][6];
    PxInlineArray<AvbdGroupFactor,32> factors;
    const PxU32 factorCount=mRigidGroupFactorOffsets[group.sharedStart+group.sharedCount]-
        mRigidGroupFactorOffsets[group.sharedStart];
    factors.resize(factorCount);
    PxMemZero(factors.begin(),factors.size()*sizeof(AvbdGroupFactor));
    for(PxU32 s=0;s<group.count;++s)
    {
        const PxU32 block=group.blocks[s];original[s]=PxTransform(mBodies[block].p,mBodies[block].q);
        assemblies[s].coupledRows=mRigidGroupSharedRows.begin()+group.sharedStart;
        assemblies[s].count=group.sharedCount;assemblies[s].member=s;
        assemblies[s].factors=factors.begin();assemblies[s].consistent=true;
        assemblies[s].factorOffsets=mRigidGroupFactorOffsets.begin()+group.sharedStart;
        assemblies[s].lockedMask=mBodies[block].core?PxU32(mBodies[block].core->lockFlags):0;
        initializeRigidMaterial(mBodies[block],assemblies[s].hessian,assemblies[s].gradient);
    }
    // Row-major assembly retains each block's row order. Material kernels
    // execute once, then feed every incident endpoint and shared factor.
    for(PxU32 r=0;r<group.rowCount;++r)
    {
        const auto& entry=mRigidGroupRows[group.rowStart+r];const AvbdRow& row=mRows[entry.row];
        if((row.flags&eAVBD_ROW_INACTIVE) || row.kernelId==eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN)continue;
        if(accumulateRigidMaterialRow(entry.row,group.blocks,group.count,assemblies))
        {
            ++group.materialEvaluations;group.materialEndpointUses+=entry.supportCount;
            if(mLocalDomainFailed)return true;
        }
        else mRowProgram.forEachBlock(entry.row,[&](PxU32 block)
        {
            for(PxU32 s=0;s<group.count;++s)if(group.blocks[s]==block)
                accumulateRigidConstraintRow(block,entry.row,invH2,assemblies[s]);
        });
    }
    for(PxU32 s=0;s<group.count;++s)
    {
        auto& a=assemblies[s];
        avbdKernelRestrict6(a.hessian,a.gradient,a.lockedMask);
        for(PxU32 d=0;d<6;++d)a.hessian[d][d]+=AVBD_REG;
        PxMemCopy(diagonal[s],a.hessian,sizeof(diagonal[s]));
        PxMemCopy(gradient[s],a.gradient,sizeof(gradient[s]));
        if(!a.consistent)return false;
    }
    bool solved=false;
    AvbdLinearResponseResult linear={false,0,0,0};
    AvbdGroupSolveArgs args={group.count,diagonal,gradient,factors.begin(),factors.size(),step,&solved,&linear};
    mKernels.launch(AVBD_RIGID_GROUP,&args);
    group.products+=linear.operatorCalls;
    if(!solved) return false;
    ++group.kernelSolved;
    auto energy=[&](const PxTransform* states)
    {
        const AvbdRigidPoseView poses={mBodies,group.blocks,states,group.count};double value=0;
        for(PxU32 s=0;s<group.count;++s)
        {
            const AvbdSolverBody& body=mBodies[group.blocks[s]];
            const PxVec3 dp=states[s].p-body.pHat;
            value+=.5*double(body.massInvH2)*double(dp.magnitudeSquared())+
                avbdRotationInertialPotential(body.qHat,states[s].q,body.inertiaWorldInvH2).energy;
        }
        for(PxU32 r=0;r<group.rowCount;++r)
        {
            const AvbdRigidGroupRow& entry=mRigidGroupRows[group.rowStart+r];
            value+=rigidRowEnergy(entry.row,entry.representative,poses,invH2);
        }
        return value;
    };
    auto admissible=[&]()
    {
        const AvbdRigidPoseView poses={mBodies,group.blocks,candidate,group.count};
        for(PxU32 s=0;s<group.count;++s)
        {
            if(!candidate[s].p.isFinite() || !candidate[s].q.isFinite()) return false;
            const AvbdSolverBody& body=mBodies[group.blocks[s]];
            if(body.ogcRegionValid)
            {
                AvbdOgcRigidRegion live=body.ogcRegion;
                for(PxU32 k=0;k<live.planeCount;++k) live.planes[k].partnerDelta=avbdOgcLivePartnerDelta(live.planes[k],poses,mIslandSoftCache);
                if(!avbdOgcRigidContains(live,candidate[s].p,candidate[s].q)) return false;
            }
        }
        for(PxU32 r=0;r<group.rowCount;++r)
        {
            const AvbdRow& row=mRows[mRigidGroupRows[group.rowStart+r].row];
            if(row.flags&eAVBD_ROW_INACTIVE) continue;
            if(mNpDomainMode==2 && !avbdNpCandidateAdmissible(row,mNpDomains,mBodies,poses,mKernels)) return false;
            if(row.kernelId==eAVBD_ROW_KERNEL_TETRAHEDRON)
            {
                if(!tetrahedronPath(row,mTetrahedronMaterials[row.geometryIndex-1],mRowSupports,mBodies,poses)) return false;
            }
            else if(row.kernelId==eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN)
            {
                AvbdOgcProjectionPlane planes[9];
                avbdCompileTriangleDomain(row,mTriangleDomainGeometry[row.geometryIndex-1],mRowSupports,mBlocks,poses,PX_MAX_U32,mKernels,planes);
                for(PxU32 k=0;k<9;++k) if(planes[k].b>planes[k].roundoff) return false;
            }
            else if(row.supportCount && (row.flags&eAVBD_ROW_CONTACT) &&
                !avbdHeterogeneousCandidateAdmissible(row,mRowSupports,mBlocks,mBodies,mBlocks,poses,contactGeometry())) return false;
        }
        return true;
    };
    const double initial=scalarObjective?energy(original):0;PxReal fraction=1;
    for(PxU32 search=0;search<16;++search)
    {
        double slope=0,delta[24]={};
        for(PxU32 s=0;s<group.count;++s)
        {
            candidate[s]=original[s];
            PxVec3 dp(step[s][0]*fraction,step[s][1]*fraction,step[s][2]*fraction);
            PxVec3 dth(step[s][3]*fraction,step[s][4]*fraction,step[s][5]*fraction);
            avbdProjectLockedDelta(mBodies[group.blocks[s]],dp,dth);avbdApplyDelta(candidate[s],dp,dth);
            const PxVec3 accepted=candidate[s].p-original[s].p;
            const PxVec3 angle=avbdAcceptedRotationDisplacement(original[s].q,candidate[s].q);
            for(PxU32 k=0;k<3;++k) slope+=double(gradient[s][k])*accepted[k]+double(gradient[s][k+3])*angle[k];
            for(PxU32 k=0;k<3;++k){delta[6*s+k]=accepted[k];delta[6*s+k+3]=angle[k];}
        }
        if(admissible())
        {
            const double trial=scalarObjective?energy(candidate):avbdGroupModelChange(args,delta);
            // Coulomb is non-associated. This is an assembled model test,
            // not a fictitious global friction energy or an NCP certificate.
            if(PxIsFinite(trial) && (scalarObjective?
                (slope<=0 && trial<=initial+1.e-4*slope):trial<=0))
            {
                for(PxU32 s=0;s<group.count;++s)
                {
                    const PxU32 b=group.blocks[s];
                    const PxReal dp=(candidate[s].p-original[s].p).magnitude();
                    const PxReal angle=avbdAcceptedRotationDisplacement(original[s].q,candidate[s].q).magnitude();
                    mPrimalSteps[b]=PxMax(dp/(getLengthScale()*AVBD_ARTIC_POSITION_REL_TOL),angle/AVBD_ARTIC_ROTATION_TOL);
                    if(candidate[s].p!=original[s].p || !(candidate[s].q==original[s].q)) mPrimalChangedIteration[b]=mStep.iteration+1;
                    mBodies[b].p=candidate[s].p;mBodies[b].q=candidate[s].q;
                }
                ++group.accepted;
                if(!scalarObjective)++group.frictionAccepted;
                if(sharedContact)++group.sharedContactAccepted;
                return true;
            }
        }
        fraction*=.5f;
    }
    return false;
}

PxReal AvbdDynamicsContext::solvePrimalRigidBlock(PxU32 i, PxReal invH2)
{
	const PxReal invLengthScale = 1.0f / PxMax(getLengthScale(), 1.0e-6f);
	PxVec3 dp, dth, gradientLinear, gradientAngular;
	PxReal metric[6][6]={};
	solvePrimalBody(i, invH2, dp, dth, gradientLinear, gradientAngular,
		mNpDomainMode==2?metric:NULL);
	const AvbdSolverBody& body = mBodies[i];
	const PxTransform original(body.p,body.q);
	// Position-friction currently projects an anisotropic tangent force and
	// has no matching scalar primitive. Preserve that existing program until
	// its variational law is specified; do not invent a false energy oracle.
	bool scalarObjective = true;
	for(PxU32 slot = mRowProgram.blockOffsets[i]; slot < mRowProgram.blockOffsets[i + 1]; ++slot)
	{
		const AvbdRow& row = mRows[mRowProgram.blockRows[slot]];
		if(!(row.flags & eAVBD_ROW_INACTIVE) && row.positionTangent && row.mu > 0.0f)
			scalarObjective = false;
	}
	const PxReal initialEnergy = scalarObjective ? rigidBlockEnergy(i, original, invH2) : 0.0f;
	// A prescribed boundary can make the initial iterate infeasible at the
	// end time. A feasible constrained proposal has priority over its finite
	// unconstrained energy. Every geometric/material check still applies.
	const bool initialFeasible = mNpDomainMode!=2 || rigidContactCandidateAdmissible(i,original);
	PxReal fraction = 1.0f;
	for(PxU32 search = 0; search < (scalarObjective || mNpDomainMode==2 ? 16u : 1u); ++search)
	{
		PxVec3 trialDp = dp * fraction, trialDth = dth * fraction;
		clipRigidContactStep(i, trialDp, trialDth);
		PxTransform candidate = original;
		avbdApplyDelta(candidate, trialDp, trialDth);
		if(!projectNpCandidate(i,candidate)) { fraction*=0.5f;continue; }
		bool spent = false;
        if(body.ogcRegionValid)
        {
            const AvbdOgcClip clip=avbdOgcTruncateRigidRelative(body.ogcRegion,
                candidate.p,candidate.q,mBodies,mIslandSoftCache);
            // A fixed trial rotation can have no admissible translation;
            // reduce the full 6-DOF proposal before declaring a failure.
            if(!clip.feasible) { fraction*=0.5f; continue; }
			spent=clip.spent;
        }
		const PxVec3 acceptedDp = candidate.p - original.p;
		const PxVec3 acceptedDth = avbdAcceptedRotationDisplacement(original.q, candidate.q);
		const PxReal slope = gradientLinear.dot(acceptedDp) + gradientAngular.dot(acceptedDth);
		const PxReal trialEnergy = scalarObjective ? rigidBlockEnergy(i, candidate, invH2) : 0.0f;
		bool modelAccepted=true;
		if(!scalarObjective && mNpDomainMode==2 && initialFeasible)
		{
			// Non-associated Coulomb has no claimed scalar energy here. Its
			// assembled positive local model still must decrease after a
			// projection that can radically change the original Newton step.
			const double delta[6]={acceptedDp.x,acceptedDp.y,acceptedDp.z,
				acceptedDth.x,acceptedDth.y,acceptedDth.z};
			double quadratic=0;
			for(PxU32 r=0;r<6;++r) for(PxU32 c=0;c<6;++c)
				quadratic+=delta[r]*metric[r][c]*delta[c];
			modelAccepted=PxIsFinite(quadratic) && double(slope)+.5*quadratic<=0;
		}
		if(rigidContactCandidateAdmissible(i, candidate) &&
			modelAccepted &&
			(!scalarObjective || (!initialFeasible && PxIsFinite(trialEnergy)) || (slope <= 0.0f && PxIsFinite(trialEnergy) &&
			trialEnergy <= initialEnergy + 1.0e-4f * slope)))
		{
			mBodies[i].p = candidate.p;
			mBodies[i].q = candidate.q;
			if(spent) mBodies[i].ogcExceeded = 1;
			return PxMax(acceptedDp.magnitude() * invLengthScale / AVBD_ARTIC_POSITION_REL_TOL,
				acceptedDth.magnitude() / AVBD_ARTIC_ROTATION_TOL);
		}
		fraction *= 0.5f;
	}
    if(!rigidContactCandidateAdmissible(i,original))
    {
        PxGetFoundation().error(PxErrorCode::eDEBUG_INFO,PX_FL,
            "AVBD domain diagnostic: committed Rigid6 state outside contact domain.");
        PxAtomicExchange(&mLocalDomainFailed,1);
    }
	return 0.0f;
}

void AvbdDynamicsContext::applyDual()
{
	const PxU32 nbRows = mRows.size();
	const PxReal invH2 = mDt > 0.0f ? 1.0f / (mDt * mDt) : 0.0f;
	const PxReal beta = AVBD_BETA / PxMax(getLengthScale(), 1.0e-6f);
	for(PxU32 ri = 0; ri < nbRows; ++ri)
	{
		AvbdRow& row = mRows[ri];
		if((row.flags & eAVBD_ROW_INACTIVE) || row.kernelId==eAVBD_ROW_KERNEL_TRIANGLE_DOMAIN)
			continue;
        if(row.kernelId==eAVBD_ROW_KERNEL_TETRAHEDRON || row.kernelId==eAVBD_ROW_KERNEL_ELASTIC_FRAME) continue;
		PxReal C;
		if(row.supportCount)
		{
			if(avbdHeterogeneousPositionAl(row))
				C = avbdHeterogeneousAlC(row, mRowSupports, mBlocks, mBodies, contactGeometry());
			else
			{
				C = avbdHeterogeneousRowC(row, mRowSupports, mBlocks, mBodies, contactGeometry());
			}
		}
		else
			C = avbdPrimalC(row, mBodies, getLengthScale());
		if(row.flags & eAVBD_ROW_CONTACT)
		{
			const PxReal oldFn = row.lambda;
			PxReal Fn;
			if(row.supportCount && !avbdHeterogeneousPositionAl(row))
			{
				// Heterogeneous OGC normal is a geometric potential: publish its
				// current force for material capacity and reports.
				Fn = avbdHeterogeneousContactPotential(row, C).gradient;
			}
			else
			{
				// demo3d updateDual: lambda <- min(0, rho*C + lambda); the penalty
				// grows only while the row is load-bearing (Eq. 16).
				Fn = row.supportCount ?
					avbdHeterogeneousContactPotential(row, C).gradient :
					avbdNpContactPotential(row,C).gradient;
				const PxReal residual=!row.supportCount && row.contactRadius>0 ?
					(Fn-oldFn)/row.rho:C;
				if(Fn < 0.0f)
					row.rho = PxMin(AVBD_CONTACT_PENALTY_MAX,
						row.rho + beta * PxAbs(residual));
			}
			PxReal f0 = 0.0f;
			PxReal f1 = 0.0f;
			PxReal cT0 = 0.0f;
			PxReal cT1 = 0.0f;
			bool frictionStick = false;
			if(row.mu > 0.0f && row.positionTangent)
			{
				const PxVec3 rel = avbdContactRelDisp(row, mBodies);
				cT0 = (1.0f - AVBD_ALPHA) * row.tangentC0 + row.t0.dot(rel);
				cT1 = (1.0f - AVBD_ALPHA) * row.tangentC1 + row.t1.dot(rel);
				f0 = row.rhoT0 * cT0 + row.lambdaT0;
				f1 = row.rhoT1 * cT1 + row.lambdaT1;
				// Stick/slip is classified from the trial dual force.  The
				// projected force is always inside the Coulomb disk and therefore
				// cannot be used as the classifier: doing so grows tangent rho on
				// every sliding sweep and turns an impact manifold into a weld.
				const PxReal preLen = PxSqrt(f0 * f0 + f1 * f1);
				const PxReal boundT = PxAbs(Fn) * row.mu;
				avbdProjectCoulomb(Fn, row.mu, f0, f1);
				frictionStick = preLen <= boundT;
				if(frictionStick)
				{
					row.rhoT0 = PxMin(AVBD_CONTACT_PENALTY_MAX,
						row.rhoT0 + beta * PxAbs(cT0));
					row.rhoT1 = PxMin(AVBD_CONTACT_PENALTY_MAX,
						row.rhoT1 + beta * PxAbs(cT1));
				}
			}
			row.lambda = Fn;
			row.lambdaT0 = f0;
			row.lambdaT1 = f1;
			// A tangent is conditioned only after the Signorini row becomes
			// load-bearing.  This gives a loaded Coulomb coordinate the same
			// dimensionless stiffness as its normal without turning separated
			// speculative contacts into a tangential glue network.
			if(Fn < 0.0f && oldFn >= 0.0f && row.positionTangent)
				avbdFloorLoadedContactTangentRho(row, mBodies, mDt);
			if(row.forceWriteback)
				*row.forceWriteback = -row.lambda;
			if(ri < mContactWarm.size())
			{
				mContactWarm[ri].lambda = row.lambda;
				mContactWarm[ri].lambdaT0 = row.lambdaT0;
				mContactWarm[ri].lambdaT1 = row.lambdaT1;
				mContactWarm[ri].rho = row.rho;
				mContactWarm[ri].rhoT0 = row.rhoT0;
				mContactWarm[ri].rhoT1 = row.rhoT1;
				mContactWarm[ri].t0 = row.t0;
				mContactWarm[ri].t1 = row.t1;
				mContactWarm[ri].stick = PxU8(frictionStick);
			}
		}
		else if(row.flags & eAVBD_ROW_DRIVE)
		{
			// A drive is a physical spring/damper potential. A persistent AL
			// multiplier would apply the authored force a second time.
			row.lambda = 0.0f;
		}
		else
		{
			PxReal dualStep = row.rho;
			if((row.flags & eAVBD_ROW_DRIVE) == 0)
				avbdHardJointPenalty(row, mBodies, invH2, &dualStep);
			const bool pointLock = (row.flags & eAVBD_ROW_POINT_LOCK) != 0;
			// Point locks use AVBD_2's in-sweep relaxation with the bounded
			// dual step above. Other hard 1D rows retain demo3d lambda += K*C.
			const PxReal retention = pointLock ? AVBD_POINT_LOCK_DUAL_DECAY : 1.0f;
			PxReal next = row.lambda * retention + dualStep * C;
			next = PxMin(row.maxLambda, PxMax(row.minLambda, next));
			row.lambda = next;
			// Point-lock rho is fixed. Other hard rows grow it inside the
			// force bounds; angular rows use demo3d's smaller betaAng.
			if(!pointLock && next > row.minLambda && next < row.maxLambda)
			{
				const bool angularRow = row.articJoint ?
					row.articAxis < PxArticulationAxis::eX :
					(row.jLinA.magnitudeSquared() < 1.0e-12f &&
					 row.jLinB.magnitudeSquared() < 1.0e-12f);
				const PxReal rowBeta = angularRow ?
					AVBD_BETA * AVBD_JOINT_BETA_ANGULAR_SCALE : beta;
				row.rho = PxMin(AVBD_RHO_MAX, row.rho + rowBeta * PxAbs(C));
			}
		}
	}
	writeJointDualState();
}

static PxReal avbdMaterialEndpointResponse(const AvbdSolverBody& b,
	const PxVec3& axis, const PxVec3& arm)
{
	if(!avbdBodyResponds(b))
		return 0.0f;
	const PxVec3 jAngLocal = b.qStart.rotateInv(arm.cross(axis));
	return b.invMass +
		jAngLocal.x * jAngLocal.x * b.invInertia.x +
		jAngLocal.y * jAngLocal.y * b.invInertia.y +
		jAngLocal.z * jAngLocal.z * b.invInertia.z;
}

static PxReal avbdMaterialAxisResponse(const AvbdRow& row,
	const AvbdMaterialRow& material, const PxArray<AvbdSolverBody>& bodies,
	const PxVec3& axis)
{
	PxReal response = 0.0f;
	if(row.bodyA < bodies.size())
		response += avbdMaterialEndpointResponse(bodies[row.bodyA], axis,
			material.armA);
	if(row.bodyB < bodies.size())
		response += avbdMaterialEndpointResponse(bodies[row.bodyB], axis,
			material.armB);
	return PxIsFinite(response) && response > 1.0e-12f ? response : 0.0f;
}

static PxReal avbdMaterialLinearAxisResponse(const AvbdRow& row,
	const PxArray<AvbdSolverBody>& bodies)
{
	PxReal response = 0.0f;
	if(row.bodyA < bodies.size() && avbdBodyResponds(bodies[row.bodyA]))
		response += bodies[row.bodyA].invMass;
	if(row.bodyB < bodies.size() && avbdBodyResponds(bodies[row.bodyB]))
		response += bodies[row.bodyB].invMass;
	return PxIsFinite(response) && response > 1.0e-12f ? response : 0.0f;
}

static PxReal avbdMaterialCrossResponse(const AvbdRow& row,
	const AvbdMaterialRow& material, const PxArray<AvbdSolverBody>& bodies,
	const PxVec3& axis0, const PxVec3& axis1)
{
	PxReal response = 0.0f;
	const PxU32 ids[2] = { row.bodyA, row.bodyB };
	const PxVec3 arms[2] = { material.armA, material.armB };
	for(PxU32 endpoint = 0; endpoint < 2; ++endpoint)
	{
		if(ids[endpoint] >= bodies.size() ||
			!avbdBodyResponds(bodies[ids[endpoint]]))
			continue;
		const AvbdSolverBody& b = bodies[ids[endpoint]];
		const PxVec3 j0 = b.qStart.rotateInv(arms[endpoint].cross(axis0));
		const PxVec3 j1 = b.qStart.rotateInv(arms[endpoint].cross(axis1));
		response += b.invMass * axis0.dot(axis1) +
			j0.x * j1.x * b.invInertia.x +
			j0.y * j1.y * b.invInertia.y +
			j0.z * j1.z * b.invInertia.z;
	}
	return PxIsFinite(response) ? response : 0.0f;
}

struct AvbdMaterialVelocityDelta
{
	double linear[3];
	double angular[3];
	AvbdMaterialVelocityDelta()
	{
		linear[0] = linear[1] = linear[2] = 0.0;
		angular[0] = angular[1] = angular[2] = 0.0;
	}
	void addLinear(const PxVec3& value, double scale = 1.0)
	{
		linear[0] += double(value.x) * scale;
		linear[1] += double(value.y) * scale;
		linear[2] += double(value.z) * scale;
	}
	void addAngular(const PxVec3& value, double scale = 1.0)
	{
		angular[0] += double(value.x) * scale;
		angular[1] += double(value.y) * scale;
		angular[2] += double(value.z) * scale;
	}
	PxVec3 linearPx() const
	{
		return PxVec3(PxReal(linear[0]), PxReal(linear[1]), PxReal(linear[2]));
	}
	PxVec3 angularPx() const
	{
		return PxVec3(PxReal(angular[0]), PxReal(angular[1]), PxReal(angular[2]));
	}
};


static PxReal avbdMaterialAxisVelocity(const AvbdRow& row,
	const AvbdMaterialRow& material, const PxArray<AvbdSolverBody>& bodies,
	const PxArray<AvbdMaterialVelocityDelta>& velocityDelta,
	const PxVec3& axis, bool linearOnly = false)
{
	double velocity = 0.0;
	if(row.bodyA < bodies.size() && bodies[row.bodyA].core)
	{
		const AvbdSolverBody& body = bodies[row.bodyA];
		const AvbdMaterialVelocityDelta& delta = velocityDelta[row.bodyA];
		const PxVec3 angularAxis = linearOnly ? PxVec3(0.0f) :
			material.armA.cross(axis);
		velocity += double(axis.x) * (double(body.outputLinVel.x) + delta.linear[0]) +
			double(axis.y) * (double(body.outputLinVel.y) + delta.linear[1]) +
			double(axis.z) * (double(body.outputLinVel.z) + delta.linear[2]) +
			double(angularAxis.x) * (double(body.outputAngVel.x) + delta.angular[0]) +
			double(angularAxis.y) * (double(body.outputAngVel.y) + delta.angular[1]) +
			double(angularAxis.z) * (double(body.outputAngVel.z) + delta.angular[2]);
	}
	if(row.bodyB < bodies.size() && bodies[row.bodyB].core)
	{
		const AvbdSolverBody& body = bodies[row.bodyB];
		const AvbdMaterialVelocityDelta& delta = velocityDelta[row.bodyB];
		const PxVec3 angularAxis = linearOnly ? PxVec3(0.0f) :
			material.armB.cross(axis);
		velocity -= double(axis.x) * (double(body.outputLinVel.x) + delta.linear[0]) +
			double(axis.y) * (double(body.outputLinVel.y) + delta.linear[1]) +
			double(axis.z) * (double(body.outputLinVel.z) + delta.linear[2]) +
			double(angularAxis.x) * (double(body.outputAngVel.x) + delta.angular[0]) +
			double(angularAxis.y) * (double(body.outputAngVel.y) + delta.angular[1]) +
			double(angularAxis.z) * (double(body.outputAngVel.z) + delta.angular[2]);
	}
	return PxReal(velocity);
}

static void avbdApplyMaterialAxisImpulse(const AvbdRow& row,
	const AvbdMaterialRow& material, PxArray<AvbdSolverBody>& bodies,
	PxArray<AvbdMaterialVelocityDelta>& velocityDelta,
	const PxVec3& axis, double impulse, bool linearOnly = false)
{
	if(!PxIsFinite(PxReal(impulse)) || PxAbs(PxReal(impulse)) < 1.0e-12f)
		return;
	const PxU32 ids[2] = { row.bodyA, row.bodyB };
	const PxVec3 arms[2] = { material.armA, material.armB };
	const PxReal signs[2] = { 1.0f, -1.0f };
	for(PxU32 endpoint = 0; endpoint < 2; ++endpoint)
	{
		if(ids[endpoint] >= bodies.size())
			continue;
		AvbdSolverBody& b = bodies[ids[endpoint]];
		if(!avbdBodyResponds(b))
			continue;
		const PxVec3 endpointAxis = axis * signs[endpoint];
		velocityDelta[ids[endpoint]].addLinear(endpointAxis,
			impulse * double(b.invMass));
		if(!linearOnly)
			velocityDelta[ids[endpoint]].addAngular(avbdWorldInvInertiaMul(
				b, arms[endpoint].cross(endpointAxis)), impulse);
	}
}


void AvbdDynamicsContext::applyImpactMaterial(PxReal dt,
	const PxArray<PxU8>& materialBody,
	const PxArray<PxReal>& linearPoseGain,
	const PxArray<PxReal>& angularPoseGain)
{
	const PxReal bounceThreshold = getBounceThreshold();
	const PxU32 nbRows = mRows.size();
	PxArray<AvbdMaterialVelocityDelta> velocityDelta(mBodies.size());
	PxArray<PxVec3> positionAlRemovalLinear(mBodies.size());
	PxArray<PxVec3> positionAlRemovalAngular(mBodies.size());
	for(PxU32 i = 0; i < mBodies.size(); ++i)
	{
		positionAlRemovalLinear[i] = PxVec3(0.0f);
		positionAlRemovalAngular[i] = PxVec3(0.0f);
	}

	// Material velocity ownership is an island property, not a scene-wide
	// "has any joint" switch.  Publish the rigid contact components once and
	// mark those containing a bilateral row.  Their pose-derived velocity is
	// the coupled Position-AL certificate; a contact-only M^-1 projection cannot
	// replace one span without the corresponding joint-nullspace mobility.
	// prepareRigidVelocities compiled this finalized row program. Only staged
	// velocities changed since then; reuse the same immutable components.
	const PxArray<PxU32>& componentParent = mMaterialComponentParentScratch;
	PxArray<PxU8>& jointComponent = mMaterialJointComponentScratch;
	jointComponent.resize(mBlocks.size());
	for(PxU32 i = 0; i < jointComponent.size(); ++i) jointComponent[i] = 0;
	for(PxU32 ri = 0; ri < nbRows; ++ri)
	{
		const AvbdRow& row = mRows[ri];
		if((row.flags & (eAVBD_ROW_CONTACT | eAVBD_ROW_INACTIVE)) == 0)
			mRowProgram.forEachBlock(ri, [&](PxU32 block)
			{ jointComponent[componentParent[block]] = 1; });
	}
	mMaterialRowsScratch.clear();
	mMaterialRowsScratch.reserve(nbRows);
	for(PxU32 ri = 0; ri < nbRows; ++ri)
	{
		const AvbdRow& row = mRows[ri];
		if((row.flags & eAVBD_ROW_CONTACT) == 0 ||
			(row.flags & (eAVBD_ROW_INACTIVE | eAVBD_ROW_SOFT_PAIR)))
			continue;
		const bool dynamicA = row.bodyA < mBodies.size() &&
			avbdBodyResponds(mBodies[row.bodyA]);
		const bool dynamicB = row.bodyB < mBodies.size() &&
			avbdBodyResponds(mBodies[row.bodyB]);
		const bool jointCoupledPair = dynamicA && dynamicB &&
			componentParent[row.bodyA] == componentParent[row.bodyB] &&
			jointComponent[componentParent[row.bodyA]] != 0;
		// The legacy joint-island restitution coordinate is translational.  Its
		// approach epoch must use the same linear Jacobian as its response; mixing
		// point angular velocity into the target but not the mobility changes the
		// restitution law.
		const PxReal vnIn = jointCoupledPair ?
			row.n.dot(mBodies[row.bodyA].linVel - mBodies[row.bodyB].linVel) :
			avbdContactVn(row, mBodies, true);
		// Restitution is a material event, not a proximity response.  The DCD
		// neighborhood is intentionally wider than the authored contact band for
		// OGC; a point is bounce-eligible only if its incoming normal motion can
		// actually close the detection separation during this step.  This is the
		// same PhysX/TGS eligibility inequality used by the distilled AVBD_2
		// manifold owner, expressed with AvbdRow's signed solve-start separation.
		const PxReal approach = -vnIn;
		const PxReal detectionRate = dt > 0.0f ? row.contactOffset / dt : PX_MAX_F32;
		const bool impactRow = vnIn < bounceThreshold && approach > detectionRate;
		const bool jointLinearRestitution = jointCoupledPair && impactRow &&
			row.restitution > 0.0f;
		// The joint component owns its passive material velocity through the
		// Position-AL pose certificate.  A contact-only endpoint in the same row
		// was reset to solve-start velocity, however, so it must still receive its
		// missing Position-AL material certificate below.  The row itself remains
		// pose-owned and
		// does not run a free-body material projection unless it is the authored
		// restitution coordinate.
		const bool jointPoseOwnedMaterial = jointCoupledPair &&
			!jointLinearRestitution;
		const bool reconstructA = dynamicA && row.bodyA < materialBody.size() &&
			materialBody[row.bodyA];
		const bool reconstructB = dynamicB && row.bodyB < materialBody.size() &&
			materialBody[row.bodyB];
		const bool finiteNormalBudget = row.minLambda > -1.0e15f;
		// NP rigid rows are Position-AL: the material NCP consumes the AL load
		// (-lambda dt) as its normal capacity.  A finite maxImpulse restarts
		// from the incoming velocity and lets the projection spend the authored
		// impulse exactly.
		const bool replayCertificate =
			(!dynamicA || reconstructA) && (!dynamicB || reconstructB);
		AvbdMaterialRow material;
		material.rowIndex = ri;
		PxVec3 freshA = row.ogcRA;
		PxVec3 freshB = row.ogcRB;
		if(row.bodyA < mBodies.size())
			freshA = avbdWorldPoint(mBodies[row.bodyA], row.ogcRA);
		if(row.bodyB < mBodies.size())
			freshB = avbdWorldPoint(mBodies[row.bodyB], row.ogcRB);
		const PxVec3 materialPoint = (freshA + freshB) * 0.5f;
		material.armA = row.bodyA < mBodies.size() ?
			materialPoint - mBodies[row.bodyA].p : PxVec3(0.0f);
		material.armB = row.bodyB < mBodies.size() ?
			materialPoint - mBodies[row.bodyB].p : PxVec3(0.0f);
		material.positionNormalImpulse = finiteNormalBudget && replayCertificate ?
			0.0f : PxMax(0.0f, -row.lambda * dt);
		material.normalImpulse = 0.0f;
		material.normalCapacity = material.positionNormalImpulse;
		material.tangentImpulse0 = 0.0f;
		material.tangentImpulse1 = 0.0f;
		// A fully contact-only row has the exact mapping
		// v = vMinus + M^-1 J^T (-lambda dt).  For a mixed row the same mapping is
		// exact on its contact-only endpoint, while the joint endpoint keeps the
		// response of the complete coupled pose objective.  The row-level material
		// KKT therefore starts with zero incremental impulse unless both endpoints
		// belong to the contact-only velocity epoch.
		if(replayCertificate && !finiteNormalBudget &&
			(row.flags & eAVBD_ROW_FRESH) == 0)
		{
			material.normalImpulse = PxMax(0.0f, -row.lambda * dt);
			material.tangentImpulse0 = -row.lambdaT0 * dt;
			material.tangentImpulse1 = -row.lambdaT1 * dt;
		}
		// A hard-joint island does not yet publish a joint-nullspace material
		// mobility.  AVBD_2 therefore leaves the complete Position-AL response in
		// the pose velocity and closes only the missing dynamic-dynamic bounce
		// coordinate with the two linear inverse masses.  Treating this row as a
		// free spatial contact both replays an AL impulse that cannot be inverted
		// independently and diverts the restitution impulse into the light link's
		// angular modes.
		material.normalLinearOnly = PxU8(jointLinearRestitution);
		material.normalCapacity = PxMax(material.normalCapacity,
			material.positionNormalImpulse + material.normalImpulse);
		avbdProjectCoulomb(material.normalCapacity, row.mu,
			material.tangentImpulse0, material.tangentImpulse1);
		const bool activeMaterialRow = row.lambda < 0.0f ||
			avbdEvalC(row, mBodies) <= 0.0f;
		const bool solveRow = impactRow || activeMaterialRow;
		material.normalTarget = impactRow && row.restitution > 0.0f ?
			-row.restitution * vnIn : 0.0f;
		material.normalResponse = solveRow ?
			(material.normalLinearOnly ?
				avbdMaterialLinearAxisResponse(row, mBodies) :
				avbdMaterialAxisResponse(row, material, mBodies, row.n)) : 0.0f;
		if(!replayCertificate && !jointLinearRestitution &&
			(row.flags & eAVBD_ROW_FRESH) == 0)
		{
			// Reconstruct the missing endpoint certificate from the final AL force
			// integral itself.  This is the exact Position-AL scatter at the
			// persistent contact anchor; projecting pose velocity point-by-point is
			// not equivalent for a multi-point rigid manifold and loses friction.
			const PxU32 ids[2] = { row.bodyA, row.bodyB };
			const bool reconstruct[2] = { reconstructA, reconstructB };
			const PxReal signs[2] = { 1.0f, -1.0f };
			const PxReal impulses[3] = {
				PxMax(0.0f, -row.lambda * dt),
				-row.lambdaT0 * dt,
				-row.lambdaT1 * dt
			};
			const PxVec3 axes[3] = { row.n, row.t0, row.t1 };
			const PxU32 componentCount = row.positionTangent ? 3u : 1u;
			for(PxU32 endpoint = 0; endpoint < 2; ++endpoint)
			{
				if(!reconstruct[endpoint] || ids[endpoint] >= mBodies.size())
					continue;
				const AvbdSolverBody& b = mBodies[ids[endpoint]];
				for(PxU32 component = 0; component < componentCount; ++component)
				{
					const PxVec3 localPoint = component == 0 ?
						(endpoint == 0 ? row.ogcRA : row.ogcRB) :
						(endpoint == 0 ? row.rA : row.rB);
					const PxVec3 persistentArm = b.q.rotate(localPoint);
					const PxReal impulse = impulses[component];
					if(!PxIsFinite(impulse) || PxAbs(impulse) <= 1.0e-12f)
						continue;
					const PxVec3 endpointAxis = axes[component] * signs[endpoint];
					const PxVec3 linearDelta = endpointAxis *
						(impulse * b.invMass);
					const PxVec3 angularDelta = avbdWorldInvInertiaMul(b,
						persistentArm.cross(endpointAxis)) * impulse;
					velocityDelta[ids[endpoint]].addLinear(linearDelta);
					velocityDelta[ids[endpoint]].addAngular(angularDelta);
				}
				material.normalCapacity = PxMax(material.normalCapacity,
					impulses[0]);
			}
		}
		const PxReal totalNormalBudget =
			(finiteNormalBudget && dt > 0.0f) ?
			PxMax(0.0f, -row.minLambda * dt) : PX_MAX_F32;
		material.maxNormalImpulse = totalNormalBudget == PX_MAX_F32 ?
			PX_MAX_F32 : PxMax(0.0f,
				totalNormalBudget - material.positionNormalImpulse);
		material.solveNormal = PxU8(material.normalResponse > 0.0f &&
			!jointPoseOwnedMaterial);
		material.solveTangent = 0;
		// The free-rigid frontier has an exact M^-1 contact operator.  A hard
		// joint island requires its joint-nullspace mobility; until that Schur
		// operator is assembled, retain the coupled pose response and solve only
		// the material residual, matching the AVBD_2 joint path.
		material.replacePositionAl = 0;
		material.tangentStep = 0.0f;
		if(solveRow && row.mu > 0.0f && !jointLinearRestitution &&
			!jointPoseOwnedMaterial)
		{
			const PxReal w0 = avbdMaterialAxisResponse(row, material, mBodies, row.t0);
			const PxReal w1 = avbdMaterialAxisResponse(row, material, mBodies, row.t1);
			if(w0 > 0.0f && w1 > 0.0f)
			{
				const PxReal w01 = avbdMaterialCrossResponse(row, material, mBodies,
					row.t0, row.t1);
				const PxReal trace = w0 + w1;
				const PxReal disc = PxSqrt(PxMax(0.0f,
					(w0 - w1) * (w0 - w1) + 4.0f * w01 * w01));
				const PxReal lipschitz = 0.5f * (trace + disc);
				if(lipschitz > 1.0e-12f)
				{
					material.tangentStep = AVBD_BOUNCE_SOR / lipschitz;
					material.solveTangent = 1;
				}
			}
		}
		mMaterialRowsScratch.pushBack(material);
		// Contact-only components restart at solve-start velocity and replay the
		// AL certificate.  A hard-joint component already contains that response
		// in its pose-derived velocity, so only later impulse deltas are scattered.
		if(replayCertificate)
		{
			avbdApplyMaterialAxisImpulse(row, material, mBodies, velocityDelta, row.n,
				material.normalImpulse);
			avbdApplyMaterialAxisImpulse(row, material, mBodies, velocityDelta, row.t0,
				material.tangentImpulse0);
			avbdApplyMaterialAxisImpulse(row, material, mBodies, velocityDelta, row.t1,
				material.tangentImpulse1);
		}
		else if(material.replacePositionAl)
		{
			// Pose reconstruction already contains the damped Position-AL force
			// integral at the persistent anchors.  Stage its exact inverse here;
			// the same total impulse is replayed below at the fresh common point.
			// Staging all rows before publishing any delta keeps the replacement
			// linear and independent of contact traversal order.
			const PxU32 ids[2] = { row.bodyA, row.bodyB };
			const PxReal signs[2] = { 1.0f, -1.0f };
			const PxVec3 persistentArms[2] = {
				row.bodyA < mBodies.size() ? mBodies[row.bodyA].q.rotate(row.rA) : PxVec3(0.0f),
				row.bodyB < mBodies.size() ? mBodies[row.bodyB].q.rotate(row.rB) : PxVec3(0.0f)
			};
			const PxReal impulses[3] = {
				-material.normalImpulse,
				-material.tangentImpulse0,
				-material.tangentImpulse1
			};
			const PxVec3 axes[3] = { row.n, row.t0, row.t1 };
			const PxU32 componentCount = row.positionTangent ? 3u : 1u;
			for(PxU32 endpoint = 0; endpoint < 2; ++endpoint)
			{
				if(ids[endpoint] >= mBodies.size() ||
					!avbdBodyResponds(mBodies[ids[endpoint]]))
					continue;
				const AvbdSolverBody& b = mBodies[ids[endpoint]];
				const PxReal linGain = ids[endpoint] < linearPoseGain.size() ?
					linearPoseGain[ids[endpoint]] : 1.0f;
				const PxReal angGain = ids[endpoint] < angularPoseGain.size() ?
					angularPoseGain[ids[endpoint]] : 1.0f;
				for(PxU32 component = 0; component < componentCount; ++component)
				{
					const PxVec3 endpointAxis = axes[component] * signs[endpoint];
					const PxReal impulse = impulses[component];
					positionAlRemovalLinear[ids[endpoint]] +=
						endpointAxis * (impulse * b.invMass * linGain);
					positionAlRemovalAngular[ids[endpoint]] +=
						avbdWorldInvInertiaMul(b,
							persistentArms[endpoint].cross(endpointAxis) * impulse) * angGain;
				}
			}
		}
	}

	// Replace the complete admitted Position-AL response atomically.  Applying
	// removal row-by-row while compiling makes a later row observe a different
	// velocity epoch and is not the same KKT.
	for(PxU32 i = 0; i < mBodies.size(); ++i)
	{
		if(!mBodies[i].core || !avbdBodyResponds(mBodies[i]))
			continue;
		velocityDelta[i].addLinear(positionAlRemovalLinear[i]);
		velocityDelta[i].addAngular(positionAlRemovalAngular[i]);
	}
	for(PxU32 mi = 0; mi < mMaterialRowsScratch.size(); ++mi)
	{
		const AvbdMaterialRow& material = mMaterialRowsScratch[mi];
		if(!material.replacePositionAl)
			continue;
		const AvbdRow& row = mRows[material.rowIndex];
		avbdApplyMaterialAxisImpulse(row, material, mBodies, velocityDelta, row.n,
			material.normalImpulse);
		if(row.positionTangent)
		{
			avbdApplyMaterialAxisImpulse(row, material, mBodies, velocityDelta, row.t0,
				material.tangentImpulse0);
			avbdApplyMaterialAxisImpulse(row, material, mBodies, velocityDelta, row.t1,
				material.tangentImpulse1);
		}
	}
	for(PxU32 iter = 0; iter < AVBD_MATERIAL_MAX_ITERS; ++iter)
	{
		// Normal material pass.  The accumulated impulse is the unknown of the
		// unilateral velocity problem; only its delta is scattered to bodies.
		for(PxU32 mi = 0; mi < mMaterialRowsScratch.size(); ++mi)
		{
			AvbdMaterialRow& material = mMaterialRowsScratch[mi];
			if(!material.solveNormal)
				continue;
			const PxU32 ri = material.rowIndex;
			const AvbdRow& row = mRows[ri];
			const PxReal vnNow = avbdMaterialAxisVelocity(row, material, mBodies,
				velocityDelta, row.n, material.normalLinearOnly != 0);
			const PxReal oldJ = material.normalImpulse;
			PxReal newJ = PxMax(0.0f, oldJ +
				(material.normalTarget - vnNow) / material.normalResponse);
			newJ = PxMin(newJ, material.maxNormalImpulse);
			material.normalImpulse = newJ;
			material.normalCapacity = material.positionNormalImpulse + newJ;
			avbdApplyMaterialAxisImpulse(row, material, mBodies, velocityDelta,
				row.n, newJ - oldJ, material.normalLinearOnly != 0);
		}
		PxReal maxNaturalResidual = 0.0f;
		PxReal velocityScale = 1.0f;
		for(PxU32 mi = 0; mi < mMaterialRowsScratch.size(); ++mi)
		{
			const AvbdMaterialRow& material = mMaterialRowsScratch[mi];
			if(!material.solveNormal)
				continue;
			const AvbdRow& row = mRows[material.rowIndex];
			const PxReal gap = avbdMaterialAxisVelocity(row, material, mBodies,
				velocityDelta, row.n, material.normalLinearOnly != 0) -
				material.normalTarget;
			const PxReal residual = material.normalImpulse > 1.0e-8f ?
				PxAbs(gap) : PxMax(0.0f, -gap);
			maxNaturalResidual = PxMax(maxNaturalResidual, residual);
			velocityScale = PxMax(velocityScale,
				PxMax(PxAbs(gap), PxAbs(material.normalTarget)));
		}
		if(maxNaturalResidual <= AVBD_MATERIAL_REL_TOL * velocityScale)
			break;
	}
	// The normal warm solve establishes the cone.  Position-AL already owns
	// hard dynamic-dynamic joint velocities through pose reconstruction; the
	// material stage solves only the contact normal/tangent complementarity.
	for(PxU32 iter = 0; iter < AVBD_MATERIAL_MAX_ITERS; ++iter)
	{
		for(PxU32 mi = 0; mi < mMaterialRowsScratch.size(); ++mi)
		{
			AvbdMaterialRow& material = mMaterialRowsScratch[mi];
			if(!material.solveNormal)
				continue;
			const AvbdRow& row = mRows[material.rowIndex];
			const PxReal oldJ = material.normalImpulse;
			PxReal newJ = PxMax(0.0f, oldJ +
				(material.normalTarget - avbdMaterialAxisVelocity(
					row, material, mBodies, velocityDelta, row.n,
					material.normalLinearOnly != 0)) /
				material.normalResponse);
			newJ = PxMin(newJ, material.maxNormalImpulse);
			material.normalImpulse = newJ;
			material.normalCapacity = material.positionNormalImpulse + newJ;
			avbdApplyMaterialAxisImpulse(row, material, mBodies, velocityDelta,
				row.n, newJ - oldJ, material.normalLinearOnly != 0);
		}
		// Tangential material pass.  Friction is a cumulative two-axis impulse
		// projected onto the disk |jt| <= mu*jn.  Recomputing -vt/w as a fresh
		// impulse each iteration repeatedly injects the cone bound and produces
		// the characteristic post-impact spin.
		for(PxU32 mi = 0; mi < mMaterialRowsScratch.size(); ++mi)
		{
			AvbdMaterialRow& material = mMaterialRowsScratch[mi];
			if(!material.solveTangent)
				continue;
			const PxU32 ri = material.rowIndex;
			const AvbdRow& row = mRows[ri];
			const PxReal old0 = material.tangentImpulse0;
			const PxReal old1 = material.tangentImpulse1;
			PxReal next0 = old0 - material.tangentStep *
				avbdMaterialAxisVelocity(row, material, mBodies, velocityDelta, row.t0);
			PxReal next1 = old1 - material.tangentStep *
				avbdMaterialAxisVelocity(row, material, mBodies, velocityDelta, row.t1);
			avbdProjectCoulomb(material.normalCapacity, row.mu, next0, next1);
			material.tangentImpulse0 = next0;
			material.tangentImpulse1 = next1;
			avbdApplyMaterialAxisImpulse(row, material, mBodies, velocityDelta,
				row.t0, next0 - old0);
			avbdApplyMaterialAxisImpulse(row, material, mBodies, velocityDelta,
				row.t1, next1 - old1);
		}
		PxReal maxNaturalResidual = 0.0f;
		PxReal velocityScale = 1.0f;
		for(PxU32 mi = 0; mi < mMaterialRowsScratch.size(); ++mi)
		{
			const AvbdMaterialRow& material = mMaterialRowsScratch[mi];
			const AvbdRow& row = mRows[material.rowIndex];
			if(material.solveNormal)
			{
				const PxReal gap = avbdMaterialAxisVelocity(row, material, mBodies,
					velocityDelta, row.n, material.normalLinearOnly != 0) -
					material.normalTarget;
				const PxReal residual = material.normalImpulse > 1.0e-8f ?
					PxAbs(gap) : PxMax(0.0f, -gap);
				maxNaturalResidual = PxMax(maxNaturalResidual, residual);
				velocityScale = PxMax(velocityScale,
					PxMax(PxAbs(gap), PxAbs(material.normalTarget)));
			}
			if(material.solveTangent && material.tangentStep > 0.0f)
			{
				const PxReal vt0 = avbdMaterialAxisVelocity(row, material, mBodies,
					velocityDelta, row.t0);
				const PxReal vt1 = avbdMaterialAxisVelocity(row, material, mBodies,
					velocityDelta, row.t1);
				PxReal projected0 = material.tangentImpulse0 -
					material.tangentStep * vt0;
				PxReal projected1 = material.tangentImpulse1 -
					material.tangentStep * vt1;
				avbdProjectCoulomb(material.normalCapacity, row.mu,
					projected0, projected1);
				const PxReal d0 = material.tangentImpulse0 - projected0;
				const PxReal d1 = material.tangentImpulse1 - projected1;
				maxNaturalResidual = PxMax(maxNaturalResidual,
					PxSqrt(d0 * d0 + d1 * d1) / material.tangentStep);
				velocityScale = PxMax(velocityScale, PxSqrt(vt0 * vt0 + vt1 * vt1));
			}
		}
		if(maxNaturalResidual <= AVBD_MATERIAL_REL_TOL * velocityScale)
			break;
	}

	// Publish only the converged net response.  Position-AL removal and total
	// material replay can each be very large for a heavy body on a light joint
	// graph; exposing either intermediate to PxReal body state loses the small
	// physical difference that the material KKT actually solved.
	for(PxU32 i = 0; i < mBodies.size(); ++i)
	{
		AvbdSolverBody& b = mBodies[i];
		if(!b.core || !avbdBodyResponds(b))
			continue;
		const PxVec3 linearDelta = velocityDelta[i].linearPx();
		const PxVec3 angularDelta = velocityDelta[i].angularPx();
		if(!linearDelta.isFinite() || !angularDelta.isFinite())
			continue;
		b.outputLinVel += linearDelta;
		b.outputAngVel += angularDelta;
		if(b.core->lockFlags & PxRigidDynamicLockFlag::eLOCK_LINEAR_X) b.outputLinVel.x = 0.0f;
		if(b.core->lockFlags & PxRigidDynamicLockFlag::eLOCK_LINEAR_Y) b.outputLinVel.y = 0.0f;
		if(b.core->lockFlags & PxRigidDynamicLockFlag::eLOCK_LINEAR_Z) b.outputLinVel.z = 0.0f;
		if(b.core->lockFlags & PxRigidDynamicLockFlag::eLOCK_ANGULAR_X) b.outputAngVel.x = 0.0f;
		if(b.core->lockFlags & PxRigidDynamicLockFlag::eLOCK_ANGULAR_Y) b.outputAngVel.y = 0.0f;
		if(b.core->lockFlags & PxRigidDynamicLockFlag::eLOCK_ANGULAR_Z) b.outputAngVel.z = 0.0f;
	}
}

void AvbdDynamicsContext::prepareRigidVelocities(PxReal dt)
{
	const PxReal invH = dt > 0.0f ? 1.0f / dt : 0.0f;
	// Compile one exclusive writeback epoch per dynamic endpoint.  A body whose
	// incident program is contact-only starts the material solve at solve-start
	// velocity and replays its Position-AL certificate.  A joint/soft endpoint
	// keeps pose-derived velocity; mixed contacts replay the same normal and
	// passive-tangent certificate only on their contact-only endpoint.
	PxArray<PxU8>& materialBody = mMaterialBodyScratch;
	PxArray<PxU8>& hasIncidentRow = mMaterialIncidentScratch;
	PxArray<PxU8>& materialTangentBody = mMaterialTangentBodyScratch;
	PxArray<PxReal>& linearPoseGain = mLinearPoseGainScratch;
	PxArray<PxReal>& angularPoseGain = mAngularPoseGainScratch;
	materialBody.resize(mBlocks.size());
	for(PxU32 i = mBodies.size(); i < mBlocks.size(); ++i) materialBody[i] = 0;
	hasIncidentRow.resize(mBodies.size());
	materialTangentBody.resize(mBodies.size());
	linearPoseGain.resize(mBodies.size());
	angularPoseGain.resize(mBodies.size());
	for(PxU32 i = 0; i < mBodies.size(); ++i)
	{
		// A contact-only body normally publishes the OGC pose velocity. The row
		// pass below retains solve-start velocity only for a phase-I feasibility
		// program, whose geometric repair is not physical momentum.
		materialBody[i] = !mStep.commonProgram && mBodies[i].core && mBodies[i].invMass > 0.0f &&
			!mBodies[i].isKinematic && !mBodies[i].artic;
		hasIncidentRow[i] = 0;
		materialTangentBody[i] = 0;
		linearPoseGain[i] = 1.0f;
		angularPoseGain[i] = 1.0f;
	}
	for(PxU32 ri = 0; ri < mRows.size(); ++ri)
	{
		const AvbdRow& row = mRows[ri];
		mRowProgram.forEachBlock(ri, [&](PxU32 block)
		{
			if(block >= mBodies.size()) return;
			hasIncidentRow[block] = 1;
			if((row.flags & (eAVBD_ROW_CONTACT | eAVBD_ROW_SOFT_PAIR)) != eAVBD_ROW_CONTACT)
				materialBody[block] = 0;
		});
	}
	for(PxU32 i = 0; i < mBodies.size(); ++i)
	{
		materialBody[i] = PxU8(materialBody[i] && hasIncidentRow[i]);
		hasIncidentRow[i] = 0;
	}
	// Velocity epoch belongs to the complete dynamic component. Resetting a
	// contact-only projectile while its spring/joint endpoint retains BDF
	// replaces only half of the coupled impulse and creates net momentum.
	PxArray<PxU32>& epochParent = mMaterialComponentParentScratch;
	compileVelocityComponents(epochParent);
	for(PxU32 i = 0; i < mBlocks.size(); ++i)
		if(!materialBody[i]) materialBody[epochParent[i]] = 0;
	for(PxU32 i = 0; i < mBodies.size(); ++i)
		materialBody[i] = materialBody[epochParent[i]];
	// An ordinary dynamic-dynamic restitution manifold is reconstructed from
	// the Position-AL residual in AVBD_2: geometry already supplied the
	// inelastic normal reaction, and material adds only the bounce/cone delta.
	// Restoring solve-start velocity here would first erase that reaction and
	// then ask a pointwise free-body solve to rediscover the mobility of an
	// attached endpoint.
	for(PxU32 ri = 0; ri < mRows.size(); ++ri)
	{
		const AvbdRow& row = mRows[ri];
		if((row.flags & (eAVBD_ROW_CONTACT | eAVBD_ROW_INACTIVE |
			eAVBD_ROW_SOFT_PAIR)) != eAVBD_ROW_CONTACT ||
			row.restitution <= 0.0f || row.bodyA >= mBodies.size() ||
			row.bodyB >= mBodies.size() ||
			!avbdBodyResponds(mBodies[row.bodyA]) ||
			!avbdBodyResponds(mBodies[row.bodyB]) ||
			row.minLambda > -1.0e15f)
			continue;
		materialBody[row.bodyA] = 0;
		materialBody[row.bodyB] = 0;
	}
	// Solver-level velocity damping is a joint-program stabilization term in
	// the AVBD_2 step contract.  A free/contact-only island does not run that
	// program: damping it merely because it has no material row changes free
	// fall and makes a later impact look artificially stiff.  Reuse the scratch
	// mask for the bodies that actually participate in an active non-contact
	// hard AL rigid row; finite DRIVE rows already dissipate their relative
	// coordinate through authored damping and must preserve common translation.
	// Public per-body damping remains independent below.
	for(PxU32 ri = 0; ri < mRows.size(); ++ri)
	{
		const AvbdRow& row = mRows[ri];
		if((row.flags & (eAVBD_ROW_CONTACT | eAVBD_ROW_INACTIVE |
			eAVBD_ROW_SOFT_PAIR)) == eAVBD_ROW_CONTACT && row.mu > 0.0f &&
			row.positionTangent)
		{
			if(row.bodyA < mBodies.size())
				materialTangentBody[row.bodyA] = 1;
			if(row.bodyB < mBodies.size())
				materialTangentBody[row.bodyB] = 1;
		}
		if(row.flags & (eAVBD_ROW_CONTACT | eAVBD_ROW_INACTIVE |
			eAVBD_ROW_SOFT_PAIR | eAVBD_ROW_DRIVE))
			continue;
		if(row.bodyA < mBodies.size())
			hasIncidentRow[row.bodyA] = 1;
		if(row.bodyB < mBodies.size())
			hasIncidentRow[row.bodyB] = 1;
	}
	for(PxU32 i = 0; i < mBodies.size(); ++i)
	{
		AvbdSolverBody& b = mBodies[i];
		if(!b.core)
			continue;
		if(b.invMass == 0.0f || b.isKinematic)
		{
			if(b.core->fixedBaseLink)
			{
				b.outputLinVel = PxVec3(0.0f);
				b.outputAngVel = PxVec3(0.0f);
			}
			continue;
		}
		PxVec3 lin;
		PxVec3 ang;
		if(materialBody[i])
		{
			lin = b.linVel;
			ang = b.angVel;
			linearPoseGain[i] = 0.0f;
			angularPoseGain[i] = 0.0f;
		}
		else
			avbdPoseDeltaVel(b, invH, lin, ang);
		if(b.core->lockFlags & PxRigidDynamicLockFlag::eLOCK_LINEAR_X) lin.x = 0.0f;
		if(b.core->lockFlags & PxRigidDynamicLockFlag::eLOCK_LINEAR_Y) lin.y = 0.0f;
		if(b.core->lockFlags & PxRigidDynamicLockFlag::eLOCK_LINEAR_Z) lin.z = 0.0f;
		if(b.core->lockFlags & PxRigidDynamicLockFlag::eLOCK_ANGULAR_X) ang.x = 0.0f;
		if(b.core->lockFlags & PxRigidDynamicLockFlag::eLOCK_ANGULAR_Y) ang.y = 0.0f;
		if(b.core->lockFlags & PxRigidDynamicLockFlag::eLOCK_ANGULAR_Z) ang.z = 0.0f;

		b.outputLinVel = lin;
		b.outputAngVel = ang;
	}

	// Damping and public speed limits define the material solve's incoming
	// velocity epoch.  Contact complementarity must be the last writer: damping
	// different endpoint types after friction has closed vt immediately creates
	// new slip, while post-material caps discard a required support impulse.
	for(PxU32 i = 0; i < mBodies.size(); ++i)
	{
		AvbdSolverBody& b = mBodies[i];
		if(!b.core || b.invMass == 0.0f || b.isKinematic)
			continue;
		if(!mStep.commonProgram && !materialBody[i] && hasIncidentRow[i] && !materialTangentBody[i])
		{
			b.outputLinVel *= AVBD_VELOCITY_DAMPING;
			b.outputAngVel *= AVBD_ANGULAR_DAMPING;
			linearPoseGain[i] *= AVBD_VELOCITY_DAMPING;
			angularPoseGain[i] *= AVBD_ANGULAR_DAMPING;
		}
		// Pose reconstruction includes constraint-generated velocity modes that
		// did not exist when the inertial target was integrated.  Authored body
		// damping therefore belongs at the final velocity boundary as well.
		if(b.core->linearDamping > 0.0f)
		{
			const PxReal decay = 1.0f / (1.0f + b.core->linearDamping * dt);
			b.outputLinVel *= decay;
			linearPoseGain[i] *= decay;
		}
		if(b.core->angularDamping > 0.0f)
		{
			const PxReal decay = 1.0f / (1.0f + b.core->angularDamping * dt);
			b.outputAngVel *= decay;
			angularPoseGain[i] *= decay;
		}
		const PxReal linSq = b.outputLinVel.magnitudeSquared();
		if(linSq > b.core->maxLinearVelocitySq && linSq > 1.0e-12f)
		{
			const PxReal scale = PxSqrt(b.core->maxLinearVelocitySq / linSq);
			b.outputLinVel *= scale;
			linearPoseGain[i] *= scale;
		}
		const PxReal angSq = b.outputAngVel.magnitudeSquared();
		if(angSq > b.core->maxAngularVelocitySq && angSq > 1.0e-12f)
		{
			const PxReal scale = PxSqrt(b.core->maxAngularVelocitySq / angSq);
			b.outputAngVel *= scale;
			angularPoseGain[i] *= scale;
		}
	}

	if(!mStep.commonProgram)applyImpactMaterial(dt, materialBody, linearPoseGain, angularPoseGain);
}

void AvbdDynamicsContext::finalizeRigidBodies(PxReal dt)
{
	// This is the only Host publication boundary for Rigid6. Both the rigid-only
	// and heterogeneous material programs have already updated output* in the
	// backend, so no intermediate pose/velocity is visible to PxsBodyCore.
	for(PxU32 i = 0; i < mBodies.size(); ++i)
	{
		AvbdSolverBody& b = mBodies[i];
		if(!b.core)
			continue;
		if(b.invMass == 0.0f || b.isKinematic)
		{
			if(b.core->fixedBaseLink)
			{
				b.core->linearVelocity = PxVec3(0.0f);
				b.core->angularVelocity = PxVec3(0.0f);
			}
			if(b.artic)
			{
				Cm::SpatialVectorF* mv =
					b.artic->getArticulationData().getMotionVelocities();
				if(mv)
					mv[b.linkIndex] = Cm::SpatialVectorF(
						PxVec3(0.0f), PxVec3(0.0f));
			}
			continue;
		}
		if(b.rigid)
			b.rigid->mLastTransform = b.core->body2World;
		b.core->body2World.p = b.p;
		b.core->body2World.q = b.q;
		b.core->linearVelocity = b.outputLinVel;
		b.core->angularVelocity = b.outputAngVel;
		avbdLockCoreVel(*b.core);
		if(b.artic)
			avbdSyncArticMotionVel(b);
	}

	for(PxU32 i = 0; i < mBodies.size(); ++i)
	{
		AvbdSolverBody& b = mBodies[i];
		if(!b.core)
			continue;
		if(b.artic && b.linkIndex > 0)
		{
			ArticulationData& artData = b.artic->getArticulationData();
			const ArticulationLink& link = artData.getLink(b.linkIndex);
			if(link.inboundJoint && link.parent != DY_ARTICULATION_LINK_NONE)
			{
				ArticulationJointCoreData& jd = artData.getJointData(b.linkIndex);
				const PxU32 parentIdx = findBody(artData.getLink(link.parent).bodyCore);
				if(jd.nbDof == 1 && jd.jointOffset != PX_MAX_U32 &&
					artData.getJointPositions() && parentIdx < mBodies.size())
				{
					PxVec3 jLinA, jAngA, jLinB, jAngB;
					PxReal C = 0.0f;
					const PxU32 axis = link.inboundJoint->dofIds[0];
					if(axis < PxArticulationAxis::eCOUNT &&
						avbdArticAxis(mBodies[parentIdx], b, *link.inboundJoint, axis,
							jLinA, jAngA, jLinB, jAngB, C))
					{
						artData.getJointPositions()[jd.jointOffset] = C;
						PxReal* jv = artData.getJointVelocities();
						if(jv && mBodies[parentIdx].core)
						{
							const PxVec3 vA = mBodies[parentIdx].core->linearVelocity;
							const PxVec3 wA = mBodies[parentIdx].core->angularVelocity;
							const PxVec3 lin = b.core->linearVelocity;
							const PxVec3 ang = b.core->angularVelocity;
							jv[jd.jointOffset] = jLinA.dot(vA) + jAngA.dot(wA) +
								jLinB.dot(lin) + jAngB.dot(ang);
						}
						link.inboundJoint->jointPos[axis] = C;
					}
				}
			}
		}
		else if(b.rigid && b.invMass > 0.0f && !b.isKinematic)
		{
			const Cm::SpatialVector motion(b.core->linearVelocity,
				b.core->angularVelocity);
			sleepCheck(b.rigid, dt, mEnableStabilization, motion, b.hasStaticTouch);
		}
	}
}
