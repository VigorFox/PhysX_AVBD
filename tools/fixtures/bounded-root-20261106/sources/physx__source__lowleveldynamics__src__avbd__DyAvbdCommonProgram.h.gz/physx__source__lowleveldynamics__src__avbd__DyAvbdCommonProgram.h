// Copyright (c) 2026 NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: BSD-3-Clause
#ifndef DY_AVBD_COMMON_PROGRAM_H
#define DY_AVBD_COMMON_PROGRAM_H
#include "foundation/PxArray.h"
#include "DyAvbdCoulombNcp.h"
#include <algorithm>
#include <cmath>
#include <cstdio>

namespace physx { namespace Dy {
// Fixed physical block factorization, shared by numerical executors.
inline bool avbdSolveSmallBlock(const double* matrix,const double* rhs,double* x,PxU32 n)
    {
        double L[36]={},D[6]={},v[6]={};
        for(PxU32 i=0;i<n;++i)
        {
            for(PxU32 j=0;j<i;++j)
            {double a=matrix[6*i+j];for(PxU32 k=0;k<j;++k)a-=L[6*i+k]*D[k]*L[6*j+k];L[6*i+j]=a/D[j];}
            double a=matrix[6*i+i];for(PxU32 k=0;k<i;++k)a-=L[6*i+k]*L[6*i+k]*D[k];
            if(!(a>0) || !std::isfinite(a))return false;D[i]=a;
            v[i]=rhs[i];for(PxU32 j=0;j<i;++j)v[i]-=L[6*i+j]*v[j];
        }
        for(PxU32 ii=n;ii>0;--ii)
        {const PxU32 i=ii-1;x[i]=v[i]/D[i];for(PxU32 j=i+1;j<n;++j)x[i]-=L[6*j+i]*x[j];if(!std::isfinite(x[i]))return false;}
        return true;
    }

// Frozen numerical view of the EXISTING row program. No poses, physical
// multipliers, material history, solver policy or ownership are stored here.
// Storage and products are sparse; physical blocks retain dimension 3 or 6.
struct AvbdCommonHBlock {PxU32 row,column;double values[36];};
struct AvbdCommonJBlock {PxU32 row,column;double values[18];};
struct AvbdCommonProgram
{
    PxArray<PxU32> dimensions,starts,sourceBlocks,sourceRows;
    PxArray<AvbdCommonHBlock> H;
    PxArray<AvbdCommonJBlock> J;
    PxArray<double> base,offset,lower,upper,compliance,mu;
    PxArray<int> coulomb;
    PxArray<double> materialEnergies;
    PxArray<PxU32> hOffsets,jOffsets,transposeOffsets,transposeEntries;
    bool valid=false;

    bool sameTangent(PxU32 a,PxU32 b) const
    {
        const auto& p=*this;
        if(!p.coulomb[a] || !p.coulomb[b] || p.mu[a]!=p.mu[b] || p.lower[3*a]<0 || p.lower[3*b]<0)return false;
        for(PxU32 q=1;q<3;++q)
            if(p.compliance[3*a+q]!=0 || p.compliance[3*b+q]!=0 || p.offset[3*a+q]!=p.offset[3*b+q] ||
                p.lower[3*a+q]!=-std::numeric_limits<double>::infinity() || p.lower[3*b+q]!=p.lower[3*a+q] ||
                p.upper[3*a+q]!=std::numeric_limits<double>::infinity() || p.upper[3*b+q]!=p.upper[3*a+q])return false;
        if(p.jOffsets[a+1]-p.jOffsets[a]!=p.jOffsets[b+1]-p.jOffsets[b])return false;
        for(PxU32 i=0;i<p.jOffsets[a+1]-p.jOffsets[a];++i)
        {const auto& x=p.J[p.jOffsets[a]+i];const auto& y=p.J[p.jOffsets[b]+i];if(x.column!=y.column)return false;
            for(PxU32 q=1;q<3;++q)for(PxU32 d=0;d<p.dimensions[x.column];++d)if(x.values[6*q+d]!=y.values[6*q+d])return false;}
        return true;
    }
    void projected(PxU32 r,const double* penalty,const double* step,const double* force,double* f,double* stiffness,bool updateCapacity=false,double* coordinates=NULL,double* residual=NULL) const
    {
        const auto& p=*this;double u[3]={p.offset[3*r],p.offset[3*r+1],p.offset[3*r+2]};
        for(PxU32 e=p.jOffsets[r];e<p.jOffsets[r+1];++e)
        {const auto& j=p.J[e];for(PxU32 q=0;q<3;++q)for(PxU32 d=0;d<p.dimensions[j.column];++d)u[q]+=j.values[6*q+d]*step[p.starts[j.column]+d];}
        if(coordinates)for(PxU32 q=0;q<3;++q)coordinates[q]=u[q];
        for(PxU32 q=0;q<3;++q)
        {
            const PxU32 i=3*r+q;const double rho=penalty[i],denom=1+rho*p.compliance[i];
            const double raw=(force[i]-rho*u[q])/denom;
            f[q]=std::max(p.lower[i],std::min(p.upper[i],raw));
            stiffness[q]=p.lower[i]<p.upper[i]?rho/denom:0.;
            if(residual)residual[q]=avbdScalarProjectionRoot(force[i],(rho/denom)*(u[q]+p.compliance[i]*force[i]),p.lower[i],p.upper[i]);
        }
        if(p.coulomb[r])
        {
            // A primal sweep freezes the current normal capacity. Each local
            // contact potential is then convex and J^T rho J majorizes its
            // gradient. The shared dual refreshes the actual normal capacity;
            // fixed points still obey the original non-associated Coulomb law.
            const double bound=p.mu[r]*std::max(0.,updateCapacity?f[0]:force[3*r]),mag=std::hypot(f[1],f[2]);
            if(mag>bound)
            {const double scale=bound/mag;for(PxU32 q=1;q<3;++q)
                {if(residual)residual[q]=((mag-bound)/mag)*force[3*r+q]+scale*residual[q];f[q]*=scale;}}
            if(p.mu[r]==0)stiffness[1]=stiffness[2]=0;
        }
    }
    void write(FILE* file,const PxArray<double>* initialForce=NULL,const PxArray<double>* motionTolerance=NULL) const
    {
        std::fprintf(file,"{\"complete\":%s,\"reason\":\"local_response_capture\",",valid?"true":"false");
        auto array=[&](const char* name,const auto& values)
        {std::fprintf(file,"\"%s\":[",name);for(PxU32 i=0;i<values.size();++i)
            {const double v=double(values[i]);if(i)std::fprintf(file,",");if(std::isfinite(v))std::fprintf(file,"%.17g",v);
                else std::fprintf(file,"\"%s\"",v<0?"-inf":"inf");}std::fprintf(file,"],");};
        array("dimensions",dimensions);array("sourceBlocks",sourceBlocks);array("sourceRows",sourceRows);
        array("base",base);array("offset",offset);array("lower",lower);array("upper",upper);array("compliance",compliance);
        array("mu",mu);array("coulomb",coulomb);
        if(initialForce)array("initialForce",*initialForce);
        if(motionTolerance)array("motionTolerance",*motionTolerance);
        auto matrix=[&](const char* name,const auto& entries,PxU32 width)
        {std::fprintf(file,"\"%s\":[",name);for(PxU32 e=0;e<entries.size();++e)
            {std::fprintf(file,"%s[%u,%u",e?",":"",entries[e].row,entries[e].column);
                for(PxU32 k=0;k<width;++k)std::fprintf(file,",%.17g",entries[e].values[k]);std::fprintf(file,"]");}std::fprintf(file,"]");};
        matrix("H",H,36);std::fprintf(file,",");matrix("J",J,18);std::fprintf(file,"}\n");
    }

    template<class Entry> static void merge(PxArray<Entry>& entries,PxU32 width)
    {
        if(entries.empty())return;
        std::sort(entries.begin(),entries.end(),[](const Entry& a,const Entry& b)
        {return a.row<b.row || (a.row==b.row && a.column<b.column);});
        PxU32 size=0;
        for(PxU32 i=0;i<entries.size();++i)
        {
            if(size && entries[size-1].row==entries[i].row && entries[size-1].column==entries[i].column)
                for(PxU32 k=0;k<width;++k)entries[size-1].values[k]+=entries[i].values[k];
            else {if(size!=i)entries[size]=entries[i];++size;}
        }
        entries.resize(size);
    }
    bool finish()
    {
        valid=false;const PxU32 n=dimensions.size(),m=mu.size();
        starts.resize(n+1);starts[0]=0;
        for(PxU32 b=0;b<n;++b)
        {if(dimensions[b]!=3 && dimensions[b]!=6)return false;starts[b+1]=starts[b]+dimensions[b];}
        if(base.size()!=starts[n] || sourceBlocks.size()!=n || sourceRows.size()!=m || coulomb.size()!=m ||
            offset.size()!=3*m || lower.size()!=3*m || upper.size()!=3*m || compliance.size()!=3*m)return false;
        for(PxU32 i=0;i<base.size();++i)if(!std::isfinite(base[i]))return false;
        for(PxU32 i=0;i<m;++i)if(!std::isfinite(mu[i]) || mu[i]<0 || (coulomb[i]!=0 && coulomb[i]!=1))return false;
        for(PxU32 i=0;i<3*m;++i)
            if(!std::isfinite(offset[i]) || !std::isfinite(compliance[i]) || compliance[i]<0 || !(lower[i]<=upper[i]))return false;
        merge(H,36);merge(J,18);
        hOffsets.resize(n+1);jOffsets.resize(m+1);transposeOffsets.resize(n+1);
        for(PxU32 b=0;b<=n;++b)hOffsets[b]=transposeOffsets[b]=0;
        for(PxU32 r=0;r<=m;++r)jOffsets[r]=0;
        for(PxU32 e=0;e<H.size();++e)
        {
            if(H[e].row>=n || H[e].column>=n)return false;
            for(PxU32 k=0;k<36;++k)if(!std::isfinite(H[e].values[k]))return false;
            ++hOffsets[H[e].row+1];
        }
        for(PxU32 e=0;e<J.size();++e)
        {
            if(J[e].row>=m || J[e].column>=n)return false;
            for(PxU32 k=0;k<18;++k)if(!std::isfinite(J[e].values[k]))return false;
            ++jOffsets[J[e].row+1];++transposeOffsets[J[e].column+1];
        }
        for(PxU32 b=1;b<=n;++b){hOffsets[b]+=hOffsets[b-1];transposeOffsets[b]+=transposeOffsets[b-1];}
        for(PxU32 r=1;r<=m;++r)jOffsets[r]+=jOffsets[r-1];
        PxArray<PxU32> cursor=transposeOffsets;transposeEntries.resize(J.size());
        for(PxU32 e=0;e<J.size();++e)transposeEntries[cursor[J[e].column]++]=e;
        valid=true;return true;
    }
    // Disjoint destination ranges may execute in parallel without atomics.
    void hessian(const double* x,double* y,PxU32 begin=0,PxU32 end=PX_MAX_U32) const
    {
        end=std::min(end,dimensions.size());
        for(PxU32 b=begin;b<end;++b)for(PxU32 d=0;d<dimensions[b];++d)
        {
            double value=0;
            for(PxU32 e=hOffsets[b];e<hOffsets[b+1];++e)
                for(PxU32 k=0;k<dimensions[H[e].column];++k)value+=H[e].values[6*d+k]*x[starts[H[e].column]+k];
            y[starts[b]+d]=value;
        }
    }
    void jacobian(const double* x,double* y,PxU32 begin=0,PxU32 end=PX_MAX_U32) const
    {
        end=std::min(end,mu.size());
        for(PxU32 r=begin;r<end;++r)for(PxU32 d=0;d<3;++d)
        {
            double value=0;
            for(PxU32 e=jOffsets[r];e<jOffsets[r+1];++e)
                for(PxU32 k=0;k<dimensions[J[e].column];++k)value+=J[e].values[6*d+k]*x[starts[J[e].column]+k];
            y[3*r+d]=value;
        }
    }
    void transpose(const double* f,double* y,PxU32 begin=0,PxU32 end=PX_MAX_U32) const
    {
        end=std::min(end,dimensions.size());
        for(PxU32 b=begin;b<end;++b)for(PxU32 d=0;d<dimensions[b];++d)
        {
            double value=0;
            for(PxU32 s=transposeOffsets[b];s<transposeOffsets[b+1];++s)
            {const auto& e=J[transposeEntries[s]];for(PxU32 k=0;k<3;++k)value+=e.values[6*k+d]*f[3*e.row+k];}
            y[starts[b]+d]=value;
        }
    }
    // Upper bound for backtracking an inexact direction from a feasible
    // iterate. This is the original affine hard domain, not a gap tolerance.
    // Nonlinear geometry and float storage remain the publisher's decision.
    double linearFeasibleFraction(const double* step) const
    {
        double fraction=1;
        for(PxU32 r=0;r<mu.size();++r)
        {
            const PxU32 k=3*r;
            if(lower[k]!=0 || !std::isinf(upper[k]) || compliance[k]!=0 || offset[k]<0)continue;
            double delta=0,scale=1+std::abs(offset[k]);
            for(PxU32 e=jOffsets[r];e<jOffsets[r+1];++e)
            {const auto& j=J[e];for(PxU32 d=0;d<dimensions[j.column];++d)
                {const double value=j.values[d]*step[starts[j.column]+d];delta+=value;scale+=std::abs(value);}}
            // Roundoff in a tangent direction must not create a zero search
            // radius. Actual geometry is still certified after float storage.
            if(offset[k]+delta>=-32*std::numeric_limits<double>::epsilon()*scale)continue;
            if(delta<0)
            {if(offset[k]==0)return 0;fraction=std::min(fraction,-offset[k]/delta);}
        }
        return fraction;
    }
};
} }
#endif
