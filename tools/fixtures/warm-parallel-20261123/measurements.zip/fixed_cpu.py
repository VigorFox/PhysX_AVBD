from pathlib import Path
import csv, json, os, statistics as st, sys, subprocess
p=Path(__file__).resolve().parent
sys.path.insert(0,str(p.parents[1]))
from benchmark_avbd_dense_scaling import SLOW,tags
env={k:v for k,v in os.environ.items() if not k.startswith(('PHYSX_AVBD_','PHYSX_SNIPPET_','PHYSX_NP_'))}
env.update(PHYSX_AVBD_COMMON_STEP='budget',PHYSX_AVBD_LOCAL_ITERATIONS='4')
out=p/'fixed-cpu';out.mkdir()
records=[]
for rep in range(6):
    for w in ((4,8) if rep%2==0 else (8,4)):
        for arm in (('base','candidate') if (rep+(w==8))%2==0 else ('candidate','base')):
            name=f'{arm}-{w}-{rep}'; exe=p/('cpu-'+arm)/'CpuWindow.exe'
            file=out/(name+'.csv')
            with (out/(name+'.log')).open('wb') as log:
                subprocess.run([exe,'--headless','--case=visual-showcase','--frames=360',f'--dispatcher-threads={w}'],env=dict(env,PHYSX_SNIPPET_STEP_TIMES=str(file)),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
            lines=(out/(name+'.log')).read_text().splitlines();g,=tags(lines,'AVBD_GATE')
            assert g['status']=='PASS' and g['completedFrames']=='360'
            rows=tags(lines,'PROCESS_FRAME');assert [int(r['frame']) for r in rows]==SLOW
            with file.open() as stream: frame=list(csv.DictReader(stream))
            assert len(frame)==360
            wall=[float(frame[f-1]['simulateFetchMs']) for f in SLOW]
            records.append(dict(rep=rep,workers=w,arm=arm,mean=st.mean(wall),p95=sorted(wall)[16],cpu=st.mean(int(r['ticks']) for r in rows)/1e4,mcycles=st.mean(int(r['cycles']) for r in rows)/1e6))
            (out/'summary.json').write_text(json.dumps(records,indent=2))
for w in (4,8):
    a,b=[[r for r in records if r['workers']==w and r['arm']==arm] for arm in ('base','candidate')]
    print(w,{k:round(st.median(y[k]/x[k] for x,y in zip(a,b)),3) for k in ('p95','mean','cpu','mcycles')})
