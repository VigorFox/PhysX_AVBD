// Copyright (c) 2026 NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: BSD-3-Clause
#ifndef DY_AVBD_LOCAL_CORRECTION_H
#define DY_AVBD_LOCAL_CORRECTION_H
#include "DyAvbdCommonProgram.h"
#include "DyAvbdCoulombNcp.h"
namespace physx { namespace Dy {
// Mixed numerical Newton operator on the existing local program. Unknowns
// are dx and df/rho. No inverse response columns or physical state are stored.
struct AvbdLocalCorrection
{
    const AvbdCommonProgram& p;const PxArray<double>& rho;
    void* context;void (*inverse)(void*,const double*,double*);
    PxArray<PxU32> rows;PxArray<double> A,B,fullForce,primal,scaled,coordinates;
    PxU32 n,size;
    PxArray<PxU32> tangentGroup;
    bool changedFace=false;
    AvbdLocalCorrection(const AvbdCommonProgram& program,const PxArray<double>& penalty,const PxArray<PxU8>& enabled,
        void* ctx,void (*inv)(void*,const double*,double*)) : p(program),rho(penalty),context(ctx),inverse(inv),n(p.base.size())
    {
        for(PxU32 r=0;r<enabled.size();++r)if(enabled[r])rows.pushBack(r);
        size=n+3*rows.size();A.resize(9*rows.size());B.resize(A.size());
        fullForce.resize(3*rows.size());primal.resize(n);scaled.resize(n);coordinates.resize(fullForce.size());
        tangentGroup.resize(rows.size());
        for(PxU32 s=0;s<rows.size();++s)
        {tangentGroup[s]=s;for(PxU32 t=0;t<s;++t)if(sameTangent(rows[s],rows[t])){tangentGroup[s]=tangentGroup[t];break;}}
    }
    bool sameTangent(PxU32 a,PxU32 b) const
    {
        if(!p.coulomb[a] || !p.coulomb[b] || p.mu[a]!=p.mu[b])return false;
        for(PxU32 q=1;q<3;++q)
            if(p.compliance[3*a+q]!=0 || p.compliance[3*b+q]!=0 || p.offset[3*a+q]!=p.offset[3*b+q] ||
                p.lower[3*a+q]!=-std::numeric_limits<double>::infinity() || p.lower[3*b+q]!=p.lower[3*a+q] ||
                p.upper[3*a+q]!=std::numeric_limits<double>::infinity() || p.upper[3*b+q]!=p.upper[3*a+q])return false;
        if(p.jOffsets[a+1]-p.jOffsets[a]!=p.jOffsets[b+1]-p.jOffsets[b])return false;
        for(PxU32 i=0;i<p.jOffsets[a+1]-p.jOffsets[a];++i)
        {const auto& x=p.J[p.jOffsets[a]+i];const auto& y=p.J[p.jOffsets[b]+i];if(x.column!=y.column)return false;
            for(PxU32 q=1;q<3;++q)for(PxU32 d=0;d<p.dimensions[x.column];++d)if(x.values[6*q+d]!=y.values[6*q+d])return false;}
        return true;
    }
    void canonicalize(double* force) const
    {
        for(PxU32 s=0;s<rows.size();++s)if(tangentGroup[s]==s)
        {
            double normal=0,t0=0,t1=0;PxU32 count=0;
            for(PxU32 t=s;t<rows.size();++t)if(tangentGroup[t]==s)
            {const PxU32 k=3*rows[t];normal+=force[k];t0+=force[k+1];t1+=force[k+2];++count;}
            if(count<2 || !(normal>0))continue;
            for(PxU32 t=s;t<rows.size();++t)if(tangentGroup[t]==s)
            {const PxU32 k=3*rows[t];const double weight=force[k]/normal;force[k+1]=weight*t0;force[k+2]=weight*t1;}
        }
    }
    void pack(double* force) const
    {
        for(PxU32 s=0;s<rows.size();++s)if(tangentGroup[s]!=s)
        {const PxU32 k=3*rows[s],owner=3*rows[tangentGroup[s]];
            for(PxU32 q=1;q<3;++q){force[owner+q]+=force[k+q];force[k+q]=0;}}
    }
    void unpack(double* force) const
    {
        for(PxU32 s=0;s<rows.size();++s)if(tangentGroup[s]==s)
        {
            const PxU32 owner=3*rows[s];double normal=0;PxU32 count=0;
            for(PxU32 t=s;t<rows.size();++t)if(tangentGroup[t]==s){normal+=force[3*rows[t]];++count;}
            if(count<2)continue;const double t0=force[owner+1],t1=force[owner+2];
            for(PxU32 t=s;t<rows.size();++t)if(tangentGroup[t]==s)
            {const PxU32 k=3*rows[t];const double weight=normal>0?force[k]/normal:0.;force[k+1]=weight*t0;force[k+2]=weight*t1;}
        }
    }
    void project(double* force) const
    {
        for(PxU32 s=0;s<rows.size();++s)for(PxU32 q=0;q<3;++q)
        {const PxU32 k=3*rows[s]+q;force[k]=q && tangentGroup[s]!=s?0.:std::max(p.lower[k],std::min(p.upper[k],force[k]));}
        for(PxU32 s=0;s<rows.size();++s)if(tangentGroup[s]==s && p.coulomb[rows[s]])
        {
            const PxU32 k=3*rows[s];double normal=0;
            for(PxU32 t=s;t<rows.size();++t)if(tangentGroup[t]==s)normal+=force[3*rows[t]];
            const double bound=p.mu[rows[s]]*std::max(0.,normal),mag=std::hypot(force[k+1],force[k+2]);
            if(mag>bound)for(PxU32 q=1;q<3;++q)force[k+q]*=bound/mag;
        }
    }
    void jproduct(const double* x,double* y) const
    {
        for(PxU32 s=0;s<rows.size();++s)
        {
            for(PxU32 q=0;q<3;++q)y[3*s+q]=0;
            for(PxU32 e=p.jOffsets[rows[s]];e<p.jOffsets[rows[s]+1];++e)
            {const auto& j=p.J[e];for(PxU32 q=0;q<3;++q)if(!q || tangentGroup[s]==s)
                for(PxU32 d=0;d<p.dimensions[j.column];++d)y[3*s+q]+=j.values[6*q+d]*x[p.starts[j.column]+d];}
        }
    }
    void jtranspose(const double* x,double* y) const
    {
        std::fill(y,y+n,0.);
        for(PxU32 s=0;s<rows.size();++s)for(PxU32 e=p.jOffsets[rows[s]];e<p.jOffsets[rows[s]+1];++e)
        {const auto& j=p.J[e];for(PxU32 q=0;q<3;++q)if(!q || tangentGroup[s]==s)
            for(PxU32 d=0;d<p.dimensions[j.column];++d)y[p.starts[j.column]+d]+=j.values[6*q+d]*x[3*s+q];}
    }
    void evaluate(const double* x,const double* f,double* out,bool derivatives)
    {
        for(PxU32 s=0;s<rows.size();++s)for(PxU32 q=0;q<3;++q)fullForce[3*s+q]=f[3*rows[s]+q];
        p.hessian(x,primal.begin());jtranspose(fullForce.begin(),scaled.begin());
        for(PxU32 d=0;d<n;++d)primal[d]-=p.base[d]+scaled[d];inverse(context,primal.begin(),out);
        jproduct(x,coordinates.begin());
        for(PxU32 s=0;s<rows.size();++s)
        {
            const PxU32 r=rows[s],k=3*r;double u[3],root[3],aggregate[3]={f[k],f[k+1],f[k+2]};
            if(tangentGroup[s]==s)for(PxU32 t=s+1;t<rows.size();++t)if(tangentGroup[t]==s)aggregate[0]+=f[3*rows[t]];
            for(PxU32 q=0;q<3;++q)u[q]=p.offset[k+q]+coordinates[3*s+q]+p.compliance[k+q]*f[k+q];
            avbdCoulombRoot(aggregate,u,rho[k],p.mu[r],p.lower.begin()+k,p.upper.begin()+k,p.coulomb[r]!=0,root);
            const double v=f[k]-rho[k]*u[0];root[0]=f[k]-std::max(p.lower[k],std::min(p.upper[k],v));
            if(tangentGroup[s]!=s){root[1]=f[k+1];root[2]=f[k+2];}
            for(PxU32 q=0;q<3;++q)out[n+3*s+q]=root[q]/rho[k+q];
            if(derivatives)
            {
                double* a=A.begin()+9*s;double* b=B.begin()+9*s;
                AvbdCoulombNcp::rootDerivative(aggregate,u,rho[k],p.mu[r],p.lower.begin()+k,p.upper.begin()+k,p.coulomb[r]!=0,a,b);
                const bool free=v>p.lower[k] && v<p.upper[k];a[0]=free?rho[k]:0.;b[0]=free?0.:1.;
                if(tangentGroup[s]!=s){std::fill(a+3,a+9,0.);std::fill(b+3,b+9,0.);b[4]=b[8]=1.;}
            }
        }
    }
    void apply(const double* v,double* out)
    {
        std::fill(fullForce.begin(),fullForce.end(),0.);
        for(PxU32 s=0;s<rows.size();++s)for(PxU32 q=0;q<3;++q)fullForce[3*s+q]=rho[3*rows[s]+q]*v[n+3*s+q];
        p.hessian(v,primal.begin());jtranspose(fullForce.begin(),scaled.begin());
        for(PxU32 d=0;d<n;++d)primal[d]-=scaled[d];inverse(context,primal.begin(),out);
        jproduct(v,coordinates.begin());
        for(PxU32 s=0;s<rows.size();++s)for(PxU32 q=0;q<3;++q)
        {
            const PxU32 k=3*rows[s];double value=0;
            for(PxU32 j=0;j<3;++j)value+=A[9*s+3*q+j]*(coordinates[3*s+j]+p.compliance[k+j]*fullForce[3*s+j])+B[9*s+3*q+j]*fullForce[3*s+j];
            if(q && tangentGroup[s]==s)for(PxU32 t=s+1;t<rows.size();++t)if(tangentGroup[t]==s)value+=B[9*s+3*q]*fullForce[3*t];
            out[n+3*s+q]=value/rho[k+q];
        }
    }
    void transpose(const double* v,double* out)
    {
        inverse(context,v,scaled.begin());p.hessian(scaled.begin(),out);jproduct(scaled.begin(),coordinates.begin());
        std::fill(fullForce.begin(),fullForce.end(),0.);
        for(PxU32 s=0;s<rows.size();++s)for(PxU32 q=0;q<3;++q)
        {
            const PxU32 k=3*rows[s];double a=0,b=0;
            for(PxU32 j=0;j<3;++j){const double w=v[n+3*s+j]/rho[k+j];a+=A[9*s+3*j+q]*w;b+=B[9*s+3*j+q]*w;}
            fullForce[3*s+q]=a;out[n+3*s+q]=rho[k+q]*(-coordinates[3*s+q]+b+p.compliance[k+q]*a);
        }
        for(PxU32 s=0;s<rows.size();++s)if(tangentGroup[s]!=s)
        {const PxU32 owner=tangentGroup[s],k=3*rows[owner];double b=0;
            for(PxU32 q=1;q<3;++q)b+=B[9*owner+3*q]*v[n+3*owner+q]/rho[k+q];out[n+3*s]+=rho[3*rows[s]]*b;}
        jtranspose(fullForce.begin(),primal.begin());for(PxU32 d=0;d<n;++d)out[d]+=primal[d];
    }
    bool forceFaceEvent(const PxArray<double>& x,PxArray<double>& f,double before,bool& normalBoundary)
    {
        PxArray<double> normal(rows.size(),0.),motion(3*rows.size());PxArray<PxU32> groups,ids;
        jproduct(x.begin(),motion.begin());for(PxU32 s=0;s<rows.size();++s)normal[tangentGroup[s]]+=f[3*rows[s]];
        for(PxU32 s=0;s<rows.size();++s)if(tangentGroup[s]==s)
        {
            const PxU32 r=rows[s],k=3*r;
            if(!p.coulomb[r] || p.compliance[k+1]!=0 || p.compliance[k+2]!=0 || !(std::hypot(f[k+1]-rho[k]*(p.offset[k+1]+motion[3*s+1]),f[k+2]-rho[k]*(p.offset[k+2]+motion[3*s+2]))<p.mu[r]*normal[s]))continue;
            groups.pushBack(s);
            for(PxU32 t=s;t<rows.size();++t)if(tangentGroup[t]==s && f[3*rows[t]]>0 && p.compliance[3*rows[t]]==0)ids.pushBack(3*t);
            ids.pushBack(3*s+1);ids.pushBack(3*s+2);
        }
        const PxU32 m=ids.size();if(!m)return false;
        // Direct, pivoted twice-orthogonalized QR of J's columns avoids
        // squaring the condition number of almost dependent normal supports.
        PxArray<double> columns(m*n,0.),Q(m*PxMin(m,n),0.),u(m),z(m),trialF(f.size()),trial(size);
        for(PxU32 i=0;i<m;++i)
        {
            const PxU32 s=ids[i]/3,q=ids[i]%3,r=rows[s];u[i]=p.offset[3*r+q]+motion[3*s+q];
            for(PxU32 e=p.jOffsets[r];e<p.jOffsets[r+1];++e)
            {const auto& j=p.J[e];for(PxU32 d=0;d<p.dimensions[j.column];++d)columns[(p.starts[j.column]+d)*m+i]+=j.values[6*q+d];}
        }
        const double columnScale=AvbdCoulombNcp::norm(columns.begin(),int(columns.size()));
        PxU32 rank=0;
        for(;rank<PxMin(m,n);++rank)
        {
            PxU32 pivot=0;double length=0;
            for(PxU32 d=0;d<n;++d){const double value=AvbdCoulombNcp::norm(columns.begin()+d*m,int(m));if(value>length){length=value;pivot=d;}}
            if(!(length>8*(m+n+1)*std::numeric_limits<double>::epsilon()*columnScale))break;
            double* q=Q.begin()+rank*m;for(PxU32 i=0;i<m;++i)q[i]=columns[pivot*m+i]/length;
            for(PxU32 d=0;d<n;++d)for(PxU32 pass=0;pass<2;++pass)
            {double* column=columns.begin()+d*m;const double amount=AvbdCoulombNcp::dot(q,column,int(m));for(PxU32 i=0;i<m;++i)column[i]-=amount*q[i];}
        }
        for(PxU32 i=0;i<m;++i)z[i]=-u[i];
        for(PxU32 pass=0;pass<2;++pass)for(PxU32 d=0;d<rank;++d)
        {const double* q=Q.begin()+d*m;const double amount=AvbdCoulombNcp::dot(q,z.begin(),int(m));for(PxU32 i=0;i<m;++i)z[i]-=amount*q[i];}
        double maximum=0,load=0;for(PxU32 i=0;i<m;++i){maximum=std::max(maximum,std::abs(z[i]));load=std::max(load,std::abs(u[i]));}
        if(!(maximum>64*std::numeric_limits<double>::epsilon()*load))return false;
        for(double& value:z)value/=maximum;
        std::fill(primal.begin(),primal.end(),0.);std::fill(scaled.begin(),scaled.end(),0.);
        for(PxU32 i=0;i<m;++i)
        {const PxU32 r=rows[ids[i]/3],q=ids[i]%3;
            for(PxU32 e=p.jOffsets[r];e<p.jOffsets[r+1];++e)
            {const auto& j=p.J[e];for(PxU32 d=0;d<p.dimensions[j.column];++d)
                {const PxU32 k=p.starts[j.column]+d;const double value=j.values[6*q+d]*z[i];primal[k]+=value;scaled[k]+=std::abs(j.values[6*q+d]);}}}
        if(AvbdCoulombNcp::norm(primal.begin(),int(n))>8*(m+n+1)*std::numeric_limits<double>::epsilon()*columnScale*AvbdCoulombNcp::norm(z.begin(),int(m)))return false;
        PxArray<double> delta(3*rows.size(),0.);for(PxU32 i=0;i<m;++i)delta[ids[i]]=z[i];
        double fraction=std::numeric_limits<double>::infinity(),work=0,bound=0;PxU32 boundary=PX_MAX_U32;
        for(PxU32 i=0;i<m;++i)
        {
            work+=u[i]*z[i];if(ids[i]%3)continue;const PxU32 k=3*rows[ids[i]/3];
            const double value=z[i]<0?p.lower[k]:p.upper[k];if(z[i]!=0)
            {const double hit=(value-f[k])/z[i];if(hit<fraction){fraction=hit;boundary=k;bound=value;}}
        }
        for(PxU32 s:groups)
        {
            const PxU32 r=rows[s],k=3*r;double dn=0;
            for(PxU32 t=s;t<rows.size();++t)if(tangentGroup[t]==s)dn+=delta[3*t];
            const double radius=p.mu[r]*normal[s],dr=p.mu[r]*dn,t0=delta[3*s+1],t1=delta[3*s+2];
            const double qa=dr*dr-t0*t0-t1*t1,qb=2*(radius*dr-f[k+1]*t0-f[k+2]*t1),qc=radius*radius-f[k+1]*f[k+1]-f[k+2]*f[k+2];
            const double discriminant=qb*qb-4*qa*qc;double hit=std::numeric_limits<double>::infinity();
            if(discriminant>0 && (qa<0 || qb<0))hit=2*qc/(-qb+std::sqrt(discriminant));else if(qa==0 && qb<0)hit=-qc/qb;
            if(hit<fraction){fraction=hit;boundary=PX_MAX_U32;}
        }
        if(!(work<0 && fraction>0 && std::isfinite(fraction)))return false;
        trialF=f;for(PxU32 i=0;i<m;++i)trialF[3*rows[ids[i]/3]+ids[i]%3]+=fraction*z[i];
        if(boundary!=PX_MAX_U32)trialF[boundary]=bound;project(trialF.begin());evaluate(x.begin(),trialF.begin(),trial.begin(),false);
        double scale=1;for(double value:x)scale+=std::abs(value);for(PxU32 r:rows)for(PxU32 q=0;q<3;++q)scale+=std::abs(f[3*r+q]/rho[3*r+q]);
        const double limit=std::sqrt(before)+64*std::numeric_limits<double>::epsilon()*scale;
        if(AvbdCoulombNcp::norm(trial.begin(),int(size))>limit)return false;
        f.swap(trialF);normalBoundary=boundary!=PX_MAX_U32;return true;
    }
    bool changeForceFace(const PxArray<double>& x,PxArray<double>& f,double before)
    {
        // Each normal event removes a coordinate from this force-only search.
        // Finish that finite active-set traversal before another AL update can
        // reintroduce a roundoff-sized load on the just-released normal.
        bool changed=false;
        for(PxU32 event=0;event<=rows.size();++event)
        {
            bool normalBoundary=false;
            if(!forceFaceEvent(x,f,before,normalBoundary))break;
            changed=true;if(!normalBoundary)break;
        }
        changedFace=changed;return changed;
    }
    bool correct(PxArray<double>& x,PxArray<double>& force,PxU32& products)
    {
        if(rows.empty())return false;
        canonicalize(force.begin());PxArray<double> f=force;pack(f.begin());
        PxArray<double> residual(size),rhs(size),direction(size),linear(size),work(6*size),trialX(n),trialF(f.size()),trial(size);
        evaluate(x.begin(),f.begin(),residual.begin(),true);const double before=AvbdCoulombNcp::dot(residual.begin(),residual.begin(),int(size));
        if(!(before>0) || !std::isfinite(before))return false;
        for(PxU32 i=0;i<size;++i)rhs[i]=-residual[i];
        products+=PxU32(AvbdCoulombNcp::lsqr(*this,int(size),rhs.begin(),direction.begin(),work.begin(),int(4*size),.01));
        apply(direction.begin(),linear.begin());const double slope=2*AvbdCoulombNcp::dot(residual.begin(),linear.begin(),int(size));
        double unresolved=0;for(PxU32 i=0;i<size;++i)unresolved=std::hypot(unresolved,linear[i]+residual[i]);
        if(unresolved>.01*std::sqrt(before) && changeForceFace(x,f,before))
        {unpack(f.begin());force.swap(f);return true;}
        if(!(slope<0))return false;
        // Visit the first finite force boundary exactly. Clipping a full
        // Newton trial past it destroys the coupled primal/dual direction.
        double first=1,boundaryValue=0;PxU32 boundary=PX_MAX_U32;
        auto event=[&](double fraction,PxU32 coordinate,double value)
        {if(fraction<=first){first=fraction;boundary=coordinate;boundaryValue=value;}};
        for(PxU32 s=0;s<rows.size();++s)for(PxU32 q=0;q<3;++q)
        {
            const PxU32 r=rows[s],k=3*r+q;if(q && p.coulomb[r])continue;
            const double delta=rho[k]*direction[n+3*s+q];
            if(delta<0 && f[k]>p.lower[k])event((p.lower[k]-f[k])/delta,k,p.lower[k]);
            if(delta>0 && f[k]<p.upper[k])event((p.upper[k]-f[k])/delta,k,p.upper[k]);
        }
        for(PxU32 search=0;search<16;++search)
        {
            const double fraction=std::ldexp(first,-int(search));trialF=f;
            for(PxU32 d=0;d<n;++d)trialX[d]=x[d]+fraction*direction[d];
            for(PxU32 s=0;s<rows.size();++s)
            {
                const PxU32 r=rows[s],k=3*r;
                for(PxU32 q=0;q<3;++q)trialF[k+q]=f[k+q]+fraction*rho[k+q]*direction[n+3*s+q];
            }
            if(search==0 && boundary!=PX_MAX_U32)trialF[boundary]=boundaryValue;
            project(trialF.begin());
            evaluate(trialX.begin(),trialF.begin(),trial.begin(),false);
            const double after=AvbdCoulombNcp::dot(trial.begin(),trial.begin(),int(size));
            if(after<=before+1.e-4*fraction*slope){x.swap(trialX);unpack(trialF.begin());force.swap(trialF);return true;}
        }
        return false;
    }
};
} }
#endif
