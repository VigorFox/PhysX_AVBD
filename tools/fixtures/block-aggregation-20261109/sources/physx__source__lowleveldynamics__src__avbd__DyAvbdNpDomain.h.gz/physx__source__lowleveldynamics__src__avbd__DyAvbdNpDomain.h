// Copyright (c) 2026 NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: BSD-3-Clause
#ifndef DY_AVBD_NP_DOMAIN_H
#define DY_AVBD_NP_DOMAIN_H

#include "foundation/PxArray.h"
#include "foundation/PxTransform.h"
#include "avbd/DyAvbdOgcProjection.h"

namespace physx { namespace Dy {

// Complete convex support sets in COM coordinates, compiled from CPU NP.
// The normal is a separating direction, not a selected contact point. All
// vertices participate, including vertices omitted by manifold reduction.
struct AvbdNpDomain
{
    PxArray<PxVec3d> points[2];
    PxTransform fixedPose[2];
    PxVec3d normal;
    double radius[2];
    double restDistance=0;
    // Optional complete support bundle in the existing row array. Fixed
    // endpoints need only one extreme; rotating endpoints keep every vertex.
    PxU32 rowStart=PX_MAX_U32,first[2]={0,0},count[2]={0,0};
};

PX_INLINE PxQuatd avbdNpRotation(const PxQuat& q)
{ return PxQuatd(q.x,q.y,q.z,q.w).getNormalized(); }

PX_INLINE PxVec3d avbdNpPointMotion(const PxVec3& p,const PxQuat& q,
    const PxVec3& start,const PxQuat& rotation,const PxVec3& local)
{
    // Evaluate the displacement itself; subtracting rounded world points
    // creates a world-position ULP staircase in the Coulomb slip coordinate.
    const PxVec3d r=avbdOgcDouble(local);
    return avbdOgcDouble(p)-avbdOgcDouble(start)+avbdNpRotation(q).rotate(r)-avbdNpRotation(rotation).rotate(r);
}

struct AvbdNpRange
{
    double lo,hi,scale;
};

PX_INLINE AvbdNpRange avbdNpSupportRange(const AvbdNpDomain& domain,
    PxU32 side,const PxTransform& pose)
{
    AvbdNpRange out={DBL_MAX,-DBL_MAX,0};
    const PxQuatd q=avbdNpRotation(pose.q);
    const PxVec3d p=avbdOgcDouble(pose.p);
    const double center=domain.normal.dot(p);
    const PxVec3d localNormal=q.rotateInv(domain.normal);
    for(PxU32 i=0;i<domain.points[side].size();++i)
    {
        const PxVec3d& v=domain.points[side][i];
        const double projection=localNormal.dot(v);
        out.lo=PxMin(out.lo,projection);out.hi=PxMax(out.hi,projection);
        out.scale=PxMax(out.scale,v.magnitude());
    }
    out.lo+=center-domain.radius[side];out.hi+=center+domain.radius[side];
    out.scale+=PxAbs(domain.normal.x*p.x)+PxAbs(domain.normal.y*p.y)+
        PxAbs(domain.normal.z*p.z)+domain.radius[side];
    return out;
}

PX_INLINE double avbdNpGap(const AvbdNpDomain& domain,const PxTransform* poses)
{
    return avbdNpSupportRange(domain,0,poses[0]).lo-
        avbdNpSupportRange(domain,1,poses[1]).hi;
}

// The same complete support coordinate used by the certificate. Rounded
// support radii are orientation independent; they must not rotate as anchors.
PX_INLINE double avbdNpGapGradient(const AvbdNpDomain& domain,const PxTransform* poses,PxVec3d* arms)
{
    double extremes[2]={DBL_MAX,-DBL_MAX};
    for(PxU32 side=0;side<2;++side)
    {
        const PxQuatd q=avbdNpRotation(poses[side].q);arms[side]=PxVec3d(0);
        for(const auto& point:domain.points[side])
        {
            const PxVec3d arm=q.rotate(point);const double value=domain.normal.dot(arm);
            if(side?value>extremes[side]:value<extremes[side]){extremes[side]=value;arms[side]=arm;}
        }
    }
    return domain.normal.dot(avbdOgcDouble(poses[0].p)-avbdOgcDouble(poses[1].p))+
        extremes[0]-extremes[1]-domain.radius[0]-domain.radius[1]-domain.restDistance;
}

PX_INLINE void avbdNpCompileFeatures(AvbdNpDomain& domain,const PxTransform* poses,const bool* rotates,PxU32 firstRow)
{
    domain.rowStart=firstRow;
    for(PxU32 s=0;s<2;++s)
    {
        domain.first[s]=0;domain.count[s]=domain.points[s].size();
        if(rotates[s])continue;
        const PxVec3d n=avbdNpRotation(poses[s].q).rotateInv(domain.normal);double extreme=s?-DBL_MAX:DBL_MAX;
        for(PxU32 v=0;v<domain.points[s].size();++v)
        {const double p=n.dot(domain.points[s][v]);if(s?p>extreme:p<extreme){extreme=p;domain.first[s]=v;}}
        domain.count[s]=1;
    }
}

PX_INLINE double avbdNpFeatureGradient(const AvbdNpDomain& domain,const PxTransform* poses,PxU32 feature,PxVec3d* arms)
{
    const PxU32 index[2]={domain.first[0]+feature/domain.count[1],domain.first[1]+feature%domain.count[1]};
    for(PxU32 s=0;s<2;++s)arms[s]=avbdNpRotation(poses[s].q).rotate(domain.points[s][index[s]]);
    return domain.normal.dot(avbdOgcDouble(poses[0].p)-avbdOgcDouble(poses[1].p)+arms[0]-arms[1])-
        domain.radius[0]-domain.radius[1]-domain.restDistance;
}

// A cubic in Bernstein form is bounded by its control values. Subdivision
// only tightens that bound; exhaustion rejects, never silently accepts.
PX_INLINE bool avbdNpNonnegativeCubic(const double* b,double roundoff,PxU32 depth=0)
{
    const double low=PxMin(PxMin(b[0],b[1]),PxMin(b[2],b[3]));
    if(low>=-roundoff) return true;
    if(b[0]<-roundoff || b[3]<-roundoff || depth==16) return false;
    const double a=(b[0]+b[1])*.5,c=(b[1]+b[2])*.5,d=(b[2]+b[3])*.5;
    const double e=(a+c)*.5,f=(c+d)*.5,g=(e+f)*.5;
    const double left[4]={b[0],a,e,g},right[4]={g,f,d,b[3]};
    return avbdNpNonnegativeCubic(left,roundoff,depth+1) &&
        avbdNpNonnegativeCubic(right,roundoff,depth+1);
}

// Numerator of rotation by an unnormalised quaternion. Its dependence on q
// is quadratic. This avoids sampling a finite rotational trajectory.
PX_INLINE PxVec3d avbdNpRotationNumerator(const PxQuatd& q,const PxVec3d& v)
{
    const PxVec3d u(q.x,q.y,q.z);
    return v*(q.w*q.w-u.dot(u))+u*(2*u.dot(v))+u.cross(v)*(2*q.w);
}

PX_INLINE PxVec3d avbdNpRotationDerivative(const PxQuatd& q,const PxQuatd& dq,const PxVec3d& v)
{
    const PxVec3d u(q.x,q.y,q.z),du(dq.x,dq.y,dq.z);
    return v*(2*(q.w*dq.w-u.dot(du)))+du*(2*u.dot(v))+u*(2*du.dot(v))+
        u.cross(v)*(2*dq.w)+du.cross(v)*(2*q.w);
}

// Full finite path in one common world axis. Multiplication by the positive
// quaternion norms makes the support gap a degree-five polynomial. Unlike
// a selected minimum vertex, all these facets have smooth endpoint gradients.
struct AvbdNpPathFeature
{
    double gap[5];PxVec3d angular[5][2];
    bool valid;
};
PX_INLINE double avbdNpBernstein5(const double* power,PxU32 k)
{
    double sum=power[0],ratio=1;
    for(PxU32 j=1;j<=k;++j){ratio*=double(k-j+1)/double(6-j);sum+=ratio*power[j];}
    return sum;
}
PX_INLINE AvbdNpPathFeature avbdNpPathFeature(const AvbdNpDomain& domain,
    const PxTransform* start,const PxTransform* end,PxU32 feature,bool derivatives=true)
{
    AvbdNpPathFeature out={};out.valid=true;
    const PxU32 ids[2]={domain.first[0]+feature/domain.count[1],domain.first[1]+feature%domain.count[1]};
    double D[2][3],R[2][3],dD[2][3][3]={},dR[2][3][3]={};
    for(PxU32 s=0;s<2;++s)
    {
        const PxQuatd a=avbdNpRotation(start[s].q);PxQuatd b=avbdNpRotation(end[s].q);
        if(a.dot(b)<0)b=-b;const PxQuatd delta=b-a;const PxVec3d& v=domain.points[s][ids[s]];
        D[s][0]=a.dot(a);D[s][1]=2*a.dot(delta);D[s][2]=delta.dot(delta);
        R[s][0]=domain.normal.dot(avbdNpRotationNumerator(a,v));
        R[s][2]=domain.normal.dot(avbdNpRotationNumerator(delta,v));
        R[s][1]=domain.normal.dot(avbdNpRotationNumerator(b,v))-R[s][0]-R[s][2];
        if(derivatives)for(PxU32 d=0;d<3;++d)
        {
            PxVec3d axis(0);axis[d]=.5;const PxQuatd db=PxQuatd(axis.x,axis.y,axis.z,0)*b;
            dD[s][d][1]=2*a.dot(db);dD[s][d][2]=2*delta.dot(db);
            dR[s][d][2]=domain.normal.dot(avbdNpRotationDerivative(delta,db,v));
            dR[s][d][1]=domain.normal.dot(avbdNpRotationDerivative(b,db,v))-dR[s][d][2];
        }
    }
    const double initial=domain.normal.dot(avbdOgcDouble(start[0].p)-avbdOgcDouble(start[1].p))-
        domain.radius[0]-domain.radius[1]-domain.restDistance;
    const double travel=domain.normal.dot(avbdOgcDouble(end[0].p)-avbdOgcDouble(start[0].p)-
        avbdOgcDouble(end[1].p)+avbdOgcDouble(start[1].p));
    double P[6]={},W[6]={},dP[2][3][6]={},dW[2][3][6]={};
    for(PxU32 i=0;i<3;++i)for(PxU32 j=0;j<3;++j)
    {
        const PxU32 k=i+j;const double product=D[0][i]*D[1][j];
        P[k]+=initial*product+R[0][i]*D[1][j]-D[0][i]*R[1][j];
        P[k+1]+=travel*product;W[k+1]+=product;
        if(derivatives)for(PxU32 d=0;d<3;++d)
        {
            const double a=dD[0][d][i]*D[1][j],b=D[0][i]*dD[1][d][j];
            dP[0][d][k]+=initial*a+dR[0][d][i]*D[1][j]-dD[0][d][i]*R[1][j];
            dP[1][d][k]+=initial*b+R[0][i]*dD[1][d][j]-D[0][i]*dR[1][d][j];
            dP[0][d][k+1]+=travel*a;dP[1][d][k+1]+=travel*b;
            dW[0][d][k+1]+=a;dW[1][d][k+1]+=b;
        }
    }
    for(PxU32 k=1;k<=5;++k)
    {
        const double weight=avbdNpBernstein5(W,k);
        if(!(weight>0)){out.valid=false;return out;}
        out.gap[k-1]=avbdNpBernstein5(P,k)/weight;
        if(derivatives)for(PxU32 s=0;s<2;++s)for(PxU32 d=0;d<3;++d)
            out.angular[k-1][s][d]=(avbdNpBernstein5(dP[s][d],k)-out.gap[k-1]*avbdNpBernstein5(dW[s][d],k))/weight;
    }
    return out;
}

PX_INLINE double avbdNpPathGap(const AvbdNpDomain& domain,const PxTransform* start,const PxTransform* end)
{
    double gap=DBL_MAX;
    for(PxU32 f=0;f<domain.count[0]*domain.count[1];++f)
    {
        const auto path=avbdNpPathFeature(domain,start,end,f,false);if(!path.valid)return -DBL_MAX;
        for(PxU32 k=0;k<5;++k)gap=PxMin(gap,path.gap[k]);
    }
    return gap;
}

PX_INLINE bool avbdNpDomainPath(const AvbdNpDomain& domain,
    const PxTransform* start,const PxTransform* end)
{
    AvbdNpRange ranges[2][2];
    for(PxU32 k=0;k<2;++k) for(PxU32 s=0;s<2;++s)
        ranges[k][s]=avbdNpSupportRange(domain,s,k?end[s]:start[s]);
    const double scale=ranges[0][0].scale+ranges[0][1].scale+
        ranges[1][0].scale+ranges[1][1].scale;
    const double roundoff=128*DBL_EPSILON*PxMax(scale,DBL_MIN);
    for(PxU32 k=0;k<2;++k)
        if(!PxIsFinite(ranges[k][0].lo) || !PxIsFinite(ranges[k][1].hi) ||
            ranges[k][0].lo-ranges[k][1].hi < -roundoff) return false;
    if(domain.rowStart!=PX_MAX_U32)return avbdNpPathGap(domain,start,end)>=-roundoff;
    // A fixed-orientation support boundary translates affinely. Use that
    // exact boundary rather than inventing a moving midpoint clearance that
    // can reject a collision-free arc above a static floor.
    double plane[2];
    for(PxU32 k=0;k<2;++k)
        plane[k]=start[1].q==end[1].q?ranges[k][1].hi:
            start[0].q==end[0].q?ranges[k][0].lo:(ranges[k][0].lo+ranges[k][1].hi)*.5;
    for(PxU32 s=0;s<2;++s)
    {
        // Translation alone has an affine gap; endpoint support suffices.
        if(start[s].q==end[s].q) continue;
        const double sign=s?-1.0:1.0;
        const PxQuatd q0=avbdNpRotation(start[s].q);
        PxQuatd q1=avbdNpRotation(end[s].q);
        if(q0.dot(q1)<0) q1=-q1;
        const PxQuatd dq=q1-q0;
        const double d[3]={q0.dot(q0),2*q0.dot(dq),dq.dot(dq)};
        const double x0=sign*(domain.normal.dot(avbdOgcDouble(start[s].p))-plane[0])-domain.radius[s];
        const double dx=sign*(domain.normal.dot(avbdOgcDouble(end[s].p)-
            avbdOgcDouble(start[s].p))-(plane[1]-plane[0]));
        for(PxU32 i=0;i<domain.points[s].size();++i)
        {
            const PxVec3d& v=domain.points[s][i];
            const double r0=sign*domain.normal.dot(avbdNpRotationNumerator(q0,v));
            const double r2=sign*domain.normal.dot(avbdNpRotationNumerator(dq,v));
            const double r1=sign*domain.normal.dot(avbdNpRotationNumerator(q1,v))-r0-r2;
            const double c[4]={x0*d[0]+r0,x0*d[1]+dx*d[0]+r1,
                x0*d[2]+dx*d[1]+r2,dx*d[2]};
            const double b[4]={c[0],c[0]+c[1]/3,c[0]+2*c[1]/3+c[2]/3,
                c[0]+c[1]+c[2]+c[3]};
            if(!avbdNpNonnegativeCubic(b,roundoff)) return false;
        }
    }
    return true;
}

struct AvbdNpDomainArgs
{
    const AvbdNpDomain* domain;
    const PxTransform* start;
    const PxTransform* end;
    bool* accepted;
};
}}
#endif
