# 已测死路（勿原样重试）

## 2026-11-05 有界 Host 新反例：不能用旧冻结绿测替代实际反作用

新 bounded 接入在反作用第 22 帧以 126 块／2880 行耗尽 1024 扫描；接触缺陷很小而相对力平衡约 8e-10，仍须拒绝。原 72 组冻结全部通过不覆盖它。真实方程残差替代固定点割线、加力平衡权重、降低 QR 秩截断、提前加入更小遗漏行均未关闭该捕获，已撤回。失败输入与输出在 `tools/fixtures/bounded-host-20261105/`；下一步需要解释双动态支持的共同模式，不能原样重复这些试验或增加上限救绿。

完整候选无半径却向球心舍入，会截掉接近一 ULP 的合法下降步，已用最近 float 加原域验收修正。此修复让五体越过原第 14 帧拒绝点，但后续仍慢收敛，最终 120 秒只有 15 个接受帧。不能把量化修正或无拒绝短跑写成完整五体通过，也不能用整程序统一缩步冒充发布阶段局部化。

2026-11-05: The engineering-direction qualification trial was also withdrawn. Reusing the legacy full-H correction and all-row checks still failed at reaction frame 22 and increased nonlinear backtracking cost. An engineering-accurate frozen direction is not sufficient for progress in the actual float contact domain; see docs/BOUNDED_HOST_20261105.md.

2026-10-30 有界收敛的新证据：本轮没有原样恢复先前仅反力 Gram／QR 选面。新的单体双接触交换明确同步更新 D^-1 J^T delta_f 位移、保留非零 wrench 余量，并沿原力界／摩擦锥限制；精确切向只汇总切向，不合并法向。还按原混合缺陷决定工作集扩展，避免过度求解遗漏大违约的子集。原 135／240／280 及此前未闭合的扩展 280 均通过，precise／fast、线程／重排／初猜矩阵 72 组全绿，硬链 825 次闭合。有限支持／固定预算与完整原根复核缺一不可；仍不能把冻结通过写成物理五体已通过。见 `docs/BOUNDED_CONVERGENCE_20261030.md`。

2026-10-30 反力坐标续修：精确切向汇总与力边界事件已关闭原 135／240／近边界 280 冻结输入，但新增“必须具有工程尺度可行步长”内层停止条件会使五体更早在第 16 帧失败，已撤回。切向／法向 Gram、直接 QR 的自平衡反力选面仍未关闭该新 280 输入，不能以理论零空间替代实测收敛，试验代码已撤回。NP 近似 GJK 轴给出负间隙也不证明实际相交：反作用捕获有完整盒面正间隙，须修 Host 方向搜索与精度，不能扩大几何容差或用穿透恢复掩盖。最终五体 41 帧后诊断超时，不是 360 帧 PASS；硬连通组达到 216 块，不能把局部化等同于有界成本。见 `docs/LOCAL_CONVERGENCE2_20261030.md`。

2026-10-30 局部混合校正：接受每次 Newton 校正就清空组合割线历史，会使四体／280 输入继续耗尽 1024 次；保留组合映射历史后 6 次工程通过。不能把 SOC 数值成功当实际准入后永久替代原方向。全体硬法向收紧至机器精度使五体在第 16 帧失败；有界 QR／提前加违反行也没有关闭旧输入。投影法向容量的等价 Newton 根使新 135 约束冻结通过，却让五体在第 19 帧停滞，已撤回。进一步要求可发布方向及局部 Gram 零空间／法向对更新仍未关闭新 280 约束输入，代码已移除。冻结通过、物理准入、完整场景不得混算；记录与失败输入见 `docs/LOCAL_CONVERGENCE_20261030.md`。

2026-10-29 非线性局部化：仅缩小执行域仍不保证组内 Coulomb 收敛。四体／240 组捕获有独立严格根，但共同增强 AL 在 1024 次后反力缺陷仍约 6.19e-6；实际五体第 23 帧拒绝。固定使用组内原严格响应的全场对照也在第 16 帧 NCP 未闭合，已撤回，不能据单个冻结解设置静默回退。工程 NCP 坐标停止试验未解决实际场景，相关容差已删除。

暖反力不能配忽略其作用的自由 primal；数值初猜不等于原物理 dual。完整 H 弱模态核验也不能把无接触耦合的材料修正回灌到共同增强迭代，否则会制造反复破坏接触的循环。最终保留原核验，只取消该组执行器的回灌；四体／90 组失败输入在原工程门限下从 1024 次失败变成 181 次通过，仍不是严格冻结或完整五体资格。跨组材料边界已有 12 体解析链通过，后续优先使用归档的小组反力反例定位，勿继续盲扫预算／AL 尺度。见 `docs/LOCAL_PATCH_SOFT_BODY_20261029.md`。

2026-10-29 局部块试验：冻结 H/J 局部着色 primal/dual 可通过严格根并提速，但并不自动解决原连通分量非线性接受。64 扫描近似方向交原检查在完整五体第 13 帧几何拒绝；1024 扫描加局部双接触选面和后续功停滞保留已验状态仍在第 16 帧失败，均未保留。最终无这些放行的局部核 15 帧接受、第 16 帧非线性功拒绝，不能只凭极小功差就证明浮点为唯一根因。需要改变候选/接受的局部组织并独立验证，勿原样重试预算或放宽残差。详细数值、各版本范围与证据见 `docs/LOCAL_BLOCK_SOFT_BODY_20261029.md`。

2026-10-29 停滞续修：仅把平方残差换成冻结共同载荷功，不能修复单极值支持切换；仅补终点支持束，仍可能被DCD完整路径拒绝。须共享完整路径坐标与导数。切向世界点float相减和零增量反复float归一化均已有反例；材料梯度保留double、能量逐项作差后才跨过先前弱转动拒绝。不得笼统将所有停滞归为浮点不足。

冗余黏着反力的首版双接触选面若在普通Newton回溯失败时无条件启用，会令原可解五体冻结输入失败；要求全体法向先严格可行也会卡住后一个真实输入。最终限定于当前线性分支不相容、原NCP数值残差不增，两个捕获通过precise／fast冷／热启动；后续27组主NCP仍未解决。不可将这两个冻结输入通过外推到完整五体，或用原26组SOC辅助输入失败直接否决仍可回溯的原方向。证据见`docs/AVBD_STAGNATION_FIX_20261029.md`。

2026-10-28 材料装配：多个支持落在同一刚体时，各支持单独外积会遗漏体内交叉项，独立共同平移反例会产生虚假曲率。先将导数转float再合并的首版也有7/1200个梯度检查失败，最大误差8.83e-6；在原double结果上合并后统一转换，原门限通过。公开四体API当前拒绝重复actor，不能据此宣称找到当前五体的运行根因。组内按row单次求值已通过生产回归，区别于跨颜色缓存旧导数；567→406ms为单次且轨迹不同的观测，不作统计加速保证。见 `docs/MATERIAL_PROGRAM_ASSEMBLY_20261028.md`。

2026-10-28 上轮重排反例已定位：Box–Box GJK_DEGENERATE被当作无接触，漏报pair没有证书；不是调顺序才能保持物理正确，也不是扩大查询距能修复（真实间隙9.568mm，查询105mm）。仅加既有完整流形面裁剪仍漏分离边—边近接触，该失败已归档。补完整最近特征后，同一原失败重排五体23.036→0.000743mm并通过，生产原顺序也通过。不得将面裁剪空结果或未解决GJK试算见证直接当作完整距离证明；不得据这一反例关闭而声称所有NP覆盖或主循环接管已完成。见 `docs/NP_BOX_COVERAGE_20261028.md`。

2026-10-27 锁定轴／装配：先解无约束6×6、再清零锁定分量会破坏自由轴平衡，公开斜向弹簧反例相对误差可达约7万倍；必须在H/g与跨块因子中同时限制运动空间，不能加迭代掩盖。首版“材料先全部累加、再约束”的浮点重排使五体出现23.036mm外部穿透，已编译NP证书仍报告0违反，失败已保存。最终恢复单遍row顺序只恢复回归，不证明该几何问题已解；不能把一条成功轨迹当作普适资格，也不能据此要求并行确定性。见 `docs/NP_PRIMAL_ASSEMBLY_20261027.md`。

2026-10-27 共同摩擦续修：第五捕获仅减少原变量锥选面到 1／2／4 次，会使原 NCP 校正在既定预算耗尽后仍失败；不能据简单捕获提速直接削减困难输入选面。较大的准定消元枢轴修正、放宽 LSQR 正规残差停止、锥与固定16步校正交替均未通过同等闭合；有界稠密 QR 通过但更慢，已撤回。保留的是原矩阵残差复核的稀疏消元、小型有界 PSD 响应缓存与原 NCP 校正；并不授予完整主循环或实时资格。见 `docs/NP_SPARSE_COULOMB_20261027.md` 和 `tools/benchmark-results/np-sparse-closure-20261027/`。

2026-10-27 共同 Coulomb 更新：第五捕获已有严格原根。完整 H 原变量锥子问题选面＋原 NCP 校正的冷启动稠密参考五项通过，第五项 8.90e-11，外部优化器对照 2.98e-13；不能再以旧 Newton 失败推断无解。关联锥单独成功不等价于非关联 Coulomb，已有抬升反例。C++ MINRES 候选第五项仍失败；N 维重启、代数正则、128/512 GMRES 及关联锥 FISTA 对照未获生产资格，勿原样增加基或迭代重试。候选只在实验区，SDK 主循环未变。见 `docs/NP_COULOMB_CLOSURE_20261027.md`；此前失败保留其算法与输入范围。

2026-10-27 接触组续接区别：本轮补全共享法向／双切向因子、将端点增强保留在对角块，并以实际候选的完整组模型下降和已有完整几何验收，才启用普通NP摩擦组；Checked trial完整五体与原生九项通过。不能把此结果改写为2026-10-23“只解除拒绝”试验通过，也不能删掉旧模型冲突或第五摩擦捕获失败。新旧同机五体348／343 ms，P95和峰值增加；约491→343 ms的跨轮差异不是加速证据。见 `docs/NP_GROUP_CONTACT_20261027.md`。

2026-10-26 混合续修：直接混合MINRES已消掉纯法向中的嵌套H逆，并补齐标量有限力限；不要再以“精确H只能嵌套”解释高成本。非关联Coulomb产生非对称耦合，不能直接套该对称核。额外LM诊断第五摩擦捕获仍停在归一化根残差约3.19e-8，部分physical_conditions通过不等于原1e-10根通过；未迁入。证据见 `tools/benchmark-results/np-mixed-kkt-20261026/`。

## 2026-10-26 回迁准备：不能把摩擦线性解或锥投影当成完整根

`native-friction-curvature.npz` 的旧稠密参考本身报 `Coulomb NCP unresolved`（J 秩40、乘子144）。混合 Newton/Krylov、局部预条件、续接、圆盘回缩、SOC Newton 均未解决该项；固定步长 FBF 稠密试验在8192外层预算内也未完成五捕获资格。失败原始结果在 `tools/benchmark-results/np-production-kernel-20261026/`，不能按原样重试或称为浮点精度已定位。完整 H 法向响应已另行通过，但两困难捕获需要上万次 H 乘法；不直接塞入生产物理迭代。后续须同时降低混合方程成本并验证原非关联摩擦残差。下段块对角适配器拒绝材料是此前状态，本轮已由共享完整 H 响应补齐。

## 2026-10-26 闭链：单体可行驻点不能证明整体收敛

两体目标 -0.01/-0.03、惯性度量 1/2、约束 x1>=x0 时，逐体可行更新停在 (-0.01,-0.01)，共同解却为 (-0.0233333,-0.0233333)。这是精确算术反例，不要继续用精度或更多同类扫掠解释。新法向锥耦合核解决了该冻结问题，但实验适配器的块对角逆不能用于带真实跨块材料的 H，当前会明确拒绝。64 体小核四线程比单线程更慢，256 体有小核收益；不能将稀疏/可并行结构或局部收益直接写成全场景加速。详见 `docs/NP_CLOSED_CONTACT_MODEL_20261026.md`。

## 2026-10-26 后续：不能仅靠新的接受条件或力预测修剪刀

同一完整 NP 域基线下，真实保守势加冻结牵引虚功、冻结法向容量的各向异性 Fenchel 摩擦，两种组合仍使剪刀严重失稳，均撤回。当前局部6×6未约束方向预测 dual 虽通过大offset/退开/压缩反例，却使 reaction 动量误差达6.415%、ball-shot响应物体为0，不能保留。仅关闭正间隙势、保留硬域也未修复剪刀。插桩异常候选均来自可行初值，不要将该轨迹归到规定边界恢复豁免。

共享核给出了独立材料反例：r>0的OGC近端律在被硬约束固定的d=0上无有限dual固定点，rho=1e4/r=.04/kc=1e5时从零经80次更新增长到7851.37N；r=0硬接触对照不增长。不能靠加迭代、夹力或排除articulation掩盖这一材料合同冲突，也不能把它当成剪刀唯一根因。最终仅保留COM标架和锁定轴子空间修复，原生trial九例继续通过。各失败源/输出与后续范围见 `docs/NP_REMAINING_CONTRACTS_20261026.md` 及 `tools/benchmark-results/np-remaining-20261026/`。

## 2026-10-26 补充：保留失败范围

OGC近端法向势单独组合硬域，reaction/压缩可过但ball-shot能量失控；仅把点曲率换成rho上界仍失控。投影后6×6局部模型验收修复了ball-shot，但不能据此授予关节树资格：最终NP trial的scissor-unloaded/cycle仍FAIL。模型版五体曾有21.760mm外穿透，捕获证明第236帧暖PCM漏接触（冷查询有点、真实间隙0.414mm、查询距29.684mm）；共有NP负缓存重生成后五体PASS。不要再把该反例解释为只需扩大查询半径，也不要因这次几何PASS将trial默认为普适接触模型。全部中间失败与最终资格见 `docs/NP_REACTION_AND_CACHE_20261026.md`。

2026-10-23 同轮修正：下段82.304 mm属于只用缓存流形方向的首版。Host NP新增完整支持GJK方向并由Backend重新验证后，完整五体外部峰值为3.6283609e-7 m、自穿透0，原场景PASS；单帧最多补回21个原方向缺失的证书。原生reaction和刚体ball-shot基础失败仍在，默认不启用。不得把该几何修复与“投影反力已进入dual”混为一谈。最终证据为axis-trial.json，原FAIL保留。

同轮运动学负例：硬域compression-recovery在360帧中出现1次明确域拒绝发布，25个证书的起点被先行推进的运动学pHat破坏（约8.419 mm）。原默认路径通过，硬域原生矩阵7/9。不能删掉该错误、把几何锚点重设到已穿透位置、忽略规定运动或仅对本场景关闭域来授予资格。

2026-10-23 NP 完整支持硬域：直接把无限响应凸体对的完整支持/有限路径域加到现有Position-AL，再对单块平移求半空间交集，五体已覆盖证书终态违反归零、自穿透63.883→0.410 mm；但reaction动量误差0.363、COM漂移0.482 m，ball-shot缺少目标响应，外部穿透仍82.304 mm。硬域阻止了AL需要的负残差，投影KKT反力没有进入共享dual。不能把局部非穿透误当成正确载荷传递。默认恢复旧路径，失败机制仅以`--np-domain trial`保留供后续共同力/域闭合对照；证据在tools/benchmark-results/np-certificate-20261023/。不得以逐对写回反力/改BDF/场景分支救绿。

2026-10-23 新标准下两项撤回：共享接触力之后，直接让单端摩擦进入材料执行组虽将末段平均外穿透降至9.44 mm，却使末段最大52.71 mm、全程115.98 mm；取消原端点矩阵条件化的末段平均更达45.41 mm。两者均未保留，不能只用末帧/峰值中较好的一项救绿。保留的是共享力/dual/能量及原矩阵条件化、接触修改力限和OGC小角数值修复。普通NP无完整凸体证书，既有alpha恢复即使残差收敛也不等价于零间隙。旧源负对照、完整轨迹及源码在tools/benchmark-results/contact-shared-law-20261023/，详见docs/CONTACT_SHARED_LAW_20261023.md。

2026-10-23 历史反例的使用范围：用户已授权按 [软体验收口径](../../../docs/SOFT_BODY_ACCEPTANCE.md) 校准工程标准并建立干净官方基线。下列记录仍证明各自版本、输入、门限下的失败，不删除或改写为 PASS；但“实验绝对残差未达标”“公开角速度上限被触发”“不同线程不逐位相同”不能自动推出产品不可用。数学小核仍按原严格尺度验证；完整场景按明确的基础合同、场景质量和性能分别判定，强保证研究另列。历史“不得调门限/预算”禁止无证据救绿，不阻止本次获授权、保留原结果的基线校准与误差—成本扫描。旧组合失败不永久否定一类方法；重试必须给出新的机制差异和独立证据。

原生完整五体目前约 86.8 / 57.0 mm 的外部/非邻接自穿透，远超现行默认 2 mm，不能用这次标准分层掩盖；但此前小实验每帧全局驻点或 `1e-7 J / N·s` 未达标，不再单独阻止本阶段已通过基础与适用场景质量的机制迁入。官方同样失败只说明参考能力边界，不能将本树失败自动转绿；旧 FEM 的五体 PASS 不含相同穿透观测，本树 PGS/TGS 也不是干净官方构建。基线测量完成前不预设替代门限。

2026-10-22 类型化有限材料回迁补充：共享真实材料值/梯度/解析完整曲率、九维 PSD 及可变秩小支持组接入生产后，八项材料用例、公共地板和旧 FEM/布料均通过，但完整原生五体仍外部/自穿透 86.799 / 56.992 mm（迁入前 85.213 / 52.918 mm）。只补曲率和材料真值不能关闭普通 NP 几何。原始第 20 帧完整凸体深度约 0.815 mm，四个 witness 只报告约 0.020 mm；迁移后仍重现同类差距，不能再用这四点的更小残差或增加精度证明完整形状非穿透。本轮保留的是验证通过的材料输入/执行合同，不授予完整接触资格，也不以此否定连续材料。有限材料的候选能量仍受位置摩擦接受缺口限制。见 docs/JOINT_SOFT_BODY_NATIVE_FRAME_20261022.md 与 experiments/avbd_contact_lab/results/native-closure-20261022/final-audit.json。

2026-10-22 有限转动续查：不能把不同提议度量产生的步长直接比较并称为收敛改善。`GN+PSD(H-GN)` 在原始 OGC 第 23 帧使自身方向残差 0.035224→0.005721、未截断角速度 147.949→6.366，但同一原参考度量的后验残差 0.006915→0.192999，真实增量势反而升高；第 225 帧也有同类反例，未保留。旧第 23 帧单元 290 距接触面 0.246 m，从步初和发布姿态均收敛到同一约 148.419 rad/s 的条件极小值，不能把该角速度本身归因于接触或材料分支错误，也不能外推全耦合驻点。对应质量仅 5.58e-7 kg，必须报告力矩/能量尺度。第一次后验观察器从最终速度重建惯性目标，已确认无效并单独归档；修正为原始步初目标后上述负结论仍成立。解析 Hessian 保留原完整 H 的 PSD 投影，在 23/179/225 三帧与原有限差分最大位姿差 2.71e-15、角速度差 3.18e-13，几何和能量观测相同；不宣称逐位一致。详见 docs/JOINT_SOFT_BODY_CURVATURE_20261022.md；完整生产五体仍未通过。

2026-10-22 OGC 组合反例：修正两段势连接系数后，以原 contactOffset、默认 kc=1e5 和同一 primal/dual 接入原始资产，初态 30 帧最小间隙 2.176 mm、能量逐帧下降，但第 23 帧仍出现 147.949 rad/s 未截断角速度，最大非线性方向残差 0.035224。不能把 offset 正间隙当成材料有限转动已经收敛。把硬接触第 179 帧直接换势还带入 43740.47 J 初始储能，方向残差 0.000402→0.004115、sweep 53248→57344，不能作为性能或恢复正确性的正证据。该试验不是论文完整接触特征集/局部域实现，也不据此否定 OGC；限定组合继续 opt-in，详见 docs/JOINT_SOFT_BODY_OGC_20261022.md。

同轮编译反例：不能用 `/fp:fast` 下的 double→float→double 转换表达式证明实际 PxReal 发布已被检查。旧有限球回归普通编译通过、fast 失败；发布边界强制真实 float 存储后两者通过。不能以放宽球半径或全局取消优化代替这个存储语义修复。

2026-10-21 原始五体：最短 log 与最短中点标架在相对半转处不连续，实际第 59 帧接受更新跨过梁 306/309/310 的分支，有限应变阻尼亦跳变；不能只拒绝过分支候选而制造人工角域。改为全局连续材料后，原逐对可表示投影又在约第 143 帧造成整体冻结：尚有约 13 mm / 413 J 的非零修正，205 次几何检查全部拒绝。不能把零速度、非穿透和正体积三项算成通过。联合恢复在同一冻结状态恢复约 11.8 mm 运动，仍需独立验证原始全程与生产管线。无条件半 ULP 内缩会错误排除无严格内点但可表示的闭域，须先求原域并验证实际舍入候选；24 点双侧固定接触链已作为反例保留。连续材料使旧 `native-float-energy-stall` 的 float/double 两边都通过，现改为精度测量，旧失败留在历史结果，不能强行维持失效负对照。严格 dense Coulomb 五立方体仍有 NCP 未解失败，与 split 候选通过分别报告。

2026-10-20 独立实验的迭代成本反例：小容量 Anderson 在两个冻结 Coulomb 捕获上增加工作量；以初始残差的宽松相对比例停止内层，使第 44 帧外层方向残差达到 0.00563。两者未进入保留执行路径，不据此否定整类算法。零载荷事件外推初版将检查间隔从 32 改为 16 后直接退出，平面滑动累计速度误差 1.88e-8 超过原 1e-8 门槛，即使没有接受任何外推也会发生；普通更新的收敛确认修复后为 2.08e-11。最终加速核减少完整独立五体实际更新总量，但第 44 帧多一轮外层更新、端到端变慢约 18.6%；禁止只报内核改善而隐去整帧退步。源码、原门禁、退避试验及资格边界见 `experiments/avbd_contact_lab/README.md` 第十轮；不得以该双精度实验授予生产完整五体或实时资格。

2026-10-19 初值复验补充：下文精确 `qHat` 候选的 Debug 失败仍是当时有效负证据。2026-10-16 已另外关闭绝对区间、KKT 互补、提交范围及实际浮点候选缺陷后，再次采用精确统一初值，三配置完整 FEM 均通过，原大角目标反例也通过。本轮没有放宽原域或增加预算。该结果不证明原生五体非穿透或完整大角速度合同；位姿存储迁移与初值修复分版本对照，详见 `docs/MIGRATION_POSE_VIEW_20261019.md`。

2026-10-16 休眠补充：下文 reaction FAIL 是计数修复前的事实。根因进一步定位为六条 Host 连通边将同一四点材料的节点 interaction 计数重复三次；改为物理约束身份的首次登记/末次撤销后，四节点自由平移反例和默认 reaction 三配置通过。不是降低 sleep threshold、关闭休眠或修补质心动量。历史摩擦候选仍撤回，完整五体仍穿透；最终源/二进制及门禁见 `full-migration-20261016/host-count/`。

2026-10-16 联合域组合负结果：绝对区间单改 Debug 182 次 fatal；区间加 KKT 互补 Checked/Release 各 157 次；仅 KKT 互补 Debug 107 次；再加提交范围但不修区间仍失败；三者组合 Debug 169 次。无条件对全部线性域预留舍入余量，Checked/Release 各 110 次；只处理实际失败接触仍漏掉三角平面，Debug 118 次。不能以单配置、小反例或插桩轨迹通过保留它们。最终保留绝对区间、互补条件、求解前确定提交集合，并对实际拒绝候选的接触/三角平面生成有限精度提议；原域/能量、物理预算不变，三配置完整 FEM 与公共地板通过。该结果不否定过去负证据，也不证明原生五体通过；原始失败目录与最终 `adaptive-domains/` 分开保留，详见 `docs/MULTI_SUPPORT_ARCHITECTURE_20261016.md`。

2026-10-16 四点材料续迁：直接叠加二次体积项使 compression-load 失去既定压缩响应，不能放松压缩门槛；当前实验采用零一、二阶 rest 导数的高阶体积项。四点材料只做逐端 6×6 GS 时，独立强冲量四节点反例出现明显动量误差；同一着色程序内的小支持组耦合候选修复了该反例，不能外推为完整接触正确。另一次组合实验将接触端点罚增强仅留作度量，并用共享 sweep 法向容量的 Fenchel 摩擦及匹配能量验收；reaction 仍 FAIL，Chainmail impact 出现 net_too_stiff，已撤回全部该组合，未将失败单独归因于摩擦或罚增强。`full-migration-20261016/withdrawn-contact-source/` 和 `contact-*.log` 保留证据。reaction 逐帧日志显示第 110→111 帧软体休眠清零后总动量从约 -0.158 跳到 +17.226 N·s；新增 `--disable-sleep` 仅为独立守恒诊断，原休眠开启用例仍保持原输入和 FAIL，不能用该诊断替换门禁。四点体积域已经消除本轮五体观测翻转，但仍有约 80 mm 外穿透，不能据此宣布完整迁移或旧 FEM 替换完成。

2026-10-15：有匹配局部势的各向异性 Coulomb 投影/冻结法向容量/能量验收，配套角图导数后五体仍 det −0.306965、外部/自穿透 147.839/162.891 mm；再配套真实有限 solverPrep 局部及候选求值，仍 −0.306542、137.769/195.420 mm，成本增加，已撤回全部摩擦势/局部回调/索引。与 10/13 未配套摩擦验收的试验不同，不能原样重试，也不能因此否定所有非线性材料或变分摩擦。PCM 仅改两端角位移与外包半径仍漏组合运动，等形 Convex–Convex 捕获回放失败；保留的是相对标架合成运动界。最终五体仍未合格，见 `docs/JOINT_SOFT_BODY_FIVE_20261015.md`。

2026-10-14 五体续查：完整 canonical Plane–Box/Convex 输出单独应用（未改 Backend）时，原八项与 Chainmail 通过，但五体穿透 201.737/321.071 mm，已撤回。对称梁基线上单独把 NP AL 目标改为原始 gap，原八项/HelloWorld 通过，Chainmail impact/projectile 失败，亦撤回。不能再把 10/12 组合失败全部归于 endpoint penalty。保留的是有独立冷缓存 NP 反例的最深支持点补入，以及有端点交换/有限差分验证的对称梁；两者仍没有关闭完整五体。中间版本数值不可代替最终 `retained-*`。见 `docs/JOINT_SOFT_BODY_FIVE_20261014B.md`。

2026-10-14：固定刚体支持点/法向求值后，精确 pHat/qHat 初值重新验证仍在 Debug 完整 FEM FAIL 195 次（Checked / Release PASS），再次撤回。全部 log 改写与联合内域试验也未获资格。保留的只有共享刚体几何变换与实际提交角位移度量，三配置原门禁通过。捕获第 136 步粒子块 761 的行 1100 是跨内联的刚体锚点舍入差，不是遗漏行或刚体并发写入；不能再以调容差/工作集替代此处几何一致求值，也不能把它当成原所有 QP 非线性发布缺口已解决。见 `docs/JOINT_SOFT_BODY_CORRECTNESS_20261014.md`。

2026-10-13 整步闭合续测：精确 qHat + 活动支持外自由提议置零虽然通过 Checked / Release 完整旧 FEM 和原小场景地板，但 Debug 完整 FEM FAIL 150 次；独立修改前 Debug PASS，不能算旧故障。工作集单独应用则 Debug PASS、Checked / Release 各 FAIL 223 次，两者均撤回。按半 ULP 内缩后继续 KKT 或显式解内缩 QP，完整 Checked 第 236 步起 FAIL，共 125 次；该次捕获的三角条件 full 与 partial 方向相同，不能直接归因于支持裁剪。初版内缩也未修复第 350 步失败。统一 float / double 接触间隙求值的组合触发已提交 Rigid6 域错误，亦撤回。上述候选源码和日志已归档；生产无 helper、参数、插桩残留，不得仅凭小型反例通过原样继承。新裁剪提交反例保留 FAIL，详见 `docs/JOINT_SOFT_BODY_CORRECTNESS_20261013B.md`。

2026-10-13 joint 后续：每个局部块/候选能量重新 solverPrep 的有限 spring 候选，原八项和 Joint/Drive 通过，但完整五体外部/自穿透 187.603/312.243 mm，且增加求值成本，已撤回其 kernel/索引/回调路径。精确 qHat 初猜候选使 69° 共同运动位置误差降至 2.42e-7 m，却使旧 FEM showcase 出现 11 次耦合域未闭合，已撤回；不能增预算或按软/刚程序分岔初猜救绿。保留的是独立的稳定有限双边 spring 材料坐标阻尼，完整五体与大角整步反例仍 FAIL。独立双精度积分已排除四个微小球面单元的质量计算错误，不能删质量或质量钳位。证据见 `docs/JOINT_SOFT_BODY_CORRECTNESS_20261013.md`。

2026-10-12 joint 五体正确性候选：局部 6×6 块对角逆响应条件化未保证固定预算收敛，reaction / 双体动量误差 2.72% / 9.85%，已撤回临时数组及编译代码。删除端点 penalty 增强、canonical 完整平面顶点 NP、法向实际间隙的组合仍有五体 192.67 mm 外部穿透及 268.29 mm 自穿透，并使 Chainmail impact / projectile 失败，已全部撤回。不能把组合回归单独归因于某一项，也不能以增预算/减门限原样救绿。Plane–Convex 双面循环的一行索引修复经独立公共 NP 反例验证后保留，与被撤回的完整生成器替换不同。完整五体的材料域及有限转动几何覆盖仍待设计，详见 `docs/JOINT_SOFT_BODY_CORRECTNESS_20261012.md`。

2026-09-29 three-avbd 对照后的性能试验：不能根据首组 196.700 → 174.696 ms 就宣称同色任务最小粒度 16 更快；交替 60 帧复测组合候选回退 5.93%，最终恢复 2。按提交维护三角缓存、每步绑定材料、pin dual 阶段清理的组合也未证明完整场景收益，虽有物理门禁通过，仍撤回。不得把性能回退当成这些方法永远不可用的证明，也不能把组合差异单独归因于某一项或说它们发生了物理失败。最终只保留同一 block 内对相同实际提议的准入复用。详见 `docs/THREE_AVBD_LOCAL_EXECUTION_20260929.md`。

2026-09-29 后续性能试验：活动集内复用 KKT 乘子的版本在 showcase 第 168 帧起五体零位移，已撤回，未单独追踪失败行，不能原样继承其资格。共享固定梯度/最强线性边界首版从第 152 帧冻结，诊断抓到 Rigid6 的已提交 AL 间隙超出自身输入误差；共用准入原先只用旧/新尺度，未要求候选自身尺度闭合。补齐该合同后，保留共享梯度的完整 360 帧恢复 PASS；不能因失败否定该等价线性压缩，也不能宣称未经重测的乘子复用已修好。证据见 `docs/SHARED_DOMAIN_PROGRAM_20260929.md`。

2026-09-29 局部二次能量首版试验：showcase 第 57 帧起联合验收拒绝发布，五体零位移；60 帧诊断有 4 次运行时错误。不能仅凭单点能量公式正确接受该版本。缓存 `gap + J·d` 与联合实际候选的输入尺度/求值次序存在边界差异，联合全能量相减也需要稳定增量；两者一起修正后原始 360 帧恢复 PASS。本轮没有独立隔离两项修正的因果贡献，不能把失败单独归因于其中一项，更不能据此否定二次限制式。证据与最终实现见 `docs/LOCAL_PRIMAL_PROGRAM_20260929.md`、`tools/benchmark-results/domain-cost-20260929/`；禁止删除联合验收来隐藏这一类冻结。

历史与数字见 `docs/ITERATION.md`。2026-09-14 用户要求接触设计闭合修正后，本表保留实验事实，禁止原样盲重试；历史“不逐位”以及不一致公式下的回退不构成永久否定整类方法的证明。新的共同势、完整几何与整步接受条件按 `docs/REFACTOR_OUTLINE.md` §12、`layers.md` 和 `docs/OGC_CERTIFICATE_CONTRACT.md` 验收。场景闸、COM 修补、位移帽和第二管线等架构禁项仍然禁止。

2026-09-29 性能试验：按当前 Newton 提议筛选局部三角工作集、投影后补充新条件的版本，60 帧物理 PASS，但完整 showcase 从第 178 帧起出现五个软体连续零位移、记录速度仍非零，已经撤销。局部候选可行和短测提速不能代替整步闭合；不通过加预算或放宽域接受这个版本。证据见 `tools/benchmark-results/certificate-program-20260929/rejected-working-set-source/` 与 `final360.log`。后续若重新研究工作集，需补充有限精度投影与完整整步验收，不能原样重试；当前采用保留原投影程序的派生数据复用。

| 死路 | 为什么死 |
|---|---|
| Surface 完整分离证书遇到初始相交就切为 type-3 恢复面（2026-09-14，第 8 轮） | 已撤回换面分支。捕获 epoch 68：约 -1.8e-6 间隙切到顶面恢复证书后，各点仍可行但交叠扩大至约 -0.001，180 帧有 4 边/4 面穿盒。保持最大最小投影间隙的完整平面才保留原几何约束；不要用接触状态切换证书并声称只是初始恢复。 |
| 全部软软三角对的 3×3 固定世界平面条件，每条都赋予偏移势（2026-09-14，第 7 轮） | 已撤回。完整投影分离不等于物理力模型；两片三角原生反例总力 0、净力矩 25.1557655，共同旋转 0.01 rad 使能量 4.5→4.74827003。原型夹持 180 绿，soft-soft/showcase 600 秒超时，仍不可接受。不能只压缩执行成本后原样重试；须补能量旋转客观性及所有支持导数。此反例不否定完整支持的几何证明。 |
| 仅替换为完整半空间交集投影，默认旧 warmstart/GS/tet 缩步自动保持可行（2026-09-14） | 原生两反例与 200 KKT 通过，但完整域版坐下掉到 y=0.6002、Surface stretch=1.8735；最近点 barycentric 修正单测夹持首芯 82→70、芯 2→4、互穿 6→14。均撤回。不能否定交集数学本身，需先证明整步特征位移和提交可行性，详见 docs/OGC_CERTIFICATE_CONTRACT.md |
| 两体积 COM 最大距离（共享动态盒，rest=首帧质心距） | 已跑。坐下 180 逐位闲置 leftover-open 2 / y **2.86057591** / 回弹 3.53925。夹持更差芯 **3** 第 **15** 帧：占用 dump B，max-distance 把 A 拉下，对 COM 仍下落。颌-颌 rest 不是世界支撑。体积-盒 max-distance 会吃坐下回弹。已撤回。不要再跑三明治 rest-length / 颌间距 |
| 膨胀 OBB 内部 k>0 井 + pair 终身 type-3 闩 | 已跑。坐下种下/回弹闲置 leftover-open 2 / 3.53925；180 不逐位 y **2.86067843** / `minDetF` **0.939821064**。闩挡不住回弹落地 VF 休息期。与 VF-blind SAT 同一 bounce-settle 内部井。已撤回。不要再给内部 offset 井加 pair 状态闩 |
| 占用净力交给弹性（tet 核正交 / 刚体模投影 / 指望应变挡住自由颌） | dump 是整体平移，落在 FEM 弹性能的刚体核里。COM-free 三顶点 J 已测：坐下覆盖焊 leftover-open 0，夹持芯 4 第 21 帧网格跟随仍打下颌。webphysics 无 FEM 三角芯。不要再找第四个家 |
| VF-blind 内部 SAT 当 Eq.21 d（动态盒、三顶点 sdf>`2*margin`、未膨胀 AABB 不叠、SAT<margin） | 已跑。想躲开 VF 休息期 satNear 和回弹空洞。坐下种下/回弹闲置 leftover-open 2 / 回弹 3.53925；180 不逐位 y **2.86023545**（回弹落地前 VF-blind 内部在 holes 出现之前开火）。夹持 20 帧 skip-all covering 0 intersecting 0，boxY 4.42。与 `!hasTriangleCore` SAT 同一家。已撤回。不要再给 SAT 当 topologyDistance 加 VF-blind / holes / 动态盒闸 |
| 无 Gu type-3 才用 15 轴 SAT 当 Eq.21 d（想坐下种下闲置、夹持挡隧道） | 已跑。坐下种下/回弹闲置（第 0 帧有 type-3）leftover-open 2 / 回弹 3.53925；回弹后 VF 壳 `hasTriangleCore=false`，第 60 帧 satNear=7 开火，180 帧不逐位 y **2.86079645** / `minDetF` **0.913570702**（合同 `2.86057591` / `0.938481927`）。夹持 onset 是 skip-all：第 11 帧 covering 0（基线 hanging **-5.5mm**），第 9 帧 intersecting 1 随后清零。闸在 VF 休息期等于给坐下 nick 裙加 SAT clip。已撤回。不要再按本步有没有 type-3 切换 SAT Eq.21 |
| 15 轴 SAT / 膨胀 AABB 接近行（`satNear`：非 Gu、三顶点 sdf>`box.margin`、SAT<margin；`inflated`：AABB vs half+margin） | 诊断未落地公式。未膨胀 AABB `holes` 在隧道前仍为空，但 15 轴 SAT 在坐下第 0 帧已 **satNear=3** `minSat15=0.29mm`（回弹第 20 帧 boxY **3.53925** leftover-open 2 仍在）。夹持第 8 帧 holes=0 而 **satNear=12** `minSat15=0.64mm`、`minVertexSdf` 仍 6.6cm。抓住夹持隧道内部的 SAT 半径就是坐下 leftover nick 裙。与 NP 投机 / 内部证人同一切口。`!hasTriangleCore` 闸已跑：种下闲置、休息期不逐位、夹持 skip-all。不要给 satNear 编 Eq.21、type-3 或把 VF/EE 扩过 `box.margin` |
| C01a 内部空洞 Eq.21 / C>0 clip（非 Gu、AABB 叠未膨胀芯、顶点在 VF 壳外） | 诊断未落地公式。坐下第 0/20 帧 holes=0。夹持第 8 帧隧道前 holes=0（顶点 sdf 6.6cm，AABB 尚未叠未膨胀芯）；第 9 帧已 Gu intersecting=2 后才 holes=2。空洞证书赶不上单步隧道。扩到第 8 帧能编行 = NP 投机 6.6cm 半径。15 轴 SAT 才看见隧道前内部，但坐下第 0 帧同样 satNear>0。不要跑 |
| 步间 `\|ΔCOM\|>dShape` 刚体模把占用 COM 交给刚体（想坐下形变、夹持刚体 dump） | 诊断未落地公式。坐下第 0 帧 dCom 5mm < dShape 22mm 故闲置。夹持接触前每帧 dCom≃2.7cm ≫ dShape 是弹道；第 11 帧 covering 抽出相对上一帧额外 COM ~4mm < dShape 8mm，仍是形变。相对 warmstart 后弹道已在 pHat，闸两边都不转或转的是弹道。不要把帧间 COM 当占用刚体模 |
| leftover C≥0 + 未膨胀 Gu 顶点/边 clip（想挡煎饼、不用 1cm） | 就是 leftover clip AL。坐下 leftover-open 2 仍 Gu 相交满盒，会抽出 millimetric nick。未跑。不要跑 |
| leftover C≥0 + 1cm Gu + other-pair 最深顶点 post-AL（想保住坐下又挡煎饼） | 死 149 家。坐下 leftover 夹心 −0.87mm 不进 1cm 故闲置；夹持第 82 帧煎饼进 1cm 故曾绿；`free-fall-triplet` 落地第 139 帧也进 1cm（同一双体积+盒三明治）故炸 `minDetF` 0.05 / 漂移 0.70。1cm 芯拆不开夹持煎饼与共落落地。不要再给 1cm 加 leftover / 对颌闸当新残差 |
| 悬挂 C≥0 时把 type-3 C 改成夹 remaining / leftover clip AL（挡煎饼） | 已跑覆盖焊：leftover-open 2→**0**，`boxFinalY` **2.86830974**，回弹第 20 帧 boxY 3.54→**4.2428**，`minDetF` 0.938→**0.830675781**。顶点/边中点沿 packed n 采样在悬挂 C>0 时抽出坐下 millimetric leftover，与悬挂在外跳过同一切口。第 82 帧煎饼需要的正是这条 leftover clip AL。拆开只能靠禁止的 1cm 芯。已撤回。不要再跑 |
| 平移不变占用 `C_def=C−n·ΔCOM`（全顶点 COM J，与 COM-free 三顶点 J 对齐） | 未跑。COM-free 只改三顶点 J 已覆盖焊 y 2.868 leftover-open 0，夹持更差芯 4 第 21 帧（三角仍能抽出，网格 COM 跟随）。把 COM 写进 C 后，坐下 spawn −10cm 只能靠顶面相对 COM 砸 10cm 凹坑（`minDetF` 灾），不能靠刚体平移。不要跑 |
| type-3 Position-AL 只在每步第一轮 outer sweep 开火（弹性继续 127 轮） | 未跑。坐下 nick 是 128 轮 AL 经 tet 链到地面；一拍后弹性回推占用而不再 AL = skip-all 余量（坐下第 7 帧芯 4 同类）。夹持第一拍即使把 5.5mm 砸平，后续 tet 回推进盒同样穿芯。不要把迭代次数当残差 |
| 按 Host `getNbCpuStaticBoxes()!=0` 切换粒子 type-3 Position-AL（坐下基座 nStatic≥1 满 ρ；夹持 nStatic=0 跳过粒子 AL，clip + 刚体 w=-1 leftover 留下） | 已跑 skip-all。坐下有基座逐位恒等 leftover-open 2 / y **2.86057591** / 回弹 3.53925 / `minDetF=0.938481927`。夹持更差：芯 2→**6** 第 82→**62** 帧，互穿 6→**20**，角点 0→**2**，`minDetF` 0.466→**0.05**，`minY→1.5e-5` 掉穿，第 11 帧 covering hanging 仍 **-5.5mm**。刚体 leftover 吃不掉粒子先扫留下的占用；粒子停 AL = 已死 skip-all（坐下第 7 帧芯 4 同类，夹持更早穿芯）。与 k>0 井闸不同：同盒 VF 井在两场景都在，本闸用 Host 静盒计数绕过井 Hessian。仍是 hasContact 家切换。已撤回。不要再按静盒/地面/nStatic 开关谁吃占用 C |
| TetMaker 体素轴 `+0.5f` / range `PxU32` 改 double `floor` 想对齐 Debug/Checked cooking | Debug showcase 仍 1117/3180，不是轴计数差 7 顶点。range floor 改体素集合：体积比 0.840→0.758，body4 跌破 0.85。Checked 坐下/夹持 216/625 网格与占用 dump 逐位。不要再改体素 index 舍入冒充 C01c |
| 相交 covering 粒子 Eq.21 沿 packed n 开口帽 `γ\|C0\|` 或 `\|C0\|` | 未跑。坐下 covering 占用 ~10cm，质心要沿 n 抽出到 C=0；`γ*10cm=4.5cm` 帽会留下占用（芯或刚体 leftover 覆盖焊）。`\|C0\|` 帽就是已死 occupancy clip（抽出后 millimetric C0 冻回弹）。夹持 covering 5.5mm 的全额抽出正是 dump。开口帽拆不开 10cm nick 和 5.5mm dump。正交 first-entry `γ·gap` 已跑：夹持 dump 不变。贴面 leftover 对向 `bound=0` 已跑：夹持更差。不要再给 covering 开口加 Eq.21 帽 |
| 色后体积 COM 能量接受（惯性 vs pHat + type-3 活 C，tet 安全整体平移） | 未跑。抽出后活 C≥0，type-3 能量不能再支付 nick 的 COM 惯性：坐下 pHat 只比 x^t 低 ~1.4mm，nick COM ~7mm，把 COM 送回 pHat 只恢复 ~5.6mm 占用（相对压缩留下），`0.5ρC²` 约 6 < 惯性约 9，会收回 nick。与 Layer D COM vs pHat 写回同一切口。夹持上 pHat 朝盒、抽出反向，能量会收回 dump，等于自由颌 skip-all。不要再跑 |
| 加强 VF/Eq.21 替换悬挂 AL，想 skip-all 仍坐下芯 0 | 未跑。skip-all 坐下第 7 帧芯 **4**、y **2.868**：那 4 芯就是缺失的 nick 抽出。逐位合同 leftover-open **2** / 回弹 3.53925 / y **2.86057591** **就是**悬挂占用 AL，换成 VF 不是该轨迹。VF 扩过 `box.margin` 已死在 6.6cm leftover 裙。不要再想用特征井代替 covering 抽出 |
| 地面感知 / nStatic==0 ker 质量进 type-3 Hessian（保持 AL 力，`H += n nᵀ M/h²`） | 已跑 skip-all。坐下基座 nStatic≥1 逐位闲置 leftover-open 2 / y **2.86057591** / 回弹 3.53925 / `minDetF=0.938481927`。夹持更早穿芯：芯 2→**3** 第 82→**12** 帧，第 11 帧 covering 抽出消失（covering 0 leftover 3），角点入体 **2**、质心入体 **1**，`minDetF` 撞 **0.05**，B 第 40 帧仍落地，`boxFinalY` **2.167**。160kg 沿 n 冻住抽出后三角留在芯里；leftover 6×6 仍吃不掉占用。与 nStatic 跳过 AL 同一家（跳过抽出=芯更早），不是漏加惯性力。已撤回。不要再按静盒/地面给占用 n 加重 COM |
| 调用未使用的 `avbdOgcConservativeBound` 当 C01b Eq.21 | 公式是 `gamma*min(vertexFacet, incidentEdge, incidentFacet)`。现网只有一份 `topologyDistance`，另两路填 +inf 等于 `gamma*d`。补第二/第三距离就是已死 incidentFacet / segment-AABB 内部证人。不要把空函数当未蒸馏证书 |
| 修 leftover 6×6 / 去掉对颌 VF 井对 type-3 leftover 的 clip 否决 | 动态 type-3 已在 `bodyA` 行表、`w=-1`、`r∥n` 故 `jAng=0`。粒子先扫 Signorini 把 C 做到 ≥0 后 leftover Newton 与 `clipRigidContactStep` 都闲置。对颌 VF 井否决只在 C 仍为负时才有窗口，那就是已死 nStatic skip-AL（芯 6 第 62 帧）。不要把 leftover「没吃掉占用」当漏 J |
| demo3d `C=(1-α)C0+J_A dqA+J_B dqB` 当 type-3 新残差 | 现网 live RowC 已含刚体 `w=-1`。粒子先扫时盒未动，C 与冻结盒线性化相同。两边同进 lhs 是已死同时 μ / 刚体 Schur。不要再把两刚体流形公式当未蒸馏占用残差 |
| NP 投机 type-3/VF/EE（`x^t` 上 offset + 一步行程，Gu 假行 C>0 只 clip） | 坐下不逐位：leftover-open **3**、回弹第 20 帧 boxY **3.60449**、y **2.86484814**、`minDetF` **0.9162606**。第 0 帧 leftover 悬挂顶点 `minVertexSdf=6.6cm`，夹持第 8 帧接近顶点也是 6.6cm：挡住夹持隧道的查询半径就是坐下 leftover nick 负载。裙上 C>0 clip 改切口不是旁路。未跑夹持。不要再给 Gu 假三角编 type-3，也不要把 VF/EE 扩过 `box.margin` |
| 分离证人 VF 盲区才补内部（vertex/edge d>margin）/ 盒棱中点 vs 三角内部 / 精确盒棱×面内部（OGC incidentFacet）/ 三角边×盒面额外 Eq.21（segment-AABB，仅边内部且盒面内部，不改编占用 C） | 坐下逐位闲置。夹持 dump 逐位：芯 2 第 82 帧 / `minDetF=0.465676427` / `boxFinalY=1.93863368` / 互穿 6。穿刺三角在壳内已有 EE/VF 证人，第 9 帧仍 Gu；第 11 帧 covering hanging **-5.5mm** 抽出不变。精确棱-面内部、中点采样、三角边×盒面额外半空间同一家。补分离 SAT 挡不住占用抽出。不要再给分离证人/Eq.21 加面心/质心/中点/棱中点/GJK/incidentFacet/segment-AABB |
| 相交 type-3 悬挂 sdf>1e-4 则跳过（质心在外的穿刺/leftover 不投票不编 AL） | 坐下覆盖焊 y **2.86806273** / 回弹消失第 20 帧 boxY **2.87441** / `minDetF` **0.969860137** / leftover-open 2 / 芯 0。坐下 DCD spawn 已是 intersecting 6 covering 4：两条悬挂在外的相交三角就是 nick/回弹负载，不是闲置穿刺。不要再按 hanging-out 饿死 leftover/穿刺投票。未跑夹持。覆盖抽出仍是 dump |
| 色后按 tet 弹性 vs pStart 收回 COM / 拒刚体模步进（非接触能 vs 惯性） | 未跑。刚体跟随会把首顶点砸击应变一起平移，energy(p) 相对 pStart 仍高，闸放行 dump。坐下 nick 的 tet 链也是 COM 跟随且能量升高。活应变 vs 刚体模需要 COM-free / 长度闸。不要再跑弹性闸 COM 收回 |
| 分离三角-盒证人补面心 vs 三角 + 质心/中点 SDF（收紧 Eq.21 d，非占用 AL） | 坐下官方 PASS 但不逐位：y **2.86080289** / `minDetF` **0.941134036** / leftover-open 2 / 回弹第 20 帧 boxY **3.53925** 仍在。不是覆盖焊。未跑夹持。顶点/棱证人就是坐下 nick 的 topologyDistance；补内部距离会改基座 Eq.21。延迟 Gu 也拆不开占用抽出。不要再给分离证人加面心/质心/中点/GJK 内部点 |
| AVBD_2 1mm 侵蚀 OBB 才编 triangle-core（`coreInset=min(1e-3, 0.25*min halfExtent)`）再 post-AL 4:1 patch | 本树禁止当求解几何。且 **1mm 准入挡不住 C01b dump**：坐下 leftover 夹心 −0.87mm 不编行，夹持 covering −5.5mm 仍编，悬挂 AL 仍抽出自由颌。坐下 nick 后 covering 也是 millimetric，1mm 会在第 0 帧后丢掉 type-3 = skip-all 回弹芯。AVBD_2 夹心绿是 drive/500kg/零 g，不是 1mm 残差。不要再把 1mm/1cm 芯当 packing 闸或查询 |
| leftover-open 当稳态穿芯拓扑（冻 onset inset / 跳过 leftover pHat / 夹心 don't-increase） | 坐下 leftover-open 只在第 0 帧；第 20 帧起 Gu=0，稳态是 ~2cm 顶点 sdf 的 VF 壳。夹持第 11 帧 leftover 到第 40 帧也 Gu=0，第 60 帧已在同一 2cm 壳，第 82 帧芯是穿壳后的第二次 leftover。onset leftover 冻结抽出 7mm 切口（y 2.868）；跳过 leftover pHat 打飞第一颌。不要再把 leftover-open 当 L-cut 生长窗口 |
| 两体积夹盒厚度行 / 对颌 Host overlap 当第一颌残差 | 第 11 帧 covering dump 是单体积 vs 盒；对颌尚未三角芯。与 other-pair / 对颌 Schur 同一窗口。坐下只有一个动态盒体积，该行不存在也改不了 nick。夹持合同还要 `maxSoftBoundaryCrossings=0`，必须先挡住 dump 而不是第 82 帧补 leftover。不要再给三明治编第三条厚度约束来拆第一颌 |
| 粒子先扫 Signorini 占用 C 既 nick 又夹持（换证人 / 第四个家 / 扫序 / 三明治厚度行） | 抽出方向就是离开盒内部。坐下 nick 与自由颌 dump 是同一残差；刚体吃 C 覆盖焊；应变 COM-free 更早穿芯。设计 §9：保存未证明，结束 C01b，不开 C01c/C02。不要再为夹持捏占用 C 的极性/证人/家 |
| AVBD_2 triangle-core safety CSR（admission-only 完整三角 min-exit 面间隙 don't-worsen，不复制 AL 行） | 本树已跑三碰撞顶点 min-gap don't-worsen 坐下覆盖焊 y **2.86811256** / 应变 0.072；vs DCD `CLin` 是 15cm 包络 y **3.015**。刚体 first-entry/remaining clip 坐下逐位或 y 2.864，夹持 dump 不变。他们的 safety 服务 1mm 准入+drive 夹具，不是 C01b leftover-open 2 nick。不要再当未蒸馏残差跑 |
| 非相交壳井加 n·v_rel / 闭合闸（回弹分离则关、接近则开） | 未跑：这是已死 k>0 壳井的速度 if。夹持第 8→9 帧顶点 sdf 仍 6.6cm 就 Gu 相交，第 11 帧 covering 已在芯内 −5.5mm；壳半径挡不住单步隧道，闭合闸也编不出那条井。不要再给完整三角壳井加接近符号 |
| `clipRigidContactStep` 扩到 heterogeneous 体积-盒（type-3 / VF） | `eAVBD_ROW_SOFT_PAIR` 就是 `HETEROGENEOUS`：现网已裁体积-盒行。粒子先扫后 C≥0 则 leftover clip 闲置。把 millimetric leftover C<0 交给刚体 clip 就是 leftover-to-rigid（回弹下落焊盒）。Dump 是粒子抽出不是盒子钻进颌。不要用「同一套 directional clip」重开占用家切换 |
| pair covering=0 才把 leftover type-3 改夹心权重（悬挂 covering 仍 1/3） | 未再跑：夹持 covering 第 13 帧已 0，闸在 dump 中途打开，等于已死「贴面 leftover 夹多边形重心」（坐下逐位，夹持芯 2→4、互穿 6→0、`minY→0.014`）。不要再给 leftover 查询加 covering 计数闸 |
| other-pair 闸满盒内顶点 Position-AL 额外行（in-primal） | 坐下闲置。夹持 dump 与基线逐位（芯 2 第 82 帧，`verticesInsideFull=0`）。第一颌无对颌；覆盖悬挂顶点在盒外。不要再给 other-pair / 满盒内三角角点加 type-3 AL |
| type-3 对颌粒子 Schur（`ρ/(1+ρ w_other)`，不含刚体 se(3)） | 坐下逐位闲置（单体积）。夹持更差：芯 2→**14** 第 84 帧 A/+X，角点入体 0→**2**，`minDetF` 0.466→**0.426**，`boxFinalY` 1.94→1.92。第 11 帧第一颌 leftover 仍起、covering **-5.5mm**，对颌 type-3 尚未编。与 other-pair 闸同一窗口：dump 是第一颌不是三明治。不要再给对颌 / 两体积岛加 type-3 柔度或 ρ_eff |
| type-3 刚体平移 Schur / 10kg `ρ_eff≈ρ/3.78`（粒子 Hessian，`r∥n` 故 `jAng=0`） | 同时两体 μ（3 顶点 tet 度量 + 刚体平移柔度，跳过顺序 type-3 AL）已跑：坐下覆盖焊 y **2.86797118** / leftover-open **0** / 回弹第 20 帧 boxY **4.26** / `minDetF` **0.687**。与均匀 n Newton（leftover-open 0、回弹 4.21）同一抽出切口，再加 ρ/3.78 刚体份额。不要再给 type-3 粒子端串刚体柔度，也不要再跑同时 μ / compact-row Newton |
| 地面感知 COM-free（ker(tet+ground) 上投影 type-3 J） | 未再跑：坐下有地面则核空=基线恒等；夹持无地面=已死 `w−m/M`（芯更早更差）。不要再按 hasContact/地面行开关 COM-free |
| 粒子色后 type-3 COM 平移交给刚体，闸=静盒/地面 OGC 能量 | 坐下覆盖焊 y **2.86817312** / leftover-open **3** / 回弹消失（第 20 帧 boxY **2.875**）/ `minDetF` 0.972。贴地单侧井静止能量≈0，探针闲置=leftover-to-rigid。不要再给 COM 转移加能量/Eq.21/hasContact 闸 |
| cache 无 k>0 井则跳过粒子 type-3 AL（反极性 leftover-to-rigid） | 已跑闲置：坐下逐位 `2.86057591`；夹持逐位芯 2 第 82 帧 `minDetF=0.465676427`。同盒 VF 井在第一接触就把粒子 AL 留着。Host nStatic 闸已另跑 skip-all（夹持芯 6 第 62 帧、互穿 20、掉穿）。不要再按 k>0 井 / 地面支撑 / 静盒计数切换粒子 vs 刚体 AL |
| 种下占用 AL / 接近 clip-only（cache 第 1 步首次 type-3 才 AL，之后首次 type-3 用 k=1e-8 井） | 坐下闲置逐位 `2.86057591`（种下）。夹持更差：芯 2→**6** 第 82→**29** 帧体积 A，角点入体 0→**1**，互穿 6→0，`minDetF` 0.466→**0.557**，`boxFinalY` 1.94→**2.32**。第 12 帧 covering hanging 只有 **-0.24mm**（基线 −5.5mm），clip-only 不抽出接近 covering，芯更早。设计 7.3 初态分裂仍是 skip-all 在自由颌上。pair-state 闸。不要再按步数/种下/接近切换 type-3 AL vs clip |
| type-3 入射粒子 → 刚体 leftover → 内部粒子（扫内 GS 重排） | 坐下覆盖焊 y **2.86809182** / leftover-open 2 / 回弹消失（第 20 帧 boxY **2.875**）/ `minDetF` **0.972**。入射 3×3 之后 C 仍大，6×6 先抬 10kg 盒，tet/地面来不及形成 nick。不是新残差，是 leftover-to-rigid 的扫序。未跑夹持。不要再按 type-3 入射 / 接触图把刚体插进粒子色中间 |
| 夹持第 82 帧穿芯当 Host 漏对 / 动态盒槽截断 | `prepareDeformableVolumeHostOverlaps` 按 `eOVERLAP` 填盒；第 82 帧 leftover type-3 仍在编。C00 芯 6 第 51 帧，悬挂 AL 后芯 2 第 82 帧、角点 0。漏对不是根因；dump 煎饼才是 |
| AVBD_2 `scene-volume-ogc-sandwich` 当 C01b 求解方程（500kg 盒、场景重力 0、每步写回颌速度 36 帧、1mm 芯、post-AL 4:1） | 绿测夹心是 snippet 夹具不是 occupancy 残差。`updateSceneCpuOgcSandwichPressureDrive` 在 `simulate` 前重写两颌速度；注释写明没有该 drive 就只有两帧初速接触、分开后能假绿。500kg 把夹具变成压缩试验而不是轻抛体回弹。C01b `rigid-squeeze` 是 10kg、重力 −9.81、只给初速的自由颌。1mm/4:1/500kg/零 g/drive 都不能搬进求解器或改 snippet。悬挂 AL 打下自由颌，正是他们用 drive 换掉的夹具 |
| 占用 type-3 线冲量找第四个家（漏装刚体 J / 夹面积缩放 / 全网格同时 μ / COM 钉 pHat / AVBD_2 材料 Jacobian 替换） | 动态 type-3 已有 `w=-1` 刚体 support；粒子先扫把 C 做到 ≥0 后 leftover Signorini 闲置，不是漏 J。夹面积缩放 C 对 GS `u=-C/w` 恒等。全网格同时 μ 比已死 3 顶点 μ 更抬 10kg 盒。COM 钉 `pHat` 跟坐下地面抢位。`applyPositionAlJacobianReplacement` 是刚体 NCP。线冲量只有粒子 / 刚体 / 应变三个去处 |
| type-3 粒子端接设计 4.4 全支持有效质量（盒进 `J M⁻¹ Jᵀ`） | 坐下 nick 需要粒子 3×3 满 ρ（盒运动学）。接 4.4 就是已死刚体平移 Schur / 同时 μ（y 2.868 leftover-open 0）。不要再以「设计有效质量」重跑 ρ_eff |
| 设计 4.1 表面间隙 `g=n·(yA−yB)` 当 type-3 新残差（悬挂质心 vs 面心） | 就是当前占用 C。覆盖盲区证人在三角内部，表面间隙=占用抽出。夹心/顶点 `yA` 是已死 skip-all 或覆盖焊。不要再把 §4.1 公式当未蒸馏残差 |
| 相交 type-3 DCD 把 hanging C 偏置到夹多边形质心（J 仍 1/3） | 坐下 15cm 包络 y **3.0125072** / 应变 0.067 / 顶点 sdf 5cm。夹心 C 饿死 hanging 占用，盒子交给 VF 壳。与改夹心权重（y 2.868）同类查询，只是写在 offset 上。不要再给 hanging C 叠夹心/Chebyshev DCD 偏置 |
| type-3 全盒夹多边形顶点 Position-AL（barycentric packed n `k=0` 权 1，替换悬挂 1/3） | 坐下覆盖焊 y **2.86782408** / leftover-open **0** / 回弹 3.57 / `minDetF` 0.901。内部补丁点抽出切口，与 compact 夹心质心同一压平。不要再把 covering 换成夹多边形顶点/边点，无论一条还是多条 |
| AVBD_2 compact 夹心 barycentric + 夹心 SDF n 当 k=0 AL（clipSdf<-1e-5 准入） | 坐下覆盖焊 y **2.86810994** / leftover-open 0 / 顶点 sdf 7cm。压平 7mm 切口。k=1e5 同证人第 3 帧穿芯。不要再把 covering type-3 换成夹心查询，无论 packed/SDF/正交 n、k=0/1e5 |
| 动态 covering type-3 等式 Position-AL（DCD `C0<=0` 去 UNILATERAL，leftover-open 仍 Signorini） | 坐下第 2 帧芯 **5**，y **2.86751437**，`minDetF` 0.797。抽出后焊 C=0 是覆盖焊；回弹仍穿芯。Signorini 闲置才是浮空颌 dump。不要再给 covering type-3 加 sticky / 双边 / 等式互补 |
| type-3 Position-AL 在 C>=0 时丢掉 leftover λ（primal/dual 对齐能量 `[C]₋`，刚体 Hessian 同步关） | 坐下覆盖焊 y **2.86804676** / leftover-open **3** / 回弹消失第 20 帧 boxY **2.87489** / `minDetF` **0.967723906** / 应变 0.068。millimetric leftover λ 是坐下 nick/回弹持力，不是夹持多余抽出。未跑夹持。不要再按 C>0 / 能量梯度 / λC=0 剥 occupancy 粘附 |
| 非相交三角悬挂质心 k>0 井（顶点在壳外，C01a 内部盲区，非 k=0 AL） | 坐下覆盖焊 y **2.86853385** / leftover-open 2 / 回弹消失第 20 帧 boxY **2.87461** / `minDetF` **0.969860137** / 应变 0.069。与 k=0 offset-shell 悬挂 AL（y 2.858）同一回弹焊。未跑夹持。不要再给 type-3 外围加完整三角壳井（含顶点在壳外 / 动态盒闸） |
| 体积 COM 沿 n 行程超过 covering occupancy 则整体平移收回 | 坐下掉穿 y **0.35** / `minDetF` 0.778。第 0 帧仍 2.88987；抽出后 millimetric `C0` 冻 COM 回弹。与 occupancy clip 同类，只是作用在 COM。夹持 5.5mm 与坐下残余 0.12mm 仍是禁止长度闸。不要再按 `|C0|` 帽体积公共平移 |
| type-3 耦合均匀 n Newton（Hessian `ρ w` 行和，`u=-C` 而非 GS `u=-C/w`） | 坐下覆盖焊 y **2.86792207** / leftover-open **0** / 回弹第 20 帧 boxY **4.21** / `minDetF` 0.734 / 应变 0.322。GS 3x 首顶点砸击就是坐下 nick。不要再把悬挂 1/3 改成均匀质心步 |
| type-3 峰值 episode occupancy clip（pair 热启动 `max(prev,−hanging)`，covering 消失清零） | 坐下逐位闲置（spawn 10cm）。夹持更差：首次 leftover 11→**10** covering 4→0，芯 2→**4** 第 **66** 帧，角点入体 1，`minY→0`，`minDetF` 0.356。onset covering 是 graze，peak 从 leftover 量级起，等于接触开始处的 live-`C0` 冻。不要再给 covering 加 episode/peak/`CLin` 行程帽 |
| type-3 covering occupancy clip（从 `pStart` 沿 n 行程 ≤ −min covering `C0`） | 坐下覆盖焊 y **2.86820054** / 回弹消失（第 20 帧 boxY 2.874）/ `minDetF` 0.970 / 应变 0.069。第 0 帧仍 2.88987；抽出后 millimetric `C0` 冻切口。与等式焊同类。不要再按 `|C0|` 帽粒子行程 |
| Layer D 粒子 type-3 沿 n 的 BDF 改用 `pHat`（pose 仍抽出） | 坐下掉穿 y **0.50** / `minDetF` 0.462 / 应变 0.536。frame0 切口仍在，回弹弱，第 40–80 帧盒子压穿体积。covering 抽出写成粒子速度是坐下托盒；不能靠写回拆开 stacked AL 与 nick。不要再从粒子 BDF 扣 type-3 extract |
| Layer D 体积 COM 写回：去掉超出 `pHat` 且与 `pHat` 同向的 COM（相对应变保留） | 坐下 FAIL y **0.34994024** / 芯 2 第 42 帧 / 回弹 3.54→**3.16** / `minDetF` 0.806。坐下 nick 的 COM 也超过惯性 `pHat`；夹持 dump 发射就是这份 nick 速度。不要再按 COM vs `pHat` 剥写回 |
| 每盒一条最深悬挂质心 type-3（其余相交三角不编） | 坐下第 5 帧芯 **4**，y **2.86554384**，回弹消失。skip-all 同类：坐下回弹芯 0 需要整组 covering 悬挂 AL。夹持第 11 帧 covering hanging 只有 **-5.5mm**，dump 是多行叠抽出写成速度，不是 16cm 占用。不要再把 covering 压成一条 |
| type-3 查询改 packed 面后方最深顶点（权 1，覆盖不再悬挂 1/3） | 坐下第 0 帧芯 **3**，y **2.868**，夹心 **-4.6mm**。覆盖三角顶点在盒外，顶点 C>0 闲置。悬挂 1/3 才是坐下芯 0；与侧切最深顶点（覆盖仍 1/3）不是同一条。不要再把 covering 从悬挂质心换成顶点 |
| 动态 type-3 clip-only（保留 AvbdRow clip，跳过 Position-AL 能量/dual） | 坐下第 0 帧芯 **6**，y **2.868**，夹心 **-12.5mm**。Don't-close clip 不能抽出第 0 帧重叠；skip-all 第 7 帧芯 4 是同一缺口。坐下芯 0 需要几何 AL 抽出。不要再把 type-3 降成只 clip |
| 跳过全部 Volume 相交 type-3 质心 Position-AL（只留 VF/EE/reverse/Eq.21） | 坐下第 7 帧芯 **4**，y **2.868**，`minDetF` 0.927。VF 过不了回弹穿芯；type-3 AL 对坐下芯 0 是负载。夹心 coreSdf 闸的「坐下逐位」仍编贴面 type-3。不要再饿死 hanging centroid AL 来拆开坐下芯和浮空颌 |
| type-3 `C=n·centroid−n·x_box` 粒子抽出 vs 刚体吃 COM（ρ_eff / 只刚体 leftover / 平移两终点 / COM-free J） | 坐下 7mm nick **就是** covering 沿 packed n 的体积 COM 抽出。COM-free 坐下官方 PASS y **2.86815619** / covering 4→0；夹持更差：首次 **21** 芯 **4**、B 第 40 帧仍落地、互穿 24、y **0.923**。入射 1/3 形变仍打下浮空颌。粒子满 ρ 保 nick、打浮空颌；刚体吃 COM 抽 nick（y 2.868）或抬到 15cm 包络。全图 COM-free clip 坐下炸。不是长度闸能拆的：1mm/1cm 禁止。不要再给这条 `C` 做载荷分裂 / 去 COM / 粒子色写刚体余量 / 把 type-3 扩到非支持顶点再 clip |
| 全岛 Jacobi + 1.8cm 位移帽 | 冲击速度被丢掉；`responseBodies=1` 假绿 |
| 全局常数 ρ 地板 + Jacobi / skip-α | `stack-settle` 不睡、~8 m/s。per-row `2/(w dt²)` 法向地板不是这条 |
| 纯平动 `2M/h²` 地板 | runaway |
| pose-derived `vn` 单趟逐行速度钳 | 密集堆不收敛，能量更差 |
| 全员接触写回 `v-` / 接触图泛洪 | 倒塌塔整岛当冲击，不睡；抹掉 joint/soft owner |
| 每帧非弹性 `vn→0` | 粘死侧向重叠，`sleep-wake` 不睡 |
| 把 AL `Δθ` 当冲击 ω | 落地拧转、顶死角速钳 |
| `C0>=0` 整段跳过反弹 | smoke `e*v_in` 峰值被压死 |
| 深穿透 skip-α（FRESH 一次拉回） | 隧道变冲量，能量数十倍 |
| 切向共用长大后的法向 ρ | 落地顶死 Coulomb，自旋 |
| 流索引热启动 λ（无几何闸门） | 冲击 λ 感染邻居 |
| 按 `|Δv|` 在 BDF 与 `v-` 之间切换 | 软弹簧时冻堆；修好 primal 后仍漏冲击 |
| 叶→根 / 贴地多解一次 | 禁止的稳定性扫序，不是着色 GS |
| 为堆叠松 2cm 穿透帽 | 假绿 |
| 测死 geodesic 世界 log 当 artic atan2 的 1D Δθ | 刚体 spherical hang 要 applyDelta 图；剪刀 inbound 是 swing-twist。两套 C 不能共用一只 geodesic `q q0⁻¹` |
| 对所有 solverPrep 行做 Eq.19 `λ*=αγ` | 剪刀升的 D6 焊接是硬锁；衰减 λ 等于每步忘掉持力。Eq.19 只给 drive/spring |
| 独立 `atan2(rel.i, rel.w)` 当 artic 角 C | FREE twist 过 ±π 时 w→0，LOCKED swing 的 C 炸到 ±π |
| artic swing 用相继框架 J（`FA.q·twist`） | 持力 λ 被拧进 FREE twist，第 4–5 帧树散 |
| artic swing 用 `FA.y·FB.x` 铰轴对齐当 C | 剪刀 rest 位姿上 C 不为 0，第 1 帧被拉开 |
| 只摘 artic 的 `r·safetyRelax` / 0.08 rad 帽，却保留会随 FREE twist 旋转的 swing 坐标 | warm multiplier 与行坐标不一致，满 Newton 会把 D6/swing 拉开。当前已改为稳定世界垂直基并删除该帽；不能恢复这条旧组合 |
| 用 `hasContact` 决定谁戴 artic 步长帽 | 无接触的 link 满 Newton 同样炸。帽的问题是线性化，不是接触拓扑 |
| artic 热启动独立 `pHat` 或 `pHat+qHat`（即使几何 C + GS 帽都在） | `scissor-unloaded` 地面接触剪树：线性 `pHat` 第 2 帧 `maxAng=20`，全 `pHat+qHat` 第 36 帧 `loop_anchor`。公共平移之后的**相对**线 `pHat` 不是这条 |
| artic 公共平移后全员 `pHat=p` | 关节速度被丢掉，FIX 上面板每步从静止再加速，比 Featherstone 硬。根仍 `pHat=p`；其余 link 用 `(v_i−v_root−ω_root×r) dt` |
| artic 公共平移用全树质量加权 `pHat` | 臂的关节速度抬飞基座 |
| artic 公共平移只加 `g dt²` | 离地后 BDF 速度永远是 `g dt≈0.16 m/s`，台子悬在空中。刚体公共步必须含根 link 的向下 `v dt` |
| artic 公共平移 `min(0, (pHat-p)·up)` 且不改 `pHat` | 净步朝上时连 `g dt²` 一起丢掉，各 link 的 `pHat` 仍带着无约束步，GS 6×6 把整树送回去。必须始终加 `g dt²`，并在 3×3 之后 `pHat=p` |
| artic 公共 3×3 用树 COM 当惯性残差（含 GS 后 commit） | 伸臂会抬 COM，3×3 把整树往下拉，基座进地。公共平移的线性惯性钉在自由基座 |
| artic 公共 6×6 吃 dual λ | AL λ 把整架抬飞（`base_pose` y→33）。刚体公共接触 6×6 只用 primal C，不用 row λ |
| 照搬 AVBD_2 的 artic/软体/关节独立 pass | 本树工作是 WebPhysics 式统一 backend。第二条积分、每 sweep 全量 DCD、公共平移 sidecar 会与统一 `AvbdRow` 互斥，矩阵可能假绿、观感必错 |
| artic 公共平移 3×3 + 沿 up 抬最深间隙 | 斜基座只有低角接触，整树被抬到低角出地，高角仍在空中，看起来僵硬浮空。接触公共步必须带绕根的刚体转动 |
| artic 根速度无摩擦 / 含水平分量的 3×3 | 法向 C 只有 `O(g dt²)`，Coulomb 刹不住水平 `v dt`，`maxAbsPosition>50` 滑走。公共 Δp 不含水平 |

| 异构材料把 offset 壳写成 `vn→0`（`C≤0` 或芯重叠 Signorini） | Position-OGC 已是法向势。再在同一行上做速度 Signorini 会在壳内/芯重叠处抹掉弹性恢复，软体碰撞后粘死。Coulomb 仍用 `\|λ\|dt` |
| 刚–软 pair-wide 把盒的整段壳层面都免掉 Eq.21 | 对侧未编入 row 的三角形失去证书，`rigid-squeeze` tet 翻转（`minDetF<0`）。零间隙豁免只属于带 triangle-core 行的那张面；对面分离特征继续出界 |
| 从壳内小正间隙给刚体 6×6 编世界系各向同性 Eq.21 域 | 刚体 trust region 钉在 DCD 锚点。壳内毫米级间隙冻住 10 kg 盒子（5-tet 轻盒假绿）。整段删掉刚体域会穿芯。粒子 3×3 仍对未拥有的面出界；刚体球只从壳外 triangle 出界 |
| 芯上把整段 6×6 contactFraction 缩成 0 | 任一侧向/对侧行内向就把盒子钉成运动学夹具，反作用只能进软体。正确是对该行法向投影；从外侧接近仍 bisection。整段取消 freeze 会穿芯 |
| 异构 primal 刚体先于粒子扫一遍（即使保留 freeze） | 重力 6×6 在 3×3 发布 OGC 之前穿透。粒子先、刚体后是已验证的耦合扫序 |
| 刚体 warmstart 只靠各向同性 SE(3) 球、不裁 pairwise 行 | 粒子 inertial guess 有相对 directional clip。壳外球 ~cm 时重力在 primal 前走进网格。6×6 与 3×3 同一套相对按行投影 |
| 动态对世界系各向同性 Eq.21 球 | 球同时限制回弹和切向。压缩/钩住后 bound 变成毫米，冻到下次 epoch 才放行，观感是粘住再生硬修正。`γd+\|pHat−p\|` 膨胀只在共落时掩盖，落地后仍冻。证书是相对半空间 `n·(Δx_i−Δx_j)≥−γd` |
| 刚体半空间把三角形 `pHat` 当对端位移 | 粒子先扫后网格往往没走到 `pHat`。盒子仍被允许按网格惯性目标下落，压进软体，直到下次 epoch 生硬拉回。对端是已提交形心，共落时粒子 warmstart 已经带走 `g dt²` |
| 半空间投影当成 `ogcExceeded` 并每 sweep 重编接触行 | 接触时 bound=0，每次弹性 Newton 都会打到平面。每 sweep `rebuildSoftRigidContacts` 使最后一次 iterate 成为 FRESH OGC 拍到两块刚体上，正好被发布成一两帧错网格。证书仍可刷新；feature 行留在步初 DCD |
| 证书首次耗尽时 FRESH 重编一次 hetero 行 | 那一次重编仍在挤扁姿态上发生，就是用户看到的一两帧拍扁；随后整步冻在这份坏流形上，`rigid-on-soft` 盒子掉穿（y→0.93） |
| 步中把当前 `partnerAnchor` 写进步初 DCD 半空间 | 形变下垂让 bound 变紧就会换锚。共落 `g dt²` 被当成闭合，颌面走进 4 cm 壳，OGC 势拖住上截。`free-fall-triplet` 关阻尼所以假绿。步中只清 exceeded，不改 Volume 证书 |
| 芯上把对端映回 DCD 刚体位姿 | 已穿透顶点被映射回步初，`rigid-on-soft` tet 翻转（`minDetF<0`） |
| 粒子 Eq.21 对端改成刚体已提交位姿 | 共落 `free-fall-triplet` 相对漂移 `0.038`。对端仍是 DCD 局部的 `pHat` |
| 相对惯性吃不掉当前间隙就 skip 该面对的各向同性球 | 共落能过 `free-fall-triplet`，但挤压接近 `|rel|≈v dt ≪ 5 cm`，壳外证书被丢掉，`rigid-squeeze` 穿芯。闭合对仍要出界 |
| 壳内已有 row 的碰撞顶点仍编各向同性毫米球 | 行拥有法向；球还焊切向。未编入 row 的壳内面仍出界 |
| 粒子整段 `contactFraction` 缩成 0 | 盒棱/角有两个法向，切向对其中一侧是内向，标量 min-alpha 把 3×3 焊死。正确是相对 directional：静态对端惯性为 0，按行投影 |
| 粒子 3×3 世界系 CCD 到冻住对端的芯 | 按行投影若不计入对端剩余惯性，会把 5 cm 间隙 CCD 进 4 cm 壳，k=1e5 把 10 kg 盒子弹飞。证书是相对 gap = 当前 C + 对端剩余 `pHat-p` |
| 芯重叠时把外向 Newton 裁回芯表面 | 接触面焊在刚体上，整步不能离开。下方软体对侧继续落，形变过大；回弹要等下一帧 DCD 才松，观感粘滞。外向是穿过 offset 井的恢复，截断在 `d=r`。无界满 Newton 会把坐下的盒子打飞；惯性+OGC 能量线搜索若拒绝全部步长会把盒子放进 `pHat` 掉穿 |
| 粒子 3×3 用满 `k` 解 pairwise OGC（刚体当运动学） | 二次井的粒子局部极小是接触点走到 `d=r`。颌/地面夹持时 +n 指向体积内部，一次 GS 就把上下表面推进网格；C 到沿后刚体零力，NH `(J-α)²` 有界，J 限到 0.05，体积塌成尖刺一摊。正确是串联刚体柔度。不要焊回 `d=0`，不要为此拧 `k`/`r` |
| 刚体 6×6 对 hetero OGC 用满 `k`（粒子当运动学） | 粒子串联之后残余井仍在。角点一行的线性化 `r×n` 一次 Newton 把接触点送向 `d=r`，盒子在一帧里拧到错误姿态，下方体积的回弹被这份错位姿吃掉。dual 仍发布真实势。不要加 `Δθ` 帽 |
| 在 particle primal 的相对 OGC 投影里持续使用刚体 `pHat` | `pHat` 只属于 DCD/惯性目标 admission；全员 warmstart 已提交后，刚体的 live GS 位姿才是 primal 对端。逐轮重放旧的闭合预测会在刚体已被推开后继续压住软体，形成无物理阻尼的回弹平台。不要把 warmstart 与 primal 合并成同一个 partner-delta evaluator |
| 把粒子 Armijo 能量也换成串联后的 `k_eff` | 近似系数被当成物理势，局部平衡点改变。showcase 下方软体 360 帧仍有约 22% 边应变，`rigid-squeeze` 穿透和恢复均变差；线搜索 / dual 仍用真实 `k`。 |
| 按 `selfLocalPoint` 合并夹持两侧的 reverse-family 半空间 | 每个角点只保留更近的一面，对面证书被丢掉，角点重新入体 |
| 壳内未相交三角/芯再编满 `k` 的 type-3 `AvbdRow` | 与 vertex/edge 族重复吃井，软边界互穿、角点再入体；clip 应走 OGC 特征半空间而不是第二份能量 |
| 壳内未相交三角/芯编 k=0 的 type-3 行只为 clip | 全壳顺序 CCD：夹持下角点再入体、芯命中回到 6 |
| 每盒一条最近 approaching type-3（k=0, margin=0） | 坐下合同仍绿，但夹持变差：芯命中 4→9、角点入体 0→2。单证人仍走 `clipRigidContactStep` 顺序 CCD，挡不住其余棱切面 |
| 12 条盒棱 reverse-family 满 `k` 行 | 与 vertex/EE 重复吃井。`rigid-on-soft` 盒子掉到 y=0.50，`rigid-squeeze` `minDetF` 撞 0.05 地板 |
| 三角-盒 DCD 证人加 face/face（三角最近点投到盒面） | 更紧的 `γd` 把夹持信任域收死，角点再入体、`minY→0`、应变变差。证人仍走 VF/EE |
| 刚体 Eq.21 在特征点做 se(3) 最小修正 `Δθ += (r×n)s` | 与满 `k` 的 `r×n` Newton 同类：一帧把盒子拧进体积。`rigid-on-soft` 第 1 帧穿芯、`boxFinalY≈1.63`。超界仍沿 n 平移质心 |
| 刚体半空间只改合并键为 `(n, r)`（仍按法向平移质心、保留分三角平面） | 坐下合同仍死：`rigid-on-soft` `boxFinalY=0.35`、第 5 帧穿芯；`rigid-squeeze` 角点入体回到 6。按法向合并是负载，不是疏漏 |
| 开棱 Eq.21 半空间 + 按 `(n,r)` 合并 + 去掉分三角平面 | 组合拳；孤立 `(n, r)` 已单独致死，不必再拆 |
| 刚体 Eq.21 半空间对整段 Newton 步做 SE(3) 二分 | 夹持时 8 张面同时限制闭合，整步被缩成近零，体积被挤扁（`minDetF≈0.12`）。信任域仍沿 n 平移质心；穿芯 clip 属于 `clipRigidContactStep` 的 row |
| 相交三角/芯编 bound=0 Eq.21 于盒棱×三角击中点（COM 平移、按法向合并） | 坐下仍绿，但夹持两颌把盒子焊死，形变力进软体：`minDetF≈0.058`、角点入体 0→2、芯命中 4→6。诊断仍是顶点在盒外、部分三角无开棱击中（面穿/软棱穿面）。不要把相交态的 `bound=0` 半空间当 clip |
| type-3 刚体端点从最小退出面心改到切割棱/面穿点（三角内三行仍共享） | 坐下仍绿。夹持因 `r×n` 力矩把盒子拧过其余三角：芯命中 4→12、角点入体 0→3、`boxFinalY≈1.58`。面心 `r∥n` 对 type-3 能量是负载，不是疏漏 |
| 相交 type-3 的 OGC 井半径从 `0.02*margin` 改成 VF/EE 的 `box.margin` | 坐下仍绿但应变变差。夹持把井吃成对拉：`minDetF` 撞 0.05 地板、芯 4→15、角点入体 0→4。AVBD_2 的 `0.02*margin` 是 SAT 退出间隙，不能当成 offset 井去加力 |
| 相交 type-3 三顶点各编一条 Position-AL（`contactRadius=0`，rest 在最小退出面） | 坐下仍绿（`minDetF≈0.84`，0 芯）。夹持把双颌 3×AL 拧成过冲：芯 4→11、角点入体 0→3、`minDetF` 0.80→0.45、首次命中 12→11。AVBD_2 的 compact AL 是一条力行，不是三条 Hessian |
| 相交 type-3 一条质心 Position-AL（三顶点 weight 1/3） | 坐下更好（`minDetF≈0.96`，0 芯）。夹持时 C 跟质心：第 34 帧质心在盒外、一角点进芯 36mm，AL 不工作。芯 4→14、角点入体 0→2、`minDetF≈0.83`。质心能量必须配粒子端 min-gap clip |
| 相交 type-3 一条最深顶点 Position-AL | 坐下第 0 帧芯命中 3（贴面切口被当成 SAT 深点推歪）。能量必须走质心，不能把最深顶点当 AL 未知量 |
| 相交 type-3 质心 Position-AL + 刚体/粒子都按三顶点 min-gap clip | 坐下仍绿。夹持芯命中 4→3，但双颌把盒子焊在最小退出面上：`boxFinalY` 1.91→0.72、角点入体 0→1、`minDetF` 0.80→0.39。刚体 6×6 不得对 min-vertex 做 bound=0；AVBD_2 的 triangle-core safety 在粒子端 |
| 相交 type-3 质心 Position-AL + 仅粒子 min-gap clip | 坐下盒子掉穿（`boxFinalY=0.35`）：粒子被焊在面上，刚体质心 C 为正不持力。AVBD_2 safety 不能单独焊软端 |
| 相交 type-3 一条 live-min Position-AL（能量取最深顶点，clip 仍用质心） | 坐下仍绿但 `minDetF` 0.95→0.75。夹持推迟到第 38 帧后一角点进芯 59mm：芯 4→10、角点入体 0→2、边界互穿 12。SAT 行在相交前不存在，live min 挡不住接近步的面穿 |
| 相交 type-3 对 r∥n 面心行取消 k_eff 串联（满 k 势） | 坐下仍绿。夹持满 k 三顶点把 16mm SAT 一次吃完：芯 4→11、角点入体 0→2、`minDetF` 0.80→0.54。k_eff 是 mobility 合同；满 k 与三顶点 AL 同类过冲 |
| Volume 相交 type-3 三顶点 Position-AL + NP α 续延（保留 SAT 半径，`k=0`） | 坐下第 0 帧芯命中 6。α 只缩小第一步，挡不住贴面切口被当成 SAT 面；3×AL Hessian 仍推歪。无 α 且 `contactRadius=0` 的三顶点 AL 是另一条死路 |
| Volume 每个 soft/box patch 一条 SAT 增量 Position-AL（C0=−patchExit，质心 J，r∥n，α） | 坐下第 0 帧芯命中 6。侧向切口的 SAT 退出很大，C0 不是质心间隙，AL 对侧向切口也出力，盒子被推进芯。质心 AL 坐下绿是因为侧向 C>0 不工作 |
| Volume 相交 type-3 一条质心 Position-AL + NP α（`k=0`，保留 SAT clip 半径） | 坐下第 0 帧芯命中 6。α 把第一步削到 ~1% C，重力先把盒子推进芯。无 α 的质心 AL 坐下绿；α 不能叠在这条能量上 |
| 质心 Position-AL + 刚体 clip 改三顶点 min 面间隙并对 AL 行做“不许变差”se(3) 二分 | 坐下仍绿但 `minDetF` 0.94→0.78。夹持焊扁：`minDetF` 撞 0.05 地板、芯 2→3、角点入体 0→1、首次命中 82→13、`boxFinalY` 1.94→1.24。面平面 `r∥n` 的转动不是 min-gap 二分能修的；对颌会把整步缩成焊 |
| 质心 Position-AL 的 C/J 改活盒面法向（`n=R n_local`，`jAng=n×(c-p)`） | 坐下仍绿但 `minDetF` 0.94→0.71。夹持更差：芯 2→4、首次命中 82→32、角点入体 0→1、边界互穿 6→24。`n×(c-p)` 与面心改切割点同类拧盒；type-3 能量必须保持冻结 DCD n 加面心 `r∥n` |
| 刚体 clip 对已相交 SAT type-3 跳过内向投影（保留接近分数 clip） | 坐下仍绿。夹持推迟到第 39 帧后 31mm 穿入：芯 4→14、角点入体 0→5、`minDetF` 0.80→0.32、`boxFinalY` 1.91→1.52。对颌内向投影挡的是下沉，不是 SAT 恢复 |
| 质心 Position-AL + 刚体 clip 对完整三角做 live SAT 面间隙不许变差（全步 se(3)） | 坐下仍绿（`minDetF=0.970`，0 芯）。夹持提前穿芯：首次命中 82→28，芯 2→11，角点入体 0→3，`boxFinalY` 1.94→1.65。几何盒 AABB 在 grazed +Y 就触发；顺序 GS clip 不是 AVBD_2 的 pair post-AL projector |
| 同上但去掉第一次 AABB 重叠的 approaching CCD，只在已重叠时不许变差 | 坐下数字与上条相同（SAT 未开火）。夹持仍第 28 帧，芯 3，角点 1，`minDetF` 0.37，`minY` 0.53。对颌 live SAT 仍改轨迹 |
| 同上但只裁 `dth`、保留 AL 平移 | 坐下仍绿。夹持更差：第 20 帧芯 6、角点 3、`minDetF` 0.11、`minY` 0.007。转动证书不能靠顺序 SAT 二分 |
| 质心 Position-AL + 粒子 3×3 对 type-3 完整三角 live SAT 不许变差（AVBD_2 companion CSR） | 坐下仍 0 芯但形变退步：`minDetF` 0.970→0.724，边应变 0.069→0.335。type-3 在坐下切口也存在，粒子 SAT 把网格焊在 grazed AABB 上。未跑夹持即撤回 |
| 质心 Position-AL + sweep 后沿 live SAT min-exit 做法向 COM 推出（AVBD_2 post-AL recovery） | 无闸坐下应变 0.09→0.32、`minDetF` 0.94→0.79。仅当两体积都有 type-3 时推出：坐下精确复原，夹持轨迹不变（第 82 帧对侧无 type-3，recovery 未开火）。compact `C<0` 闸与无闸坐下数字相同——坐下 type-3 已在持力。COM 推出不是转动面穿的证书 |
| 质心 Position-AL + 耦合 SAT 残差 `compactC-satGap` 当 post-AL projector | 每 Newton：坐下略好但夹持第 53 帧 11cm 无限平面残差把盒子打出夹层（`boxFinalY` 1.94→0.67）。芯上 Gu + `C>0` 闸：坐下精确，夹持第 82 帧不开火。去掉 Gu 后整步 6 sweep：坐下应变 0.09→0.28、`minDetF` 0.94→0.82。坐下 type-3 的无限平面 SAT 不是质心 C，残差不闲置。AVBD_2 绿路径是共享最小退出面上的整三角顶点 patch，不是质心残差 |
| 质心 Position-AL + post-AL 共享最小退出面整三角顶点 patch | 全盒 Gu：坐下应变 0.09→0.28。仅芯上 Gu 进 patch：坐下精确复原，夹持推迟到第 107 帧后穿芯（芯 11、角点 3、`|v|≈4.8`、`minDetF` 0.36）。无 other-pair clip 的 live n 平移会把盒子打进对颌。不要把 AVBD_2 的 pair-state local manifold 压成无对端闸的 COM/顶点平移 |
| 质心 Position-AL + 芯上 Gu + other-pair 刚体 clip 的最深顶点 patch | 夹持可绿（芯 0、角点 0、边界互穿 0），坐下精确。`free-fall-triplet` 落地第 139 帧开火：芯 2、角点 2、`minDetF` 撞 0.05、相对漂移 0.70（门限 0.02）。同一拓扑（双体积+盒）上 post-AL 粒子投影无法区分准静态夹持与共落落地。C01b 停船含共落 canary，不能留夹持假绿 |
| 质心 Position-AL 能量保持面心 r∥n，仅 clip 把刚体杠杆改到三角质心在冻结面上的面内投影 | 坐下仍绿且更好（`minDetF` 0.94→0.97）。夹持更差：首次命中 82→50，芯 2→6，角点 0→2，`minDetF` 0.47→0.16，`minY` 0.02。clip 的 `jAng=r×n` 与能量改切割点同类拧盒；信任域也不得给 type-3 加面内力矩 |
| 相交 type-3 编相对 Eq.21（冻结 SAT min-exit n，面内杠杆，正 bound=`max(1e-5,γ·SAT间隙)`，COM 平移） | 坐下精确复原。夹持更差：首次命中 82→73，芯 2→4，角点 0→2，`minDetF` 撞 0.05，`|ω|≈1.35`。正 bound 仍把对颌焊进软体；面内杠杆的 COM 补偿会泵转动。不要把相交态 Eq.21 当 clip，即使 bound>0 |
| 相交 type-3 冻结 n 最小顶点当 AlC（J 仍质心 r∥n，clip 同步用 AlC） | 坐下第 2 帧穿芯 10，盒子飞到 `boxFinalY≈9.34`，`minDetF` 撞 0.05，应变 7.4。冻结 n 的最小顶点仍是无限平面：切口另一侧顶点在面半空间里很深，AL 把盒子打飞。与 live-min / SAT 残差同类，不能当质心 C 的替代 |
| 对着 snippet 1cm 侵蚀芯做 Gu CCD / SAT 深度二分（全部边界三角或 packed type-3，带/不带顶点在满盒外闸） | 规格禁止 CCD 补漏。坐下无闸会浮（`boxFinalY` 2.86→3.01）；顶点闸则夹持 dump 与基线逐位相同，二分未改到转动零空间。OGC 开着还穿是证书没覆盖完整三角，不是再扫一套 oracle 几何 |
| packed type-3 面穿（Gu∩顶点在满盒外）首次进入后再对编译面 SAT 深度不许变差 | 坐下更好（`minDetF` 0.94→0.97）。夹持更差：首次命中 82→35，芯 2→11，角点 0→4，`minDetF` 撞 0.05，`|ω|≈0.86`。已面穿的顺序 SAT 与 live SAT clip 同类拧盒；只裁首次进入才是 OGC 非法域 admission |
| packed type-3 面穿首次进入（无 SAT 不许变差） | 夹持顶面覆盖被当成面穿，整步 se(3) 挡住压缩：首次命中 82→34，芯 2→14。颌面 type-3 的面穿是持力覆盖，不是侧向转动漏芯 |
| covering-gated 面穿首次进入（质心投影在证书面矩形上则跳过） | 坐下近精确。夹持仍更差：首次命中 82→63，芯 2，角点 1，`minDetF≈0.25`，`|ω|≈0.86`，exitFace=+Z。离面侧切的整步 se(3) 仍拧夹持；覆盖闸挡得住颌面，挡不住转动零空间 |
| 面穿 AlC 改三角∩盒形心（J 仍 r∥n） | 坐下形变退步：`minDetF` 0.94→0.77，应变 0.09→0.29。大切口形心在盒外、夹多边形在面上，C 被改成≈0，AL 把切口吸到接触面 |
| 同上但覆盖闸（质心在证书面矩形则跳过） | 坐下近精确（`minDetF=0.949`，应变 0.093，`boxFinalY=2.859`）。夹持第 14 帧顶面覆盖质心略出矩形，形心 C 开火：芯 2→5，`minDetF` 撞 0.05，`boxFinalY` 1.94→0.55 |
| 面穿且质心 C>0 时 AlC=夹多边形沿冻结 n 最深点 | 坐下更好（`minDetF=0.972`，应变 0.069）但 `boxFinalY` 2.860→2.868。夹持第 53 帧 +Y 贯穿，最深点是对面：芯 2→4，角点 0→1，`minDetF` 0.47→0.077 |
| 同上但丢弃 |C|>2cm 的贯穿残差 | 坐下数字与上条相同。夹持仍第 53 帧芯 4、角点 2。2cm 带是旋钮，挡不住贯穿覆盖改变的轨迹 |
| type-3 粒子 companion：完整三角对编译盒面不许变差（冻结 feature index，候选位姿） | 坐下应变 0.09→0.28、`minDetF` 0.94→0.83。切口 type-3 把网格焊在证书面上；与「仅粒子 min-gap / 粒子 live SAT」同类。刚体端同公式坐下精确，但夹持仍第 82 帧芯 2——顶点对面间隙看不见三角内部切实体盒 |
| 刚体 clip 对全部边界三角做芯 SAT 深度不许变差（满盒退出>1cm 才准入，整步 se(3) 二分） | 坐下精确复原（切口 SAT 只有毫米，准入闲置）。夹持更差：首次命中 82→50，芯 2→6，角点入体 0→3，`boxFinalY` 1.94→1.77。顺序 GS 把对颌 Newton 缩掉，盒子被拧进另一侧 22cm 面穿。1cm 准入挡得住坐下，挡不住夹持顺序 SAT；芯深度 se(3) 仍是死路上的 live SAT clip |
| primal 每 sweep 对 Gu 芯命中三角做耦合顶点 patch（共享芯最小退出面，粒子/刚体 4:1，other-pair 否决刚体平移） | 坐下盒子掉穿（`boxFinalY=0.50`），芯命中仍 0：GS 中切口三角会瞬时 Gu 到 1cm 芯，patch 把网格揭开，质心 AL 失去证人。与 post-AL 顶点 patch 同类，不能靠「已经进芯」当坐下闸 |
| type-3 证书面间隙 companion CSR（粒子+刚体对冻结退出面三顶点 min-gap 不许变差） | 坐下应变 0.09→0.28、`minDetF` 0.94→0.83。与粒子 live SAT 同类：坐下切口的 type-3 把网格焊在 grazed 面上 |
| 离面面穿顶点 patch（Gu∩三顶点满盒外∩形心不在 live 最小退出面矩形，每 sweep 粒子投到该面） | 坐下不精确（`boxFinalY` 2.860→2.868，应变 0.09→0.069）。夹持更差：首次命中 82→48，芯 2→6，角点 0→1。贯穿三角的 live min-exit 是颌面，离面闸把它当侧切；每 sweep 叠加切口 |
| post-AL 完整三角顶点 patch（打包共享面，质心 C≥0，覆盖矩形闸，粒子-only，每 Newton） | 坐下形变退步：`minDetF` 0.94→0.75，应变 0.09→0.32，`boxFinalY` 2.860→2.867。C≥0 在 AL 把覆盖切口刚推出后仍为真；打包面向下推边切口。加三顶点满盒外数字与无该闸相同。满盒 Gu 顶点 patch 无法在坐下切口上闲置 |
| 同上但去掉 C≥0（仅 Gu∩三顶点外∩形心不在打包面矩形，每 Newton） | 坐下数字与上条逐位相同。C≥0 不是根因；打包颌面把边切口沿重力推出，应变 0.32。live min-exit 每 sweep 反而只是 7mm 浮起（侧向推）。打包面顶点 patch 不能当坐下闲置的完整三角证书 |
| post-AL 打包面完整顶点 patch + 4:1 软/刚 + 共享正 J α + 对颌否决刚体平移 | 坐下 PASS 但 y 2.860→2.868、应变 0.09→0.070。夹持更差：第 50 帧芯 5、角点 2、`minDetF` 撞 0.05、`boxFinalY` 1.94→0.35、`|ω|≈1.94`。贯穿三角仍走打包 +Y，4:1 也改不了无限平面/贯穿。AVBD_2 的 pair-state 不能压成无流形状态的逐顶点 4:1 |
| post-AL live 夹多边形 min-exit 完整顶点 patch（4:1、det(F) 0.035、对颌否决刚体平移） | SH 要求多边形≥3 时第 82 帧 grazed 切口 clip 失败。加 packed==live 闸：坐下逐位复原，夹持 dump 与基线相同后芯 2→10。去掉 packed 闸并用顶点 AABB∩盒回退：坐下 y 2.868、应变 0.26、`minDetF` 0.82；夹持第 27 帧 +Y 覆盖芯 11。pair 级 union MAX 在颌面覆盖仍在时把侧切 4cm 藏进 +Y。packing 改非贯穿 clip 投票：坐下逐位，夹持首次命中不变，只改事后 `boxFinalY` 1.94→2.67。AVBD_2 的 live min-exit 依赖 pair-state 流形，不能压成无状态 post-AL 顶点投影或改 packing 投票 |
| type-3 `planeExtra`：夹深度沿打包 n 超过质心才加深 C（覆盖矩形/非贯穿/clip min-exit==打包面） | 坐下闸闲置、逐位。夹持更差：第 57 帧芯 8、角点 2、`minDetF` 地板、`|ω|≈0.61`，hit 在 +Y/−X  Rim。同一无限平面加深度把颌面切口泵进另一面。不要再沿冻结 n 给质心 C 加 clip 余量 |
| 相交非贯穿三角在相邻 clip 面再编一条质心 type-3（`r∥n`，`softFeature1=face+1`） | 坐下 FAIL `boxFinalY=0.571` 掉穿。第二条 ±X AL 剪切颌面，与 packing「分三角退出面互相对抗」同一剪切。Rim 不能靠第二条平移 AL |
| 盒棱穿三角内部再编 type-3 Position-AL（杠杆在击中点，打包 n，k=0） | 无闸：坐下 y 2.868、`minDetF` 0.97；夹持第 26 帧覆盖芯 10、角点 4、`minDetF` 地板、`boxFinalY` 0.50。覆盖矩形闸（形心在打包面矩形则跳过）：坐下逐位，夹持第 71 帧侧切芯 2、`minDetF` 地板、`|ω|≈0.65`、`boxFinalY` 0.85。VF/EE 漏的棱×面证人是对的拓扑，但 `jAng≠0` 能量与「type-3 r 改切割点」同类拧盒，覆盖闸只把拧推迟到侧切 |
| post-AL live 顶点 AABB min-exit 完整顶点 patch（alreadySeparated、4:1、det(F) 0.035、对颌 min-exit 二分刚体） | 坐下不闲置：7mm 覆盖的 union AABB 六面退出都 ≫ `1e-4`，应变 0.09→0.38、`minDetF` 0.94→0.67、y 2.867。夹持第 31 帧 +Y 覆盖芯 3、角点 1、`boxFinalY` 0.35。alreadySeparated 只认「已有一面 exit≈0」，挡不住毫米级覆盖切口，live 顶点 AABB 仍把颌面当 min-exit。无 pair-state 时这就是又一条 post-AL 顶点 patch |
| post-AL 侧切粒子-only 顶点 patch（本三角 live min-exit、覆盖矩形闸、盒棱穿刺、非贯穿、det(F) 0.035） | 坐下逐位（闸闲置）。夹持更差：第 81 帧体积 A +X 芯 5、角点 2、`minDetF` 0.59、应变 1.24、`boxFinalY` 4.49（盒子被掀出夹层）。无刚体平移仍把侧切从 B/−X 赶到 A/+X。粒子-only 完整三角投影没有对颌 pair-state，不能当 Rim 证书 |
| 侧切准入后对共享该刚体的全部 type-3 做 pair 完整顶点 patch（4:1、det(F) 0.035、对颌 min-exit 二分） | 坐下逐位（无侧切则整段跳过）。夹持更差：第 81 帧芯 11、角点 4、芯内顶点 1、`minDetF` 0.064、边界互穿 18。侧切准入打开覆盖颌面的完整三角投影，与无闸 4:1 顶点 patch 同类把夹层挤扁。不要用侧切当覆盖投影的开关 |
| post-AL 侧切 4:1 顶点 patch（覆盖矩形/穿刺/非贯穿闸，覆盖颌只做 other-pair 刚体 clip） | 坐下逐位。打包 type-3 union min-exit 当对颌：夹持第 77 帧 A/+X 芯 6、角点 3、`minDetF` 0.359。live 逐三角 min-exit（新相交收到接触、已相交不许变差）：第 78 帧芯 11、角点 4、`|ω|≈6.9`、`|v|≈4.7`。4:1 沿侧切 n 平移刚体，覆盖颌的正交间隙挡不住对侧新切口；粒子端把顶点送进芯。覆盖当 trust region 不是 pair-state 流形 |
| 相交 type-3 侧切三角改 live min-exit n（仍质心 `r∥n`，覆盖保持 patch 公共面） | 坐下逐位。夹持第 82 帧 dump 与基线逐位相同（体积 B/−X，芯 2）：证人三角的 patch 面本来就是 live −X，换 n 是空操作。事后 `boxFinalY` 1.939→1.988。 Rim 缺口不在法向，在质心查询看不见三角∩面矩形 |
| 相交侧切三角补 bound=0 刚体 Eq.21（杠杆在盒棱×三角击中点，live min-exit n，仍 COM 平移） | 坐下逐位。夹持更差：第 79 帧芯 11、角点 4、`minDetF` 0.20、`|ω|≈0.72`。覆盖闸闲置，但击中点 r 不平行 n 时 COM 平移补偿转动，与「半空间改 (n,r) 仍平移质心」同类把夹层剪开。不要再给侧切补 bound=0 刚体平面 |
| primal 侧切额外顶点 Position-AL 行（覆盖矩形/穿刺/非贯穿闸，`r∥n`，`k=0`，`softFeature1=corner+1`） | 坐下逐位。夹持更差：第 139 帧芯 4、应变 0.77、`|ω|≈1.06`、`averageStepMs≈478`。独立顶点 Hessian 沿同一 n 过冲，与三顶点 AL 同类。不要把完整三角压成额外 `AvbdRow` |
| primal 后耦合侧切 4:1 完整三角 peel（同闸、刚体只平移、det(F) 0.035、对颌证书已相交则冻刚体） | 坐下逐位。夹持更差：第 79 帧体积 A/+X 芯 4、角点入体 2、`minDetF` 0.40、`minY→0`。AVBD_2 的 other-pair 冻结在夹持里把刚体焊死，粒子 peel 仍把切口赶到对侧。不要再把 DyAvbdOgcDynamicTriangle 整段挂到 `solveHeterogeneousPrimal` 之后 |
| 侧切 type-3 用最深顶点替换质心查询（仍一条 `k=0` `r∥n`，覆盖保持 1/3 质心） | 坐下逐位。夹持芯仍 2，首次命中推迟到第 121 帧体积 A/+X 覆盖切口（`hitLocal=(0.5,0.35)`，形心在面矩形上）。侧切 AL 吃掉 B/−X 后切口变成对侧覆盖，覆盖与坐下 7mm 切口同类，闸会闲置。不要再单独加深侧切 C |
| 相交 type-3 各编自己的 SAT min-exit n（slab 重叠面，仍质心 `r∥n`） | 坐下逐位（覆盖三角自己的 min-exit 仍是 +Y）。夹持到第 82 帧轨迹与基线同（union 翻转前每三角 min-exit 仍是颌面），之后对向 n 剪切：芯 10、角点 2、`minDetF` 地板、应变 14.9、`boxFinalY` 20.5。覆盖离开后剩下的侧切/颌面互相对抗。不要再把 packing 从 pair union MAX 改成逐三角退出面 |
| `clipRigidContactStep` 按逐三角 own min-exit 不许顶点平面间隙变差（r 冻在面矩形最近点，能量仍质心 `r∥n`） | 坐下 PASS 但不精确：y 2.860→2.868，应变 0.09→0.13。夹持更差：第 34 帧体积 A/+Y 覆盖芯 3、角点 2。覆盖 leftover 的 don't-worsen 把坐下/夹持颌面焊住，AL 只能沿 n 把盒子抬出切口。Trust region 看见覆盖切口 ≡ 覆盖投影 |
| post-AL 耦合完整三角顶点 patch（live type-3 union AABB min-exit、4:1、det(F) 0.035、other-pair 冻刚体、无芯 Gu） | `alreadySeparated`（任一面 union MAX ≤tol 则跳过整 pair）：坐下/夹持数字与质心 AL 基线逐位相同，每步白烧 ~287ms。leftover type-3 把某一面 union MAX 打成 0，连 −X rim nick 一起闲置。去掉该闸、只在 exit>tol 的面取 min-exit：坐下仍逐位；夹持第 10 帧覆盖 leftover 开火，`|v|≈14`、芯 19、角点入体 7、`minDetF` 撞 0.035、`boxFinalY=0.35`。无 pair-state 时 live min-exit 不是 AVBD_2 流形；覆盖 leftover 的投影就是覆盖投影 |
| post-AL 逐三角完整顶点 patch（本三角 SAT min-exit、4:1、det(F) 0.035、对颌 Signorini、5cm 帽） | 只扫步初 type-3：坐下/夹持逐位（不开火）。改扫 live Gu 相交边界三角：坐下仍逐位、`averageStepMs` 21→30；夹持第 82 帧 dump 与基线相同，之后更差（芯 2→3、边界互穿 6→10、应变 0.52→0.69、`boxFinalY` 1.938→1.941）。`verticesInsideFull=0` 的面穿在 AL 内形成，post-AL 来不及；事后粒子 peel 只加大形变。完整三角证书必须进 primal/Eq.21，不能挂在 nonlinear 循环之后 |
| primal 粒子 companion CSR：type-3 三碰撞顶点 live SAT min-exit 不许变差（无额外 Hessian） | 坐下 PASS 但不精确：y 2.860→2.868，应变 0.09→0.069，`minDetF` 0.94→0.97。夹持更差：第 36 帧体积 A/+Y 覆盖芯 3，角点入体 1，边界互穿 10。覆盖 leftover 的 live min-exit 焊粒子，AL 只能沿颌面抬盒，切口提前进芯。AVBD_2 的 companion 依赖 pair-state 流形，不能压成无状态 live min-exit don't-worsen |
| 相交 type-3 刚体 Eq.21 正交 clip-polygon remaining-exit（跳过 pair packed 颌面，面心 `r∥n`，`bound=γ·remaining`） | 无闸：坐下 PASS 但不精确（y 2.860→2.864）。夹持更差：第 81 帧体积 A/+X 芯 4，边界互穿 8，`boxFinalY` 1.94→3.44。覆盖 leftover 的正交 remaining 在坐下 7mm 切口上开火。覆盖闸（仅当本三角 clip min-exit ≠ packed）：坐下逐位；夹持第 82 帧 dump 与基线逐位相同，之后芯 2→3。切口在 AL 内长出时 DCD own min-exit 仍是颌面，半空间闲置；事后侧切 Eq.21 与「侧切改 live min-exit n」同类来不及。Rim 证书不能挂在 DCD 冻结 Eq.21 上 |
| 覆盖闸 live clip-polygon remaining（`clipRigidContactStep`，own min-exit ≠ packed 才不许变差） | 坐下逐位。夹持第 82 帧 dump 与基线逐位相同，之后芯 2→3、互穿 6→8。覆盖 leftover 的 clip remaining 在 packed 颌面是 0，Rim 1cm 不是 min-exit，闸闲置。own≠packed 不能把 Rim 从覆盖 leftover 里分出来；无闸正交 remaining 已在 Eq.21 上坐下浮起。不要再给这条闸加 live/DCD 变体 |
| 覆盖闸 vertex-AABB own≠packed remaining don't-worsen（刚体 clip，再补粒子端） | 坐下逐位。夹持第 82 帧 dump 与基线逐位相同（`|w|`/`|v|` 也同），芯仍 2；事后互穿 6→14、应变 0.52→0.68。clip-polygon own 因颌面 remaining=0 看不到 Rim；vertex AABB own 在进芯当帧与 packed 对齐或证书未绑上。覆盖闸 remaining 没有芯前开火窗口 |
| 相交 type-3 在 vertex-AABB min-exit ≠ packed 且非同轴时再编一条质心 Position-AL（`r∥n`，`k=0`，`softFeature1=own+1`） | 坐下逐位（闸闲置）。夹持第 82 帧 dump 与基线逐位相同，芯仍 2；事后互穿 6→8、应变 0.52→0.72。DCD extra 能量与 covering-gated own≠packed remaining 同一窗口：芯前 own 仍是颌面。不要再给 own≠packed 加第二条平移 AL |
| 粒子+刚体 clip 对 type-3 正交面 vertex-AABB remaining 不许减小（无 own≠packed 闸，整步 bisect） | 坐下第 0 帧芯 6、`minDetF` 地板、`boxFinalY=1.706`、应变 5.83。无闸正交 AABB remaining 就是坐下 7mm 覆盖切口；bisect 把颌面 AL 一起裁掉。不要再给 vertex-AABB remaining 加 live clip / DCD 变体 |
| 粒子+刚体 clip 对 type-3 正交 clip-polygon remaining 不许减小（无 own≠packed 闸，空 clip 不回退 AABB） | 坐下 PASS 但不精确：y 2.860→2.868，`minDetF` 0.94→0.77，应变 0.09→0.31。夹持第 30 帧 +Y 覆盖芯 6，角点入体 1，`minDetF` 0.13。覆盖 leftover 的夹多边形在颌面 AL 下正交 remaining 仍减小；don't-worsen 就是覆盖投影。不要再给 remaining don't-decrease 加几何变体 |
| type-3 改三角外向 n、盒支撑面 `r||n`（质心仍 1/3） | 坐下第 0 帧芯 6、`minDetF` 地板、应变 173、`boxFinalY≈1122`。覆盖切口的三角法向已经互相对抗；与逐三角 SAT min-exit n 同一剪切。不要再换 n 家族来表示倾斜切面 |
| 相交 EE `distance≈0` 改 k=0 正交面 `r∥n` | 第 82 帧 dump 与基线逐位相同。type-2 是软边×盒棱；面穿是盒棱×三角内部，最近点不必在软边上 |
| 盒棱×三角内部正交面 Position-AL（`r∥n`，`k=0`，查询在击中点） | 跳过打包面棱：坐下第 1 帧芯 4、应变 35.9、`boxFinalY≈47.7`。覆盖 7mm 切口也会切垂直棱。只留对面棱：坐下第 1 帧芯 3、应变 19.4、`boxFinalY=1.45`。打包 n + `jAng≠0` 与覆盖矩形闸已死；再加「对面/垂直/打包面」闸仍剪切坐下。不要再给棱穿三角补 `r∥n` AL |
| 相交 type-3 粒子正交面 first-entry Eq.21（gap>0 才编） | `bound=0` 坐下 y 2.860→3.017。`bound=γ·gap` 坐下 y 2.859；夹持第 82 帧 dump 逐位相同，芯 2→3。悬挂顶点 DCD 已在正交无限板内（gap<0），first-entry 闲置；L-cut 靠已入板顶点滑上面矩形。不要再给正交 gap>0 加 DCD first-entry 变体 |
| 相交 type-3 粒子对面 first-entry Eq.21（打包轴反面，gap>0，`bound=0`） | 坐下逐位。夹持第 22 帧体积 A/+Y/+X 棱芯 6、角点入体 2、`minDetF` 地板、`boxFinalY` 0.89。冻悬挂顶点沿打包轴靠近对面 = 挡住覆盖包络。不要再给对面 gap>0 加 first-entry（含 `γ·gap`） |
| 分离三角 AABB 跨正交面后沿打包 n `bound=0` Eq.21（粒子-only） | 无闸：坐下逐位，夹持第 13 帧 A/+Y 覆盖芯 14。宽覆盖三角 AABB 跨 ±X，冻 packed 闭合饿死覆盖。own≠packed 且非同轴：坐下逐位，夹持第 39 帧覆盖芯 6。L-cut 早段 own 仍是颌面（整段在 packed 板外），闸闲置；能开火的种群就是覆盖邻接三角。不要再给分离悬挂补 packed-n Eq.21 |
| 粒子 clip 分离三角正交 first-Gu（pair 已有 type-3，own 为侧才裁） | 坐下逐位。夹持第 82 帧 dump 与基线逐位相同。L-cut 三角先以覆盖 Gu 相交（own=packed，准入），之后已相交态沿打包轴滑上侧矩形；分离 first-Gu 看不见已相交覆盖三角的侧切生长。不要再给分离三角加 first-Gu 变体 |
| 粒子 clip 已相交三角的正交面矩形 first-entry（跳过 packed/对面轴） | 坐下 y 2.860→2.868、应变 0.09→0.069。夹持第 15 帧覆盖芯 6、`|v|≈16`、角点入体 2。坐下 7mm 覆盖切口已经切竖棱；侧矩形 first-entry 与盒棱×三角 `r∥n` AL 同一竖棱焊。不要再给正交面矩形 / 盒棱穿刺加 first-entry clip |
| 粒子 clip 盒棱×三角内部 first-entry（已穿刺则闲置，`t∈(1e-3,1-1e-3)` 且重心内部） | 坐下 y 2.860→2.868。覆盖 leftover 休息时未必已有内部棱穿；GS 把覆盖切口长到竖棱时 `pierce(0)==false` 且 `pierce(Δ)==true`，与正交面矩形 first-entry 同一覆盖焊。不要再给盒棱×三角内部加 first-entry clip |
| 同上但 packed 面 `box.margin` 带内击中闲置 | 坐下逐位。夹持第 82 帧 dump 与基线逐位相同、芯仍 2。覆盖 leftover 在 DCD 已深穿（`pierce(0)==true`）则闲置；带内竖棱生长被闸掉后，带外 leftover 只跨帧变深，first-entry 没有开火窗口。不要再给深穿刺 first-entry 加 packed 带闸 |
| 相交 type-3 深穿刺正交面第二条质心 Position-AL（`r∥n`，`k=0`，packed 带闸） | 坐下第 0 帧芯 3、`boxFinalY=0.35`、应变 1.02。覆盖三角平面已切到底棱，底棱击中相对打包面永远深（≈2·hy）；带闸分不开坐下切口和夹持 L-cut。与无闸相邻面第二条质心 AL / 盒棱 `r∥n` 同一剪切。不要再给深穿刺 leftover 加第二条平移 AL |
| 相交 type-3 悬挂顶点沿打包 n 的 Position-AL（`packedDistance>box.margin`，`r∥n`，`k=0`） | 坐下 y 2.860→2.868、应变 0.09→0.070、`minDetF` 0.94→0.97。覆盖切口三角仍有顶点落在打包半空间 4cm 外；第二条打包 n 顶点 AL 就是覆盖焊。不要再给打包 n 悬挂顶点加第二条 AL |
| 粒子+刚体 clip 对 type-3 正交无限条带顶点 packedDistance 帽 `max(d0, box.margin)`（厚 `2·margin`，不要求面矩形） | 坐下逐位。夹持第 76 帧 A/+X 芯 5、角点入体 2、`|ω|≈1.46`、`averageStepMs≈373`。条带比矩形更早看见悬挂 leftover，packed 帽仍是覆盖投影。不要再给正交条带 packedDistance 加 first-entry / don't-deepen |
| primal 每 sweep 逐三角 live AABB alreadySeparated 跳过（不冻结）+ 沿本三角 min-exit 4:1 顶点 peel（`det(F)` 0.035、5cm 帽、无 other-pair） | 坐下 y 2.860→2.868、应变 0.09→0.069、`minDetF` 0.94→0.97。7mm 覆盖切口 remaining>0.1mm，peel 即覆盖焊。不要放宽 alreadySeparated，也不要再把这条 peel 挂进 primal |
| 同上但 own≠packed 才 peel | 坐下逐位。夹持第 82 帧 dump 与基线逐位相同、芯仍 2；事后互穿 6→0、应变 0.98、`averageStepMs≈381`。进芯当帧 own 仍 packed。不要再给 own≠packed 加 primal peel |
| 粒子+刚体 clip 悬挂条带 `packedDistance<0` 才 first-entry 进入打包半空间 | 坐下逐位。夹持第 76 帧 A/+X dump 与无闸条带帽逐位相同，芯 6、角点入体 2。union MAX 翻转 packed n 后「面外」就是覆盖 leftover。不要再给悬挂条带 packedDistance 符号闸加 first-entry |
| 粒子+刚体 clip 悬挂条带沿 live clip min-exit，要求 `packedDistance` 从面内翻到面外才 first-entry | 坐下逐位（`boxFinalY=2.86057591`）。夹持 dump 与质心 AL 基线逐位相同（第 82 帧体积 B/−X，芯 2，`minDetF=0.465676427`），`averageStepMs≈373`。L-cut 沿覆盖 n 的 `packedDistance` 始终 ≤0（侧矩形上的点相对颌面仍在盒内），符号翻闸闲置。不要再给 clip min-exit 悬挂条带加 `packedDistance` 变号 first-entry |
| 同上但去掉变号：悬挂（`packedDistance<0`）且 `!start.inSlab && end.inSlab`（条带厚 `2·margin`，live clip min-exit） | 坐下 FAIL：第 0 帧芯 6，`minDetF=0.722`，应变 0.34，`boxFinalY=2.818`。8cm 正交条带 first-entry 就是覆盖包络绕边；与无闸条带 packed 帽同一覆盖焊，只是更早。不要再给悬挂条带 / clip min-exit 加 first-entry（有无变号、AABB packed n / live clip n 都已死） |
| 粒子+刚体 clip 盒棱×三角内部 first-entry，闸是 other-pair 已有 type-3（无芯 Gu、无粒子 peel） | 坐下逐位（单体积闸闲置）。夹持更差：首次命中 82→84，芯 2→7，角点入体 0→1，互穿 6→8，`verticesInsideFull=1`，`averageStepMs≈323`。夹持两颌都已有 type-3，闸常开，裁的是覆盖 leftover 竖棱而不是 L-cut。不要再给 edge/rectangle/strip first-entry 加 other-pair 闸 |
| 远悬挂（打包轴在 OGC 井外且在正交无限板内）+ 网格顶点首次落到正交面矩形 | 坐下逐位。夹持第 82 帧 dump 与质心 AL 基线逐位相同（体积 B/−X `exit=0.041`，芯 graze 同帧），事后更差：芯 2→3，互穿 6→18，`minDetF` 0.47→0.33，`averageStepMs≈385`。first-entry 承认的就是 leftover 贴上侧矩形的姿态，与芯 graze 同一 GS。不要再给正交面矩形 / 侧矩形网格顶点加 first-entry |
| 远悬挂顶点不许沿打包轴靠近颌面（don't-decrease packed-axis exterior） | 坐下不逐位：`boxFinalY` 2.860→2.86094，`minDetF` 0.938→0.944。坐下相交 type-3 已有井外顶点落在正交无限板；远悬挂闸分不开覆盖切口和大三角。不要再给打包轴 exterior / 井外悬挂加 don't-approach |
| 相交 type-3 远悬挂顶点沿打包轴朝向该顶点的 Eq.21（`γ·exterior`） | 坐下逐位。夹持第 82 帧 dump 与质心 AL 基线逐位相同（芯 2，`minDetF=0.465676427`），`averageStepMs≈373`。粒子 OGC 锚在 DCD 位姿：`bound=γ·77cm` 允许沿对向 n 走近 35cm，夹层每步只有毫米级。对面悬挂半空间太松，只烧 8 槽。不要再给朝向悬挂顶点的打包轴 Eq.21 加 `γ·d` |
| 同上但 `bound=0` | 坐下逐位（与打包 n 同向则合并）。夹持更差：首次命中 82→81 体积 A/+X，芯 2→11，角点入体 0→4，`verticesInsideFull` 到 2，`|v|≈3.68`，`|ω|≈1.02`，`averageStepMs≈342`。冻对向悬挂靠近 = 挡住覆盖包络，盒子被拧进网格；与「对面 first-entry `bound=0`」同类。不要再给朝向悬挂顶点的打包轴 Eq.21 加 `bound=0` |
| type-3 已穿刺的打包轴平行盒棱 don't-increase t（粒子+刚体 clip） | 坐下不逐位：`boxFinalY` 2.860→2.868，`minDetF` 0.938→0.970，应变 0.09→0.069。坐下 7mm 覆盖切口已经切竖棱；冻结该 t 就是覆盖投影。不要再给侧棱穿刺深度加 don't-increase / first-entry 变体 |
| 相交 type-3 质心不在打包面矩形则跳过 | 坐下不逐位：`boxFinalY` 2.860→2.8599，`minDetF` 0.938→0.956。Rim 切口三角质心略出矩形。夹持 leftover 质心在覆盖面切向矩形内（dump `\|x\|=0.49<hx`），闸闲置且会饿死坐下覆盖。不要再给质心切向矩形加 type-3 准入 |
| 相交 type-3 质心已穿过盒子对面则跳过 | 坐下逐位。夹持第 82 帧 dump 与质心 AL 基线逐位相同（芯 2，`minDetF=0.465676427`），`averageStepMs≈373`。DCD 质心尚未穿过，GS 中才穿过；步初跳过看不见 L-cut。不要再给穿过对面的质心加 packing 跳过 |
| 质心 Position-AL 的 AlC：任一粒子支持穿过对面则 `max(C,0)` | 坐下逐位。夹持第 82 帧 dump 与基线逐位相同（L-cut 仍由覆盖三角完成），事后芯 2→5、`minDetF` 地板 0.052、`boxFinalY` 1.94→3.65、应变 1.12、互穿 6→0。穿过后拒拉 leftover = 饿死夹层恢复。不要再给穿过对面的质心 C 加 `max(C,0)` |
| 粒子 clip 夹多边形 packed 轴厚度 first-entry（已有 extent>1mm 则闲置） | 坐下 y 2.860→2.868、`minDetF` 0.94→0.73、应变 0.09→0.32。覆盖 leftover 平面夹多边形 extent~0，GS 长出切口厚度即覆盖焊。不要再给夹多边形 packed 厚度 / 相交体积加 first-entry clip |
| 粒子 clip 逐三角 alreadySeparated AABB（任一面 exit≤0.1mm 跳过）+ 不许 min-exit 加深 / 不许离开已分离 | 坐下 y 2.860→2.868、应变 0.09→0.069、`minDetF` 0.94→0.97。夹持第 60 帧 B/−Y 芯 9、角点入体 3、`|ω|≈0.89`、`averageStepMs≈959`。覆盖 leftover 离开 packed 面的 live AABB 就是覆盖投影；与 companion live min-exit 同类。不要再给逐三角 alreadySeparated 加 clip / don't-deepen 变体 |
| 同上但贴面只跳过、允许离开（不禁止绕行） | 坐下 y 2.868、应变 0.069。夹持第 60 帧 A/+Y 覆盖 remaining 17cm，芯 8、角点入体 4、`minDetF` 地板。0.1mm alreadySeparated 跳不过夹持颌面厘米级 AABB remaining；don't-deepen 焊颌。不要再给 alreadySeparated 0.1mm 闸加 don't-deepen |
| 相交 type-3 packing 在 packed-face clip remaining>1e-4 时改 clip min-exit n | 坐下逐位。夹持到第 82 帧 dump 与基线相同：DCD 冻结 n 看不见 GS 长出的 L-cut。覆盖 leftover 的 clip remaining 在 packed 上是 0，侧 remaining 1–4cm，live clip min-exit 不会翻到 Rim。事后互穿 6→8、`boxFinalY` 1.94→2.67。不要再给 packing / clip 换 min-exit n |
| type-3 夹多边形 DCD 面占用 don't-increase（粒子+刚体 clip） | 坐下第 0 帧芯 6，`boxFinalY` 2.860→3.016，应变 0.16。坐下切口在第 0 帧 GS 从单面长到竖棱，与夹持 L-cut 同一 wrap；don't-increase 饿死覆盖包络。不要再给夹多边形占用的盒面集合加 first-entry / don't-increase |
| pair-union 改夹多边形 remaining（替换顶点 AABB） | 坐下逐位。夹持第 82 帧 dump / `minDetF=0.465676427` 与 AABB 质心 AL 基线逐位相同（芯 2），事后互穿 6→8、`boxFinalY` 1.94→2.67、`averageStepMs≈327`。第 82 帧 DCD 的 AABB 并集并未翻 n；挡住事后 leftover 翻到侧 n 会饿死夹层恢复。不要再给 pair-union 换夹多边形 remaining |
| 相交 type-3 质心 k=1e5 偏移井（packed n，`r∥n`，半径 `0.02*margin`） | 坐下 PASS 但是覆盖焊金丝：`boxFinalY` 2.860→**2.86817026**，`minDetF` 0.938→0.968，应变 0.09→0.069，0 芯。有限井在质心上过持覆盖切口，与 k=0 夹心查询同类。不要再给质心 type-3 换 k>0 井 |
| 相交 type-3 仅当夹心 coreSdf<-1e-5 才编行（质心 AL / packed n / 1/3 不变） | 坐下逐位。夹持芯 2→**0**，但互穿 6→18、`maxInsideParticles` 0→1（第 159 帧）、应变终值 0.59、`minDetF` 0.466→0.441。AVBD_2 这条准入会去掉贴面 leftover AL；没有 companion CSR / 每 sweep DCD 时 leftover 贴面绕行。芯 0 是饿死 leftover 的假绿。不要再给贴面 leftover 单独跳过 type-3 |
| 贴面 leftover 对向打包 n `bound=0`（仍编质心 AL） | 坐下逐位。夹持更差：首次 82→81 体积 A/+X，芯 2→12，角点入体 0→2，`verticesInsideFull` 到 2，`|v|≈2.22`，`|ω|≈0.87`，互穿 6→0。冻悬挂沿打包 n 开口后 leftover AL 把力卸到面顶/刚体，盒子被拧进网格；与「对面 first-entry `bound=0`」同类。不要再给贴面 leftover 加对向 `bound=0` 同时保留质心 AL |
| 贴面 leftover 跳过 type-3 + 夹多边形 6 面 remaining Eq.21 companion | 坐下逐位。夹持芯仍 2（第 82 帧 A/+X），角点入体 0→1，互穿 6→10，`|v|≈3.18`，`|ω|≈0.76`。单独跳过 type-3 曾把芯打到 0；6 面 companion 把力拧回颌面。不要再给贴面 leftover 叠 clip-remaining companion |
| 贴面 leftover 跳过 type-3 + 仅 leftover-exclusive 悬挂顶点未占用面 remaining Eq.21 | 坐下逐位。夹持更差：第 91 帧体积 A/+X，芯 2→10，角点入体 0→1，`verticesInsideFull` 到 2，`|v|≈4.18`，`|ω|≈1.61`，互穿 6→4。跳过 leftover AL 后侧向悬挂平面成了夹层持力，覆盖 AL 把盒子拧进网格。不要再给贴面 leftover 在去掉质心 AL 的同时加悬挂/侧向 remaining companion |
| 贴面 leftover 仍编质心 AL + 仅 leftover-exclusive 悬挂未占用面 remaining Eq.21 | 坐下逐位。夹持 `minDetF=0.465676427` 与质心 AL 基线逐位相同（同一 L-cut），首次命中推迟 82→113，芯 2→4，互穿 6→4，角点仍 0，`|v|≈0.32`。悬挂侧向冻挡住棱绕行后 leftover 改从 +X 面穿进芯（dump `edgeCrossings=0`，verts 仍在满盒外）。顶点 remaining 看不见三角内部切面；不要再给 leftover 悬挂顶点加侧向 remaining |
| 贴面 leftover 仍编质心 AL + 三顶点未占用 AABB remaining `γ·remaining` Eq.21 | 坐下逐位。夹持第 82 帧 dump / `minDetF=0.465676427` 与基线逐位相同（体积 B/−X `exit=0.041`，芯 graze 同帧），事后芯 2→3，互穿 6→10。4cm 侧 remaining 的 γ 仍允许 ~1.8cm 闭合，够 nick 1cm 芯；冻结 DCD remaining 看不见步内 L-cut。不要再给 leftover 三顶点加 `γ·AABB remaining` |
| 贴面 leftover 仍编质心 AL + 三顶点未占用 AABB `bound=0` Eq.21 | 坐下逐位。夹持 `minDetF=0.465676427` 仍逐位，首次 82→86，芯 2→4，角点入体 0→1，互穿 6→**0**。侧向冻把 leftover 棱绕行挡住后质心 AL 把力卸进芯/角点；与「对向打包 n `bound=0` 仍编 AL」同类。不要再给 leftover 未占用面加 `bound=0` 同时保留质心 AL |
| leftover-only live 完整三角 AABB remaining 不许减小（非打包面，admission clip） | 坐下逐位。夹持芯 2→**0**、角点 0、互穿 6→20、`minDetF` 0.466→0.278。SAT exit 不许减小 = 冻住步初重叠、挡住抽出；leftover 停在满盒切口、进不了 1cm 芯。芯 0 是壳层假绿。不要再给 leftover remaining 加 don't-decrease |
| leftover-only live 完整三角 AABB remaining 不许加深（六面，admission clip） | 坐下逐位。夹持 `minDetF=0.465676427` 逐位，第 82 帧体积 A/+X，芯 2→4，互穿 6→0，`|v|≈13`，`|ω|≈1.10`。don't-deepen 是 AVBD_2 face-gap 符号，但保留 leftover 质心 AL 时把力拧进覆盖颌。不要再给 leftover 叠 live remaining clip 同时保留质心 AL |
| 每 sweep 把 type-3 n 改成该三角 live 顶点-AABB min-exit（仍质心 `r∥n`） | 坐下 y 2.860→2.868、应变 0.09→0.32、`minDetF` 0.94→0.74。夹持第 57 帧 A/+Y 覆盖芯 3。覆盖 leftover 的 live AABB min-exit 仍是颌面；GS 中换 n 就是覆盖投影。与 DCD 逐三角 min-exit / companion live min-exit 同类。AABB 也不会在芯前把 covering leftover 翻到 Rim |
| leftover-only DCD AABB min-exit n，闸是夹心 `coreSdf>=-1e-5`（覆盖仍 pair packed） | 坐下逐位 `2.86057591`。夹持第 82 帧 dump / `minDetF=0.465676427` / 芯 2 / 互穿 6 / `boxFinalY=1.93863368` 与质心 AL 基线逐位相同。包裹 leftover 的夹心在满盒内部，被当成覆盖 nick，闸闲置。snippet dump 的 `exitFace` 是三角自己的 AABB，不是 solver packed n。不要再给 leftover 用满盒夹心 SDF 当 own-n 闸 |
| leftover-only DCD AABB min-exit n，闸是 own≠packed（覆盖仍 pair packed） | 坐下逐位 `2.86057591`。夹持第 82 帧 dump 与基线逐位相同（L-cut 当帧 DCD own 仍是颌面），之后对向 n 剪切：芯 2→10，角点入体 0→2，`minDetF` 地板 0.049966，应变 14.9，`boxFinalY` 20.5。与逐三角 SAT min-exit n 同一事后剪切。DCD 冻结 leftover n 看不见步内 L-cut；覆盖离开后 Rim n 与颌面互相对抗。不要再给 leftover 换 DCD own AABB / SAT min-exit n |
| leftover-only 夹多边形重心权重（质心在满盒外才换，packed n / k=0 / 1/3 覆盖不变） | 坐下 PASS 但是覆盖焊：`boxFinalY` 2.860→**2.86794686**，`minDetF` 0.938→0.970，应变 0.09→0.067。坐下覆盖 nick 的三角质心已经在盒外，闸就是覆盖查询。与全员夹心查询同类。不要再给 leftover 用质心在盒外 / 夹多边形重心当 1/3 的替代 |
| 相交 type-3 夹心 `coreSdf<-1e-5` 换 AVBD_2 compact 井（夹多边形重心 + k=1e5 + 夹心 SDF n 或 packed n，平面 leftover 仍质心 packed AL，`r∥n`） | 坐下 FAIL：第 3 帧芯 3，`boxFinalY` 2.860→**2.86826301**，`minDetF` 0.938→0.972，应变 0.09→0.060。packed n 与夹心 SDF n 坐下数字逐位相同——覆盖 nick 的夹心 SDF 已是颌面。损伤是夹心查询+k=1e5 井，不是换 n。覆盖 nick 本身就是夹心<0，闸就是覆盖井。不要再给相交 type-3 加夹心 compact 井 |
| type-3 Position-AL 支持多边形对打包无限板夹心 SDF 不许加深（能量仍质心 AL，`r∥n`） | 坐下官方 PASS 但不逐位：`boxFinalY` 2.860→2.85686135，`minDetF` 0.938→0.945，0 芯。夹持更差：首次 82→**11** 体积 A/+Y 覆盖，芯 2→8，角点入体 0→3，互穿 6→0，`|v|≈1.59`。don't-deepen 打包板厚度就是覆盖包络；与 leftover remaining don't-deepen 同类把颌面 AL 拧进芯。恰好 3 粒子支持时闲置（embedding>3）。不要再给 type-3 加打包板 / 夹心 SDF don't-deepen clip |
| type-3 持力粒子 Coulomb 切向 Hessian（`C<0` 才开火，质心仍法向 AL） | 坐下 y 2.860→2.868、应变 0.09→0.063、`minDetF` 0.94→0.97。夹持第 65 帧芯 7、角点入体 2、互穿 20、`minDetF` 地板、`|ω|≈6.3`。覆盖 leftover 持力时切向焊包络；开口悬挂滑 `C≥0` 时 `|Fn|μ=0`，库仑盘空。不要再给 type-3 Position-AL 加切向 AL / 摩擦 |
| 粒子+刚体 clip 完整三角 15 轴 SAT MTD don't-deepen，闸是 min 轴非盒面（三角平面或棱×棱） | 坐下 FAIL：第 1 帧芯 11，`boxFinalY` 2.860→**2.86815572**，`minDetF` 地板 0.050，应变 1.17，`minY=1.055`。覆盖 nick 的 MTD 已经不是盒面；非面闸就是覆盖投影。与 live SAT 面间隙 / leftover remaining don't-deepen 同类。不要再给 type-3 加非面 SAT MTD clip |
| 同上但闸收成仅棱×棱（family=2），三角平面闲置 | 坐下 FAIL：0 芯，`boxFinalY` 2.860→**6.7546463**，`minDetF=0.971`，应变 0.069，`minY=1.087`。覆盖 nick 的 MTD 已是 EE；don't-deepen EE remaining 与颌面质心 AL 对拉把盒子打飞。AABB 颌面 remaining 与 SAT EE MTD 不是同一轴，所以「覆盖是面、L-cut 是 EE」不成立。不要再给完整三角 SAT 按轴家族分覆盖/侧切 |
| 粒子+刚体 clip 冻结打包面完整三角 AABB remaining don't-increase（能量仍质心 AL） | 坐下官方 PASS 但是覆盖焊：`boxFinalY` 2.860→**2.86794543**，`minDetF` 0.938→0.725，应变 0.09→0.328，0 芯。悬挂顶点会撑大打包面 AABB remaining，坐下 7mm 切口在第 0 帧 GS 里同样撑大；don't-increase 就是覆盖包络。夹多边形厚度看不见悬挂，AABB remaining 看得见，但看见的就是坐下切口生长。未跑夹持。不要再给打包面完整三角 AABB remaining 加 don't-increase / don't-deepen |
| type-3 Position-AL 活残差改 `max(质心 C, 满盒夹多边形形心 C)`（J 仍 1/3 质心，`r∥n`，k=0，clip 仍质心） | 坐下官方 PASS 但不逐位：`boxFinalY` 2.860→2.85981488，`minDetF` 0.938→0.955，0 芯。夹持更差：首次 82→**61** 体积 A/+Y，芯 2→8，角点入体 0→2，互穿 6→0，`minY→0.008`，`|v|≈1.90`。夹心 C 更浅等于削弱 leftover AL：边界互穿没了，夹层却提前穿芯。与跳过 leftover AL / 夹心查询同类。不要再给 type-3 用夹心 C 替换或 max 掉悬挂质心残差 |
| primal 每 sweep 后耦合 4:1 不许 type-3 三顶点打包 n min-gap 变差（对颌 positive-J 否决刚体平移，能量仍质心 AL） | 坐下覆盖焊：`boxFinalY` 2.860→**2.86763501**，`minDetF` 0.938→0.813，应变 0.09→0.259，0 芯。未跑夹持。扫后按本 sweep 起点 restore min-gap 就是抽出坐下切口 wrap；与 4:1 extract-to-zero 同类。顺序 min-gap clip（死 77）坐下绿是因为它不事后抽出。不要再给 type-3 加扫后 4:1 / 共享α min-gap restore |
| 刚体 clip 只裁 type-3 `dth`：粒子支持面对打包 n 的 min-gap 不得差过仅平移候选（能量/质心 clip 不变） | 坐下逐位 `2.86057591` / `minDetF=0.938481927`（闸闲置：坐下 wrap 不靠转动加深 embedding min-gap）。夹持更差：首次 82→**68** 体积 A/+X 棱，芯 2→1，角点入体 0→1，互穿 6→10，`minDetF` 0.466→0.174，`maxInsideParticles` 0→1，`minY→0.008`。冻转动把夹层拧进竖棱；与「只裁 dth 的 live SAT」同类。不要再给 type-3 加 min-gap / SAT 的刚体-only `dth` clip |
| type-3 粒子-only wrap AL：`C=min_i(n·p_i)−质心(n·p)`，刚体 J=0，质心 AL 不变 | 坐下覆盖焊：`boxFinalY` 2.860→**2.86816454**，`minDetF` 0.938→0.972，应变 0.09→0.070，0 芯。未跑夹持。覆盖 nick 的 embedding 沿 n 已有 spread，min−mean 就是覆盖抽出。面坐标抵消后看不见盒转动，只看见坐下切口的粒子高低。不要再给 type-3 加 min−质心 / hanging-vs-mean 粒子 AL |
| type-3 wrap AL 只罚 excess：`C=(min−mean)_live − (min−mean)_{pStart}`，刚体 J=0，质心 AL 不变 | 坐下覆盖焊：`boxFinalY` 2.860→**2.86811733**，`minDetF` 0.938→0.972，应变 0.09→0.070，0 芯。未跑夹持。坐下第 0 帧 GS 已经把覆盖 nick 的 embedding spread 撑大（开口允许质心抽出、min 不动），excess vs x^t 仍是覆盖抽出。不要再给 type-3 加 min−mean / hanging-vs-centroid 的 live 或相对 pStart / CLin 变体 |
| type-3 粒子 clip 不许 embedding 支持 `min_i n·p` 变差（刚体仍质心 clip，能量仍质心 AL） | 坐下官方 PASS 但不逐位：`boxFinalY` 2.860→2.86194277，`minDetF` 0.938→**0.441**，应变 0.09→**0.589**，0 芯。未跑夹持。embedding 粒子 min-gap 在坐下切口上开火并把网格挤扁；死 77 的三顶点 min-gap 不是这份 embedding min。不要再给 type-3 加 embedding / 全支持 min(n·p) 粒子 clip |
| 动态 type-3 leftover AL 只刚体：C 用粒子 `pStart`+活刚体，粒子 J/clip=0 | 坐下覆盖焊：`boxFinalY` 2.860→**2.86808252**，`minDetF` 0.938→0.751，应变 0.09→0.314，0 芯。未跑夹持。粒子不分担 leftover 时刚体把 DCD 切口抽到 C=0，正是覆盖焊。坐下 7mm 平衡靠两端 leftover AL。不要再给动态 type-3 冻粒子 / 粒子 J=0 / 只刚体 leftover |
| type-3 粒子 clip 不许三碰撞顶点沿打包 n 的 min-gap 变差（刚体仍质心 clip，能量仍质心 AL） | 坐下覆盖焊：`boxFinalY` 2.860→**2.86811256**，`minDetF` 0.938→0.963，应变 0.09→0.072，0 芯。未跑夹持。死 77 两端 3 顶点 min-gap 坐下绿是因为刚体也被锁、切口抽不出去；只锁粒子时 leftover AL 把切口抽出。不要再给 type-3 加粒子-only 3 顶点 / 3 角点 min-gap clip |
| type-3 粒子 clip 三碰撞顶点 min-gap 相对 DCD `CLin` 的 trust region，slack=`contactRadius` | 坐下覆盖包络：`boxFinalY` 2.860→**3.01496696**（15cm），`minDetF` 0.966，应变 0.069，0 芯。未跑夹持。步内相对 DCD 的 3 角 min-gap 地板仍把坐下切口抽出；比 live 0-slack 的 2.868 更飞。不要再给 type-3 加 DCD/CLin 3 角 min-gap 帽（含 contactRadius slack） |
| type-3 刚体 wrap 能量 `0.5 ρ (max n_live·r − max n_DCD·r)_+²`（悬挂杠杆 `jAng=n_live×r`，质心 AL/clip 不变） | 坐下 FAIL：`boxFinalY` 2.860→**0.34998557**，0 芯，`minDetF` 0.970。相对 `qStart` 的恢复力矩把盒子拧离 7mm 切口后掉穿。死 193 的 dth clip 坐下闲置，是因为裁的是本步 Newton 增量而不是整步转角；能量把悬挂杠杆焊回 DCD。不要再给 type-3 加 vs `qStart` / vs `pStart` 的 wrap 恢复能量 |
| type-3 刚体 wrap Hessian-only（`C0=0`，`jLin=0`，`jAng=n_live×r_hanging`，无恢复力） | 坐下覆盖焊：`boxFinalY` 2.860→**2.86814737**，`minDetF` 0.938→0.971，应变 0.09→0.069，0 芯。未跑夹持。悬挂杠杆上的角刚度抽出 7mm 切口；坐下覆盖包络需要这条转动零空间。不要再给 `n_live×r_hanging` 加 wrap Hessian / 扭转弹簧（含两向、仅角、闸 tilt） |
| type-3 粒子 3×3 把刚体 se(3) 柔度（`jLin=n`，`jAng=(p_i−p)×n`）串进 leftover AL 的 `ρ_eff` | 坐下覆盖焊且挤扁：`boxFinalY` 2.860→**2.86818242**，`minDetF` 0.938→**0.787**，应变 0.09→**0.285**，0 芯。未跑夹持。削弱粒子 leftover 份额后刚体把切口抽到 C=0，与只刚体 leftover 同类。不要再给 type-3 粒子端 Schur `ρ` / 刚体转动柔度 / `ρ/4` |
| type-3 Position-AL 粒子 commit 后按平移质量把 n 向抽出 undo 给刚体 | 坐下第 0 帧炸：`boxY~1.79e14`，`minDetF~-1e26`，芯 8，`fatalErrors=1`。线搜索接受后 undo 粒子 n 分量，离开 tet 域。不要再给 type-3 在 tet 接受后再 undo 粒子 / 事后平移对端 |
| type-3 Position-AL 线搜索前按平移质量帽粒子 opening，剩余 C 1D 平移牛顿在粒子色写刚体 | 坐下 15cm 覆盖包络：`boxFinalY` **3.01374173**，`minDetF` 0.967，应变 0.039，0 芯，leftover-open 2→9。未跑夹持。剩余 covering C 在粒子色写刚体，与跳过 leftover pHat / 只刚体 leftover 同类把盒子抬到 DCD 地板。不要再给 type-3 粒子色写刚体余量 / 平移质量 splitting（含线搜索前帽、jAng=0） |
| type-3 Position-AL 粒子 J 改 COM-free（`w_i−m_i/M`，非入射粒子 `−m_i/M`，能量/clip 同步；刚体 J 仍 `−n`） | 坐下覆盖焊：`boxFinalY` **2.86813807**，`minDetF` 0.972，应变 0.070，0 芯，leftover-open 2→**0**（切口未形成）。未跑夹持。坐下 7mm nick 就是 covering 沿 n 的体积 COM 抽出；COM-free 把那份交给刚体。与 se(3) ρ_eff / 只刚体 leftover 同类。不要再给 type-3 粒子端去 COM / 体积平移零空间 / `w−m/M` |
| type-3 夹多边形侧脸内部 first-entry（`away>1mm`，只裁 `dth`，仅平移已有内部则闲置） | 坐下官方 PASS 但不逐位：`boxFinalY` 2.860→**2.85891008**，`minDetF` 0.938→0.955，应变 0.09→0.089，0 芯。未跑夹持。坐下 7mm 切口的夹多边形已经有侧脸内部；相对仅平移的转动 first-entry 仍开火。与占用竖棱 / 盒棱内部 first-entry 同一覆盖切口。不要再给夹多边形侧脸内部 / away 门槛加 first-entry clip |
| type-3 刚体 wrap 能量改打包平行棱×三角内部 t：`C=t(p,qStart)-t(p,q)`，`jLin=0`，质心 AL/clip 不变 | 坐下 FAIL：`boxFinalY` 2.860→**0.349996954**，0 芯，`minDetF` 0.590，应变 0.42。完整三角棱参数相对 `qStart` 仍是恢复力矩，把盒子拧离 7mm 切口后掉穿。与悬挂杠杆 vs `qStart` 同一家族。不要再给 type-3 加 vs `qStart` / vs `pStart` 的打包平行棱 t 能量 |
| type-3 刚体 clip 只裁 `dth`：打包平行棱×三角内部 t 不得差过仅平移候选 | 坐下覆盖焊：`boxFinalY` 2.860→**2.86816096**，第 9 帧芯 2，`minDetF` 0.938→0.908，应变 0.09→0.040，`minY=1.087`。坐下覆盖切口的转动会加深竖棱 t；dth-only 不是坐闲置信号（死 193 的 min-gap 才是）。完整三角棱 t 就是覆盖 nick 生长。不要再给打包平行棱 / 竖棱 t 加 first-entry / don't-increase / dth clip |
| type-3 刚体 clip 只裁 `dth`：非线性质心 C（`candidateGap`）不得差过仅平移候选 | 坐下逐位 `2.86057591` / `minDetF=0.938481927` / 应变 0.091777429（闸闲置或与基线同轨迹）。夹持更差：首次 82→**76** 体积 A/+X，芯 2→5，角点入体 0→2，互穿 6→0，`boxFinalY` 1.94→3.31，`|ω|≈1.46`。冻转动加深质心 C 把夹层拧进竖棱；与死 193 min-gap dth clip 同一剪切。不要再给 type-3 质心 C / row C / candidateGap 加刚体-only `dth` clip |
| type-3 粒子 clip 打包平行棱×三角内部 t 不许变差（刚体仍质心 clip，能量仍质心 AL） | 坐下逐位 `2.86057591` / `minDetF=0.938481927`（闸闲置：坐下 t 生长是刚体转动）。夹持更差：首次 82→**81** 体积 A/+X，芯 2→11，角点入体 0→4，互穿 6→12，`maxInsideParticles` 0→1，`minY→0.0002`，`|v|≈4.24`，`|ω|≈2.43`。挡住粒子绕行后 leftover AL 把力卸到刚体竖棱。刚体 dth t clip 抽出坐下切口，粒子 t clip 拧夹层；不要再给打包平行棱 t 加单端 clip |
| type-3 Position-AL 刚体面心改 `qStart.rotate(r)`（`jAng=0` 整步，clip 同步只用平移） | 坐下官方 PASS 但不逐位：`boxFinalY` 2.860→**2.86074853**，`minDetF` 0.938→0.946，应变 0.09→0.086，0 芯。夹持更差：首次 82→**56** 体积 A/−Y 棱，芯仍 2，角点入体 0→1，`minDetF` 撞 0.05，`|ω|≈10.1`，`|v|≈7.25`，`boxFinalY` 1.94→1.42。冻 DCD 面心不让 leftover C 随倾角卸载，对颌把转动零空间打进竖棱。不要再给 type-3 用 `qStart` 刚体面 / 整步 `jAng=0` / 不认 live `q.rotate(r)` |
| type-3 Position-AL 刚体 clip 不保留粒子 `pHat`（把 leftover `C<0` 当非芯重叠） | 坐下官方 PASS 但是 15cm 覆盖包络：`boxFinalY` 2.860→**3.01638937**，`minDetF` 0.938→0.929，应变终值 0.039，0 芯。未跑夹持。leftover SAT<0 时刚体 clip 保留粒子惯性余量是坐下 7mm 切口的负载；拿掉后 leftover AL 把盒子抬到 DCD 地板。不要再给 type-3 刚体 clip 跳过 leftover `pHat` / 把 AL 残差当非芯 |
| type-3 热启动粒子 clip 完整三角 min-gap don't-worsen（primal 仍质心 AL/clip） | 坐下逐位 `2.86057591` / `minDetF=0.938481927`。夹持更差：首次 82→**17** 体积 A/+Y，芯 2→4，角点入体 0→1，互穿 6→0，`boxFinalY` 1.94→1.72。惯性准入的 3 支持 min-gap 挡住对颌闭合，leftover AL 提前拧进芯。不要再给 type-3 加热启动 / 惯性准入 min-gap companion（含只粒子、只刚体） |
| type-3 Position-AL 粒子 primal 把刚体 `pHat` 余量加进 leftover C（assemble/energy/clip） | 坐下覆盖焊：`boxFinalY` 2.860→**2.86806226**，`minDetF` 0.938→0.894，应变终值 0.039，0 芯。未跑夹持。粒子先扫时 leftover 追刚体惯性面，抽出 7mm 切口。offset 井 primal 必须读 live 刚体；leftover Position-AL 同样不能在 primal 重放刚体 `pHat`。不要再给 leftover 粒子 primal 加对端惯性余量 |
| type-3 粒子 C0=0 切向 Hessian（仅 leftover 质心 `C>0`） | 坐下官方 PASS 但不逐位：`boxFinalY` 2.860→**2.86095953**，`minDetF` 0.938→0.938，0 芯。夹持更差：首次 82→**16** 体积 B/−Y，芯 2→10，角点入体 0→3，互穿 6→18，`maxInsideParticles` 0→2，`minDetF` 0.466→0.146，`|ω|≈21.6`，`|v|≈14.9`。张开 leftover 的切向绕行是对颌闭合的零空间；挡住后 leftover AL 把盒子拧进 −Y。不要再给 type-3 加 `C>0` / 张开 leftover 的粒子切向 Hessian（含 Coulomb 变体） |
| 动态 leftover Position-AL 粒子改后于刚体的 GS 色（offset 井仍粒子先） | 坐下覆盖焊：`boxFinalY` 2.860→**2.86801386**，`minDetF` 0.938→**0.734**，应变 0.09→**0.325**，0 芯。未跑夹持。刚体 leftover AL 对着未动的 leftover 粒子抽出 7mm 切口。整岛刚体先已死；leftover-only 后置色是同一抽出。异构 GS 必须整段粒子先、刚体后 |
| type-3 Position-AL 跳过 Eq.16 leftover ρ 增长（λ 仍更新，ρ 钉在 1e5） | 坐下近逐位：`boxFinalY` 2.860→**2.86057687**，`minDetF` 0.938→0.956，0 芯。夹持更差：首次 82→**56** 体积 B/−X，芯 2→10，角点入体 0→2，`minDetF` 0.466→0.401。冻 leftover ρ 让绕行更早卸到侧脸。不要再给 leftover Position-AL 冻 ρ / 跳过 Eq.16 |
| 相交三角粒子 Eq.21 不再编 packed-n `bound=0`（只靠 leftover 质心 clip；静盒仍编） | 坐下覆盖焊：`boxFinalY` 2.860→**2.86810184**，`minDetF` 0.938→0.970，应变 0.09→0.064，0 芯。未跑夹持。相交顶点 `bound=0` 是坐下 7mm 切口的负载；拿掉后 leftover AL 沿 n 抽出切口。不要再给动态相交三角跳过粒子 Eq.21 `bound=0` |
| 每 sweep 把 leftover type-3 n 改成夹多边形质心 live SDF 面（闸：夹心 sdf<-1e-5 且 face≠DCD packed，能量仍 1/3，`r∥n`，闲置则还原 DCD n） | 坐下掉穿：`boxFinalY` 2.860→**0.349943489**，`minDetF` 0.938→0.610，应变 0.09→0.254，0 芯。未跑夹持。坐下覆盖 nick 的夹心已在满盒内；Rim 上 SDF 面离开 packed 后 live n 与死 86 / vs `qStart` 同类把盒子拧离 7mm 切口。不要再给 leftover type-3 加 live clip-centroid / live SDF n（含 own≠packed、夹心 inside、还原 DCD） |
| primal 粒子 clip 贴面 leftover（DCD 夹心 sdf>=-1e-5）在 AlC<0 时去掉切向（只留 packed n，热启动仍带惯性切向） | 坐下逐位 `2.86057591` / `minDetF=0.938481927`。夹持芯 2→**0**、角点 0、互穿 6→4、`minDetF=0.465676427` 仍逐位、`minY→0`、`boxFinalY` 1.94→1.63。挡住贴面 leftover 切向绕行后三角不再进 1cm 芯，但夹层塌到地面；芯 0 是饿死 leftover wrap 的假绿（死 172 / leftover remaining don't-decrease）。张开 leftover（C>0）切向已是对颌（死 212）；相交 leftover 切向同时是 L-cut 和夹层持力。不要再给贴面 leftover 加粒子切向 clip / 切向 Hessian（含只 packed-parallel t） |
| 贴面 leftover（DCD 夹心 sdf>=-1e-5）改夹多边形重心权重（覆盖 nick 仍 1/3） | 坐下逐位 `2.86057591`。夹持更差：首次 82→**87** 体积 B/−X，芯 2→**4**，互穿 6→0，`minDetF` 仍 0.465676427，`minY→0.014`，`boxFinalY` 1.94→2.19。削弱 leftover 悬挂质心 C 就是饿死 leftover AL；切向仍绕行进芯。死 185 闸是质心在盒外（覆盖 nick 开火）；夹心 sdf 闸坐下闲置但仍不能当 leftover 查询。不要再给贴面 leftover 换夹心/夹多边形重心权重 |
| primal 粒子 clip 贴面 leftover 正交面矩形 first-entry（夹心 sdf>=-1e-5，热启动仍带惯性切向） | 坐下逐位 `2.86057591`。夹持更差：芯 2→**3**、首次仍 82 B/−X、`minDetF` 0.466→**0.106**、`minY→0`、互穿 6→4、`boxFinalY` 1.94→2.23。L-cut 在 DCD 已是夹心（死 182），贴面闸看不见芯 graze；开火的是夹层贴面绕行，挡住后 leftover AL 把体积拍扁。不要再给贴面 leftover 加正交面矩形 / 侧矩形 first-entry 粒子 clip |
| primal 刚体 clip 贴面 leftover 正交面矩形 first-entry（热启动不裁） | 坐下逐位 `2.86057591`。夹持第 82 帧 dump / `minDetF=0.465676427` / 芯 2 / 互穿 6 / `boxFinalY=1.93863368` 与质心 AL 基线逐位相同。粒子先扫已让三角占用侧脸，刚体 first-entry `startHit` 闲置。L-cut wrap 是粒子运动。不要再给贴面 leftover 加刚体正交面 first-entry |
| 相交 type-3 夹多边形非打包面顶点 Eq.21 `bound=0`（DCD 冻结，三碰撞顶点分发） | 坐下覆盖焊：`boxFinalY` 2.860→**2.86814976**，`minDetF` 0.938→0.971，应变 0.09→0.069，0 芯。未跑夹持。坐下 7mm 切口夹多边形已占用正交面（竖棱生长）；跳过 packed 仍是覆盖投影。不要再给夹多边形正交面 / 非打包面加 DCD Eq.21 `bound=0`（含按面去重） |
| type-3 粒子 clip 打包正交盒棱×三角内部 first-entry（跳过 packed-parallel 竖棱，热启动不裁） | 坐下覆盖焊：`boxFinalY` 2.860→**2.86816382**，`minDetF` 0.938→0.972，应变 0.09→0.069，0 芯。未跑夹持。坐下切口占用打包面 Rim 棱，与 L-cut `hitLocal=(-0.5,-0.35,0)` 同属 packed-orthogonal。死 145 正交面 / 死 161 竖棱 / 死 189 SAT 轴家族 同一覆盖投影。不要再给盒棱按平行/正交轴分覆盖与 L-cut |
| primal 粒子 clip 夹心 type-3（DCD 夹多边形质心 sdf<-1e-5）AlC<0 时去掉切向（热启动仍带惯性切向） | 坐下覆盖焊：`boxFinalY` 2.860→**2.86820102**，`minDetF` 0.938→0.921，应变 0.09→0.039，0 芯。未跑夹持。死 217 贴面 leftover 切向是夹层；夹心切向是坐下 7mm 切口本身。L-cut 与坐下 nick 同属夹心，冻切向就是覆盖抽出。不要再给夹心 type-3 加粒子切向 clip / 切向 Hessian |
| primal 粒子 clip 夹心 type-3 夹多边形质心 sdf 不许低于 DCD（能量仍质心 AL，leftover 不闸） | 坐下官方 PASS 但不逐位：`boxFinalY` 2.860→**2.86096883**，`minDetF` 0.938→0.953，0 芯。夹持芯 2→**0** 但是假绿：`boxFinalY` 1.94→**0.349976301**，`minY→0.017`，互穿 6→**10**，`minDetF` 0.466→**0.218**，应变 0.52→**0.710**。夹心厚度地板挡住颌闭合，悬挂质心 AL 把夹层拧穿。死 186 全体 type-3 打包板 don't-deepen 同类对拉。不要再给夹心 / 满盒夹多边形质心 sdf 加 don't-deepen vs DCD / vs live |
| 夹心-only 夹多边形重心 k=1e5 井 + 跳过贴面 leftover type-3（packed n，`r∥n`，满盒 clip） | 坐下 FAIL：第 3 帧芯 3，`boxFinalY` 2.860→**2.86805058**，`minDetF` 0.938→0.972，应变 0.09→0.060。未跑夹持。死 185 留 leftover AL，死 172 留 1/3 夹心 AL；焊在一起仍是第 3 帧进芯。夹心井自己抽出 7mm 切口并穿 1cm 芯，不是 leftover 对拉。不要再给相交 type-3 加夹心 compact 井，也不要把跳过 leftover AL 当它的配对 |
| 相交 leftover Eq.21 n 改 pair-union packed、partner 改打包面心（bound 仍 0） | 坐下 15cm 覆盖包络：`boxFinalY` 2.860→**3.01512766**，`minDetF` 0.938→0.970，应变 0.09→0.063，0 芯。未跑夹持。悬挂质心当刚体锚是坐下 7mm 切口负载；面心 `r∥n` partner 抽出切口。与刚体 clip 跳过 leftover `pHat` 同类。不要再给相交 Eq.21 换面心 / COM partner |
| 相交 leftover Eq.21 只改 n 为 pair-union packed（partner 仍悬挂质心，bound=0） | 坐下掉穿：`boxFinalY` 2.860→**0.349986672**，`minDetF` 0.938→0.908，应变 0.09→0.145，0 芯。未跑夹持。坐下覆盖 nick 的质心 SDF 已不是 pair packed；强制 packed n 与死 216 live leftover n 同类拧离切口。不要再给相交 Eq.21 对齐 type-3 packed n |
| 相交 leftover Eq.21 逐顶点盒 SDF n，partner 改该顶点盒面最近点（bound=0） | 坐下 15cm 覆盖包络：`boxFinalY` 2.860→**3.01291299**，`minDetF` 0.938→0.970，应变 0.09→0.068，0 芯。未跑夹持。盒面 partner 不是面心也抽出切口；与死 226 同类。不要再给相交 Eq.21 换盒面 / 最近点 partner |
| 相交 leftover Eq.21 逐顶点盒 SDF n，partner 仍悬挂质心（bound=0） | 坐下覆盖焊：`boxFinalY` 2.860→**2.86807704**，`minDetF` 0.938→0.967，应变 0.09→0.067，0 芯。未跑夹持。贴面顶点自身 SDF 已是 packed；拆开悬挂质心混合法向就是死 227 的 packed n。悬挂质心 SDF n 与悬挂质心 partner 必须成对。不要再给相交 Eq.21 换逐顶点 SDF |
| primal 粒子 clip 对颌闸冻夹心 type-3 切向（DCD 夹多边形质心 sdf<-1e-5，AlC 已进芯，同刚体另一体积 packed n 点积<0） | 坐下逐位 `2.86057591` / `minDetF=0.938481927`（单体积无对颌）。夹持更差：芯 2→**4**，互穿 6→**10**，`minY→0`，`minDetF=0.465676427` 仍逐位，`boxFinalY` 1.939。夹心切向在对颌上仍是颌面滑动（死 223 无闸是覆盖焊）；冻它把载荷卸进更多芯命中。不要再给夹心 type-3 加对颌/夹层/other-pair 闸的粒子切向 clip |
| 夹心 type-3 n 改 DCD 夹多边形质心 SDF 面（贴面 leftover 仍 pair packed，`k=0` 1/3 `r∥n`） | 坐下逐位 `2.86057591`。夹持第 82 帧 dump / `minDetF=0.465676427` / 芯 2 与基线逐位相同（DCD 夹心 SDF 仍是颌面），事后互穿 6→8、`minY→0`、`boxFinalY` 1.94→2.67。Rim 与 graze 同时翻；冻结 DCD 夹心 SDF 与死 183 leftover DCD AABB min-exit n 同类看不见步内 L-cut。不要再给夹心 type-3 换 DCD 夹心 SDF / clip-centroid n（含 own≠packed 闸） |
| primal 粒子 clip 夹心 type-3 live 夹多边形质心 SDF 面离开 packed 颌后 don't-worsen 该 SDF vs current（DCD compact 才闸，能量仍悬挂质心 AL） | 坐下逐位 `2.86057591` / `minDetF=0.938481927`（单体积 SDF 仍是颌面，闸闲置）。夹持更差：芯 2→**4**，互穿 6→**10**，`minY→0.252`，`minDetF=0.465676427` 仍逐位，`boxFinalY` 1.940，第 82 帧仍 B/−X leftover。夹心质心 SDF 翻 Rim 与 graze 同时发生，但 clip 的是夹层颌面滑动（对颌冻切向同类），不是悬挂顶点仍在盒外的完整三角穿芯。不要再给夹心 clip-centroid 加 live SDF 面≠packed 的 iso / sdf / remaining 闸 |
| primal 粒子 clip 夹心 type-3 禁止 live 夹多边形占用 DCD 没有的盒棱（DCD compact 才闸，能量仍悬挂质心 AL） | 坐下覆盖焊：`boxFinalY` 2.860→**2.86800861**，`minDetF` 0.938→0.972，应变 0.09→0.069，0 芯。未跑夹持。坐下夹心 nick 在 GS 里仍新占 Rim 棱；leftover 形成切口之后 compact 仍会长棱。与死 222 完整三角×棱 first-entry / 死 137 clip-polygon remaining 同一覆盖投影。不要再给夹心 clip-polygon 加 new-edge / 盒棱占用 vs DCD 或 vs current |
| 相交 type-3 满盒夹多边形质心 sdf 比悬挂质心更深时改夹多边形重心权重（仍 `k=0` packed n `r∥n` 1 行） | 坐下覆盖焊：`boxFinalY` 2.860→**2.86813569**，`minDetF` 0.938→0.972，应变 0.09→0.071，0 芯。未跑夹持。坐下 7mm 切口已经内部比悬挂深（悬挂在盒外或更浅）；闸就是覆盖查询。与死 184 leftover 夹心权重 / 死 102 夹心当查询同类抽出切口。不要再给 type-3 用 hanging-vs-clip 深度、内部比悬挂深、或质心在盒外换夹心权重 |
| primal 粒子 clip 夹多边形尖点（最深夹顶点 iso sdf < 夹心质心 sdf，且 live SDF 面与 DCD packed |n·n|<0.5，don't-worsen 该 sdf，能量仍悬挂 1/3） | 坐下逐位 `2.86057591`。夹持第 82 帧 dump / `minDetF=0.465676427` / 芯 2 / 互穿 6 / `boxFinalY=1.93863368` 与基线逐位相同。各向同性「比质心更深」要求 Rim 尖点比打包切口还深才开火，窗口与 graze 同时。不要再给夹多边形顶点加 vs 夹心质心的 iso sdf 尖点 / n≠packed 闸 |
| primal 粒子 clip 三角上距盒心最近点（sdf<-1e-5 且 live SDF 面≠DCD packed，don't-worsen 该 sdf，能量仍悬挂 1/3） | 坐下逐位 `2.86057591`。夹持第 82 帧 dump / `minDetF=0.465676427` / 芯 2 与基线逐位相同：盒心最近点在 Rim 面上 sdf≈0，Gu 证人是 packed–Rim 棱附近的三角内点。事后互穿 6→**20**、`maxInsideParticles` 1。不要再给三角∩盒心最近点加 n≠packed iso sdf 闸 |
| primal 粒子 clip 夹心 type-3 质心被非打包面限制时 don't-increase 该轴夹多边形顶点 max remaining（能量仍悬挂 1/3） | 坐下逐位 `2.86057591`（质心 packed-limited，闸闲置）。夹持更差：芯 2→**6**，首次 82→**117** 体积 A/+X，`minDetF` 0.466→**0.170**，`minY→0`，互穿 6→8，角点入体 1，粒子入体 1，`boxFinalY` 1.942。graze 质心仍 packed-limited，尖点朝芯加深 packed rem；Rim-limited 后 don't-increase rem 挡住夹层朝中面恢复。不要再给 Rim-limited / 非打包面限制质心加轴 remaining don't-increase |
| primal 粒子 clip packed-limited 三角∩满盒 Chebyshev 深度 don't-increase vs current（均匀侵蚀 r，能量仍悬挂 1/3） | 坐下覆盖包络：`boxFinalY` 2.860→**3.01462555**，应变 0.09→0.126，0 芯。未跑夹持。第一次 clip 的 current r=0，冻住第 0 帧 GS 长出的 7mm 切口。完整三角相对满盒的 Chebyshev 深度就是覆盖切口。不要再给三角∩盒均匀侵蚀 / Chebyshev 深度加 don't-increase vs current |
| primal 粒子 clip packed-limited 三角∩满盒 Chebyshev 深度 don't-increase vs DCD（Gu 均匀侵蚀 r 存进 feature，能量仍悬挂 1/3） | 坐下覆盖包络：`boxFinalY` 2.860→**3.01356435**，`minDetF` 0.938→0.970，应变 0.09→0.067，0 芯。未跑夹持。DCD Gu 相交已是贴面 graze（r≈0）；7mm 切口是悬挂质心 AL 在 GS 里从 graze 长出的平衡，不是 DCD 事实。冻 DCD r 与冻 current r 同一抽出。不要再给三角∩盒 Chebyshev 加 don't-increase vs DCD / vs packing epoch |
| primal 粒子 clip 三角∩满盒 Chebyshev−夹心质心 remaining 的 spike excess don't-increase vs current（能量仍悬挂 1/3） | 坐下覆盖包络：`boxFinalY` 2.860→**3.01567459**，`minDetF` 0.938→0.958，应变 0.09→0.065，0 芯。未跑夹持。7mm 切口在 GS 里已经是内部比夹心质心深的尖点（与死 232 hanging-vs-clip 同构）。不要再给 Chebyshev−质心 / 内部比夹心深加 don't-increase |
| primal 粒子 clip 三角∩满盒最深点两轴（立方体二面）时 Chebyshev remaining don't-increase vs current（能量仍悬挂 1/3） | 悬挂三角采样：坐下逐位；夹持 dump/`minDetF`/芯 2 逐位，事后 `minY→0`。夹多边形扇形采样：坐下 y **2.85874796**（坐下 nick 占用 packed 面 Rim 棱时夹心采样两轴）。L-cut 对角与坐下 Rim 占用同属二面。不要再给最深点两轴 / 立方体对角 Chebyshev 加 don't-increase |
| primal 粒子 clip 三角∩满盒 Chebyshev don't-increase vs current，闸是同刚体另一体积 type-3 对向 packed n | 坐下逐位 `2.86057591`。夹持首次 82→**132**，芯 2→**4**，互穿 6→4，`minDetF=0.465676427` 仍逐位，`boxFinalY` 1.94→**3.327**。对向 n 等到第二颌编出 type-3；L-cut 已在第一颌长成，开火把盒子抬离夹层。不要再给对向 packed n / 等第二颌 type-3 加完整三角 Chebyshev |
| primal 粒子 clip 三角∩满盒 Chebyshev don't-increase vs current，闸是岛内耦合体积≥2 | 坐下逐位 `2.86057591`。夹持首次 82→**13** A/+Y 覆盖，芯 2→**8**，角点入体 3，粒子入体 1，互穿 23，`minDetF` 0.466→**0.299**，`boxFinalY` 1.73。两体积从第 0 帧就在，第一颌 graze 冻覆盖切口。不要再给两体积/夹层岛加完整三角 Chebyshev |
| 双体积岛 type-3 改夹多边形重心权重（`k=0` packed n `r∥n`，单体积仍 1/3） | 坐下逐位 `2.86057591`。夹持首次 82→**22** A/+Y 覆盖，芯 2→**11**，角点入体 3，互穿 6→0，`minDetF` 0.466→**0.776**，`boxFinalY` 2.07。夹心查询仍是覆盖抽出；两体积第 0 帧焊第一颌 graze。不要再给两体积/夹层岛换夹心/夹多边形重心查询 |
| primal 粒子 clip 夹心质心 sdf don't-increase vs current，闸是 leftover-open（悬挂 sdf>0 且夹心 sdf<-1e-5）+ 同刚体另一体积 type-3 `λ<0` | 坐下逐位 `2.86057591`。夹持首次 82→**91**，芯 2→**12**，角点入体 1，互穿 6→0，`minY→0`，`minDetF=0.465676427` 仍逐位。L-cut 在 leftover-open 之前已长成（`minDetF` 逐位）；开火后与悬挂 AL 对拉。不要再给 leftover-open / 对颌 λ / 夹层载荷加夹心质心 sdf don't-increase |







| 质心 Position-AL 的 AlC 改打包面三顶点盒局部 AABB（J/clip 仍质心） | 坐下 PASS 但不精确（y 2.860→2.868，应变 0.09→0.070）。无闸夹持第 57 帧芯 7、角点 2、`minDetF` 地板、`|ω|≈4`：切顶跨 x 三角质心 C>0，AABB 14mm 开火，对侧闸看不见切向贯穿。仅质心 C<0 才升级：夹持提前到第 15 帧芯 3。覆盖矩形闸坐下第 114 帧芯 2；覆盖+|C<0| 坐下仍 y 2.868。顶点沿冻结 n 看不见三角内部切盒，却看得到跨面切口；与冻结 n 最小顶点同类 |
| 质心已侵入时 AlC=夹多边形沿冻结 n 最深点（对侧回退、角点在盒内回退、不得弱于质心，J/clip 仍质心） | 坐下 PASS 但不精确（y 2.868）。夹持更差：第 120 帧芯 6、角点 1、边界互穿 4、`minDetF` 地板。与「质心 C>0 时夹多边形最深点」同一冻结 n 无限平面：坐下覆盖切口三顶点在盒外时夹多边形仍比质心深 7mm；夹持颌面贯穿把盒子拧进对侧。角点在盒内闸挡不住全顶点在外的面穿。不要再给夹多边形最深点加覆盖矩形 / 中面 / 1cm 带 |
| primal 粒子 clip 三角∩满盒内部两轴 min-sdf don't-increase vs current（能量仍悬挂 1/3） | 最深点再测两轴：坐下逐位；夹持首次 82→137、芯仍 2、`minDetF` 仍 0.465676427。进芯点相对满盒可以是单轴（距一面 1cm）。只计两轴内部样本（1mm 相等、近盒棱夹顶点向质心）：坐下掉穿 y=0.50、`minDetF` 地板、0 芯假绿。坐下 Rim 棱占用的近棱内部已是两轴，与死 246 扇形采样同类。不要再给内部两轴 / 近棱夹多边形样本加 min-sdf don't-increase |
| type-3 `|n_tri·packed|` don't-decrease vs DCD（能量+primal，ρ 跟 type-3 AL，悬挂 1/3 不变） | 坐下官方 PASS 但不逐位：y 2.860→**2.86153531**，`minDetF` 0.939，应变 0.094，0 芯。夹持更差：首次 82→**61** 体积 A，芯 10，角点入体 1，互穿 0，`minY→0.008`，`minDetF` 0.692。第一颌 graze 的三角朝向变化就是覆盖抽出；1mm 坐下位移已焊夹持。不要再给 type-3 加 vs DCD / vs current 的 packed-alignment / 三角法向朝 packed 的能量、Hessian 或 clip |
| DCD 软软棱×三角穿刺 Position-AL（`k=0`，内侧端点 vs 面 1/3，冻结 DCD 外向 n，featureType 2） | 坐下逐位（单体积无软软行）。夹持第 82 帧 dump / 芯 2 与基线逐位；事后 `minDetF` 地板 **0.05**，应变 **1.14**，互穿 6→4，`boxFinalY` 1.939。沿对面外向 n 拉开穿刺端点就是夹层加压。不要再给软软棱×面穿刺加 AL（`k=0` 或 `k>0`，端点或质心，冻结或 live n）。同一拓扑的 Eq.21 也按夹层加压处理，不要再试 |
| 预测位姿软软 VF/EE DCD（当前位姿之外再在 pHat 上编 VF/EE，按 feature key 去重） | 坐下逐位 `2.86057591`。夹持芯仍 2、`minDetF=0.465676427` 仍逐位，互穿 6→**8**（首次 132），`boxFinalY` 1.940，`minY→0.0028`。L-cut 三角已是 leftover type-3；漏的不是软软 VF/EE。pHat 窄相是投机 DCD / 第二 epoch。不要再给软软 VF/EE 加预测位姿候选 |
| 夹心闸完整三角 Chebyshev inset don't-increase vs DCD（DCD inset>1e-5 才冻，能量仍悬挂 1/3） | 坐下 FAIL `boxFinalY` **0.499999493**，0 芯，`minDetF` 0.964。DCD graze 均匀侵蚀已经 >1e-5，闸冻 r≈0，与无闸 vs DCD 同一抽出后 leftover AL 对拉塌穿。不要再给 Chebyshev / 均匀侵蚀加 compact / clipSdf / inset>ε 闸 vs DCD |
| 非相交完整三角 offset-shell 悬挂质心 Position-AL（`k=0`，`margin=box.margin`，`!hasTriangleCore`，三顶点在壳外才编） | 坐下不逐位：无顶点壳闸 y **2.86036158** / `minDetF` 0.956；顶点在壳则跳过、再限动态盒均为 y **2.85823512** / `minDetF` 0.956103。未跑夹持。坐下动态盒的 VF 盲区裙就是「接近但不相交」；静盒闸改不了这条抽出。不要再给非相交完整三角加 offset-shell 悬挂 AL（含动态-only、顶点在壳外、无相交 patch） |
| leftover-open 闸 type-3 粒子 clip Chebyshev don't-increase vs DCD（悬挂 sdf>1e-4 且夹心 sdf<-1e-4 才冻 DCD 均匀侵蚀） | 坐下覆盖焊 y **2.86805153** / `minDetF` 0.968 / 应变 0.069 / 0 芯。未跑夹持。坐下 DCD t=0 leftover-open=0，切口是第 0 帧 GS 长出；onset leftover-open 的 inset 仍是 graze 量级，冻它抽出 7mm 切口。夹持 leftover-open 第 11 帧已 2、芯在 82，闸本身早，但坐下已死。不要再给 leftover-open / 悬挂在外夹心在内加 Chebyshev vs DCD |
| leftover-open 闸跳过 type-3 刚体 clip 粒子 `pHat` 余量（packed SAT 仍闭、悬挂在外） | 坐下逐位 `2.86057591`。夹持更差：首次 82→**64** A/+Y，芯 6，角点入体 2，`minDetF` 0.135，`|v|≈5.87`。无闸跳过是 15cm 包络；leftover-open 闸丢掉第一颌闭合惯性。坐下 leftover-open 首次夹心 **-0.87mm** / Chebyshev **1.5mm**，夹持第 11 帧 **-4.9mm** / **5mm**；onset 不是 7mm 成熟切口。不要再给 leftover-open type-3 跳过粒子 `pHat` |

Chebyshev 不是必须的。AVBD_2 冲击帧本来就关它；demo3d / webphysics 没有。
