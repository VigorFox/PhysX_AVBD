# 有界数值核接入 Host：实际发布已接，长跑仍未通过

本轮完成显式 `PHYSX_AVBD_COMMON_STEP=bounded` 的 PhysX dispatcher 接入。主方向、可选二阶修正（SOC）、完整 H 驻点证书都经过同一个有界 Table 核，并消费同一个可挂起的共同发布流程。小场景取得实际位姿／反力发布资格；**反作用和完整五体尚未取得新路径的长跑资格，默认入口不变**。

## 实现边界

- `DyAvbdDynamics.cpp` 复用现有 fan-in continuation 和 PhysX worker。每个数值批次最多 32 项，一次分发最多 32 个批次；worker 不等待子任务、不无界抢单。同色任务全部完成后才推进下一波，色间仍是 GS。
- `DyAvbdSolve.cpp` 将原共同候选整理为可恢复流程。数值请求结束后继续原量化、完整几何、真实材料／功及位姿／反力验收。strict／local／patch 与 bounded 共用发布代码；新路径不构造旧稀疏分解，不调用旧整组 PCG，也没有失败回退。
- 数值状态及候选仅是本次求解的 scratch；原物理状态仍在已有 body／row 中。最终 Host 发布与 BDF 仍各一次。SOC 不成功时只恢复原已求出的共同方向，不能发布失败反力。
- 完整 H 证书同样使用有界着色块解，保留原 `max(1e-14, 1e-12 * ||rhs||∞)` 的真实残差要求。H-only 请求删除无意义的接触阶段，并复用已编译的 3／6 维对角逆。1024 扫描上限不变。
- 完整候选使用直接位姿索引，避免小组稀疏 view 在每次读位姿时扫描数百个 body。

这只证明数值批次有界及 CPU 任务接入。编译／装配、候选与几何验证、部分 continuation 控制和最终 BDF 尚未全部分片；GPU 尚未接入。不能把单批有界解释成任意场景的常数帧时间，也不能宣称端到端并行有界已经完成。

## 修正了一个实际量化偏差

共同 SQP 候选没有球半径限制，却复用了有限球域的“向球心舍入”。在 y≈26 的实际输入中，约 `-1.829e-6 m` 的下降方向被截成零；附近可表示位移约为 `-1.907e-6 m`。把无半径域先量化到最近 float，再验原半空间，能够保留这个下降方向。有限球仍向内舍入；原完整路径和功验收不变。

独立惯性目标反例的平方误差由 `3.34617e-12` 降到 `6.09872e-15`，同时验证有限半径约束仍有效。precise／fast 均通过。

修正前，完整五体前 13 帧闭合，第 14 帧第 16 轮因实际功不下降而拒绝；其同一冻结 H/J 已通过原严格根。捕获同时显示微小单元的大角响应和 float 平移量化互相耦合，因此不能把所有剩余停滞都归于这个舍入偏差。修正后确实越过该拒绝点，但后续仍反复缩步、耗尽非线性轮数；没有把原失败改写为完整长跑通过。

## 已通过的检查

| 检查 | 结果及适用范围 |
|---|---|
| Checked PhysX 构建、smoke | PASS |
| 原冻结矩阵 precise／fast、1／4 线程、重排与初猜 | 72／72 PASS；原 135／240／280 及扩展 280 保留资格 |
| 有界机制及 257 块硬链 | precise／fast PASS；预算、支持／颜色拒绝保留 |
| 完整 H 证书 | `1e-8 / 1 / 1e8` 尺度，1／4 线程，precise／fast 均通过独立完整算子残差 |
| 共同实际发布 | bounded 的 0／1／4 worker 各 7 项正例与 1 项初始重叠拒绝，共 24 项 PASS |
| 129 体解析链 | 0／1／4 worker 均 PASS；四 worker 实测 peakTasks=4，258 个提交任务、654 个数值批次；独立位姿、BDF、动量检查通过 |
| 旧 strict／patch 发布 | 各 8 项 PASS，发布流程重构未破坏这些合同 |
| NP 几何与零响应排除 | bounded／patch 各 16 项 PASS；其中禁用响应的重叠是预期排除合同，不是非穿透保证 |
| 公共 HelloWorld／Joint／ArticulationRC | AVBD／PGS／TGS 九组 PASS |
| 原 patch 反作用 360 帧 | PASS；360 帧全部 stationary，外部穿透观测 0，动量相对误差约 0.002686 |

数值与小发布门禁不能代替下列真实长跑。最后一轮部分验证同时执行，不作为性能对比数据。

## 新路径剩余失败

**反作用：第 22 帧数值预算耗尽。** 新路径已接受 21 帧、全部驻点闭合，随后 126 块／756 DOF／2880 行在 1024 次扫描后仍有约 `8.01e-10` 原数值误差，明确拒绝发布。相同冻结输入 precise 回放也失败：活动缺陷约 `4.04e-11`，相对力平衡约 `7.58e-10`。这说明不能只看接触 gap 很小便放行。

该捕获的非零接触均有两个动态支持，现有单动态支持的局部反力交换不能直接覆盖它；但这只是明确的覆盖差异，尚未证明是唯一根因。一次失败数值请求已经产生 763998 个固定批次、524358 个提交任务，暴露出收敛成本和分发成本同时需要降低。没有增加 1024 上限或放宽原根。

真实残差割线、附加力平衡权重、QR 截断改成机器精度、提前加入更小遗漏行四种试验均未关闭该输入，已全部撤回。所保存的原失败输入与试验结果应继续用于机制验证，不能只重跑此前 72 组绿例。

另对生产适配做了工程方向证书试验：复用旧 local SDK 的全部原行检查与 `0.1 * motionTolerance` 完整 H 修正界，证书仍由有界核严格求解，失败从同一状态继续剩余预算，没有修改冻结标准。严格局部缺陷触发版与工程尺度触发版都仍在第 22 帧失败；后者在前一帧耗尽 32 个非线性轮次，总耗时约 18.50 秒，而保留版的同一短跑约 4.41 秒。该试验已撤回。它确认“内层工程合格”不足以使真实接触域中的候选有效前进，不能仅放宽数值停止条件。工程方向资格仍是生产迁移缺口，不能反过来主张所有场景永久要求冻结严格精度。

**完整五体：最终在 120 秒上限处超时。** 原完整资产、Checked、grid=5、4 worker、目标 360 帧，实际接受 15 帧、拒绝 0，其中 14 帧 stationary、1 帧未闭合；第 16 帧尚在数值／候选迭代，没有最终场景 gate。该结果是 TIMEOUT，不是 PASS。原始记录见证据 manifest 和 `five-verified.json`。另一次最终构建长跑因执行环境重载而中断，日志名 `five-final.txt`，没有 summary；它不作为完成／超时资格。

当前 bounded 候选仍整程序共享回溯步长，尚未恢复旧 strict 路径按独立动态分量分别搜索的性质。跨块材料与接触仍完整，但不同分量的存储误差和几何拒绝会互相拖慢；这是生产迁移缺口，不是可长期保留的优化方案。

## 下一步

1. 先关闭新增双动态支持反作用捕获：在原 H/J 与单份 row dual 上验证有界多支持预条件／共同反力更新，明确冲突集与并行提交，不能搬回硬连通大组。工程停止适配须同时验证可发布方向，不能只降低内层残差要求。
2. 将共同候选与接受进一步局部化，至少恢复独立动态分量的搜索独立性；随后按既有 row/block 依赖分片装配、几何与功归约。不能用统一缩步长期阻塞全部软体。
3. 再跑反作用、完整五体及既有公开回归。只有数值、真实场景质量和成本分别通过，才能开放默认接管。Particle3 生产共同编译、初始恢复和 GPU 仍 OPEN。

## 复现与证据

```powershell
cmake --build physx/compiler/vc17win64-cpu-only --config checked --target PhysX --parallel 6
python tools/run_avbd_common_step_probe.py --mode bounded --threads 4 --chain-bodies 129 --logs <output>
python tools/run_avbd_bounded_convergence_probe.py --reports <output>
python tools/run_avbd_local_scene.py --mode bounded --case reaction --frames 360 --stats --stop-on-rejection --capture-failure <failure.json> --log <reaction.txt>
python tools/run_avbd_local_response_probe.py tools/fixtures/bounded-host-20261105/reaction-failure.json.gz --bounded --report <replay.json>
python tools/run_avbd_local_scene.py --mode bounded --frames 360 --threads 4 --timeout 120 --stats --stop-on-rejection --log <five.txt>
```

精选输入、结果、原始日志、最终源码快照及 SHA-256 存于 `tools/fixtures/bounded-host-20261105/manifest.json`。较大中间日志仍在忽略目录 `tools/benchmark-results/bounded-host-20261105/`。本轮没有自动 commit，也没有覆盖此前未提交的工作。
