"""Exercise actual opt-in pose/force publication, not a frozen capture."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

from run_avbd_ogc_certificate_probe import ROOT, run_probe

LIBRARIES = ("PhysXExtensions_static_64.lib", "PhysXPvdSDK_static_64.lib",
             "PhysX_64.lib", "PhysXCommon_64.lib", "PhysXCooking_64.lib")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--child", type=int)
    parser.add_argument("--overlap", action="store_true")
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--chain-bodies", type=int, default=12)
    parser.add_argument("--mode", choices=("strict", "local", "patch", "bounded"), default="strict")
    parser.add_argument("--logs", type=Path,
                        default=ROOT / "tools/benchmark-results/common-step")
    args = parser.parse_args()
    if args.child is not None:
        return run_probe(ROOT / "tools/avbd_common_program_scene_probe.cpp",
                         args=[str(args.child), "overlap" if args.overlap else "separated",
                               str(args.threads), str(args.chain_bodies)],
                         libraries=LIBRARIES)
    args.logs.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    # A frozen diagnostic call must never qualify physical publication.
    for key in list(env):
        if key.startswith("PHYSX_AVBD_COMMON_"):
            del env[key]
    env.update(PHYSX_AVBD_COMMON_STEP="1" if args.mode == "strict" else args.mode, PHYSX_AVBD_COMMON_STATS="1",
               PHYSX_NP_GEOMETRY_CERTIFICATES="2")
    failures = 0
    for mode, overlap in [(i, False) for i in range(7)] + [(0, True)]:
        cmd = [sys.executable, __file__, "--child", str(mode),
               "--threads", str(args.threads), "--chain-bodies", str(args.chain_bodies)]
        if overlap:
            cmd.append("--overlap")
        run = subprocess.run(cmd, env=env, capture_output=True, timeout=60)
        output = (run.stdout + run.stderr).decode("utf-8", errors="replace")
        name = "initial-recovery-rejected" if overlap else f"mode{mode}"
        (args.logs / (name + ".log")).write_text(output, encoding="utf-8")
        frames = [line for line in output.splitlines() if line.startswith("[AVBD_COMMON_FRAME]")]
        if overlap:
            ok = (len(frames) == 1 and "status=REJECTED" in frames[0] and
                  "poseForcePublications=0 bdf=0" in frames[0] and
                  "np_geometry_or_initial_recovery_uncompiled" in output)
        else:
            ok = (run.returncode == 0 and len(frames) == 1 and
                  "status=ACCEPTED poseForcePublications=1 bdf=1 stationary=1" in frames[0] and
                  "fetchedFinite=PASS" in output and "status=FAIL" not in output)
            if mode == 6 and args.mode == 'patch':
                ok = ok and 'groups=3 colors=2 maxBlocks=4' in output and '[COMMON_CHAIN]' in output
        failures += not ok
        print(f"[COMMON_STEP_TEST] case={name} status={'PASS' if ok else 'FAIL'}", flush=True)
    return int(failures != 0)


if __name__ == "__main__":
    raise SystemExit(main())
