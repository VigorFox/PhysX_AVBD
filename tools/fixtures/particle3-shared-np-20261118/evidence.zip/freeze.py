"""Freeze source/evidence after the final serial verification/performance run."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path(__file__).resolve().parents[3]
evidence = Path(__file__).resolve().parent
out = root / 'tools/fixtures/particle3-shared-np-20261118'
out.mkdir(parents=True, exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
verification = json.loads((evidence / 'verification-publish/summary.json').read_text())
benchmark = json.loads((evidence / 'reaction-ab-publish/summary.json').read_text())
assert verification['binariesUnchanged'] and benchmark['binariesUnchanged']
assert len(benchmark['runs']) == 18
assert all(verification['after'][p] == h for p, h in benchmark['after'].items())
sdk = Path(benchmark['sdk'])
assert all(sha(sdk / p) == h for p, h in verification['after'].items())
previous = json.loads((root / 'tools/fixtures/particle3-np-input-20261118/summary.json').read_text())
defaults = []
for item in previous['defaultProducts']:
    digest = sha(root / 'physx/bin/win.x86_64.vc143.md/checked' / item['file'])
    defaults.append(dict(file=item['file'], sha256=digest, unchanged=digest == item['sha256']))
assert all(p['unchanged'] for p in defaults)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root).decode('utf8').strip()

names = set(git('diff', '--name-only').splitlines())
names.update(git('ls-files', '--others', '--exclude-standard').splitlines())
names = sorted(n for n in names if n.startswith(('physx/', 'docs/')) or
               (n.startswith('tools/') and n.count('/') == 1))
manifest = [dict(path=n, bytes=(root / n).stat().st_size, sha256=sha(root / n))
            for n in names if (root / n).is_file()]
with zipfile.ZipFile(out / 'source.zip', 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for entry in manifest:
        archive.write(root / entry['path'], entry['path'])
(out / 'source-manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf8')
files = sorted(p for p in evidence.rglob('*') if p.is_file())
with zipfile.ZipFile(out / 'evidence.zip', 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for p in files:
        archive.write(p, p.relative_to(evidence).as_posix())
with zipfile.ZipFile(out / 'source.zip') as archive:
    assert archive.testzip() is None
    assert all(hashlib.sha256(archive.read(e['path'])).hexdigest() == e['sha256'] for e in manifest)
with zipfile.ZipFile(out / 'evidence.zip') as archive:
    assert archive.testzip() is None

summary = dict(scope='Shared NP schedule, mixed rows and one shared dual integrated; physical acceptance FAILED',
    head=git('rev-parse', 'HEAD'), iterations=4, productionSwitched=False,
    sharedNpScheduleIntegrated=True, mixedContactRowsIntegrated=True, sharedDualIntegrated=True,
    boundedNpPacketsPerTask=16, rigidSoftReactionQualified=False, softSoftReactionQualified=False,
    materialReleaseQualified=False, wholeStepCostQualified=False, parallelScalingQualified=False,
    gpuQualified=False, checks=len(verification['checks']),
    checksPassed=sum(c['passed'] for c in verification['checks']),
    failedChecks=[c['name'] for c in verification['checks'] if not c['passed']],
    executionAuditPassed=all(c.get('executionAuditPassed', True) for c in verification['checks']),
    defaultProducts=defaults, testedSdk=verification['after'],
    reactionBenchmarkMedians=benchmark['medians'], sourceFiles=len(manifest), evidenceFiles=len(files),
    sourceArchiveSha256=sha(out / 'source.zip'), evidenceArchiveSha256=sha(out / 'evidence.zip'),
    allPhysicalGatesPassed=False,
    qualification='Restricted cloth drape passes; rigid-soft and soft-soft reaction fail. No default/five-body or GPU qualification.')
(out / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf8')
print(json.dumps({k: summary[k] for k in ('checks', 'checksPassed', 'failedChecks', 'executionAuditPassed',
                                       'sourceFiles', 'evidenceFiles', 'productionSwitched')}, indent=2))
